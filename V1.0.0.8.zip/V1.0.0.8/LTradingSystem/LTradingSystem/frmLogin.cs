﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace VIPTradingSystem
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();

            try
            {
                //Bitmap bmp = Properties.Resources._16x16;
                //Icon ic = Icon.FromHandle(bmp.GetHicon());
                //this.Icon = ic;
            }
            catch (Exception ex)
            {
            }

        }


        private void frmLogin_Load(object sender, EventArgs e)
        {
            try
            {

                cmbBroker.SelectedIndex = 0;
                //if (Properties.Settings.Default.TestMode)
                //{
                //    this.BackColor = Color.Yellow;
                //    lblMode.Text = "測試版";
                //    lblMode.BackColor = Color.Crimson;
                //    lblMode.ForeColor  = Color.White ;
                //}
                //else
                //{
                //    lblMode.Text = "正式版";
                //    lblMode.BackColor = Color.White;
                //    lblMode.ForeColor = Color.Blue ;
                //}

                display_cmb_link_server();
                if (frmMain.UserConfigs.bolIDlogin)
                {
                    rdoID.Checked = true;
                    if (frmMain.UserConfigs.bolEnabledSave)
                        txtUserId.Text = frmMain.UserConfigs.LoginID;
                }
                else
                {
                    if (frmMain.UserConfigs.bolEnabledSave)
                        txtUserId.Text = frmMain.UserConfigs.LoginACNO;
                    rdoAC_NO.Checked = true;
                    cmbBroker.Enabled = true;
                    if (frmMain.UserConfigs.Company == "000")
                        cmbBroker.SelectedIndex = 0;
                    //else if (frmMain.UserConfigs.Company == "003")
                    //    cmbBroker.SelectedIndex = 1;
                }
                if (frmMain.UserConfigs.bolEnabledSavePW)
                    txtPassword.Text = frmMain.UserConfigs.PW;
                chkAccount.Checked = frmMain.UserConfigs.bolEnabledSave;
                chkPW.Checked = frmMain.UserConfigs.bolEnabledSavePW;
            }

            catch (Exception ex)
            {
                MYcls.DataAgent._LM.WriteLog("UIErrorLog", ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        /// <summary>
        /// 載入登入主機設定檔於連線主機下拉選單
        /// </summary>
        private void display_cmb_link_server()
        {
            try
            {

                DataTable dtLoginServerSet = frmMain.UserConfigs.LoginServerSet;
                //DataRow[] drNewData = dtLoginServerSet.Select("","sortno");

                //if (drNewData.Length > 0)
                //{
                //    foreach (DataRow dr in drNewData)
                //    {

                //        if (dr["ServerPort"].ToString().Trim() != "")
                //        {
                //            dr["ServerData"] = dr["ServerIP"].ToString().Trim() + ":" + dr["ServerPort"].ToString().Trim();
                //        }
                //        else
                //        {
                //            dr["ServerData"] = dr["ServerIP"].ToString().Trim();
                //        }
                //    }
                //}
                DataView dv = new DataView(dtLoginServerSet);
                dv.Sort = "IsDefault desc,sortno";
                cmb_link_server.DataSource = dv;
                cmb_link_server.DisplayMember = "ServerDsc";
                cmb_link_server.ValueMember = "ServerIP";
            }

            catch (Exception ex)
            {
                MYcls.DataAgent._LM.WriteLog("UIErrorLog", ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }

        }

        /// <summary>
        /// 取消
        /// </summary>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult = DialogResult.Cancel;
            }

            catch (Exception ex)
            {
                MYcls.DataAgent._LM.WriteLog("UIErrorLog", ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }

        /// <summary>
        /// 登入
        /// </summary>
        private void btnEnter_Click(object sender, EventArgs e)
        {
            try
            {
                if (rdoID.Checked)
                    frmMain.UserConfigs.Company = "";
                else
                {
                    if (cmbBroker.SelectedIndex == 0)
                        frmMain.UserConfigs.Company = "000";
                  
                }
                frmMain.UserConfigs.bolIDlogin = rdoID.Checked;
                frmMain.UserConfigs.bolEnabledSave = chkAccount.Checked;
                frmMain.UserConfigs.bolEnabledSavePW = chkPW.Checked;
                if (cmb_link_server.SelectedIndex == 0) //判斷登入正式機或備援機
                    frmMain.UserConfigs.MASTER = true;
                else
                    frmMain.UserConfigs.MASTER = false;
                string msg = frmMain.mobjDataAgent.login(cmb_link_server.SelectedValue.ToString(), txtUserId.Text, txtPassword.Text);
                if (msg == "")
                {

                    DialogResult = DialogResult.OK;

                }
                else
                {
                    VIPTradingSystem.MYcls.CommonFunction.ShowWarningMessageBox(this, msg);
                  
                }
            }
            catch (Exception ex)
            {
                
            }

        }

        private void rdoID_Click(object sender, EventArgs e)
        {
            try
            {
                if (rdoID.Checked)
                    cmbBroker.Enabled = false;
                else
                    cmbBroker.Enabled = true;
            }
            catch (Exception ex)
            {
                MYcls.DataAgent._LM.WriteLog("UIErrorLog", ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }


    }
}
