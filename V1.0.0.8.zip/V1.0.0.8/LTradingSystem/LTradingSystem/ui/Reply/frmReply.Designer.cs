﻿namespace VIPTradingSystem.ui.Reply
{
    partial class frmReply
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmReply));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.dgvReply = new com.ddsc.tool.window.DDSCDataGridView();
            this.dgvReplyDetail = new com.ddsc.tool.window.DDSCDataGridView();
            this.dgvMatchreply = new com.ddsc.tool.window.DDSCDataGridView();
            this.dgvMachTotal = new com.ddsc.tool.window.DDSCDataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnClearNet = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnFilter = new System.Windows.Forms.Button();
            this.txtMatchTime_ed = new System.Windows.Forms.TextBox();
            this.txtMatchTime_st = new System.Windows.Forms.TextBox();
            this.cmbAccountNet = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.btnUpdateProduct = new System.Windows.Forms.Button();
            this.btnUpdateNet = new System.Windows.Forms.Button();
            this.cmbAccount = new System.Windows.Forms.ComboBox();
            this.btnCancelAll = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnChange = new System.Windows.Forms.Button();
            this.txtOrderPrice = new System.Windows.Forms.TextBox();
            this.txtQty = new System.Windows.Forms.TextBox();
            this.btnQty500 = new System.Windows.Forms.Button();
            this.btnQty100 = new System.Windows.Forms.Button();
            this.btnQty10 = new System.Windows.Forms.Button();
            this.btnQty5 = new System.Windows.Forms.Button();
            this.btnQty1 = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvReply)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvReplyDetail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMatchreply)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMachTotal)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.Images.SetKeyName(0, "sign-out.ico");
            this.imageList1.Images.SetKeyName(1, "sign-in.ico");
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.panel2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 73F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1181, 684);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.splitContainer1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(3, 76);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1175, 605);
            this.panel2.TabIndex = 1;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.splitContainer2);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.dgvMachTotal);
            this.splitContainer1.Size = new System.Drawing.Size(1175, 605);
            this.splitContainer1.SplitterDistance = 474;
            this.splitContainer1.TabIndex = 1;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.splitContainer3);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.dgvMatchreply);
            this.splitContainer2.Size = new System.Drawing.Size(1175, 474);
            this.splitContainer2.SplitterDistance = 343;
            this.splitContainer2.TabIndex = 0;
            // 
            // splitContainer3
            // 
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.Location = new System.Drawing.Point(0, 0);
            this.splitContainer3.Name = "splitContainer3";
            this.splitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.dgvReply);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.dgvReplyDetail);
            this.splitContainer3.Size = new System.Drawing.Size(1175, 343);
            this.splitContainer3.SplitterDistance = 229;
            this.splitContainer3.TabIndex = 1;
            // 
            // dgvReply
            // 
            this.dgvReply.AllowUserToAddRows = false;
            this.dgvReply.AllowUserToDeleteRows = false;
            this.dgvReply.AllowUserToOrderColumns = true;
            this.dgvReply.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.PowderBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvReply.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvReply.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Bisque;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvReply.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvReply.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvReply.EnableHeadersVisualStyles = false;
            this.dgvReply.Location = new System.Drawing.Point(0, 0);
            this.dgvReply.MultiSelect = false;
            this.dgvReply.Name = "dgvReply";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.Bisque;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvReply.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvReply.RowHeadersVisible = false;
            this.dgvReply.RowTemplate.Height = 27;
            this.dgvReply.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvReply.Size = new System.Drawing.Size(1175, 229);
            this.dgvReply.TabIndex = 0;
            this.dgvReply.Tag = ((object)(resources.GetObject("dgvReply.Tag")));
            this.dgvReply.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvReply_CellDoubleClick);
            this.dgvReply.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvReply_CellValueChanged);
            this.dgvReply.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvReply_ColumnHeaderMouseClick);
            this.dgvReply.CurrentCellDirtyStateChanged += new System.EventHandler(this.dgvReply_CurrentCellDirtyStateChanged);
            this.dgvReply.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.dgvReply_RowsAdded);
            this.dgvReply.MouseClick += new System.Windows.Forms.MouseEventHandler(this.dgvReply_MouseClick);
            // 
            // dgvReplyDetail
            // 
            this.dgvReplyDetail.AllowUserToAddRows = false;
            this.dgvReplyDetail.AllowUserToDeleteRows = false;
            this.dgvReplyDetail.AllowUserToOrderColumns = true;
            this.dgvReplyDetail.AllowUserToResizeRows = false;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.PowderBlue;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvReplyDetail.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvReplyDetail.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.Bisque;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvReplyDetail.DefaultCellStyle = dataGridViewCellStyle5;
            this.dgvReplyDetail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvReplyDetail.EnableHeadersVisualStyles = false;
            this.dgvReplyDetail.Location = new System.Drawing.Point(0, 0);
            this.dgvReplyDetail.MultiSelect = false;
            this.dgvReplyDetail.Name = "dgvReplyDetail";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.Bisque;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvReplyDetail.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dgvReplyDetail.RowHeadersVisible = false;
            this.dgvReplyDetail.RowTemplate.Height = 27;
            this.dgvReplyDetail.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvReplyDetail.Size = new System.Drawing.Size(1175, 110);
            this.dgvReplyDetail.TabIndex = 1;
            this.dgvReplyDetail.Tag = ((object)(resources.GetObject("dgvReplyDetail.Tag")));
            this.dgvReplyDetail.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvReplyDetail_CellValueChanged);
            this.dgvReplyDetail.CurrentCellDirtyStateChanged += new System.EventHandler(this.dgvReplyDetail_CurrentCellDirtyStateChanged);
            // 
            // dgvMatchreply
            // 
            this.dgvMatchreply.AllowUserToAddRows = false;
            this.dgvMatchreply.AllowUserToDeleteRows = false;
            this.dgvMatchreply.AllowUserToOrderColumns = true;
            this.dgvMatchreply.AllowUserToResizeRows = false;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.PowderBlue;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvMatchreply.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dgvMatchreply.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.Bisque;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvMatchreply.DefaultCellStyle = dataGridViewCellStyle8;
            this.dgvMatchreply.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvMatchreply.EnableHeadersVisualStyles = false;
            this.dgvMatchreply.Location = new System.Drawing.Point(0, 0);
            this.dgvMatchreply.MultiSelect = false;
            this.dgvMatchreply.Name = "dgvMatchreply";
            this.dgvMatchreply.ReadOnly = true;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.Bisque;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvMatchreply.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.dgvMatchreply.RowHeadersVisible = false;
            this.dgvMatchreply.RowTemplate.Height = 27;
            this.dgvMatchreply.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvMatchreply.Size = new System.Drawing.Size(1175, 127);
            this.dgvMatchreply.TabIndex = 1;
            this.dgvMatchreply.Tag = ((object)(resources.GetObject("dgvMatchreply.Tag")));
            this.dgvMatchreply.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.dgvMatchreply_RowsAdded);
            // 
            // dgvMachTotal
            // 
            this.dgvMachTotal.AllowUserToAddRows = false;
            this.dgvMachTotal.AllowUserToDeleteRows = false;
            this.dgvMachTotal.AllowUserToOrderColumns = true;
            this.dgvMachTotal.AllowUserToResizeRows = false;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.PowderBlue;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvMachTotal.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.dgvMachTotal.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.Bisque;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvMachTotal.DefaultCellStyle = dataGridViewCellStyle11;
            this.dgvMachTotal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvMachTotal.EnableHeadersVisualStyles = false;
            this.dgvMachTotal.Location = new System.Drawing.Point(0, 0);
            this.dgvMachTotal.MultiSelect = false;
            this.dgvMachTotal.Name = "dgvMachTotal";
            this.dgvMachTotal.ReadOnly = true;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.Bisque;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvMachTotal.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.dgvMachTotal.RowHeadersVisible = false;
            this.dgvMachTotal.RowTemplate.Height = 27;
            this.dgvMachTotal.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvMachTotal.Size = new System.Drawing.Size(1175, 127);
            this.dgvMachTotal.TabIndex = 1;
            this.dgvMachTotal.Tag = ((object)(resources.GetObject("dgvMachTotal.Tag")));
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnClearNet);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.btnFilter);
            this.panel1.Controls.Add(this.txtMatchTime_ed);
            this.panel1.Controls.Add(this.txtMatchTime_st);
            this.panel1.Controls.Add(this.cmbAccountNet);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.btnUpdateProduct);
            this.panel1.Controls.Add(this.btnUpdateNet);
            this.panel1.Controls.Add(this.cmbAccount);
            this.panel1.Controls.Add(this.btnCancelAll);
            this.panel1.Controls.Add(this.btnCancel);
            this.panel1.Controls.Add(this.btnChange);
            this.panel1.Controls.Add(this.txtOrderPrice);
            this.panel1.Controls.Add(this.txtQty);
            this.panel1.Controls.Add(this.btnQty500);
            this.panel1.Controls.Add(this.btnQty100);
            this.panel1.Controls.Add(this.btnQty10);
            this.panel1.Controls.Add(this.btnQty5);
            this.panel1.Controls.Add(this.btnQty1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1175, 67);
            this.panel1.TabIndex = 0;
            // 
            // btnClearNet
            // 
            this.btnClearNet.Location = new System.Drawing.Point(786, 2);
            this.btnClearNet.Name = "btnClearNet";
            this.btnClearNet.Size = new System.Drawing.Size(83, 28);
            this.btnClearNet.TabIndex = 51;
            this.btnClearNet.Text = "Clear net";
            this.btnClearNet.UseVisualStyleBackColor = true;
            this.btnClearNet.Click += new System.EventHandler(this.btnClearNet_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(891, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(15, 15);
            this.label2.TabIndex = 50;
            this.label2.Text = "~";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(697, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 15);
            this.label1.TabIndex = 49;
            this.label1.Text = "MatchTime";
            // 
            // btnFilter
            // 
            this.btnFilter.Location = new System.Drawing.Point(1025, 34);
            this.btnFilter.Name = "btnFilter";
            this.btnFilter.Size = new System.Drawing.Size(67, 28);
            this.btnFilter.TabIndex = 48;
            this.btnFilter.Text = "Filter";
            this.btnFilter.UseVisualStyleBackColor = true;
            this.btnFilter.Click += new System.EventHandler(this.btnFilter_Click);
            // 
            // txtMatchTime_ed
            // 
            this.txtMatchTime_ed.Font = new System.Drawing.Font("新細明體", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtMatchTime_ed.Location = new System.Drawing.Point(912, 36);
            this.txtMatchTime_ed.Name = "txtMatchTime_ed";
            this.txtMatchTime_ed.Size = new System.Drawing.Size(107, 28);
            this.txtMatchTime_ed.TabIndex = 47;
            // 
            // txtMatchTime_st
            // 
            this.txtMatchTime_st.Font = new System.Drawing.Font("新細明體", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtMatchTime_st.Location = new System.Drawing.Point(776, 36);
            this.txtMatchTime_st.Name = "txtMatchTime_st";
            this.txtMatchTime_st.Size = new System.Drawing.Size(109, 28);
            this.txtMatchTime_st.TabIndex = 46;
            // 
            // cmbAccountNet
            // 
            this.cmbAccountNet.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAccountNet.FormattingEnabled = true;
            this.cmbAccountNet.Location = new System.Drawing.Point(597, 3);
            this.cmbAccountNet.Name = "cmbAccountNet";
            this.cmbAccountNet.Size = new System.Drawing.Size(100, 23);
            this.cmbAccountNet.TabIndex = 45;
            this.cmbAccountNet.Visible = false;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(247, 44);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 44;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnUpdateProduct
            // 
            this.btnUpdateProduct.Location = new System.Drawing.Point(987, 3);
            this.btnUpdateProduct.Name = "btnUpdateProduct";
            this.btnUpdateProduct.Size = new System.Drawing.Size(125, 25);
            this.btnUpdateProduct.TabIndex = 43;
            this.btnUpdateProduct.Text = "Update Product";
            this.btnUpdateProduct.UseVisualStyleBackColor = true;
            this.btnUpdateProduct.Visible = false;
            this.btnUpdateProduct.Click += new System.EventHandler(this.btnUpdateProduct_Click);
            // 
            // btnUpdateNet
            // 
            this.btnUpdateNet.Location = new System.Drawing.Point(700, 2);
            this.btnUpdateNet.Name = "btnUpdateNet";
            this.btnUpdateNet.Size = new System.Drawing.Size(82, 28);
            this.btnUpdateNet.TabIndex = 42;
            this.btnUpdateNet.Text = "Update net";
            this.btnUpdateNet.UseVisualStyleBackColor = true;
            this.btnUpdateNet.Click += new System.EventHandler(this.btnUpdateNet_Click);
            // 
            // cmbAccount
            // 
            this.cmbAccount.FormattingEnabled = true;
            this.cmbAccount.Location = new System.Drawing.Point(597, 28);
            this.cmbAccount.Name = "cmbAccount";
            this.cmbAccount.Size = new System.Drawing.Size(99, 23);
            this.cmbAccount.TabIndex = 41;
            this.cmbAccount.Visible = false;
            // 
            // btnCancelAll
            // 
            this.btnCancelAll.Location = new System.Drawing.Point(511, 9);
            this.btnCancelAll.Name = "btnCancelAll";
            this.btnCancelAll.Size = new System.Drawing.Size(80, 40);
            this.btnCancelAll.TabIndex = 40;
            this.btnCancelAll.Text = "CancelAll";
            this.btnCancelAll.UseVisualStyleBackColor = true;
            this.btnCancelAll.Click += new System.EventHandler(this.btnCancelAll_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(434, 9);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(71, 40);
            this.btnCancel.TabIndex = 39;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnChange
            // 
            this.btnChange.Location = new System.Drawing.Point(9, 9);
            this.btnChange.Name = "btnChange";
            this.btnChange.Size = new System.Drawing.Size(91, 58);
            this.btnChange.TabIndex = 38;
            this.btnChange.Text = "Change";
            this.btnChange.UseVisualStyleBackColor = true;
            this.btnChange.Click += new System.EventHandler(this.btnChange_Click);
            // 
            // txtOrderPrice
            // 
            this.txtOrderPrice.Font = new System.Drawing.Font("新細明體", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtOrderPrice.Location = new System.Drawing.Point(328, 9);
            this.txtOrderPrice.Name = "txtOrderPrice";
            this.txtOrderPrice.Size = new System.Drawing.Size(100, 28);
            this.txtOrderPrice.TabIndex = 37;
            this.txtOrderPrice.Text = "0";
            this.txtOrderPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtQty
            // 
            this.txtQty.Font = new System.Drawing.Font("新細明體", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtQty.Location = new System.Drawing.Point(222, 9);
            this.txtQty.Name = "txtQty";
            this.txtQty.Size = new System.Drawing.Size(100, 28);
            this.txtQty.TabIndex = 36;
            this.txtQty.Text = "0";
            this.txtQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnQty500
            // 
            this.btnQty500.Location = new System.Drawing.Point(161, 39);
            this.btnQty500.Name = "btnQty500";
            this.btnQty500.Size = new System.Drawing.Size(57, 28);
            this.btnQty500.TabIndex = 35;
            this.btnQty500.Text = "500";
            this.btnQty500.UseVisualStyleBackColor = true;
            this.btnQty500.Click += new System.EventHandler(this.btnQty_Click);
            // 
            // btnQty100
            // 
            this.btnQty100.Location = new System.Drawing.Point(104, 39);
            this.btnQty100.Name = "btnQty100";
            this.btnQty100.Size = new System.Drawing.Size(56, 28);
            this.btnQty100.TabIndex = 34;
            this.btnQty100.Text = "100";
            this.btnQty100.UseVisualStyleBackColor = true;
            this.btnQty100.Click += new System.EventHandler(this.btnQty_Click);
            // 
            // btnQty10
            // 
            this.btnQty10.Location = new System.Drawing.Point(177, 9);
            this.btnQty10.Name = "btnQty10";
            this.btnQty10.Size = new System.Drawing.Size(41, 28);
            this.btnQty10.TabIndex = 33;
            this.btnQty10.Text = "10";
            this.btnQty10.UseVisualStyleBackColor = true;
            this.btnQty10.Click += new System.EventHandler(this.btnQty_Click);
            // 
            // btnQty5
            // 
            this.btnQty5.Location = new System.Drawing.Point(140, 9);
            this.btnQty5.Name = "btnQty5";
            this.btnQty5.Size = new System.Drawing.Size(38, 28);
            this.btnQty5.TabIndex = 32;
            this.btnQty5.Text = "5";
            this.btnQty5.UseVisualStyleBackColor = true;
            this.btnQty5.Click += new System.EventHandler(this.btnQty_Click);
            // 
            // btnQty1
            // 
            this.btnQty1.Location = new System.Drawing.Point(104, 9);
            this.btnQty1.Name = "btnQty1";
            this.btnQty1.Size = new System.Drawing.Size(37, 28);
            this.btnQty1.TabIndex = 31;
            this.btnQty1.Text = "1";
            this.btnQty1.UseVisualStyleBackColor = true;
            this.btnQty1.Click += new System.EventHandler(this.btnQty_Click);
            // 
            // frmReply
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(120F, 120F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(1181, 684);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "frmReply";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "frmReply";
            this.Load += new System.EventHandler(this.frmReply_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvReply)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvReplyDetail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMatchreply)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMachTotal)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnCancelAll;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnChange;
        private System.Windows.Forms.TextBox txtOrderPrice;
        private System.Windows.Forms.TextBox txtQty;
        private System.Windows.Forms.Button btnQty500;
        private System.Windows.Forms.Button btnQty100;
        private System.Windows.Forms.Button btnQty10;
        private System.Windows.Forms.Button btnQty5;
        private System.Windows.Forms.Button btnQty1;
        private com.ddsc.tool.window.DDSCDataGridView dgvMachTotal;
        private com.ddsc.tool.window.DDSCDataGridView dgvMatchreply;
        private com.ddsc.tool.window.DDSCDataGridView dgvReply;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.Button btnUpdateProduct;
        private System.Windows.Forms.Button btnUpdateNet;
        private System.Windows.Forms.ComboBox cmbAccount;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox cmbAccountNet;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnFilter;
        private System.Windows.Forms.TextBox txtMatchTime_ed;
        private System.Windows.Forms.TextBox txtMatchTime_st;
        private System.Windows.Forms.Button btnClearNet;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private com.ddsc.tool.window.DDSCDataGridView dgvReplyDetail;
    }
}