﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using VIPTradingSystem.MYcls;
namespace VIPTradingSystem.ui.Reply
{
    public partial class frmReply : BaseForm
    {
        DataTable _MatchTotal;

        DataView dvReply = frmMain.mobjDataAgent.objTradeStringHandle.OrderReplyProvider.ReplyMain.DefaultView;
        DataView dvReplyDetail = frmMain.mobjDataAgent.objTradeStringHandle.OrderReplyProvider.OrderReply.DefaultView;

        public frmReply()
        {
            InitializeComponent();

            frmMain.mobjDataAgent.objTradeStringHandle.OrderReplyProvider.ReplyMain.RowChanged += new DataRowChangeEventHandler(OrderReply_RowChanged);
            dgvReply.DataSourceChanged += new EventHandler(dgvReply_DataSourceChanged);
            dgvReply.Sorted += new EventHandler(dgvReply_Sorted);
            dgvReply.RowTemplate.Height = 22;

            dgvMatchreply.RowTemplate.Height = 22;
            dgvMachTotal.RowTemplate.Height = 22;
            dgvMachTotal.DataSource = frmMain.mobjDataAgent.objTradeStringHandle.MatchTotalProvider.MatchTotal;
            dgvMatchreply.DataSource = frmMain.mobjDataAgent.objTradeStringHandle.MatchReplyProvider.TmpMatchDetailReply;
            dgvReply.Name = "dgvReply_ad";
            dgvReply.DataSource = dvReply;
            //  dgvReply.CellPainting += new DataGridViewCellPaintingEventHandler(dgvReply_CellPainting);
            dgvReply.CellMouseDown += new DataGridViewCellMouseEventHandler(dgvReply_CellMouseDown);

            SetReplyStyle(dgvReply);
            dgvReply.MouseClick += new MouseEventHandler(dgvReply_MouseClick);
            dgvReply.SelectionChanged += new EventHandler(dgvReply_SelectionChanged);
            SetMatchreplyStyle();
            dgvMatchreply.SelectionChanged += new EventHandler(dgvMatchreply_SelectionChanged);


            SetMatchTotalStyle();


            frmMain.mobjDataAgent.objTradeStringHandle.MatchReplyProvider.MatchDetailReply.DefaultView.Sort = "TRADEDATE asc,MATCHTIME asc";
            DataView dv = frmMain.mobjDataAgent.objTradeStringHandle.OrderReplyProvider.OrderReply.DefaultView;

            frmMain.mobjDataAgent.objTradeStringHandle.MatchReplyProvider.MatchDetailReply.DefaultView.ListChanged += new ListChangedEventHandler(DefaultView_MatchListChanged);



            byte[] bb = frmMain.mobjDataAgent.WS_LService.WS_AccountList();

            DataSet ds = CommonFunction.SerialUnZip(bb);

            if (ds.Tables.Count > 0)
            {
                DataRow dr = ds.Tables[0].NewRow();
                dr["account"] = "all";
                ds.Tables[0].Rows.InsertAt(dr, 0);
                this.cmbAccountNet.DataSource = ds.Tables[0];
                this.cmbAccountNet.ValueMember = "account";
                this.cmbAccountNet.DisplayMember = "account";
            }

            dgvReplyDetail.RowTemplate.Height = 22;
            dvReplyDetail.RowFilter = "seq_ad='' and seq=''";
            dgvReplyDetail.DataSource = dvReplyDetail;
            SetReplyDetailStyle(dgvReplyDetail);
        }







        private void frmReply_Load(object sender, EventArgs e)
        {
            dvReply.ListChanged += new ListChangedEventHandler(DefaultView_ListChanged);

             dvReply.Sort = " time asc,seq_ad asc,ORDERID asc ";
       
            SeqReset();
        }
        void dgvReply_DataSourceChanged(object sender, EventArgs e)
        {
            lock (frmMain.mobjDataAgent.objTradeStringHandle.OrderReplyProvider._locker)
            {
                SeqReset();
                dgvReply.Invalidate();
            }
        }

        void dgvReply_Sorted(object sender, EventArgs e)
        {
            lock (frmMain.mobjDataAgent.objTradeStringHandle.OrderReplyProvider._locker)
            {
                SeqReset();
                dgvReply.Invalidate();
            }
        }

        void OrderReply_RowChanged(object sender, DataRowChangeEventArgs e)
        {
            lock (frmMain.mobjDataAgent.objTradeStringHandle.OrderReplyProvider._locker)
            {

                SeqReset();
                //if (dgvReply.Rows.Count > 0)
                //    dgvReply.FirstDisplayedScrollingRowIndex = 0;

                try
                {

                    //if (dgvReply.CurrentCell.RowIndex > -1)
                    //{
                    //    int tmp = dgvReply.CurrentCell.RowIndex;
                    //    if (dgvReply.Rows.Count > (tmp + 1))
                    //    {
                    //        dgvReply.CurrentCell = dgvReply[dgvReply.CurrentCell.ColumnIndex, tmp + 1];
                    //    }
                    //    dgvReply.CurrentCell = dgvReply[dgvReply.CurrentCell.ColumnIndex, tmp];


                    //}
                }
                catch (Exception)
                {
                }
            }
            dgvReply.Invalidate();

        }

        void dgvReply_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            try
            {


                if (e.ColumnIndex == -1 && e.RowIndex > -1)
                {
                    lock (frmMain.mobjDataAgent.objTradeStringHandle.OrderReplyProvider._locker)
                    {
                        if (dgvReply.Rows[e.RowIndex].HeaderCell.Value.ToString().Split('.').Length == 1)
                        {

                            Rectangle rect = dgvReply.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, false);
                            rect.Width = 10;

                            Point pt = new Point(rect.Left + e.Location.X, rect.Top + e.Location.Y);
                            rect.X = rect.X + 13;
                            rect.Y = rect.Y + 3;
                            if (rect.IntersectsWith(new Rectangle(pt.X, pt.Y, 1, 1)))
                            {
                                dgvReply.CurrentCell = dgvReply.Rows[e.RowIndex].Cells[0];
                                string tag = "";
                                if (dgvReply.Rows[e.RowIndex].HeaderCell.Tag != null)
                                    tag = dgvReply.Rows[e.RowIndex].HeaderCell.Tag.ToString();

                                if (tag == "Y" || tag == "")
                                    tag = "N";
                                else
                                    tag = "Y";
                                dgvReply.Rows[e.RowIndex].HeaderCell.Tag = tag;
                                bool bolshow = tag == "Y" ? true : false;
                                if (dgvReply.Rows[e.RowIndex].Cells["SEQ_AD"].Value.ToString() != "")
                                {
                                    for (int i = e.RowIndex + 1; i < dgvReply.Rows.Count; i++)
                                    {
                                        if (dgvReply.Rows[i].Cells["ORDERKIND"].Value.ToString() == "P")
                                            break;
                                        string v = dgvReply.Rows[i].Cells["SEQ_AD"].Value.ToString();
                                        if (v == dgvReply.Rows[e.RowIndex].Cells["SEQ_AD"].Value.ToString())
                                        {
                                            dgvReply.Rows[i].Visible = bolshow;
                                        }
                                    }
                                    DataAgent._LM.WriteLog("UIEventLog", this.GetType().Name + " dgvReply_CellMouseDown " + dgvReply.Rows[e.RowIndex].Cells["SEQ_AD"].Value.ToString());
                                }
                            }
                        }

                    }

                }
            }

            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("UIErrorLog", this.GetType().Name
                       + " " + System.Reflection.MethodInfo.GetCurrentMethod().Name + " " + ex.Message);

            }
        }

        void dgvReply_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            try
            {

                if (e.ColumnIndex == -1 && e.RowIndex >= 0)
                {
                    Rectangle newRect = new Rectangle(e.CellBounds.X + 13,
                        e.CellBounds.Y + 3, 10,
                       10);
                    Color backcolor = e.CellStyle.BackColor;
                    if (e.RowIndex == dgvReply.CurrentRow.Index)
                        backcolor = e.CellStyle.SelectionBackColor;
                    using (
                        Brush gridBrush = new SolidBrush(this.dgvReply.GridColor),
                        backColorBrush = new SolidBrush(backcolor))
                    {
                        using (Pen gridLinePen = new Pen(gridBrush))
                        {
                            e.Graphics.FillRectangle(backColorBrush, e.CellBounds);
                            e.Graphics.DrawLine(gridLinePen, e.CellBounds.Left,
                                e.CellBounds.Bottom - 1, e.CellBounds.Right - 1,
                                e.CellBounds.Bottom - 1);
                            e.Graphics.DrawLine(gridLinePen, e.CellBounds.Right - 1,
                                e.CellBounds.Top, e.CellBounds.Right - 1,
                                e.CellBounds.Bottom);
                            bool bolParent = false;
                            if (e.Value.ToString().Split('.').Length == 1)
                                bolParent = true;
                            if (dgvReply.Rows[e.RowIndex].Cells["SEQ"].Value.ToString() != "" && dgvReply.Rows[e.RowIndex].Cells["ORDERKIND"].Value.ToString() == "P")
                            {
                                if (bolParent)
                                {
                                    e.Graphics.FillRectangle(Brushes.Ivory, newRect);
                                    e.Graphics.DrawRectangle(Pens.DimGray, newRect);
                                    e.Graphics.DrawLine(Pens.Gray, newRect.X, newRect.Y + newRect.Height / 2, newRect.X + newRect.Width, newRect.Y + newRect.Height / 2);
                                    if (dgvReply.Rows[e.RowIndex].HeaderCell.Tag == "N")
                                    {
                                        e.Graphics.DrawLine(Pens.Gray, newRect.X + newRect.Width / 2, newRect.Y, newRect.X + newRect.Width / 2, newRect.Y + newRect.Height);
                                    }
                                }
                                else
                                {
                                    e.Graphics.DrawLine(Pens.Gray, newRect.X + newRect.Width / 2, newRect.Y + newRect.Height / 2, newRect.X + newRect.Width, newRect.Y + newRect.Height / 2);
                                    e.Graphics.DrawLine(Pens.Gray, newRect.X + newRect.Width / 2, newRect.Y, newRect.X + newRect.Width / 2, newRect.Y + newRect.Height);
                                }

                            }
                            if (e.Value != null)
                            {
                                e.Graphics.DrawString((String)e.Value, e.CellStyle.Font,
                                    Brushes.Black, e.CellBounds.X + 25,
                                    e.CellBounds.Y + 3, StringFormat.GenericDefault);
                            }
                            e.Handled = true;
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("UIErrorLog", this.GetType().Name
                       + " " + System.Reflection.MethodInfo.GetCurrentMethod().Name + " " + ex.Message);

            }

        }

        void DefaultView_ListChanged(object sender, ListChangedEventArgs e)
        {
            try
            {
                lock (frmMain.mobjDataAgent.objTradeStringHandle.OrderReplyProvider._locker)
                {
                    DataView dv = (DataView)sender;
                    if (e.ListChangedType == ListChangedType.ItemDeleted)
                    {
                    }

                    if (e.ListChangedType == ListChangedType.ItemMoved)
                    {
                    }
                    if (e.ListChangedType == ListChangedType.ItemAdded || e.ListChangedType == ListChangedType.ItemMoved
                       || e.ListChangedType == ListChangedType.Reset)
                    {


                    }
                    if (e.ListChangedType == ListChangedType.ItemAdded)
                    {
                        // 
                    }
                    else if (e.ListChangedType == ListChangedType.Reset)
                    {
                        DataView mdv = frmMain.mobjDataAgent.objTradeStringHandle.MatchReplyProvider.TmpMatchDetailReply.DefaultView;
                        DataView ddv = frmMain.mobjDataAgent.objTradeStringHandle.MatchTotalProvider.MatchTotal.DefaultView;
                        Dictionary<string, string> mtag = (Dictionary<string, string>)dgvMatchreply.Tag;
                        mtag.Clear();


                        Dictionary<string, string> FilterList = (Dictionary<string, string>)dgvReply.Tag;
                        //grid column篩選時，以委託回報為主，成交回報篩選必須加上委託回報篩選條件再加上委託回報勾選資料
                        string filer = "";
                        string dfiler = "";
                        foreach (string k in FilterList.Keys)
                        {
                            if (k != "default")
                            {
                                string val = FilterList[k];
                                if (mdv.Table.Columns.Contains(k))
                                {

                                    filer += "AND " + val;
                                }
                                if (ddv.Table.Columns.Contains(k))
                                {

                                    dfiler += "AND " + val;
                                }
                            }
                        }

                        string RowFilter = "";

                        if (RowFilter.Length > 3)
                            RowFilter = RowFilter.Substring(3);



                        if (filer.Length > 3)
                        {
                            filer = filer.Substring(3);
                            mdv.RowFilter = "(" + filer + ")";

                            if (RowFilter.Length > 0)
                                mdv.RowFilter += " and " + RowFilter;

                            mtag["default"] = mdv.RowFilter;
                        }
                        else
                        {
                            mdv.RowFilter = "";

                            if (RowFilter.Length > 0)
                                mdv.RowFilter = RowFilter;
                            mtag["default"] = mdv.RowFilter;
                        }
                        if (dfiler.Length > 3)
                        {
                            dfiler = dfiler.Substring(3);
                            ddv.RowFilter = "(" + dfiler + ")";
                            //沒有書號
                            //if (RowFilter.Length > 0)
                            //    ddv.RowFilter += " and " + RowFilter;
                        }
                        else
                        {
                            ddv.RowFilter = "";

                        }
                        SeqReset();
                        //dgvReply_SelectionChanged(dgvReply, EventArgs.Empty);
                        dgvReply.Invalidate();
                    }

                }
            }

            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("UIErrorLog", this.GetType().Name
                       + " " + System.Reflection.MethodInfo.GetCurrentMethod().Name + " " + ex.Message);

            }
        }
        void DefaultView_MatchListChanged(object sender, ListChangedEventArgs e)
        {

        }
        private void SetReplyStyle(com.ddsc.tool.window.DDSCDataGridView dgvReply)
        {
            //  dgvReply.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            //  dgvReply.RowHeadersDefaultCellStyle.WrapMode = DataGridViewTriState.True;
            //  dgvReply.ColumnHeadersDefaultCellStyle.WrapMode = DataGridViewTriState.True;
            //  dgvReply.RowHeadersDefaultCellStyle.WrapMode = DataGridViewTriState.True;

            ////  dgvReply.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;

            //    dgvReply.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            dgvReply.RowHeadersVisible = true;
            dgvReply.RowHeadersWidth = 70;


            //   dgvReply.ColumnHeadersHeight = 40;
            // CommonFunction.SetColumnTextStyle(this.dgvReply, "time", "time", 100, true, true);


            //CommonFunction.SetColumnTextStyle(dgvReply, "group", "group", 100, true, true);
            // CommonFunction.SetColumnTextStyle(dgvReply, "MDATE", "MDATE", 100, true, true);


            CommonFunction.SetColumnCheckStyle(dgvReply, "check", 30, true, false,true);
            CommonFunction.SetColumnTextExStyle(dgvReply, "INVESTORACNO", "Account", 100, true, false);
            CommonFunction.SetColumnTextExStyle(dgvReply, "SECURITYEXCHANGE", "exchange ", 50, true, false);
            CommonFunction.SetColumnTextExStyle(dgvReply, "product", "product ", 50, true, false);
            CommonFunction.SetColumnTextExStyle(dgvReply, "contract", "contract ", 100, true, false);
            CommonFunction.SetColumnTextStyle(dgvReply, "STATUSCODE_DISPLAY", "state", 50, true, false);
            CommonFunction.SetColumnTextExStyle(dgvReply, "ORDERSTATUS_DISPLAY", "Status", 150, true, false);
            CommonFunction.SetColumnTextExStyle(dgvReply, "BS", "B/S", 50, true, false);

            CommonFunction.SetColumnTextExStyle(dgvReply, "ORDERQTY", "Order Qty", 50, true, false);

            CommonFunction.SetColumnTextStyle(dgvReply, "NOMATCHQTY", "Work Qty", 50, true, false);
            CommonFunction.SetColumnTextStyle(dgvReply, "UNDQTY", "Und Qty", 50, true, false);
            CommonFunction.SetColumnTextStyle(dgvReply, "MATCHQTY", "Filled Qty", 50, true, false);
            CommonFunction.SetColumnTextStyle(dgvReply, "DELQTY", "Del Qty", 50, true, false);
            CommonFunction.SetColumnTextStyle(dgvReply, "PRICE", "Price", 70, true, false);
            CommonFunction.SetColumnTextStyle(dgvReply, "AVGPRICE", "Avg Price", 70, true, false);
            CommonFunction.SetColumnTextStyle(dgvReply, "ORDERTYPE_DISPLAY", "Order Type", 50, true, false);

            CommonFunction.SetColumnTextStyle(dgvReply, "ADVANCED", "advanced", 100, true, false);
            CommonFunction.SetColumnTextStyle(dgvReply, "ORDERTIME_DISPLAY", "Order Time", 100, true, false);
            CommonFunction.SetColumnTextStyle(dgvReply, "ORDERNO", "Order No", 100, true, false);
            CommonFunction.SetColumnTextStyle(dgvReply, "AE", "AE", 100, true, false);
            CommonFunction.SetColumnTextStyle(dgvReply, "ORDERTAG", "Order Tag", 100, true, false);
            CommonFunction.SetColumnTextStyle(dgvReply, "SEQ_AD", "ParentKey", 100, true, false); //策略單 編號


            CommonFunction.SetColumnTextStyle(dgvReply, "ORDERID", "Order ID", 100, false, false);

            CommonFunction.SetColumnTextStyle(dgvReply, "CLORDID", "ClordID", 100, false, false);
            CommonFunction.SetColumnTextStyle(dgvReply, "TRADEDATE_DISPLAY", "Trade Date", 100, false, false);
            CommonFunction.SetColumnTextStyle(dgvReply, "TIMEINFORCE_DISPLAY", "TIF", 50, false, false);
            CommonFunction.SetColumnTextExStyle(dgvReply, "SEQ", "Seq", 100, false, false);



            CommonFunction.SetColumnTextStyle(dgvReply, "BROKERID", "Broker ID", 100, false, false);
            CommonFunction.SetColumnTextStyle(dgvReply, "OPENCLOSE_DISPLAY", "Open Close", 50, false, false);




            CommonFunction.SetColumnTextStyle(dgvReply, "STOPPRICE", "Stop Price", 70, false, false);


            CommonFunction.SetColumnTextStyle(dgvReply, "ORDERKIND", "", 0, false, false);
            //CommonFunction.SetColumnTextStyle(this.dgvReply, "SOURCECODE", "", 100, false, false);

            //CommonFunction.SetColumnTextStyle(this.dgvReply, "TARGETID", "", 100, false, false);
            //CommonFunction.SetColumnTextStyle(this.dgvReply, "ACCOUNT", "", 100, false, false);
            //CommonFunction.SetColumnTextStyle(this.dgvReply, "EXPIREDATE", "", 100, false, false);


            //CommonFunction.SetColumnTextStyle(this.dgvReply, "DTRADE", 100, true, true);
            //CommonFunction.SetColumnTextStyle(this.dgvReply, "IP", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvReply, "PRODUCTKIND", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvReply, "SECURITYTYPE1", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvReply, "SYMBOL1", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvReply, "MATURITYMONTHYEAR1", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvReply, "PUTORCALL1", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvReply, "STRIKEPRICE1", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvReply, "SIDE1", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvReply, "SECURITYTYPE2", 15, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvReply, "SYMBOL2", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvReply, "MATURITYMONTHYEAR2", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvReply, "PUTORCALL2", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvReply, "STRIKEPRICE2", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvReply, "SIDE2", 100, false, true);

        }

        private void SetReplyDetailStyle(com.ddsc.tool.window.DDSCDataGridView dgvReply)
        {
            //  dgvReply.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            //  dgvReply.RowHeadersDefaultCellStyle.WrapMode = DataGridViewTriState.True;
            //  dgvReply.ColumnHeadersDefaultCellStyle.WrapMode = DataGridViewTriState.True;
            //  dgvReply.RowHeadersDefaultCellStyle.WrapMode = DataGridViewTriState.True;

            ////  dgvReply.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;

            //    dgvReply.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            //dgvReply.RowHeadersVisible = true;
            //dgvReply.RowHeadersWidth = 70;


            //   dgvReply.ColumnHeadersHeight = 40;
            // CommonFunction.SetColumnTextStyle(this.dgvReply, "time", "time", 100, true, true);


            //CommonFunction.SetColumnTextStyle(dgvReply, "group", "group", 100, true, true);
            // CommonFunction.SetColumnTextStyle(dgvReply, "MDATE", "MDATE", 100, true, true);


            CommonFunction.SetColumnCheckStyle(dgvReply, "check", 30, true, false,false);
            CommonFunction.SetColumnTextStyle(dgvReply, "INVESTORACNO", "Account", 100, true, false);
            CommonFunction.SetColumnTextStyle(dgvReply, "SECURITYEXCHANGE", "exchange ", 50, true, false);
            CommonFunction.SetColumnTextStyle(dgvReply, "product", "product ", 50, true, false);
            CommonFunction.SetColumnTextStyle(dgvReply, "contract", "contract ", 100, true, false);
            CommonFunction.SetColumnTextStyle(dgvReply, "STATUSCODE_DISPLAY", "state", 50, true, false);
            CommonFunction.SetColumnTextStyle(dgvReply, "ORDERSTATUS_DISPLAY", "Status", 150, true, false);
            CommonFunction.SetColumnTextStyle(dgvReply, "BS", "B/S", 50, true, false);

            CommonFunction.SetColumnTextStyle(dgvReply, "ORDERQTY", "Order Qty", 50, true, false);

            CommonFunction.SetColumnTextStyle(dgvReply, "NOMATCHQTY", "Work Qty", 50, true, false);
            CommonFunction.SetColumnTextStyle(dgvReply, "UNDQTY", "Und Qty", 50, true, false);
            CommonFunction.SetColumnTextStyle(dgvReply, "MATCHQTY", "Filled Qty", 50, true, false);
            CommonFunction.SetColumnTextStyle(dgvReply, "DELQTY", "Del Qty", 50, true, false);
            CommonFunction.SetColumnTextStyle(dgvReply, "PRICE", "Price", 70, true, false);
            CommonFunction.SetColumnTextStyle(dgvReply, "AVGPRICE", "Avg Price", 70, true, false);
            CommonFunction.SetColumnTextStyle(dgvReply, "ORDERTYPE_DISPLAY", "Order Type", 50, true, false);

            CommonFunction.SetColumnTextStyle(dgvReply, "ADVANCED", "advanced", 100, true, false);
            CommonFunction.SetColumnTextStyle(dgvReply, "ORDERTIME_DISPLAY", "Order Time", 100, true, false);
            CommonFunction.SetColumnTextStyle(dgvReply, "ORDERNO", "Order No", 100, true, false);
            CommonFunction.SetColumnTextStyle(dgvReply, "AE", "AE", 100, true, false);
            CommonFunction.SetColumnTextStyle(dgvReply, "ORDERTAG", "Order Tag", 100, true, false);
            CommonFunction.SetColumnTextStyle(dgvReply, "SEQ_AD", "ParentKey", 100, true, false); //策略單 編號


            CommonFunction.SetColumnTextStyle(dgvReply, "ORDERID", "Order ID", 100, false, false);

            CommonFunction.SetColumnTextStyle(dgvReply, "CLORDID", "ClordID", 100, false, false);
            CommonFunction.SetColumnTextStyle(dgvReply, "TRADEDATE_DISPLAY", "Trade Date", 100, false, false);
            CommonFunction.SetColumnTextStyle(dgvReply, "TIMEINFORCE_DISPLAY", "TIF", 50, false, false);
            CommonFunction.SetColumnTextExStyle(dgvReply, "SEQ", "Seq", 100, false, false);



            CommonFunction.SetColumnTextStyle(dgvReply, "BROKERID", "Broker ID", 100, false, false);
            CommonFunction.SetColumnTextStyle(dgvReply, "OPENCLOSE_DISPLAY", "Open Close", 50, false, false);




            CommonFunction.SetColumnTextStyle(dgvReply, "STOPPRICE", "Stop Price", 70, false, false);


            CommonFunction.SetColumnTextStyle(dgvReply, "ORDERKIND", "", 0, false, false);
            //CommonFunction.SetColumnTextStyle(this.dgvReply, "SOURCECODE", "", 100, false, false);

            //CommonFunction.SetColumnTextStyle(this.dgvReply, "TARGETID", "", 100, false, false);
            //CommonFunction.SetColumnTextStyle(this.dgvReply, "ACCOUNT", "", 100, false, false);
            //CommonFunction.SetColumnTextStyle(this.dgvReply, "EXPIREDATE", "", 100, false, false);


            //CommonFunction.SetColumnTextStyle(this.dgvReply, "DTRADE", 100, true, true);
            //CommonFunction.SetColumnTextStyle(this.dgvReply, "IP", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvReply, "PRODUCTKIND", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvReply, "SECURITYTYPE1", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvReply, "SYMBOL1", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvReply, "MATURITYMONTHYEAR1", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvReply, "PUTORCALL1", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvReply, "STRIKEPRICE1", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvReply, "SIDE1", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvReply, "SECURITYTYPE2", 15, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvReply, "SYMBOL2", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvReply, "MATURITYMONTHYEAR2", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvReply, "PUTORCALL2", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvReply, "STRIKEPRICE2", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvReply, "SIDE2", 100, false, true);

        }
        private void SetMatchreplyStyle()
        {
            CommonFunction.SetColumnTextStyle(this.dgvMatchreply, "INVESTORACNO", "Account", 100, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvMatchreply, "SECURITYEXCHANGE", "exchange", 50, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvMatchreply, "product", "product", 50, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvMatchreply, "contract", "contract", 100, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvMatchreply, "BS", "B/S", 50, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvMatchreply, "MATCHQTY", "Qty", 50, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvMatchreply, "MATCHPRICE", "Price", 70, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvMatchreply, "STATE", "state", 50, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvMatchreply, "MATCHTIME_DISPLAY", "Match Time", 100, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvMatchreply, "ORDERNO", "Order No", 100, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvMatchreply, "AE", "AE", 100, true, true);
            //CommonFunction.SetColumnTextExStyle(this.dgvMatchreply, "OPENCLOSE", "Open Close", 50, true, true);

            CommonFunction.SetColumnTextStyle(this.dgvMatchreply, "ORDERTAG", "Order Tag", 100, true, true);



            CommonFunction.SetColumnTextStyle(this.dgvMatchreply, "BROKERID", "Broker ID", 100, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvMatchreply, "TRADEDATE_DISPLAY", "Trade Date", 100, true, true);


            CommonFunction.SetColumnTextStyle(this.dgvMatchreply, "CLORDID", "CLORDID", 100, false, true);
            CommonFunction.SetColumnTextStyle(this.dgvMatchreply, "EXECID", "Exec ID", 100, false, true);
            CommonFunction.SetColumnTextStyle(this.dgvMatchreply, "PSEQ", "ParentKey", 100, false, true); //策略單 編號
            // CommonFunction.SetColumnTextStyle(this.dgvMatchreply, "MDATE", "MDATE", 100, true, true);



            //CommonFunction.SetColumnTextStyle(this.dgvMatchreply, "ORDERID", "ORDERID", 100, true, true);
            //CommonFunction.SetColumnTextStyle(this.dgvMatchreply, "TARGETID", "TARGETID", 100, true, true);
            //CommonFunction.SetColumnTextStyle(this.dgvMatchreply, "ACCOUNT", "ACCOUNT", 100, true, true);




            //CommonFunction.SetColumnTextStyle(this.dgvMatchreply, "PRODUCTKIND", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvMatchreply, "SECURITYTYPE1", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvMatchreply, "SYMBOL1", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvMatchreply, "MATURITYMONTHYEAR1", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvMatchreply, "PUTORCALL1", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvMatchreply, "STRIKEPRICE1", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvMatchreply, "SIDE1", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvMatchreply, "PRICE1", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvMatchreply, "SECURITYTYPE2", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvMatchreply, "SYMBOL2", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvMatchreply, "MATURITYMONTHYEAR2", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvMatchreply, "PUTORCALL2", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvMatchreply, "STRIKEPRICE2", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvMatchreply, "SIDE2", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvMatchreply, "PRICE2", 100, false, true);
        }

        private void SetMatchTotalStyle()
        {


            CommonFunction.SetColumnTextStyle(this.dgvMachTotal, "INVESTORACNO", "Account", 100, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvMachTotal, "SECURITYEXCHANGE", "exchange", 50, true, true);

            CommonFunction.SetColumnTextStyle(this.dgvMachTotal, "product", "product", 50, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvMachTotal, "contract", "contract", 100, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvMachTotal, "BQty", "Buy Qty", 50, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvMachTotal, "SQty", "Sell Qty", 50, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvMachTotal, "TotalQty", "Total Qty", 50, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvMachTotal, "NetPost", "Net Pos", 50, true, true);

            CommonFunction.SetColumnTextStyle(this.dgvMachTotal, "WrkBuy", "Wrk Buy", 50, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvMachTotal, "WrkSell", "Wrk Sell", 50, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvMachTotal, "AvgBuyPrice", "Avg Buy Price", 110, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvMachTotal, "AvgSellPrice", "Avg Sell Price", 110, true, true);

            // dgvMachTotal.Columns["AvgBuyPrice"].DefaultCellStyle.Format = "0.########";

            CommonFunction.SetColumnTextStyle(this.dgvMachTotal, "BROKERID", "Broker ID", 100, true, true);

            //     CommonFunction.SetColumnTextExStyle(this.dgvMachTotal, "SUBACT", "AE", 100, true, true);


            //CommonFunction.SetColumnTextStyle(this.dgvMachTotal, "SECURITYTYPE1", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvMachTotal, "SYMBOL1", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvMachTotal, "MATURITYMONTHYEAR1", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvMachTotal, "PUTORCALL1", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvMachTotal, "STRIKEPRICE1", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvMachTotal, "SIDE1", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvMachTotal, "SECURITYTYPE2", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvMachTotal, "SYMBOL2", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvMachTotal, "MATURITYMONTHYEAR2", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvMachTotal, "PUTORCALL2", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvMachTotal, "STRIKEPRICE2", 100, false, true);
            //CommonFunction.SetColumnTextStyle(this.dgvMachTotal, "SIDE2", 100, false, true);


        }

        void dgvReply_SelectionChanged(object sender, EventArgs e)
        {
            DataView dv = dvReply;
            if (this.dgvReply.CurrentRow == null) return;
            if (this.dgvReply.CurrentRow.Index > -1)
            {
                DataRowView dvr = dv[dgvReply.CurrentCell.RowIndex];

                dvReplyDetail.RowFilter = "seq_ad='" + dvr["seq_ad"].ToString() + "' and  seq=''     ";
            }
        }


        void dgvReply_MouseClick(object sender, MouseEventArgs e)
        {
            try
            {


                if (this.dgvReply.CurrentRow == null) return;
                if (this.dgvReply.CurrentRow.Index > -1)
                {
                    lock (frmMain.mobjDataAgent.objTradeStringHandle.OrderReplyProvider._locker)
                    {
                        DataView dv = dvReply;

                        DataRowView dvr = dv[dgvReply.CurrentCell.RowIndex];

                        if (dvr["ORDERKIND"].ToString() == "P") { txtQty.Enabled = false; }
                        else
                            txtQty.Enabled = true;
                        //if (int.Parse(dvr["NOMATCHQTY"].ToString()) > 0)
                        //{
                        this.txtQty.Text = dvr["NOMATCHQTY"].ToString();
                        this.txtOrderPrice.Text = dvr["PRICE"].ToString();
                        //}

                        cmbAccount.Text = dvr["INVESTORACNO"].ToString();
                        DataAgent._LM.WriteLog("UIEventLog", this.GetType().Name + " Selection:" + this.dgvReply.CurrentRow.Index.ToString() + " " +

                          this.txtQty.Text + " " + this.txtOrderPrice.Text + " " + cmbAccount.Text + " " + dvr["seq_ad"].ToString());

                        //      dvReplyDetail.RowFilter = "seq_ad='" + dvr["seq_ad"].ToString() + "' and  seq=''     ";

                    }
                }
            }

            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("UIErrorLog", this.GetType().Name
                       + " " + System.Reflection.MethodInfo.GetCurrentMethod().Name + " " + ex.Message);

            }
        }


        void dgvMatchreply_SelectionChanged(object sender, EventArgs e)
        {
            if (this.dgvMatchreply.CurrentRow == null) return;
            if (this.dgvMatchreply.CurrentRow.Index > -1)
            {
            }
        }



        private void SeqReset()
        {

            DataView dv = frmMain.mobjDataAgent.objTradeStringHandle.OrderReplyProvider.ReplyMain.DefaultView;
            int seq = 0;
            int group = 0;
            bool bolsame = false;
            for (int i = 0; i < dgvReply.Rows.Count; i++)
            {
                bool checkflag= (bool)dvReply[i]["checkflag"];
                dgvReply.Rows[i].HeaderCell.Value =(checkflag?"*":"")+ (i + 1).ToString() ;
                if ( dvReply[i]["ORDERKIND"].ToString() == "P")
                {
                    dgvReply.Rows[i].HeaderCell.Value += "+";
                }
                //if (i > 0)
                //{
                //    if (dv[i]["SEQ_AD"].ToString().Trim() != "")
                //    {
                //        if (dv[i]["SEQ_AD"].ToString() == dv[i - 1]["SEQ_AD"].ToString())
                //        {
                //            bolsame = true;
                //        }
                //        else
                //        {
                //            bolsame = false;
                //        }
                //    }
                //}
                //if (!bolsame)
                //{
                //    seq = 0;
                //    group++;
                //}
                //else
                //    seq++;
                //if (dv[i]["SEQ"].ToString().Trim() == "" && dv[i]["SEQ_AD"].ToString().Trim() != "")//子單序號
                //    dgvReply.Rows[i].HeaderCell.Value = group.ToString() + "." + seq.ToString();
                //else if (dv[i]["ORDERKIND"].ToString().Trim() == "P")
                //    dgvReply.Rows[i].HeaderCell.Value = " " + group.ToString();
                //else
                //    dgvReply.Rows[i].HeaderCell.Value = group.ToString();

            }
        }


        private void btnChange_Click(object sender, EventArgs e)
        {

            if (this.txtQty.Text.Trim().Length == 0 || this.txtOrderPrice.Text.Trim().Length == 0)
            {
                MessageBox.Show("改單條件不得為空白!");
                return;
            }
            if (this.txtQty.Text.Trim() == "0")
            {
                MessageBox.Show("改單條件口數不得為０!");
                return;
            }
            DataAgent._LM.WriteLog("UIEventLog", this.GetType().Name + "Change ");
            Order(OrderType.Replace);


        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (this.txtQty.Text.Trim().Length == 0 || this.txtOrderPrice.Text.Trim().Length == 0)
            {
                MessageBox.Show("未點選欲cancel之委託單!");
                return;
            }




            DataAgent._LM.WriteLog("UIEventLog", this.GetType().Name + "Cancel ");
            Order(OrderType.Cancel);
        }

        private void OrderStrategy(string pEXECTYPE)
        {
            try
            {
                DataView dv = dvReply;
                DataRowView dvr = dv[this.dgvReply.CurrentRow.Index];
                string PRODUCTKIND = dvr["PRODUCTKIND"].ToString();
                string EXECTYPE = pEXECTYPE;
                string BROKERID = dvr["BROKERID"].ToString();
                string ORDERNO = dvr["ORDERNO"].ToString();
                string INVESTORACNO = dvr["INVESTORACNO"].ToString();
                string SUBACT = dvr["SUBACT"].ToString();
                string SECURITYEXCHANGE = dvr["SECURITYEXCHANGE"].ToString();
                string SECURITYTYPE1 = dvr["SECURITYTYPE1"].ToString();
                string SYMBOL1 = dvr["SYMBOL1"].ToString(); ;
                string MATURITYMONTHYEAR1 = dvr["MATURITYMONTHYEAR1"].ToString(); ;
                string PUTORCALL1 = dvr["PUTORCALL1"].ToString(); ;
                decimal STRIKEPRICE1 = decimal.Parse(dvr["STRIKEPRICE1"].ToString()); ;
                string SIDE1 = dvr["SIDE1"].ToString(); ;
                string SECURITYTYPE2 = dvr["SECURITYTYPE2"].ToString(); ;
                string SYMBOL2 = dvr["SYMBOL2"].ToString(); ;
                string MATURITYMONTHYEAR2 = dvr["MATURITYMONTHYEAR2"].ToString(); ;
                string PUTORCALL2 = dvr["PUTORCALL2"].ToString(); ;
                decimal STRIKEPRICE2 = decimal.Parse(dvr["STRIKEPRICE2"].ToString()); ;
                string SIDE2 = dvr["SIDE2"].ToString(); ;
                string BS = dvr["BS"].ToString(); ;
                string ORDERTYPE = dvr["ORDERTYPE"].ToString(); ;
                decimal PRICE = decimal.Parse(txtOrderPrice.Text);//decimal.Parse(dvr["PRICE"].ToString());
                decimal STOPPRICE = decimal.Parse(dvr["STOPPRICE"].ToString());


                int ORDERQTY = int.Parse(dvr["ORDERQTY"].ToString());
                string TIMEINFORCE = dvr["TIMEINFORCE"].ToString();
                string OPENCLOSE = dvr["OPENCLOSE"].ToString();
                string DTRADE = dvr["DTRADE"].ToString();
                string CLORDID = dvr["CLORDID"].ToString();
                string EXPIREDATE = dvr["EXPIREDATE"].ToString();
                string SOURCECODE = "l";
                string KEEPDATA = dvr["KEEPDATA"].ToString(); ;


                string ret = frmMain.mobjDataAgent.objTradeStringHandle.sendOrderStrategy(PRODUCTKIND
                 , EXECTYPE
                 , BROKERID
                 , ORDERNO
                 , INVESTORACNO
                 , SUBACT
                 , SECURITYEXCHANGE
                 , SECURITYTYPE1
                 , SYMBOL1
                 , MATURITYMONTHYEAR1
                 , PUTORCALL1
                 , STRIKEPRICE1
                 , SIDE1
                 , SECURITYTYPE2
                 , SYMBOL2
                 , MATURITYMONTHYEAR2
                 , PUTORCALL2
                 , STRIKEPRICE2
                 , SIDE2
                 , BS
                 , ORDERTYPE
                 , PRICE
                 , STOPPRICE
                 , ORDERQTY
                 , TIMEINFORCE
                 , OPENCLOSE
                 , DTRADE
                 , CLORDID
                 , EXPIREDATE
                 , SOURCECODE, KEEPDATA);

                DataAgent._LM.WriteLog("UIEventLog", this.GetType().Name + "OrderStrategy change " + ret);

            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("UIErrorLog", this.GetType().Name
                           + " " + System.Reflection.MethodInfo.GetCurrentMethod().Name + " " + ex.Message);
            }
        }




        private void Order(string exec)
        {
            if (this.dgvReply.CurrentRow.Index > -1)
            {

                DataView dv = dvReply;

                DataRowView dvr = dv[this.dgvReply.CurrentRow.Index];
                if (dvr["ORDERKIND"].ToString() == "P")
                {
                    if (exec == OrderType.Cancel)
                    {
                        OrderStrategy("4");
                        CancelByParent(dvr["SEQ_AD"].ToString()); return;
                    }
                    else if (exec == OrderType.Replace)
                    { OrderStrategy("5"); return; }
                }
                string PRODUCTKIND = dvr["PRODUCTKIND"].ToString();
                string EXECTYPE = exec;
                string BROKERID = dvr["BROKERID"].ToString();
                string ORDERNO = dvr["ORDERNO"].ToString();
                string INVESTORACNO = dvr["INVESTORACNO"].ToString();
                string SUBACT = dvr["SUBACT"].ToString();
                string SECURITYEXCHANGE = dvr["SECURITYEXCHANGE"].ToString();
                string SECURITYTYPE1 = dvr["SECURITYTYPE1"].ToString();
                string SYMBOL1 = dvr["SYMBOL1"].ToString(); ;
                string MATURITYMONTHYEAR1 = dvr["MATURITYMONTHYEAR1"].ToString(); ;
                string PUTORCALL1 = dvr["PUTORCALL1"].ToString(); ;
                decimal STRIKEPRICE1 = decimal.Parse(dvr["STRIKEPRICE1"].ToString()); ;
                string SIDE1 = dvr["SIDE1"].ToString(); ;
                string SECURITYTYPE2 = dvr["SECURITYTYPE2"].ToString(); ;
                string SYMBOL2 = dvr["SYMBOL2"].ToString(); ;
                string MATURITYMONTHYEAR2 = dvr["MATURITYMONTHYEAR2"].ToString(); ;
                string PUTORCALL2 = dvr["PUTORCALL2"].ToString(); ;
                decimal STRIKEPRICE2 = decimal.Parse(dvr["STRIKEPRICE2"].ToString()); ;
                string SIDE2 = dvr["SIDE2"].ToString(); ;
                string BS = dvr["BS"].ToString(); ;
                string ORDERTYPE = dvr["ORDERTYPE"].ToString(); ;
                decimal PRICE = decimal.Parse(txtOrderPrice.Text);//decimal.Parse(dvr["PRICE"].ToString());
                decimal STOPPRICE = decimal.Parse(dvr["STOPPRICE"].ToString());


                int ORDERQTY = int.Parse(txtQty.Text);//int.Parse(dvr["ORDERQTY"].ToString());
                string TIMEINFORCE = dvr["TIMEINFORCE"].ToString();
                string OPENCLOSE = dvr["OPENCLOSE"].ToString();
                string DTRADE = dvr["DTRADE"].ToString();
                string CLORDID = dvr["CLORDID"].ToString();
                string EXPIREDATE = dvr["EXPIREDATE"].ToString();
                string SOURCECODE = "l";
                string KEEPDATA = dvr["KEEPDATA"].ToString(); ;
                string ret = frmMain.mobjDataAgent.objTradeStringHandle.sendOrder(PRODUCTKIND
                   , EXECTYPE
                   , BROKERID
                   , ORDERNO
                   , INVESTORACNO
                   , SUBACT
                   , SECURITYEXCHANGE
                   , SECURITYTYPE1
                   , SYMBOL1
                   , MATURITYMONTHYEAR1
                   , PUTORCALL1
                   , STRIKEPRICE1
                   , SIDE1
                   , SECURITYTYPE2
                   , SYMBOL2
                   , MATURITYMONTHYEAR2
                   , PUTORCALL2
                   , STRIKEPRICE2
                   , SIDE2
                   , BS
                   , ORDERTYPE
                   , PRICE
                   , STOPPRICE
                   , ORDERQTY
                   , TIMEINFORCE
                   , OPENCLOSE
                   , DTRADE
                   , CLORDID
                   , EXPIREDATE
                   , SOURCECODE, KEEPDATA);

                this.txtQty.Text = "";
                this.txtOrderPrice.Text = "";
                cmbAccount.Text = "";
                DataAgent._LM.WriteLog("UIEventLog", this.GetType().Name + "Order  exec: " + exec + " " + ret);
            }
        }

        private void CancelByParent(string seq)
        {
            DataRow[] drs = frmMain.mobjDataAgent.objTradeStringHandle.OrderReplyProvider.GetNoWorkDataByParent(seq);
            if (drs == null) return;
            for (int i = 0; i < drs.Length; i++)
            {
                DataRow dr = drs[i];
                string PRODUCTKIND = dr["PRODUCTKIND"].ToString();
                string EXECTYPE = OrderType.Cancel;
                string BROKERID = dr["BROKERID"].ToString();
                string ORDERNO = dr["ORDERNO"].ToString();
                string INVESTORACNO = dr["INVESTORACNO"].ToString();
                string SUBACT = dr["SUBACT"].ToString();
                string SECURITYEXCHANGE = dr["SECURITYEXCHANGE"].ToString();
                string SECURITYTYPE1 = dr["SECURITYTYPE1"].ToString();
                string SYMBOL1 = dr["SYMBOL1"].ToString(); ;
                string MATURITYMONTHYEAR1 = dr["MATURITYMONTHYEAR1"].ToString(); ;
                string PUTORCALL1 = dr["PUTORCALL1"].ToString(); ;
                decimal STRIKEPRICE1 = decimal.Parse(dr["STRIKEPRICE1"].ToString()); ;
                string SIDE1 = dr["SIDE1"].ToString(); ;
                string SECURITYTYPE2 = dr["SECURITYTYPE2"].ToString(); ;
                string SYMBOL2 = dr["SYMBOL2"].ToString(); ;
                string MATURITYMONTHYEAR2 = dr["MATURITYMONTHYEAR2"].ToString(); ;
                string PUTORCALL2 = dr["PUTORCALL2"].ToString(); ;
                decimal STRIKEPRICE2 = decimal.Parse(dr["STRIKEPRICE2"].ToString()); ;
                string SIDE2 = dr["SIDE2"].ToString(); ;
                string BS = dr["BS"].ToString(); ;
                string ORDERTYPE = dr["ORDERTYPE"].ToString(); ;
                decimal PRICE = decimal.Parse(dr["PRICE"].ToString());
                decimal STOPPRICE = decimal.Parse(dr["STOPPRICE"].ToString());


                int ORDERQTY = int.Parse(dr["ORDERQTY"].ToString());
                string TIMEINFORCE = dr["TIMEINFORCE"].ToString();
                string OPENCLOSE = dr["OPENCLOSE"].ToString();
                string DTRADE = dr["DTRADE"].ToString();
                string CLORDID = dr["CLORDID"].ToString();
                string EXPIREDATE = dr["EXPIREDATE"].ToString();
                string SOURCECODE = "d";
                string KEEPDATA = dr["KEEPDATA"].ToString(); ;
                string ret = frmMain.mobjDataAgent.objTradeStringHandle.sendOrder(PRODUCTKIND
                 , EXECTYPE
                 , BROKERID
                 , ORDERNO
                 , INVESTORACNO
                 , SUBACT
                 , SECURITYEXCHANGE
                 , SECURITYTYPE1
                 , SYMBOL1
                 , MATURITYMONTHYEAR1
                 , PUTORCALL1
                 , STRIKEPRICE1
                 , SIDE1
                 , SECURITYTYPE2
                 , SYMBOL2
                 , MATURITYMONTHYEAR2
                 , PUTORCALL2
                 , STRIKEPRICE2
                 , SIDE2
                 , BS
                 , ORDERTYPE
                 , PRICE
                 , STOPPRICE
                 , ORDERQTY
                 , TIMEINFORCE
                 , OPENCLOSE
                 , DTRADE
                 , CLORDID
                 , EXPIREDATE
                 , SOURCECODE, KEEPDATA);
                DataAgent._LM.WriteLog("UIEventLog", this.GetType().Name + "CancelByParent  Cancel " + ret);
            }

        }

        private void btnQty_Click(object sender, EventArgs e)
        {
            try
            {
                TextBox obj = (TextBox)this.txtQty;
                Button srcobj = (Button)sender;
                decimal qty = 0;

                if (decimal.TryParse(obj.Text, out qty))
                {
                    this.txtQty.Text = (qty + decimal.Parse(srcobj.Text)).ToString("#");
                }
            }
            catch (Exception ex)
            {
                this.txtQty.Text = "0";
            }
        }
        private void btnCancelAll_Click(object sender, EventArgs e)
        {
            try
            {
                lock (frmMain.mobjDataAgent.objTradeStringHandle.OrderReplyProvider._locker)
                {
                    DataRow[] drs = frmMain.mobjDataAgent.objTradeStringHandle.OrderReplyProvider.GetWorkData();
                    if (drs == null) return;




                    for (int i = 0; i < drs.Length; i++)
                    {
                        DataRow dr = drs[i];






                        string PRODUCTKIND = dr["PRODUCTKIND"].ToString();
                        string EXECTYPE = OrderType.Cancel;
                        string BROKERID = dr["BROKERID"].ToString();
                        string ORDERNO = dr["ORDERNO"].ToString();
                        string INVESTORACNO = dr["INVESTORACNO"].ToString();
                        string SUBACT = dr["SUBACT"].ToString();
                        string SECURITYEXCHANGE = dr["SECURITYEXCHANGE"].ToString();
                        string SECURITYTYPE1 = dr["SECURITYTYPE1"].ToString();
                        string SYMBOL1 = dr["SYMBOL1"].ToString(); ;
                        string MATURITYMONTHYEAR1 = dr["MATURITYMONTHYEAR1"].ToString(); ;
                        string PUTORCALL1 = dr["PUTORCALL1"].ToString(); ;
                        decimal STRIKEPRICE1 = decimal.Parse(dr["STRIKEPRICE1"].ToString()); ;
                        string SIDE1 = dr["SIDE1"].ToString(); ;
                        string SECURITYTYPE2 = dr["SECURITYTYPE2"].ToString(); ;
                        string SYMBOL2 = dr["SYMBOL2"].ToString(); ;
                        string MATURITYMONTHYEAR2 = dr["MATURITYMONTHYEAR2"].ToString(); ;
                        string PUTORCALL2 = dr["PUTORCALL2"].ToString(); ;
                        decimal STRIKEPRICE2 = decimal.Parse(dr["STRIKEPRICE2"].ToString()); ;
                        string SIDE2 = dr["SIDE2"].ToString(); ;
                        string BS = dr["BS"].ToString(); ;
                        string ORDERTYPE = dr["ORDERTYPE"].ToString(); ;
                        decimal PRICE = decimal.Parse(dr["PRICE"].ToString());
                        decimal STOPPRICE = decimal.Parse(dr["STOPPRICE"].ToString());


                        int ORDERQTY = int.Parse(dr["ORDERQTY"].ToString());
                        string TIMEINFORCE = dr["TIMEINFORCE"].ToString();
                        string OPENCLOSE = dr["OPENCLOSE"].ToString();
                        string DTRADE = dr["DTRADE"].ToString();
                        string CLORDID = dr["CLORDID"].ToString();
                        string EXPIREDATE = dr["EXPIREDATE"].ToString();
                        string SOURCECODE = "d";
                        string KEEPDATA = dr["KEEPDATA"].ToString(); ;

                        if (dr["ORDERKIND"].ToString() == "P")
                        {
                            frmMain.mobjDataAgent.objTradeStringHandle.sendOrderStrategy(PRODUCTKIND
                          , EXECTYPE
                          , BROKERID
                          , ORDERNO
                          , INVESTORACNO
                          , SUBACT
                          , SECURITYEXCHANGE
                          , SECURITYTYPE1
                          , SYMBOL1
                          , MATURITYMONTHYEAR1
                          , PUTORCALL1
                          , STRIKEPRICE1
                          , SIDE1
                          , SECURITYTYPE2
                          , SYMBOL2
                          , MATURITYMONTHYEAR2
                          , PUTORCALL2
                          , STRIKEPRICE2
                          , SIDE2
                          , BS
                          , ORDERTYPE
                          , PRICE
                          , STOPPRICE
                          , ORDERQTY
                          , TIMEINFORCE
                          , OPENCLOSE
                          , DTRADE
                          , CLORDID
                          , EXPIREDATE
                          , SOURCECODE, KEEPDATA);


                        }
                        else
                        {


                            frmMain.mobjDataAgent.objTradeStringHandle.sendOrder(PRODUCTKIND
                          , EXECTYPE
                          , BROKERID
                          , ORDERNO
                          , INVESTORACNO
                          , SUBACT
                          , SECURITYEXCHANGE
                          , SECURITYTYPE1
                          , SYMBOL1
                          , MATURITYMONTHYEAR1
                          , PUTORCALL1
                          , STRIKEPRICE1
                          , SIDE1
                          , SECURITYTYPE2
                          , SYMBOL2
                          , MATURITYMONTHYEAR2
                          , PUTORCALL2
                          , STRIKEPRICE2
                          , SIDE2
                          , BS
                          , ORDERTYPE
                          , PRICE
                          , STOPPRICE
                          , ORDERQTY
                          , TIMEINFORCE
                          , OPENCLOSE
                          , DTRADE
                          , CLORDID
                          , EXPIREDATE
                          , SOURCECODE, KEEPDATA);
                        }
                    }
                    this.txtQty.Text = "";
                    this.txtOrderPrice.Text = "";
                    cmbAccount.Text = "";
                    DataAgent._LM.WriteLog("UIEventLog", this.GetType().Name + "CancelAll");
                }
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("UIErrorLog", this.GetType().Name
                       + " " + System.Reflection.MethodInfo.GetCurrentMethod().Name + " " + ex.Message);

            }
        }

        private void btnUpdateProduct_Click(object sender, EventArgs e)
        {
            VIPTradingSystem.ui.Main.frmProductSet frm = new Main.frmProductSet();
            frm.ShowDialog();
        }

        private void btnUpdateNet_Click(object sender, EventArgs e)
        {
            //VIPTradingSystem.ui.Main.frmPostionSet frm = new Main.frmPostionSet();
            //frm.ShowDialog();

            string account = cmbAccountNet.Text.Trim();
            //先清除之前的部位
            DataTable dt = frmMain.mobjDataAgent.Position;
            foreach (DataRow dr in dt.Rows)
            {
                //if (dr["Account"].ToString().Trim() == account || cmbAccountNet.Text == "all")
                //{
                MatchTotalItem Item = new MatchTotalItem();
                Item.BROKERID = dr["BROKERID"].ToString();
                Item.INVESTORACNO = dr["Account"].ToString();
                Item.SUBACT = "";// SUBACT;
                Item.SECURITYEXCHANGE = dr["SECURITYEXCHANGE"].ToString();
                Item.SECURITYTYPE1 = dr["SECURITYTYPE"].ToString();
                Item.SYMBOL1 = dr["SYMBOL1"].ToString();
                Item.MATURITYMONTHYEAR1 = dr["MATURITYMONTHYEAR1"].ToString();
                Item.PUTORCALL1 = dr["PUTORCALL1"].ToString();
                Item.STRIKEPRICE1 = decimal.Parse(dr["STRIKEPRICE1"].ToString());
                Item.STRIKEPRICE1 = Decimal.Parse(Item.STRIKEPRICE1.ToString("0.#######"));
                Item.SIDE1 = dr["SIDE1"].ToString();

                Item.SYMBOL2 = dr["SYMBOL2"].ToString();
                Item.MATURITYMONTHYEAR2 = dr["MATURITYMONTHYEAR2"].ToString();
                Item.PUTORCALL2 = dr["PUTORCALL2"].ToString();
                Item.STRIKEPRICE2 = decimal.Parse(dr["STRIKEPRICE2"].ToString());

                Item.STRIKEPRICE2 = Decimal.Parse(Item.STRIKEPRICE2.ToString("0.#######"));
                Item.SIDE2 = dr["SIDE2"].ToString();
                if (Item.SECURITYTYPE1.Trim() == "FUT")
                {
                    if (Item.SYMBOL2.Trim().Length > 0)
                    {
                        Item.SECURITYTYPE2 = dr["SECURITYTYPE"].ToString();
                        Item.PRODUCTKIND = "4";
                    }
                    else
                        Item.PRODUCTKIND = "1";
                }
                else
                {
                    if (Item.SYMBOL2.Trim().Length > 0)
                    {
                        Item.SECURITYTYPE2 = dr["SECURITYTYPE"].ToString();
                        Item.PRODUCTKIND = "3";
                    }
                    else
                        Item.PRODUCTKIND = "2";
                }

                frmMain.mobjDataAgent.objTradeStringHandle.MatchTotalProvider.DelMatchQty("", Item, dr["BS"].ToString()
                    , decimal.Parse(dr["PRICE"].ToString()), int.Parse(dr["QTY"].ToString()));
                dr.Delete();
                // }
            }
            dt.AcceptChanges();

            //匯入新的維護部位資料
            byte[] bb = frmMain.mobjDataAgent.WS_LService.WS_PostionList();

            DataSet ds = CommonFunction.SerialUnZip(bb);

            if (ds.Tables.Count > 0)
            {
                frmMain.mobjDataAgent.Position = ds.Tables[0];
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    //if (dr["Account"].ToString().Trim() == account || cmbAccountNet.Text == "all")
                    //{
                    MatchTotalItem Item = new MatchTotalItem();
                    Item.BROKERID = dr["BROKERID"].ToString();
                    Item.INVESTORACNO = dr["Account"].ToString();
                    Item.SUBACT = "";// SUBACT;
                    Item.SECURITYEXCHANGE = dr["SECURITYEXCHANGE"].ToString();
                    Item.SECURITYTYPE1 = dr["SECURITYTYPE"].ToString();
                    Item.SYMBOL1 = dr["SYMBOL1"].ToString();
                    Item.MATURITYMONTHYEAR1 = dr["MATURITYMONTHYEAR1"].ToString();
                    Item.PUTORCALL1 = dr["PUTORCALL1"].ToString();
                    Item.STRIKEPRICE1 = decimal.Parse(dr["STRIKEPRICE1"].ToString());
                    Item.STRIKEPRICE1 = Decimal.Parse(Item.STRIKEPRICE1.ToString("0.#######"));
                    Item.SIDE1 = dr["SIDE1"].ToString();

                    Item.SYMBOL2 = dr["SYMBOL2"].ToString();
                    Item.MATURITYMONTHYEAR2 = dr["MATURITYMONTHYEAR2"].ToString();
                    Item.PUTORCALL2 = dr["PUTORCALL2"].ToString();
                    Item.STRIKEPRICE2 = decimal.Parse(dr["STRIKEPRICE2"].ToString());

                    Item.STRIKEPRICE2 = Decimal.Parse(Item.STRIKEPRICE2.ToString("0.#######"));
                    Item.SIDE2 = dr["SIDE2"].ToString();
                    if (Item.SECURITYTYPE1.Trim() == "FUT")
                    {
                        if (Item.SYMBOL2.Trim().Length > 0)
                        {
                            Item.SECURITYTYPE2 = dr["SECURITYTYPE"].ToString();
                            Item.PRODUCTKIND = "4";
                        }
                        else
                            Item.PRODUCTKIND = "1";
                    }
                    else
                    {
                        if (Item.SYMBOL2.Trim().Length > 0)
                        {
                            Item.SECURITYTYPE2 = dr["SECURITYTYPE"].ToString();
                            Item.PRODUCTKIND = "3";
                        }
                        else
                            Item.PRODUCTKIND = "2";
                    }




                    frmMain.mobjDataAgent.objTradeStringHandle.MatchTotalProvider.AddMatchQty("", Item, dr["BS"].ToString()
                        , decimal.Parse(dr["PRICE"].ToString()), int.Parse(dr["QTY"].ToString()));
                    // }
                }
            }
        }

        private void btnClearNet_Click(object sender, EventArgs e)
        {
            string account = cmbAccountNet.Text.Trim();
            DataTable dt = frmMain.mobjDataAgent.Position;
            foreach (DataRow dr in dt.Rows)
            {

                MatchTotalItem Item = new MatchTotalItem();
                Item.BROKERID = dr["BROKERID"].ToString();
                Item.INVESTORACNO = dr["Account"].ToString();
                Item.SUBACT = "";// SUBACT;
                Item.SECURITYEXCHANGE = dr["SECURITYEXCHANGE"].ToString();
                Item.SECURITYTYPE1 = dr["SECURITYTYPE"].ToString();
                Item.SYMBOL1 = dr["SYMBOL1"].ToString();
                Item.MATURITYMONTHYEAR1 = dr["MATURITYMONTHYEAR1"].ToString();
                Item.PUTORCALL1 = dr["PUTORCALL1"].ToString();
                Item.STRIKEPRICE1 = decimal.Parse(dr["STRIKEPRICE1"].ToString());
                Item.STRIKEPRICE1 = Decimal.Parse(Item.STRIKEPRICE1.ToString("0.#######"));
                Item.SIDE1 = dr["SIDE1"].ToString();

                Item.SYMBOL2 = dr["SYMBOL2"].ToString();
                Item.MATURITYMONTHYEAR2 = dr["MATURITYMONTHYEAR2"].ToString();
                Item.PUTORCALL2 = dr["PUTORCALL2"].ToString();
                Item.STRIKEPRICE2 = decimal.Parse(dr["STRIKEPRICE2"].ToString());

                Item.STRIKEPRICE2 = Decimal.Parse(Item.STRIKEPRICE2.ToString("0.#######"));
                Item.SIDE2 = dr["SIDE2"].ToString();
                if (Item.SECURITYTYPE1.Trim() == "FUT")
                {
                    if (Item.SYMBOL2.Trim().Length > 0)
                    {
                        Item.SECURITYTYPE2 = dr["SECURITYTYPE"].ToString();
                        Item.PRODUCTKIND = "4";
                    }
                    else
                        Item.PRODUCTKIND = "1";
                }
                else
                {
                    if (Item.SYMBOL2.Trim().Length > 0)
                    {
                        Item.SECURITYTYPE2 = dr["SECURITYTYPE"].ToString();
                        Item.PRODUCTKIND = "3";
                    }
                    else
                        Item.PRODUCTKIND = "2";
                }

                frmMain.mobjDataAgent.objTradeStringHandle.MatchTotalProvider.DelMatchQty("", Item, dr["BS"].ToString()
                    , decimal.Parse(dr["PRICE"].ToString()), int.Parse(dr["QTY"].ToString()));
                dr.Delete();

            }
            dt.AcceptChanges();
        }
        private void dgvReplyDetail_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {

            try
            {

                if (e.ColumnIndex == -1 || e.RowIndex == -1) return;
                computReplyDetail(e.RowIndex);

                if (dgvReply.CurrentCell.RowIndex > -1)
                {
                    DataView dv = dvReply;
                    DataRowView dvr = dv[dgvReply.CurrentCell.RowIndex];
                    dvr["check"] = false;
                  //  dvr["checkflag"] = false;
                }

            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("UIErrorLog", this.GetType().Name
                       + " " + System.Reflection.MethodInfo.GetCurrentMethod().Name + " " + ex.Message);

            }
        }
        private void computReplyDetail(int rowindex)
        {
            lock (frmMain.mobjDataAgent.objTradeStringHandle.OrderReplyProvider._locker)
            {

                DataView dv = dvReplyDetail;

                DataRowView dvr = dv[rowindex];



                if (dgvReplyDetail[0, rowindex].Value != null)
                {
                    string BROKERID = dvr["BROKERID"].ToString().Trim();
                    string ORDERNO = dvr["ORDERNO"].ToString().Trim();
                    string INVESTORACNO = dvr["INVESTORACNO"].ToString().Trim();
                    string SUBACT = dvr["SUBACT"].ToString().Trim();
                    string SECURITYEXCHANGE = dvr["SECURITYEXCHANGE"].ToString();
                    string SECURITYTYPE1 = dvr["SECURITYTYPE1"].ToString();
                    string SYMBOL1 = dvr["SYMBOL1"].ToString(); ;
                    string MATURITYMONTHYEAR1 = dvr["MATURITYMONTHYEAR1"].ToString(); ;
                    string PUTORCALL1 = dvr["PUTORCALL1"].ToString(); ;
                    decimal STRIKEPRICE1 = decimal.Parse(dvr["STRIKEPRICE1"].ToString()); ;
                    string SIDE1 = dvr["SIDE1"].ToString(); ;
                    string SECURITYTYPE2 = dvr["SECURITYTYPE2"].ToString(); ;
                    string SYMBOL2 = dvr["SYMBOL2"].ToString(); ;
                    string MATURITYMONTHYEAR2 = dvr["MATURITYMONTHYEAR2"].ToString(); ;
                    string PUTORCALL2 = dvr["PUTORCALL2"].ToString(); ;
                    decimal STRIKEPRICE2 = decimal.Parse(dvr["STRIKEPRICE2"].ToString()); ;
                    string SIDE2 = dvr["SIDE2"].ToString(); ;
                    string PRODUCTKIND = dvr["PRODUCTKIND"].ToString(); ;
                    string BS = dvr["BS"].ToString(); ;

                    string KEEPDATA = dvr["KEEPDATA"].ToString(); ;
                    MatchTotalItem Item = new MatchTotalItem();
                    Item.BROKERID = BROKERID;
                    Item.INVESTORACNO = INVESTORACNO;
                    Item.SUBACT = "";// SUBACT;
                    Item.SECURITYEXCHANGE = SECURITYEXCHANGE;
                    Item.SECURITYTYPE1 = SECURITYTYPE1;
                    Item.SYMBOL1 = SYMBOL1;
                    Item.MATURITYMONTHYEAR1 = MATURITYMONTHYEAR1;
                    Item.PUTORCALL1 = PUTORCALL1;
                    Item.STRIKEPRICE1 = STRIKEPRICE1;
                    Item.SIDE1 = SIDE1;
                    Item.SECURITYTYPE2 = SECURITYTYPE2;
                    Item.SYMBOL2 = SYMBOL2;
                    Item.MATURITYMONTHYEAR2 = MATURITYMONTHYEAR2;
                    Item.PUTORCALL2 = PUTORCALL2;
                    Item.STRIKEPRICE2 = STRIKEPRICE2;
                    Item.SIDE2 = SIDE2;
                    Item.PRODUCTKIND = PRODUCTKIND;
                    string bs = BS;
                    int NOMATCHQTY = int.Parse(dvr["NOMATCHQTY"].ToString()); ;
                    string key = "";
                    if ((bool)dvr["check"])
                    {
                        if ((int)dvr["MATCHQTY"] > 0)
                        {
                            // RowFilter = RowFilter.Replace("AND ORDERNO <>'" + dv[e.RowIndex]["ORDERNO"].ToString() + "' ", "");
                        }
                        //frmMain.mobjDataAgent.objTradeStringHandle.MatchTotalProvider.RemoveCheck(ORDERNO);
                        frmMain.mobjDataAgent.objTradeStringHandle.MatchTotalProvider.AddCheck(ORDERNO);
                    }
                    else
                    {
                        if ((int)dvr["MATCHQTY"] > 0)
                        {
                            //  RowFilter += "AND ORDERNO <>'" + dv[e.RowIndex]["ORDERNO"].ToString() + "' ";
                        }
                        //frmMain.mobjDataAgent.objTradeStringHandle.MatchTotalProvider.AddCheck(ORDERNO);
                        frmMain.mobjDataAgent.objTradeStringHandle.MatchTotalProvider.RemoveCheck(ORDERNO);
                    }

                    if ((bool)dvr["check"] == false)
                    {
                        if (NOMATCHQTY > 0)
                            frmMain.mobjDataAgent.objTradeStringHandle.MatchTotalProvider.DelWrkQty(Item, bs, NOMATCHQTY);

                        key = BROKERID + INVESTORACNO + SUBACT + ORDERNO;
                        //DataRow[] drs = frmMain.mobjDataAgent.objTradeStringHandle.MatchReplyProvider.GetMatch(key);
                        DataRow[] drs = frmMain.mobjDataAgent.objTradeStringHandle.MatchReplyProvider.GetMatchFortmp(key);
                        if (drs != null)
                            // foreach (DataRow dr in drs)
                            for (int i = 0; i < drs.Length; i++)
                            {
                                DataRow dr = drs[i];
                                if (int.Parse(dr["MATCHQTY"].ToString()) > 0)
                                {
                                    Item.BROKERID = dr["BROKERID"].ToString();
                                    Item.INVESTORACNO = dr["INVESTORACNO"].ToString();
                                    Item.SUBACT = "";// SUBACT;
                                    Item.SECURITYEXCHANGE = dr["SECURITYEXCHANGE"].ToString();
                                    Item.SECURITYTYPE1 = dr["SECURITYTYPE1"].ToString();
                                    Item.SYMBOL1 = dr["SYMBOL1"].ToString();
                                    Item.MATURITYMONTHYEAR1 = dr["MATURITYMONTHYEAR1"].ToString();
                                    Item.PUTORCALL1 = dr["PUTORCALL1"].ToString();
                                    Item.STRIKEPRICE1 = decimal.Parse(dr["STRIKEPRICE1"].ToString());
                                    Item.SIDE1 = dr["SIDE1"].ToString();
                                    Item.SECURITYTYPE2 = dr["SECURITYTYPE2"].ToString();
                                    Item.SYMBOL2 = dr["SYMBOL2"].ToString();
                                    Item.MATURITYMONTHYEAR2 = dr["MATURITYMONTHYEAR2"].ToString();
                                    Item.PUTORCALL2 = dr["PUTORCALL2"].ToString();
                                    Item.STRIKEPRICE2 = decimal.Parse(dr["STRIKEPRICE2"].ToString());
                                    Item.SIDE2 = dr["SIDE2"].ToString();
                                    Item.PRODUCTKIND = dr["PRODUCTKIND"].ToString();


                                    frmMain.mobjDataAgent.objTradeStringHandle.MatchTotalProvider.DelMatchQty(dr["ORDERNO"].ToString(), Item, dr["BS"].ToString()
                                        , decimal.Parse(dr["MATCHPRICE"].ToString()), int.Parse(dr["MATCHQTY"].ToString()));
                                }
                                frmMain.mobjDataAgent.objTradeStringHandle.MatchReplyProvider.Delete(key, dr);
                            }

                    }
                    else
                    {
                        if (NOMATCHQTY > 0)
                            frmMain.mobjDataAgent.objTradeStringHandle.MatchTotalProvider.AddWrkQty(dvr["ORDERNO"].ToString(), Item, bs, NOMATCHQTY);
                        key = BROKERID + INVESTORACNO + SUBACT + ORDERNO;

                        DataRow[] drs = frmMain.mobjDataAgent.objTradeStringHandle.MatchReplyProvider.GetMatchAddTmp(key);
                        if (drs != null)
                            // foreach (DataRow dr in drs)
                            for (int i = 0; i < drs.Length; i++)
                            {
                                DataRow dr = drs[i];
                                if (int.Parse(dr["MATCHQTY"].ToString()) > 0)
                                {
                                    Item.BROKERID = dr["BROKERID"].ToString();
                                    Item.INVESTORACNO = dr["INVESTORACNO"].ToString();
                                    Item.SUBACT = "";// SUBACT;
                                    Item.SECURITYEXCHANGE = dr["SECURITYEXCHANGE"].ToString();
                                    Item.SECURITYTYPE1 = dr["SECURITYTYPE1"].ToString();
                                    Item.SYMBOL1 = dr["SYMBOL1"].ToString();
                                    Item.MATURITYMONTHYEAR1 = dr["MATURITYMONTHYEAR1"].ToString();
                                    Item.PUTORCALL1 = dr["PUTORCALL1"].ToString();
                                    Item.STRIKEPRICE1 = decimal.Parse(dr["STRIKEPRICE1"].ToString());
                                    Item.SIDE1 = dr["SIDE1"].ToString();
                                    Item.SECURITYTYPE2 = dr["SECURITYTYPE2"].ToString();
                                    Item.SYMBOL2 = dr["SYMBOL2"].ToString();
                                    Item.MATURITYMONTHYEAR2 = dr["MATURITYMONTHYEAR2"].ToString();
                                    Item.PUTORCALL2 = dr["PUTORCALL2"].ToString();
                                    Item.STRIKEPRICE2 = decimal.Parse(dr["STRIKEPRICE2"].ToString());
                                    Item.SIDE2 = dr["SIDE2"].ToString();
                                    Item.PRODUCTKIND = dr["PRODUCTKIND"].ToString();
                                    frmMain.mobjDataAgent.objTradeStringHandle.MatchTotalProvider.AddMatchQty(dr["ORDERNO"].ToString(), Item, dr["BS"].ToString()
                                        , decimal.Parse(dr["MATCHPRICE"].ToString()), int.Parse(dr["MATCHQTY"].ToString()));

                                    // 
                                }
                            }
                    }
                    bool checkflag = false;
                    for (int i = 0; i < dv.Count; i++)
                    {
                          checkflag|= (bool) dv[i]["check"];

                    }

                    dvReply[dgvReply.CurrentCell.RowIndex]["checkflag"] = checkflag;
                    dgvReply.Invalidate();
                    SeqReset();
                    DataAgent._LM.WriteLog("UIEventLog", this.GetType().Name + " CellValueChanged ");
                }

            }
        }
        private void dgvReply_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {



            try
            {

                if (e.ColumnIndex == -1 || e.RowIndex == -1) return;
                lock (frmMain.mobjDataAgent.objTradeStringHandle.OrderReplyProvider._locker)
                {
                    DataGridViewCheckBoxCell chkchecking = dgvReply[e.ColumnIndex, e.RowIndex] as DataGridViewCheckBoxCell;
                    DataView dv = dvReply;

                    DataRowView dvr = dv[e.RowIndex];

                    if (dgvReply.Columns[e.ColumnIndex] is com.ddsc.tool.window.DDSCDataGridViewCheckBoxColumn)
                    {


                        // this.dgvReply.CurrentCell .ContentBounds.

                        if (dvr["ORDERKIND"].ToString().Trim() == "P") //母單不算
                        {
                            for (int i = e.RowIndex + 1; i < dv.Count; i++)
                            {
                                if (dv[i - 1]["SEQ_AD"].ToString() == dv[i]["SEQ_AD"].ToString())
                                {
                                    if ((bool)chkchecking.Value == false)
                                        dgvReply.Rows[i].Cells["check"].Value = false;
                                    else dgvReply.Rows[i].Cells["check"].Value = true;

                                }
                                else
                                    break;
                            }

                            dgvReply.CurrentCell = dgvReply[e.ColumnIndex, e.RowIndex];
                            string seq = dvr["seq_ad"].ToString();
                            dvReplyDetail.RowFilter = "seq_ad='" + seq + "' and  seq=''     ";
                            
                            for (int i = 0; i < dvReplyDetail.Count; i++)
                            {
                                if ((bool)chkchecking.Value == false)
                                {
                                    if ((bool)dvReplyDetail[i]["check"] == true)
                                    {
                                        dvReplyDetail[i]["check"] = false;
                                        computReplyDetail(i);
                                    }
                                }
                                else
                                {

                                    if ((bool)dvReplyDetail[i]["check"] == false)
                                    {
                                        dvReplyDetail[i]["check"] = true;
                                        computReplyDetail(i);
                                    }

                                }
                              

                            }
                            if ((bool)chkchecking.Value == false)
                            {
                                //全選取消成交物件全部刪除
                                frmMain.mobjDataAgent.objTradeStringHandle.OrderReplyProvider.DelStrategySeq(seq);
                                for (int i = 0; i < dvReplyDetail.Count; i++)
                                {
                                    string key = dvReplyDetail[i]["BROKERID"].ToString().Trim() 
                                        + dvReplyDetail[i]["INVESTORACNO"].ToString().Trim()
                                        + dvReplyDetail[i]["SUBACT"].ToString().Trim()
                                        + dvReplyDetail[i]["ORDERNO"].ToString().Trim();
                
                                    frmMain.mobjDataAgent.objTradeStringHandle.MatchReplyProvider.DelStrategySeq(key);

                                }
                                dvr["checkflag"] = false;
                            }
                            else
                            {
                          
                                frmMain.mobjDataAgent.objTradeStringHandle.OrderReplyProvider.AddStrategySeq(seq);
                                dvr["checkflag"] = true;
                            }
                            SeqReset();
                            dgvReplyDetail.Invalidate();
                            // dgvReplyDetail.CommitEdit(DataGridViewDataErrorContexts.Commit);
                            return;
                        }
                        if (dgvReply[e.ColumnIndex, e.RowIndex].Value != null)
                        {
                            string BROKERID = dvr["BROKERID"].ToString().Trim();
                            string ORDERNO = dvr["ORDERNO"].ToString().Trim();
                            string INVESTORACNO = dvr["INVESTORACNO"].ToString().Trim();
                            string SUBACT = dvr["SUBACT"].ToString().Trim();
                            string SECURITYEXCHANGE = dvr["SECURITYEXCHANGE"].ToString();
                            string SECURITYTYPE1 = dvr["SECURITYTYPE1"].ToString();
                            string SYMBOL1 = dvr["SYMBOL1"].ToString(); ;
                            string MATURITYMONTHYEAR1 = dvr["MATURITYMONTHYEAR1"].ToString(); ;
                            string PUTORCALL1 = dvr["PUTORCALL1"].ToString(); ;
                            decimal STRIKEPRICE1 = decimal.Parse(dvr["STRIKEPRICE1"].ToString()); ;
                            string SIDE1 = dvr["SIDE1"].ToString(); ;
                            string SECURITYTYPE2 = dvr["SECURITYTYPE2"].ToString(); ;
                            string SYMBOL2 = dvr["SYMBOL2"].ToString(); ;
                            string MATURITYMONTHYEAR2 = dvr["MATURITYMONTHYEAR2"].ToString(); ;
                            string PUTORCALL2 = dvr["PUTORCALL2"].ToString(); ;
                            decimal STRIKEPRICE2 = decimal.Parse(dvr["STRIKEPRICE2"].ToString()); ;
                            string SIDE2 = dvr["SIDE2"].ToString(); ;
                            string PRODUCTKIND = dvr["PRODUCTKIND"].ToString(); ;
                            string BS = dvr["BS"].ToString(); ;

                            string KEEPDATA = dvr["KEEPDATA"].ToString(); ;
                            MatchTotalItem Item = new MatchTotalItem();
                            Item.BROKERID = BROKERID;
                            Item.INVESTORACNO = INVESTORACNO;
                            Item.SUBACT = "";// SUBACT;
                            Item.SECURITYEXCHANGE = SECURITYEXCHANGE;
                            Item.SECURITYTYPE1 = SECURITYTYPE1;
                            Item.SYMBOL1 = SYMBOL1;
                            Item.MATURITYMONTHYEAR1 = MATURITYMONTHYEAR1;
                            Item.PUTORCALL1 = PUTORCALL1;
                            Item.STRIKEPRICE1 = STRIKEPRICE1;
                            Item.SIDE1 = SIDE1;
                            Item.SECURITYTYPE2 = SECURITYTYPE2;
                            Item.SYMBOL2 = SYMBOL2;
                            Item.MATURITYMONTHYEAR2 = MATURITYMONTHYEAR2;
                            Item.PUTORCALL2 = PUTORCALL2;
                            Item.STRIKEPRICE2 = STRIKEPRICE2;
                            Item.SIDE2 = SIDE2;
                            Item.PRODUCTKIND = PRODUCTKIND;
                            string bs = BS;
                            int NOMATCHQTY = int.Parse(dvr["NOMATCHQTY"].ToString()); ;
                            string key = "";
                            if ((bool)dv[e.RowIndex]["check"])
                            {
                                if ((int)dv[e.RowIndex]["MATCHQTY"] > 0)
                                {
                                    // RowFilter = RowFilter.Replace("AND ORDERNO <>'" + dv[e.RowIndex]["ORDERNO"].ToString() + "' ", "");
                                }
                                frmMain.mobjDataAgent.objTradeStringHandle.MatchTotalProvider.AddCheck(ORDERNO);
                               
                            }
                            else
                            {
                                if ((int)dv[e.RowIndex]["MATCHQTY"] > 0)
                                {
                                    //  RowFilter += "AND ORDERNO <>'" + dv[e.RowIndex]["ORDERNO"].ToString() + "' ";
                                }
                                frmMain.mobjDataAgent.objTradeStringHandle.MatchTotalProvider.RemoveCheck(ORDERNO);
                            }

                            if ((bool)chkchecking.Value == false)
                            {
                                if (NOMATCHQTY > 0)
                                    frmMain.mobjDataAgent.objTradeStringHandle.MatchTotalProvider.DelWrkQty(Item, bs, NOMATCHQTY);

                                key = BROKERID + INVESTORACNO + SUBACT + ORDERNO;
                              
                                DataRow[] drs = frmMain.mobjDataAgent.objTradeStringHandle.MatchReplyProvider.GetMatchFortmp(key);
                                if (drs != null)
                                    // foreach (DataRow dr in drs)
                                    for (int i = 0; i < drs.Length; i++)
                                    {
                                        DataRow dr = drs[i];
                                        if (int.Parse(dr["MATCHQTY"].ToString()) > 0)
                                        {
                                            Item.BROKERID = dr["BROKERID"].ToString();
                                            Item.INVESTORACNO = dr["INVESTORACNO"].ToString();
                                            Item.SUBACT = "";// SUBACT;
                                            Item.SECURITYEXCHANGE = dr["SECURITYEXCHANGE"].ToString();
                                            Item.SECURITYTYPE1 = dr["SECURITYTYPE1"].ToString();
                                            Item.SYMBOL1 = dr["SYMBOL1"].ToString();
                                            Item.MATURITYMONTHYEAR1 = dr["MATURITYMONTHYEAR1"].ToString();
                                            Item.PUTORCALL1 = dr["PUTORCALL1"].ToString();
                                            Item.STRIKEPRICE1 = decimal.Parse(dr["STRIKEPRICE1"].ToString());
                                            Item.SIDE1 = dr["SIDE1"].ToString();
                                            Item.SECURITYTYPE2 = dr["SECURITYTYPE2"].ToString();
                                            Item.SYMBOL2 = dr["SYMBOL2"].ToString();
                                            Item.MATURITYMONTHYEAR2 = dr["MATURITYMONTHYEAR2"].ToString();
                                            Item.PUTORCALL2 = dr["PUTORCALL2"].ToString();
                                            Item.STRIKEPRICE2 = decimal.Parse(dr["STRIKEPRICE2"].ToString());
                                            Item.SIDE2 = dr["SIDE2"].ToString();
                                            Item.PRODUCTKIND = dr["PRODUCTKIND"].ToString();


                                            frmMain.mobjDataAgent.objTradeStringHandle.MatchTotalProvider.DelMatchQty(dr["ORDERNO"].ToString(), Item, dr["BS"].ToString()
                                                , decimal.Parse(dr["MATCHPRICE"].ToString()), int.Parse(dr["MATCHQTY"].ToString()));
                                        }
                                        frmMain.mobjDataAgent.objTradeStringHandle.MatchReplyProvider.Delete(key, dr);

                                       
                                    }

                            }
                            else
                            {
                                if (NOMATCHQTY > 0)
                                    frmMain.mobjDataAgent.objTradeStringHandle.MatchTotalProvider.AddWrkQty(dvr["ORDERNO"].ToString(), Item, bs, NOMATCHQTY);
                                key = BROKERID + INVESTORACNO + SUBACT + ORDERNO;
                                DataRow[] drs = frmMain.mobjDataAgent.objTradeStringHandle.MatchReplyProvider.GetMatchAddTmp(key);
                                if (drs != null)
                                    // foreach (DataRow dr in drs)
                                    for (int i = 0; i < drs.Length; i++)
                                    {
                                        DataRow dr = drs[i];
                                        if (int.Parse(dr["MATCHQTY"].ToString()) > 0)
                                        {
                                            Item.BROKERID = dr["BROKERID"].ToString();
                                            Item.INVESTORACNO = dr["INVESTORACNO"].ToString();
                                            Item.SUBACT = "";// SUBACT;
                                            Item.SECURITYEXCHANGE = dr["SECURITYEXCHANGE"].ToString();
                                            Item.SECURITYTYPE1 = dr["SECURITYTYPE1"].ToString();
                                            Item.SYMBOL1 = dr["SYMBOL1"].ToString();
                                            Item.MATURITYMONTHYEAR1 = dr["MATURITYMONTHYEAR1"].ToString();
                                            Item.PUTORCALL1 = dr["PUTORCALL1"].ToString();
                                            Item.STRIKEPRICE1 = decimal.Parse(dr["STRIKEPRICE1"].ToString());
                                            Item.SIDE1 = dr["SIDE1"].ToString();
                                            Item.SECURITYTYPE2 = dr["SECURITYTYPE2"].ToString();
                                            Item.SYMBOL2 = dr["SYMBOL2"].ToString();
                                            Item.MATURITYMONTHYEAR2 = dr["MATURITYMONTHYEAR2"].ToString();
                                            Item.PUTORCALL2 = dr["PUTORCALL2"].ToString();
                                            Item.STRIKEPRICE2 = decimal.Parse(dr["STRIKEPRICE2"].ToString());
                                            Item.SIDE2 = dr["SIDE2"].ToString();
                                            Item.PRODUCTKIND = dr["PRODUCTKIND"].ToString();
                                            frmMain.mobjDataAgent.objTradeStringHandle.MatchTotalProvider.AddMatchQty(dr["ORDERNO"].ToString(), Item, dr["BS"].ToString()
                                                , decimal.Parse(dr["MATCHPRICE"].ToString()), int.Parse(dr["MATCHQTY"].ToString()));

                                        }
                                    }
                            }

                            dgvReplyDetail.Invalidate();
                            DataAgent._LM.WriteLog("UIEventLog", this.GetType().Name + " CellValueChanged ");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("UIErrorLog", this.GetType().Name
                       + " " + System.Reflection.MethodInfo.GetCurrentMethod().Name + " " + ex.Message);

            }
          
        }


        int testseq = 124;
        private void button1_Click(object sender, EventArgs e)
        {

            //  frmMain.mobjDataAgent.GetReply();
            return;
            testseq++;
            string[] arrData = new string[1];
            arrData[0] = "                    0000000048201610061524502610F9040004A011H 6666666       1SGX       FUT  TW        201610              0.0000000                      0                                   0.0000000                      0B2                   300                     0    10O            0                     0    1    0                     04A000000000" + testseq.ToString() + "           l0000   委託成功                                                              06AU1C069:0                                                                0                                                                           06AU1C069 TTDEV25O  speedydts           AD=Time Slice|2|5|20161006114551410|20161006114851000|34000|1|0^pseq=A001C000K^";
            //testseq++;
            //arrData[1] = "                    0000000048201610061524502610F9040004A011H 6666666       1SGX       FUT  TW        201610              0.0000000                      0                                   0.0000000                      0B2                   300                     0    10O            0                     0    1    0                     04A000000000" + testseq.ToString() + "           l0000   委託成功                                                              06AU1C069:0                                                                0                                                                           06AU1C069 TTDEV25O  speedydts           AD=Time Slice|2|5|20161006114551410|20161006114851000|34000|1|0^pseq=A001C000L^";
            foreach (string data in arrData)
            {
                byte[] body = ASCIIEncoding.Default.GetBytes(data.Substring(20, data.Length - 20));
                string OldSeq = data.Substring(0, 9);
                string NewSeq = data.Substring(10, 9);
                com.ddsc.BI.F.SockClientParserFunction.DDSCHead DDSCHead = new com.ddsc.BI.F.SockClientParserFunction.DDSCHead();
                DDSCHead.HEAD = new byte[1] { com.ddsc.BI.F.SockClientParserFunction.DDSCSocketHead.Reply };
                DDSCHead.MESSAGETIME = ASCIIEncoding.ASCII.GetBytes(DateTime.Now.ToString("HHmmssfff"));
                DDSCHead.LENGTH = BitConverter.GetBytes(UInt16.Parse(body.Length.ToString()));
                if (BitConverter.IsLittleEndian)
                    Array.Reverse(DDSCHead.LENGTH);
                byte[] retBuffer = new byte[50 + body.Length + 1];
                DDSCHead.OLDSEQ = ASCIIEncoding.ASCII.GetBytes(OldSeq);
                DDSCHead.NEWSEQ = ASCIIEncoding.ASCII.GetBytes(NewSeq);
                DDSCHead.USERID = ASCIIEncoding.ASCII.GetBytes("".PadRight(20, ' '));
                byte[] headbyte = com.ddsc.BI.F.SockClientParserFunction.StructureToByteArray(DDSCHead);
                Array.Copy(headbyte, 0, retBuffer, 0, headbyte.Length);
                Array.Copy(body, 0, retBuffer, headbyte.Length, body.Length);
                retBuffer[retBuffer.Length - 1] = com.ddsc.BI.F.SockClientParserFunction.DDSCSocketHead.End;

                com.ddsc.BI.F.SockClientParserFunction.Reply Reply = new com.ddsc.BI.F.SockClientParserFunction.Reply();
                string KeepData = ASCIIEncoding.Default.GetString(retBuffer, 50 + System.Runtime.InteropServices.Marshal.SizeOf(Reply), retBuffer.Length - 50 - System.Runtime.InteropServices.Marshal.SizeOf(Reply) - 1);
                string AD = "";
                string pseq = "";
                //KeepData
                //AD=Time Slice|2|500|20161004172843726|20161004182843000|35000|5|0^          代表委託母單
                //AD=Time Slice|2|5|20161006114551410|20161006114851000|34000|1|0^pseq=A000C0002^ 代表委託出去的單子 子單
                foreach (string f in KeepData.Split('^'))
                {
                    if (f.IndexOf("AD") > -1)
                    {
                        AD = f.Split('=')[1];
                    }
                    if (f.IndexOf("pseq") > -1)
                    {
                        pseq = f.Split('=')[1];
                    }

                }
                if (AD.Length > 0 && pseq.Length == 0)
                    frmMain.mobjDataAgent.mobj_TradeStringHandle.ParseProgramTradeReply(retBuffer);
                else
                {
                    retBuffer = frmMain.mobjDataAgent.mobj_ReplyIntegration.DataEncode ? com.ddsc.BI.F.SockClientParserFunction.EncodeData(retBuffer) : retBuffer;
                    frmMain.mobjDataAgent.mobj_ReplyIntegration.Received(retBuffer);
                }

            }
        }

        private void dgvReply_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (dgvReply.Columns[e.ColumnIndex].DataPropertyName == "ORDERTIME_DISPLAY")
            {
                lock (frmMain.mobjDataAgent.objTradeStringHandle.OrderReplyProvider._locker)
                {
                    DataGridViewColumn newColumn = dgvReply.Columns["time"];

                    ListSortDirection direction = ListSortDirection.Ascending;
                    string sort = dvReply.Sort;
                    if (sort.IndexOf("TIME asc") > -1)
                    {
                        direction = ListSortDirection.Descending;
                        dvReply.Sort = "TIME desc,seq_ad asc,ORDERID asc";

                    }
                    else
                    {

                        direction = ListSortDirection.Ascending;
                        dvReply.Sort = "TIME asc,seq_ad asc,ORDERID asc";

                    }

                    DataAgent._LM.WriteLog("UIEventLog", this.GetType().Name + " " + dvReply.Sort);
                    // dgvReply.Sort(newColumn, direction);

                }
            }
        }




        private void dgvReply_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {

                if (e.RowIndex == -1 || e.ColumnIndex == -1) return;
                lock (frmMain.mobjDataAgent.objTradeStringHandle.OrderReplyProvider._locker)
                {
                    if (dgvReply.Columns[e.ColumnIndex].Name == "ORDERKIND") return;
                    if (dgvReply.Columns[e.ColumnIndex].Name == "check") return;

                    DataView dv = dvReply;

                    DataRowView dvr = dv[dgvReply.CurrentCell.RowIndex];

                    string SecurityExchange = dvr["SecurityExchange"].ToString().Trim();
                    string SecurityType1 = dvr["SecurityType1"].ToString().Trim();
                    string Symbol1 = dvr["Symbol1"].ToString().Trim();
                    string MaturityMonthYear1 = dvr["MaturityMonthYear1"].ToString().Trim();
                    string Cp1 = dvr["PUTORCALL2"].ToString().Trim();
                    decimal Strike1 = decimal.Parse(dvr["STRIKEPRICE1"].ToString().Trim());
                    string Side1 = dvr["Side1"].ToString().Trim();
                    string SecurityType2 = dvr["SecurityType2"].ToString().Trim(); ;
                    string Symbol2 = dvr["Symbol2"].ToString().Trim();
                    string MaturityMonthYear2 = dvr["MaturityMonthYear2"].ToString().Trim();
                    string Cp2 = dvr["PUTORCALL1"].ToString().Trim();
                    decimal Strike2 = decimal.Parse(dvr["STRIKEPRICE2"].ToString().Trim());
                    string Side2 = dvr["Side2"].ToString().Trim();

                    string contract = "";

                    if (Symbol2.Trim().Length == 0)
                        contract = Symbol1 + MaturityMonthYear1 + Cp1
                            + (SecurityType1 == "FUT" ? "" : Strike1.ToString("#.######"));
                    else
                        contract = Symbol1 + (Side1 == "B" ? "+1*" : "-1*") + MaturityMonthYear1 + Cp1 + (SecurityType1 == "FUT" ? "" : Strike1.ToString("#.######"))
                                           + (Side2 == "B" ? "+1*" : "-1*") + MaturityMonthYear2 + Cp2 + (SecurityType2 == "FUT" ? "" : Strike2.ToString("#.######"));


                    string KeepData = dvr["KEEPDATA"].ToString();



                    string BS = "";
                    if (dvr["BS"].ToString() == "B")
                        BS = "Buy";
                    else
                        BS = "Sell";
                    string Price = dvr["PRICE"].ToString();
                    string OrderQty = dvr["ORDERQTY"].ToString();


                    string PriceType = dvr["ORDERTYPE_DISPLAY"].ToString();
                    string Openclose = dvr["OPENCLOSE_DISPLAY"].ToString();
                    string TIF = dvr["TIMEINFORCE_DISPLAY"].ToString();
                    string account = dvr["INVESTORACNO"].ToString();

                    VIPTradingSystem.ui.Order.frmViewOrder fm = new VIPTradingSystem.ui.Order.frmViewOrder();
                    fm.view = true;
                    fm.lblOrder.Text += BS + OrderQty;
                    fm.lblContract.Text += SecurityExchange + contract; ;
                    fm.lblPriceType.Text += Price + " " + PriceType;
                    fm.lblOpenclose.Text += Openclose;
                    fm.lbltimeinforce.Text += TIF;
                    fm.lblaccount.Text += account;


                    string AD = "";

                    //KeepData
                    //AD=Time Slice|2|500|20161004172843726|20161004182843000|35000|5|0^          代表委託母單
                    //AD=Time Slice|2|5|20161006114551410|20161006114851000|34000|1|0^pseq=A000C0002^ 代表委託出去的單子 子單
                    foreach (string f in KeepData.Split('^'))
                    {
                        if (f.IndexOf("AD") > -1)
                        {
                            AD = f.Split('=')[1];
                        }
                    }
                    if (dvr["ORDERKIND"].ToString() == "P")
                    {
                        if (AD.Split('|').Length < 7) return;
                        string Type = AD.Split('|')[1];
                        int TotalQty = int.Parse(AD.Split('|')[2]);
                        int Interval = int.Parse(AD.Split('|')[5]);
                        int Qty = int.Parse(AD.Split('|')[6]);
                        decimal Ratio = decimal.Parse(AD.Split('|')[7]);
                        IFormatProvider culture = new System.Globalization.CultureInfo("zh-TW", true);
                        string begin = AD.Split('|')[3];
                        string end = AD.Split('|')[4];

                        DateTime BeginDateTime = DateTime.ParseExact(begin, "yyyyMMddHHmmssfff", culture);
                        DateTime EndDateTime = DateTime.ParseExact(end, "yyyyMMddHHmmssfff", culture);

                        if (BeginDateTime.ToString("yyyyMMddHHmmss") != DateTime.MaxValue.ToString("yyyyMMddHHmmss")
                            && BeginDateTime.ToString("yyyyMMddHHmmss") != DateTime.MinValue.ToString("yyyyMMddHHmmss"))
                            fm.lblstartime.Text += BeginDateTime.ToString("yyyy/MM/dd HH:mm:ss.fff");
                        if (EndDateTime.ToString("yyyyMMddHHmmss") != DateTime.MaxValue.ToString("yyyyMMddHHmmss")
                            && EndDateTime.ToString("yyyyMMddHHmmss") != DateTime.MinValue.ToString("yyyyMMddHHmmss"))
                            fm.lblworkuntil.Text += EndDateTime.ToString("yyyy/MM/dd HH:mm:ss.fff");
                        fm.lblworkorderas.Text += (Type == "1" ? "Time Slice" : (Type == "2" ? "Time Duration" : "None"));
                        //if (Type == "1" || Type == "2")
                        //    fm.lblworkorderas.Text += " " + (EndDateTime - BeginDateTime).TotalSeconds.ToString("0") + "Sec";

                        fm.lblIsclosedqty.Text += Qty.ToString();
                        fm.lblInterval.Text += Interval.ToString();

                    }
                    fm.ShowDialog();

                    DataAgent._LM.WriteLog("UIEventLog", this.GetType().Name + "View Order ");
                }
            }

            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("UIErrorLog", this.GetType().Name
                       + " " + System.Reflection.MethodInfo.GetCurrentMethod().Name + " " + ex.Message);

            }
        }

        private void dgvMatchreply_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {


        }

        private void dgvReply_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            //dgvReply.Rows[e.RowIndex].HeaderCell.Value = "A";
        }



        private void btnFilter_Click(object sender, EventArgs e)
        {
            Dictionary<string, string> FilterList = (Dictionary<string, string>)dgvReply.Tag;
            string filer = "";
            foreach (string k in FilterList.Keys)
            {
                if (k != "default")
                {
                    string val = FilterList[k];
                    filer += "AND " + val;
                }
            }


            DataView mdv = frmMain.mobjDataAgent.objTradeStringHandle.MatchReplyProvider.TmpMatchDetailReply.DefaultView;
            //  mdv.RowFilter = "";
            string RowFilter;
            RowFilter = "";

            RowFilter = RowFilter.Length > 3 ? RowFilter.Substring(3) : "";




            Dictionary<string, string> mtag = (Dictionary<string, string>)dgvMatchreply.Tag;
            string mfiler = "";
            foreach (string k in mtag.Keys)
            {
                if (k != "default")
                {
                    string val = mtag[k];
                    mfiler += "AND " + val;
                }
            }
            if (txtMatchTime_st.Text.Trim().Length > 0 && txtMatchTime_ed.Text.Trim().Length > 0)
            {
                mfiler += "AND ( MATCHTIME_DISPLAY >='" + txtMatchTime_st.Text.Trim() + "' AND   MATCHTIME_DISPLAY <='" + txtMatchTime_ed.Text.Trim() + "') ";
            }

            //MATCHTIME_DISPLAY
            if (filer.Length > 3)
            {
                filer = filer.Substring(3);
                mdv.RowFilter = "(" + filer + ")";

                if (RowFilter.Length > 0)
                    mdv.RowFilter += " and " + RowFilter;

                if (mfiler.Length > 3)
                {
                    mfiler = mfiler.Substring(3);
                    mdv.RowFilter += "and (" + mfiler + ")";

                }
            }
            else
            {
                mdv.RowFilter = "";

                if (RowFilter.Length > 0)
                    mdv.RowFilter = RowFilter;
                if (mfiler.Length > 3)
                {
                    mfiler = mfiler.Substring(3);
                    if (mdv.RowFilter.Length > 0)
                        mdv.RowFilter += "and (" + mfiler + ")";
                    else
                        mdv.RowFilter += "  (" + mfiler + ")";
                }
            }

        }

        private void dgvReply_CurrentCellDirtyStateChanged(object sender, EventArgs e)
        {
            if (this.dgvReply.IsCurrentCellDirty) //有未提交的更//改
            {
                this.dgvReply.CommitEdit(DataGridViewDataErrorContexts.Commit);
            }
        }

        private void dgvReplyDetail_CurrentCellDirtyStateChanged(object sender, EventArgs e)
        {
            if (this.dgvReplyDetail.IsCurrentCellDirty) //有未提交的更//改
            {
                this.dgvReplyDetail.CommitEdit(DataGridViewDataErrorContexts.Commit);
            }
        }






    }



}
