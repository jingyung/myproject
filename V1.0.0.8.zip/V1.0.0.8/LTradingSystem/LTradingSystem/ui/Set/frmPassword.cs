﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;
namespace VIPTradingSystem.ui.Set
{
    public partial class frmPassword : Form  
    {
        public frmPassword()
        {
            InitializeComponent();
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            //if (txtOgnPW.Text != frmMain.UserConfigs.PW)
            //{
            //    MessageBox.Show("輸入原密碼錯誤");
            //    txtOgnPW.Focus();
            //    return;
            //}
            //if (txtOgnPW.Text == txtNewPW.Text)
            //{
            //    MessageBox.Show("輸入密碼要和舊密碼不同!");
            //    txtNewPW.Focus();
            //    return;
            //}
            //bool chklg = Regex.IsMatch(txtNewPW.Text, @"[\w]{6,20}");
            //bool chkaz = Regex.IsMatch(txtNewPW.Text, @"[a-z]{1}");
            //bool chkAZ = Regex.IsMatch(txtNewPW.Text, @"[A-Z]{1}");
            //bool chk09 = Regex.IsMatch(txtNewPW.Text, @"[0-9]{1}");
            //if (!chkaz || !chkAZ || !chk09 || !chklg)
            //{
            //    MessageBox.Show("因應主管機關要求,密碼更變請符合長度範圍為6~20位大寫和小寫英文及數字組合");
            //    txtNewPW.Focus();
            //    return;
            //}
            if (txtNewPW.Text != txtCnfPW.Text)
            {
                MessageBox.Show("輸入新密碼和確認密碼不同!");
                txtCnfPW.Focus();
                return;
            }

            //透過SSO 登入
          string returnMsg ="";//= frmMain.mobjDataAgent.WS_VIPService.WS_SSO_PWSET(frmMain.UserConfigs.LoginID, txtOgnPW.Text, txtCnfPW.Text);
            if (returnMsg == "")
            {
                MessageBox.Show("密碼修改發生異常!") ;
            }
            else
            {
                   string msgcode = returnMsg.Substring(52, 6);
                   if (msgcode == "000000")
                   {
                       frmMain.UserConfigs.PW = txtCnfPW.Text;
                       MessageBox.Show("密碼修改成功!");
                       if (this.Name.Contains("Dialog"))
                       {
                           this.DialogResult = DialogResult.OK;
                       }
                       this.Close();
                   }
                   else
                   {
                       string errormsg = "";
                       if (returnMsg.Length > 63)
                       {
                           errormsg = returnMsg.Substring(63);
                       }
                       if (errormsg.Trim() == "")
                       {
                           errormsg = "登入失敗:錯誤代碼" + msgcode;
                       }
                       MessageBox.Show(errormsg);
                   }
            }
           
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmPassword_Load(object sender, EventArgs e)
        { 
            //dicControls.Add("this", this);
            //if (!this.Name.Contains("Dialog"))
            //{
            //    MYcls.CommonFunction.SetStyle(this.Name, this.Tag.ToString(), dicControls);
            //}
        }

    }
}
