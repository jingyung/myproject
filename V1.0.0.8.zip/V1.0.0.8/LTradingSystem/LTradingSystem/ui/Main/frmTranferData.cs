﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using VIPTradingSystem.MYcls;
namespace VIPTradingSystem.ui.Main
{
    public partial class frmTranferData : BaseForm
    {
        public frmTranferData()
        {
            InitializeComponent();

            dtpDate.Value = DateTime.Now;
        }

        private void btnTime_Click(object sender, EventArgs e)
        {
            try
            {
                string tradedate = dtpDate.Value.ToString("yyyyMMdd");
                string hh = numUnit_HH.Value.ToString("00");
                string mm = numUnit_mm.Value.ToString("00");
                string ss = numUnit_ss.Value.ToString("00");
                string ms = numUnit_fff.Value.ToString("000");
                //mode 1=all 2=time 3=rollback

                frmMain.mobjDataAgent.WS_LService.Timeout = 1000 * 1000;
                bool a = frmMain.mobjDataAgent.WS_LService.WS_TransferData("2", tradedate, hh, mm, ss, ms);
                bool b = frmMain.mobjDataAgent.WS_LService.WS_Upload("2",tradedate, hh, mm, ss, ms);


                if (!a || !b)
                {
                    VIPTradingSystem.MYcls.CommonFunction.ShowWarningMessageBox(this, "轉檔失敗!");
                }
                else
                    VIPTradingSystem.MYcls.CommonFunction.ShowWarningMessageBox(this, "轉檔成功!");
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("UIErrorLog", this.GetType().Name
                       + " " + System.Reflection.MethodInfo.GetCurrentMethod().Name + " " + ex.Message);

            }

        }

        private void btnAll_Click(object sender, EventArgs e)
        {
            try
            {
                string tradedate = dtpDate.Value.ToString("yyyyMMdd");
                string hh = "";
                string mm = "";
                string ss = "";
                string ms = "";
                //mode 1=all 2=time 3=rollback
                frmMain.mobjDataAgent.WS_LService.Timeout = 1000 * 1000;
                bool a = frmMain.mobjDataAgent.WS_LService.WS_TransferData("1", tradedate, hh, mm, ss, ms);
                bool b = frmMain.mobjDataAgent.WS_LService.WS_Upload("1", tradedate, hh, mm, ss, ms);


                if (!a || !b)
                {
                    if (!a && !b)
                        VIPTradingSystem.MYcls.CommonFunction.ShowWarningMessageBox(this, "轉檔與上傳失敗!");
                    if (a && !b)
                        VIPTradingSystem.MYcls.CommonFunction.ShowWarningMessageBox(this, "轉檔成功與上傳失敗!");
                    else
                        VIPTradingSystem.MYcls.CommonFunction.ShowWarningMessageBox(this, "轉檔失敗!");
                }
                else
                    VIPTradingSystem.MYcls.CommonFunction.ShowWarningMessageBox(this, "轉檔成功!");
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("UIErrorLog", this.GetType().Name
                       + " " + System.Reflection.MethodInfo.GetCurrentMethod().Name + " " + ex.Message);

            }
        }

        private void btnRollBack_Click(object sender, EventArgs e)
        {
            try
            {
                string tradedate = dtpDate.Value.ToString("yyyyMMdd");
                string hh = "";
                string mm = "";
                string ss = "";
                string ms = "";
                //mode 1=all 2=time 3=rollback
                frmMain.mobjDataAgent.WS_LService.Timeout = 1000 * 1000;
                bool a = frmMain.mobjDataAgent.WS_LService.WS_TransferData("3", tradedate, hh, mm, ss, ms);



                if (!a)
                {
                    VIPTradingSystem.MYcls.CommonFunction.ShowWarningMessageBox(this, "復原失敗!");
                }
                else
                    VIPTradingSystem.MYcls.CommonFunction.ShowWarningMessageBox(this, "復原成功!");
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("UIErrorLog", this.GetType().Name
                       + " " + System.Reflection.MethodInfo.GetCurrentMethod().Name + " " + ex.Message);

            }
        }
    }
}
