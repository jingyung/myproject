﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using VIPTradingSystem.MYcls;
namespace VIPTradingSystem.ui.Main
{
    public partial class frmPostionSet : BaseForm
    {
        public frmPostionSet()
        {
            InitializeComponent();
            SetGridStyle();
 
            dgvData.SelectionChanged += new EventHandler(dgvData_SelectionChanged);

            byte[] bb = frmMain.mobjDataAgent.WS_LService.WS_AccountList();

            DataSet ds = CommonFunction.SerialUnZip(bb);

            if (ds.Tables.Count > 0)
            {
                this.cmbAccount.DataSource = ds.Tables[0];
                this.cmbAccount.ValueMember = "account";
                this.cmbAccount.DisplayMember = "account";
            }


            bb = frmMain.mobjDataAgent.WS_LService.WS_SecurityExchangeList();

            ds = CommonFunction.SerialUnZip(bb);

            if (ds.Tables.Count > 0)
            {
                this.cmbExchange.DataSource = ds.Tables[0];
                this.cmbExchange.ValueMember = "SecurityExchange";
                this.cmbExchange.DisplayMember = "SecurityExchange";
            }


            DataTable dtleg = new DataTable();
            dtleg.Columns.Add("Text");
            dtleg.Columns.Add("Value");
            dtleg.Rows.Add(new string[] { "", "" });
            dtleg.Rows.Add(new string[] { "+1", "B" });
            dtleg.Rows.Add(new string[] { "-1", "S" });

            cmbLeg1.DataSource = dtleg;
            cmbLeg1.DisplayMember = "Text";
            cmbLeg1.ValueMember = "Value";

            DataTable dtleg2 = dtleg.Copy();

            cmbLeg2.DataSource = dtleg2;
            cmbLeg2.DisplayMember = "Text";
            cmbLeg2.ValueMember = "Value";
        }

        private void SetGridStyle()
        {

            CommonFunction.SetColumnTextStyle(this.dgvData, "SecurityExchange","Exchange", 50, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "account", "account", 50, true, true);


            CommonFunction.SetColumnTextStyle(this.dgvData, "Symbol1", "product1", 50, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "MaturityMonthYear1", "contract1", 50, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "PutOrCall1", "cp1", 50, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "StrikePrice1", "StrikePrice1", 50, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "", "SIDE1", 50, false, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "sign1", "sign1", 50, true, true);


            CommonFunction.SetColumnTextStyle(this.dgvData, "Symbol2", "product2", 50, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "MaturityMonthYear2", "contract2", 50, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "PutOrCall2", "cp2", 50, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "StrikePrice2", "StrikePrice2", 50, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "", "SIDE2", 50, false, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "sign2", "sign2", 50, true, true);


            CommonFunction.SetColumnTextStyle(this.dgvData, "BS", "bs", 50, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "Price", "Price", 50, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "Qty", "Qty", 50, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "Keyin", "Keyin", 100, true, true);




            CommonFunction.SetColumnTextStyle(this.dgvData, "AddUser", "AddUser", 100, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "AddDate", "AddDate", 100, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "UpdUser", "UpdUser", 100, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "UpdDate", "UpdDate", 100, true, true);
            //CommonFunction.SetColumnTextStyle(this.dgvData, "SecurityType", 100, true, true);
        }
        void dgvData_SelectionChanged(object sender, EventArgs e)
        {
            try
            {

                if (this.dgvData.CurrentRow.Index > -1)
                {
                    DataGridViewRow dr = this.dgvData.Rows[this.dgvData.CurrentRow.Index];
                    DataView dv = ((DataTable)this.dgvData.DataSource).DefaultView;
                    DataRowView dvr = dv[this.dgvData.CurrentRow.Index];


                    cmbAccount.Text = dvr["Account"].ToString();
                    cmbExchange.Text = dvr["SecurityExchange"].ToString();
                    txtProduct.Text = dvr["Symbol1"].ToString();
                    txtMaturityMonthYear.Text = dvr["MaturityMonthYear1"].ToString();
                    txtCp.Text = dvr["PutOrCall1"].ToString();
                    txtStrike.Text = dvr["StrikePrice1"].ToString();
                    cmbLeg1.SelectedValue = dvr["SIDE1"].ToString();
                    txtProduct2.Text = dvr["Symbol2"].ToString();
                    txtMaturityMonthYear2.Text = dvr["MaturityMonthYear2"].ToString();
                    txtCp2.Text = dvr["PutOrCall2"].ToString();
                    txtStrike2.Text = dvr["StrikePrice2"].ToString();
                    cmbLeg2.SelectedValue = dvr["SIDE2"].ToString();

                    txtBs.Text = dvr["Bs"].ToString();
                    txtQty.Text = dvr["Qty"].ToString();
                    txtPrice.Text = dvr["Price"].ToString();
                    txtKeyin.Text = dvr["Keyin"].ToString();
                }
            }
            catch (Exception ex)
            {
                try
                {
                    DataAgent._LM.WriteLog("UIErrorLog", this.GetType().Name
                        + " " + System.Reflection.MethodInfo.GetCurrentMethod().Name + " " + ex.Message);
                }
                catch (Exception exe)
                {
                }
            }
        }
        private void btnSearch_Click(object sender, EventArgs e)
        {
            byte[] bb = frmMain.mobjDataAgent.WS_LService.WS_PostionList();

            DataSet ds = CommonFunction.SerialUnZip(bb);

            if (ds.Tables.Count > 0)
            {
                DataTable dt = ds.Tables[0];
                dt.Columns.Add("sign1");
                dt.Columns.Add("sign2");
                dt.Columns["sign1"].Expression = "IIF(SIDE1='B','+1',IIF(SIDE1='S','-1',''))";
                dt.Columns["sign2"].Expression = "IIF(SIDE2='B','+1',IIF(SIDE2='S','-1',''))";

                dgvData.DataSource = dt;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                string SecurityType = "";
                string StrikePrice = "0";
      
                string StrikePrice2 = "0";
                string BS1 = "";
                string BS2 = "";
                txtCp.Text = txtCp.Text.Trim().ToUpper();
                if (txtCp.Text != "C" || txtCp.Text != "P")
                {
                    SecurityType = "FUT";
                }
                else SecurityType = "OPT";
                if (txtStrike.Text.Trim().Length == 0)
                {
                    StrikePrice = "0";
                }
                else StrikePrice = txtStrike.Text.Trim();

                if (cmbLeg1.SelectedIndex > -1 && cmbLeg2.SelectedIndex > -1)
                {
                    BS1 = cmbLeg1.SelectedValue.ToString();
                    BS2 = cmbLeg2.SelectedValue.ToString();
                }
                bool ret = frmMain.mobjDataAgent.WS_LService.WS_updPostionList("ADD","F008000", cmbAccount.Text, cmbExchange.Text, SecurityType
           , txtProduct.Text.Trim(), txtMaturityMonthYear.Text.Trim(), txtCp.Text.Trim(), decimal.Parse(StrikePrice),BS1
            , txtProduct2.Text.Trim(), txtMaturityMonthYear2.Text.Trim(), txtCp2.Text.Trim(), decimal.Parse(StrikePrice2), BS2
           , int.Parse(txtQty.Text.Trim()), decimal.Parse(txtPrice.Text.Trim()), txtBs.Text, txtKeyin.Text);
                if (ret)
                {
                    CommonFunction.ShowWarningMessageBox(this, "存檔成功");
                    btnSearch_Click(this.btnSearch, EventArgs.Empty);
                }
                else
                    CommonFunction.ShowWarningMessageBox(this, "存檔失敗");
            }
            catch (Exception ex)
            {
                try
                {
                    DataAgent._LM.WriteLog("UIErrorLog", this.GetType().Name
                        + " " + System.Reflection.MethodInfo.GetCurrentMethod().Name + " " + ex.Message);
                }
                catch (Exception exe)
                {
                }
            }

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {

            try
            {
                string SecurityType = "";
                string StrikePrice = "0";
                string StrikePrice2 = "0";
                string BS1 = "";
                string BS2 = "";
                txtCp.Text = txtCp.Text.Trim().ToUpper();
                if (txtCp.Text != "C" || txtCp.Text != "P")
                {
                    SecurityType = "FUT";
                }
                else SecurityType = "OPT";
                if (txtStrike.Text.Trim().Length == 0)
                {
                    StrikePrice = "0";
                }
                else StrikePrice = txtStrike.Text.Trim();

                if (cmbLeg1.SelectedIndex > -1 && cmbLeg2.SelectedIndex > -1)
                {
                    BS1 = cmbLeg1.SelectedValue.ToString();
                    BS2 = cmbLeg2.SelectedValue.ToString();
                }

                bool ret = frmMain.mobjDataAgent.WS_LService.WS_updPostionList("UPD", "F008000", cmbAccount.Text, cmbExchange.Text, SecurityType
       , txtProduct.Text.Trim(), txtMaturityMonthYear.Text.Trim(), txtCp.Text.Trim(), decimal.Parse(StrikePrice), BS1
        , txtProduct2.Text.Trim(), txtMaturityMonthYear2.Text.Trim(), txtCp2.Text.Trim(), decimal.Parse(StrikePrice2), BS2
       , int.Parse(txtQty.Text.Trim()), decimal.Parse(txtPrice.Text.Trim()), txtBs.Text, txtKeyin.Text);
                if (ret)
                {
                    CommonFunction.ShowWarningMessageBox(this, "存檔成功");
                    btnSearch_Click(this.btnSearch, EventArgs.Empty);
                }
                else
                    CommonFunction.ShowWarningMessageBox(this, "存檔失敗");
            }
            catch (Exception ex)
            {
                try
                {
                    DataAgent._LM.WriteLog("UIErrorLog", this.GetType().Name
                        + " " + System.Reflection.MethodInfo.GetCurrentMethod().Name + " " + ex.Message);
                }
                catch (Exception exe)
                {
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {

            try
            {
                string SecurityType = "";
                string StrikePrice = "0";
                string StrikePrice2 = "0";
                string BS1 = "";
                string BS2 = "";
                txtCp.Text = txtCp.Text.Trim().ToUpper();
                if (txtCp.Text != "C" || txtCp.Text != "P")
                {
                    SecurityType = "FUT";
                }
                else SecurityType = "OPT";
                if (txtStrike.Text.Trim().Length == 0)
                {
                    StrikePrice = "0";
                }
                else StrikePrice = txtStrike.Text.Trim();
                if (cmbLeg1.SelectedIndex > -1 && cmbLeg2.SelectedIndex > -1)
                {
                    BS1 = cmbLeg1.SelectedValue.ToString();
                    BS2 = cmbLeg2.SelectedValue.ToString();
                }
                bool ret = frmMain.mobjDataAgent.WS_LService.WS_updPostionList("DEL", "F008000", cmbAccount.Text, cmbExchange.Text, SecurityType
    , txtProduct.Text.Trim(), txtMaturityMonthYear.Text.Trim(), txtCp.Text.Trim(), decimal.Parse(StrikePrice), BS1
     , txtProduct2.Text.Trim(), txtMaturityMonthYear2.Text.Trim(), txtCp2.Text.Trim(), decimal.Parse(StrikePrice2), BS2
    , int.Parse(txtQty.Text.Trim()), decimal.Parse(txtPrice.Text.Trim()), txtBs.Text, txtKeyin.Text);

                if (ret)
                {
                    CommonFunction.ShowWarningMessageBox(this, "存檔成功");
                    btnSearch_Click(this.btnSearch, EventArgs.Empty);
                }
                else
                    CommonFunction.ShowWarningMessageBox(this, "存檔失敗");
            }
            catch (Exception ex)
            {
                try
                {
                    DataAgent._LM.WriteLog("UIErrorLog", this.GetType().Name
                        + " " + System.Reflection.MethodInfo.GetCurrentMethod().Name + " " + ex.Message);
                }
                catch (Exception exe)
                {
                }
            }
        }

        private void btnHistory_Click(object sender, EventArgs e)
        {
            byte[] bb = frmMain.mobjDataAgent.WS_LService.WS_PostionList_H();

            DataSet ds = CommonFunction.SerialUnZip(bb);

            if (ds.Tables.Count > 0)
            {
                dgvData.DataSource = ds.Tables[0];
            }
        }


    }
}

