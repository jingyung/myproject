﻿namespace VIPTradingSystem.ui.Main
{
    partial class frmTranferData
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmTranferData));
            this.numUnit_HH = new System.Windows.Forms.NumericUpDown();
            this.numUnit_mm = new System.Windows.Forms.NumericUpDown();
            this.numUnit_fff = new System.Windows.Forms.NumericUpDown();
            this.numUnit_ss = new System.Windows.Forms.NumericUpDown();
            this.btnAll = new System.Windows.Forms.Button();
            this.btnRollBack = new System.Windows.Forms.Button();
            this.btnTime = new System.Windows.Forms.Button();
            this.dtpDate = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.numUnit_HH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUnit_mm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUnit_fff)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUnit_ss)).BeginInit();
            this.SuspendLayout();
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.Images.SetKeyName(0, "sign-out.ico");
            this.imageList1.Images.SetKeyName(1, "sign-in.ico");
            // 
            // numUnit_HH
            // 
            this.numUnit_HH.Location = new System.Drawing.Point(44, 90);
            this.numUnit_HH.Maximum = new decimal(new int[] {
            23,
            0,
            0,
            0});
            this.numUnit_HH.Name = "numUnit_HH";
            this.numUnit_HH.Size = new System.Drawing.Size(60, 25);
            this.numUnit_HH.TabIndex = 4;
            this.numUnit_HH.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numUnit_mm
            // 
            this.numUnit_mm.Location = new System.Drawing.Point(131, 90);
            this.numUnit_mm.Maximum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.numUnit_mm.Name = "numUnit_mm";
            this.numUnit_mm.Size = new System.Drawing.Size(60, 25);
            this.numUnit_mm.TabIndex = 5;
            this.numUnit_mm.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numUnit_fff
            // 
            this.numUnit_fff.Location = new System.Drawing.Point(131, 148);
            this.numUnit_fff.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
            this.numUnit_fff.Name = "numUnit_fff";
            this.numUnit_fff.Size = new System.Drawing.Size(60, 25);
            this.numUnit_fff.TabIndex = 6;
            this.numUnit_fff.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numUnit_ss
            // 
            this.numUnit_ss.Location = new System.Drawing.Point(44, 148);
            this.numUnit_ss.Maximum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.numUnit_ss.Name = "numUnit_ss";
            this.numUnit_ss.Size = new System.Drawing.Size(60, 25);
            this.numUnit_ss.TabIndex = 7;
            this.numUnit_ss.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnAll
            // 
            this.btnAll.Location = new System.Drawing.Point(349, 90);
            this.btnAll.Name = "btnAll";
            this.btnAll.Size = new System.Drawing.Size(75, 23);
            this.btnAll.TabIndex = 8;
            this.btnAll.Text = "All";
            this.btnAll.UseVisualStyleBackColor = true;
            this.btnAll.Click += new System.EventHandler(this.btnAll_Click);
            // 
            // btnRollBack
            // 
            this.btnRollBack.Location = new System.Drawing.Point(349, 146);
            this.btnRollBack.Name = "btnRollBack";
            this.btnRollBack.Size = new System.Drawing.Size(75, 23);
            this.btnRollBack.TabIndex = 9;
            this.btnRollBack.Text = "RollBack";
            this.btnRollBack.UseVisualStyleBackColor = true;
            this.btnRollBack.Click += new System.EventHandler(this.btnRollBack_Click);
            // 
            // btnTime
            // 
            this.btnTime.Location = new System.Drawing.Point(349, 30);
            this.btnTime.Name = "btnTime";
            this.btnTime.Size = new System.Drawing.Size(75, 23);
            this.btnTime.TabIndex = 10;
            this.btnTime.Text = "By Time";
            this.btnTime.UseVisualStyleBackColor = true;
            this.btnTime.Click += new System.EventHandler(this.btnTime_Click);
            // 
            // dtpDate
            // 
            this.dtpDate.Location = new System.Drawing.Point(44, 30);
            this.dtpDate.Name = "dtpDate";
            this.dtpDate.Size = new System.Drawing.Size(155, 25);
            this.dtpDate.TabIndex = 11;
            // 
            // frmTranferData
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(522, 252);
            this.Controls.Add(this.dtpDate);
            this.Controls.Add(this.btnTime);
            this.Controls.Add(this.btnRollBack);
            this.Controls.Add(this.btnAll);
            this.Controls.Add(this.numUnit_ss);
            this.Controls.Add(this.numUnit_fff);
            this.Controls.Add(this.numUnit_mm);
            this.Controls.Add(this.numUnit_HH);
            this.Name = "frmTranferData";
            this.Text = "frmTranferData";
            ((System.ComponentModel.ISupportInitialize)(this.numUnit_HH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUnit_mm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUnit_fff)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUnit_ss)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.NumericUpDown numUnit_HH;
        private System.Windows.Forms.NumericUpDown numUnit_mm;
        private System.Windows.Forms.NumericUpDown numUnit_fff;
        private System.Windows.Forms.NumericUpDown numUnit_ss;
        private System.Windows.Forms.Button btnAll;
        private System.Windows.Forms.Button btnRollBack;
        private System.Windows.Forms.Button btnTime;
        private System.Windows.Forms.DateTimePicker dtpDate;
    }
}