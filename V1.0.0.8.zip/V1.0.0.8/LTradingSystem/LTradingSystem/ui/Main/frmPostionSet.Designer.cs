﻿namespace VIPTradingSystem.ui.Main
{
    partial class frmPostionSet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPostionSet));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.txtStrike = new System.Windows.Forms.TextBox();
            this.txtMaturityMonthYear = new System.Windows.Forms.TextBox();
            this.txtProduct = new System.Windows.Forms.TextBox();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.cmbLeg2 = new System.Windows.Forms.ComboBox();
            this.cmbLeg1 = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtCp2 = new System.Windows.Forms.TextBox();
            this.txtStrike2 = new System.Windows.Forms.TextBox();
            this.txtMaturityMonthYear2 = new System.Windows.Forms.TextBox();
            this.txtProduct2 = new System.Windows.Forms.TextBox();
            this.txtKeyin = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.cmbAccount = new System.Windows.Forms.ComboBox();
            this.btnHistory = new System.Windows.Forms.Button();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtQty = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtBs = new System.Windows.Forms.TextBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtCp = new System.Windows.Forms.TextBox();
            this.cmbExchange = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.dgvData = new com.ddsc.tool.window.DDSCDataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvData)).BeginInit();
            this.SuspendLayout();
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.Images.SetKeyName(0, "sign-out.ico");
            this.imageList1.Images.SetKeyName(1, "sign-in.ico");
            // 
            // txtStrike
            // 
            this.txtStrike.Location = new System.Drawing.Point(80, 160);
            this.txtStrike.MaxLength = 20;
            this.txtStrike.Name = "txtStrike";
            this.txtStrike.Size = new System.Drawing.Size(101, 25);
            this.txtStrike.TabIndex = 13;
            this.txtStrike.Text = "0";
            // 
            // txtMaturityMonthYear
            // 
            this.txtMaturityMonthYear.Location = new System.Drawing.Point(80, 130);
            this.txtMaturityMonthYear.MaxLength = 6;
            this.txtMaturityMonthYear.Name = "txtMaturityMonthYear";
            this.txtMaturityMonthYear.Size = new System.Drawing.Size(101, 25);
            this.txtMaturityMonthYear.TabIndex = 12;
            // 
            // txtProduct
            // 
            this.txtProduct.Location = new System.Drawing.Point(80, 99);
            this.txtProduct.MaxLength = 10;
            this.txtProduct.Name = "txtProduct";
            this.txtProduct.Size = new System.Drawing.Size(101, 25);
            this.txtProduct.TabIndex = 11;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.cmbLeg2);
            this.splitContainer1.Panel1.Controls.Add(this.cmbLeg1);
            this.splitContainer1.Panel1.Controls.Add(this.label11);
            this.splitContainer1.Panel1.Controls.Add(this.txtCp2);
            this.splitContainer1.Panel1.Controls.Add(this.txtStrike2);
            this.splitContainer1.Panel1.Controls.Add(this.txtMaturityMonthYear2);
            this.splitContainer1.Panel1.Controls.Add(this.txtProduct2);
            this.splitContainer1.Panel1.Controls.Add(this.txtKeyin);
            this.splitContainer1.Panel1.Controls.Add(this.label10);
            this.splitContainer1.Panel1.Controls.Add(this.label9);
            this.splitContainer1.Panel1.Controls.Add(this.cmbAccount);
            this.splitContainer1.Panel1.Controls.Add(this.btnHistory);
            this.splitContainer1.Panel1.Controls.Add(this.txtPrice);
            this.splitContainer1.Panel1.Controls.Add(this.label8);
            this.splitContainer1.Panel1.Controls.Add(this.txtQty);
            this.splitContainer1.Panel1.Controls.Add(this.label7);
            this.splitContainer1.Panel1.Controls.Add(this.txtBs);
            this.splitContainer1.Panel1.Controls.Add(this.btnSearch);
            this.splitContainer1.Panel1.Controls.Add(this.txtCp);
            this.splitContainer1.Panel1.Controls.Add(this.txtStrike);
            this.splitContainer1.Panel1.Controls.Add(this.txtMaturityMonthYear);
            this.splitContainer1.Panel1.Controls.Add(this.txtProduct);
            this.splitContainer1.Panel1.Controls.Add(this.cmbExchange);
            this.splitContainer1.Panel1.Controls.Add(this.label6);
            this.splitContainer1.Panel1.Controls.Add(this.label5);
            this.splitContainer1.Panel1.Controls.Add(this.label4);
            this.splitContainer1.Panel1.Controls.Add(this.label3);
            this.splitContainer1.Panel1.Controls.Add(this.label2);
            this.splitContainer1.Panel1.Controls.Add(this.label1);
            this.splitContainer1.Panel1.Controls.Add(this.btnDelete);
            this.splitContainer1.Panel1.Controls.Add(this.btnUpdate);
            this.splitContainer1.Panel1.Controls.Add(this.btnAdd);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.dgvData);
            this.splitContainer1.Size = new System.Drawing.Size(823, 452);
            this.splitContainer1.SplitterDistance = 240;
            this.splitContainer1.TabIndex = 1;
            // 
            // cmbLeg2
            // 
            this.cmbLeg2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbLeg2.FormattingEnabled = true;
            this.cmbLeg2.Location = new System.Drawing.Point(431, 99);
            this.cmbLeg2.Name = "cmbLeg2";
            this.cmbLeg2.Size = new System.Drawing.Size(80, 23);
            this.cmbLeg2.TabIndex = 32;
            // 
            // cmbLeg1
            // 
            this.cmbLeg1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbLeg1.FormattingEnabled = true;
            this.cmbLeg1.Location = new System.Drawing.Point(346, 99);
            this.cmbLeg1.Name = "cmbLeg1";
            this.cmbLeg1.Size = new System.Drawing.Size(79, 23);
            this.cmbLeg1.TabIndex = 31;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(303, 102);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(24, 15);
            this.label11.TabIndex = 30;
            this.label11.Text = "+/-";
            // 
            // txtCp2
            // 
            this.txtCp2.Location = new System.Drawing.Point(431, 61);
            this.txtCp2.MaxLength = 1;
            this.txtCp2.Name = "txtCp2";
            this.txtCp2.Size = new System.Drawing.Size(80, 25);
            this.txtCp2.TabIndex = 29;
            // 
            // txtStrike2
            // 
            this.txtStrike2.Location = new System.Drawing.Point(188, 160);
            this.txtStrike2.MaxLength = 20;
            this.txtStrike2.Name = "txtStrike2";
            this.txtStrike2.Size = new System.Drawing.Size(101, 25);
            this.txtStrike2.TabIndex = 28;
            // 
            // txtMaturityMonthYear2
            // 
            this.txtMaturityMonthYear2.Location = new System.Drawing.Point(187, 130);
            this.txtMaturityMonthYear2.MaxLength = 6;
            this.txtMaturityMonthYear2.Name = "txtMaturityMonthYear2";
            this.txtMaturityMonthYear2.Size = new System.Drawing.Size(101, 25);
            this.txtMaturityMonthYear2.TabIndex = 27;
            // 
            // txtProduct2
            // 
            this.txtProduct2.Location = new System.Drawing.Point(187, 99);
            this.txtProduct2.MaxLength = 10;
            this.txtProduct2.Name = "txtProduct2";
            this.txtProduct2.Size = new System.Drawing.Size(101, 25);
            this.txtProduct2.TabIndex = 26;
            // 
            // txtKeyin
            // 
            this.txtKeyin.Location = new System.Drawing.Point(588, 183);
            this.txtKeyin.MaxLength = 20;
            this.txtKeyin.Name = "txtKeyin";
            this.txtKeyin.Size = new System.Drawing.Size(98, 25);
            this.txtKeyin.TabIndex = 25;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(536, 187);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(41, 15);
            this.label10.TabIndex = 24;
            this.label10.Text = "Keyin";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(12, 21);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(54, 15);
            this.label9.TabIndex = 23;
            this.label9.Text = "Account";
            // 
            // cmbAccount
            // 
            this.cmbAccount.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbAccount.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbAccount.FormattingEnabled = true;
            this.cmbAccount.Location = new System.Drawing.Point(80, 24);
            this.cmbAccount.Name = "cmbAccount";
            this.cmbAccount.Size = new System.Drawing.Size(101, 23);
            this.cmbAccount.TabIndex = 22;
            // 
            // btnHistory
            // 
            this.btnHistory.Location = new System.Drawing.Point(716, 133);
            this.btnHistory.Name = "btnHistory";
            this.btnHistory.Size = new System.Drawing.Size(75, 23);
            this.btnHistory.TabIndex = 21;
            this.btnHistory.Text = "History";
            this.btnHistory.UseVisualStyleBackColor = true;
            this.btnHistory.Click += new System.EventHandler(this.btnHistory_Click);
            // 
            // txtPrice
            // 
            this.txtPrice.Location = new System.Drawing.Point(588, 144);
            this.txtPrice.MaxLength = 20;
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new System.Drawing.Size(98, 25);
            this.txtPrice.TabIndex = 20;
            this.txtPrice.Text = "0";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(541, 148);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(36, 15);
            this.label8.TabIndex = 19;
            this.label8.Text = "Price";
            // 
            // txtQty
            // 
            this.txtQty.Location = new System.Drawing.Point(588, 102);
            this.txtQty.MaxLength = 5;
            this.txtQty.Name = "txtQty";
            this.txtQty.Size = new System.Drawing.Size(98, 25);
            this.txtQty.TabIndex = 18;
            this.txtQty.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(541, 106);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(28, 15);
            this.label7.TabIndex = 17;
            this.label7.Text = "Qty";
            // 
            // txtBs
            // 
            this.txtBs.Location = new System.Drawing.Point(588, 63);
            this.txtBs.MaxLength = 1;
            this.txtBs.Name = "txtBs";
            this.txtBs.Size = new System.Drawing.Size(98, 25);
            this.txtBs.TabIndex = 16;
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(716, 21);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 15;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtCp
            // 
            this.txtCp.Location = new System.Drawing.Point(347, 61);
            this.txtCp.MaxLength = 1;
            this.txtCp.Name = "txtCp";
            this.txtCp.Size = new System.Drawing.Size(78, 25);
            this.txtCp.TabIndex = 14;
            // 
            // cmbExchange
            // 
            this.cmbExchange.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbExchange.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbExchange.FormattingEnabled = true;
            this.cmbExchange.Location = new System.Drawing.Point(80, 63);
            this.cmbExchange.Name = "cmbExchange";
            this.cmbExchange.Size = new System.Drawing.Size(101, 23);
            this.cmbExchange.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(541, 67);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(21, 15);
            this.label6.TabIndex = 8;
            this.label6.Text = "Bs";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(318, 63);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(23, 15);
            this.label5.TabIndex = 7;
            this.label5.Text = "Cp";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(36, 163);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 15);
            this.label4.TabIndex = 6;
            this.label4.Text = "Strike";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(22, 136);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 15);
            this.label3.TabIndex = 5;
            this.label3.Text = "contract";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(23, 102);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 15);
            this.label2.TabIndex = 4;
            this.label2.Text = "Product";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 15);
            this.label1.TabIndex = 3;
            this.label1.Text = "Exchange";
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(716, 104);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 2;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(716, 75);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(75, 23);
            this.btnUpdate.TabIndex = 1;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(716, 48);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 0;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // dgvData
            // 
            this.dgvData.AllowUserToAddRows = false;
            this.dgvData.AllowUserToDeleteRows = false;
            this.dgvData.AllowUserToOrderColumns = true;
            this.dgvData.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.PowderBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvData.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Bisque;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvData.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvData.EnableHeadersVisualStyles = false;
            this.dgvData.Location = new System.Drawing.Point(0, 0);
            this.dgvData.MultiSelect = false;
            this.dgvData.Name = "dgvData";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.Bisque;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvData.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvData.RowHeadersVisible = false;
            this.dgvData.RowTemplate.Height = 27;
            this.dgvData.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvData.Size = new System.Drawing.Size(823, 208);
            this.dgvData.TabIndex = 0;
            this.dgvData.Tag = ((object)(resources.GetObject("dgvData.Tag")));
            // 
            // frmPostionSet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(823, 452);
            this.Controls.Add(this.splitContainer1);
            this.Name = "frmPostionSet";
            this.Text = "frmPostionSet";
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvData)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txtStrike;
        private System.Windows.Forms.TextBox txtMaturityMonthYear;
        private System.Windows.Forms.TextBox txtProduct;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtCp;
        private System.Windows.Forms.ComboBox cmbExchange;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnAdd;
        private com.ddsc.tool.window.DDSCDataGridView dgvData;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtQty;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtBs;
        private System.Windows.Forms.Button btnHistory;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cmbAccount;
        private System.Windows.Forms.TextBox txtKeyin;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtStrike2;
        private System.Windows.Forms.TextBox txtMaturityMonthYear2;
        private System.Windows.Forms.TextBox txtProduct2;
        private System.Windows.Forms.TextBox txtCp2;
        private System.Windows.Forms.ComboBox cmbLeg2;
        private System.Windows.Forms.ComboBox cmbLeg1;
        private System.Windows.Forms.Label label11;
    }
}