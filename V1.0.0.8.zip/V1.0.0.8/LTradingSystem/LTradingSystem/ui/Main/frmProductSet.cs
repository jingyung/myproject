﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using VIPTradingSystem.MYcls;
namespace VIPTradingSystem.ui.Main
{
    public partial class frmProductSet : BaseForm
    {

        public frmProductSet()
        {
            InitializeComponent();

            SetGridStyle();
            //this.dgvData.DefaultCellStyle.SelectionBackColor = Color.AliceBlue;
            dgvData.SelectionChanged += new EventHandler(dgvData_SelectionChanged);




            byte[] bb = frmMain.mobjDataAgent.WS_LService.WS_SecurityExchangeList();

            DataSet ds = CommonFunction.SerialUnZip(bb);

            if (ds.Tables.Count > 0)
            {
                this.cmbExchange.DataSource = ds.Tables[0];
                this.cmbExchange.ValueMember = "SecurityExchange";
                this.cmbExchange.DisplayMember = "SecurityExchange";
            }

            bb = frmMain.mobjDataAgent.WS_LService.WS_gwList();

            ds = CommonFunction.SerialUnZip(bb);

            if (ds.Tables.Count > 0)
            {
                this.cmbGw.DataSource = ds.Tables[0];
                this.cmbGw.ValueMember = "gw";
                this.cmbGw.DisplayMember = "gw";
            }

            DataTable dtleg = new DataTable();
            dtleg.Columns.Add("Text");
            dtleg.Columns.Add("Value");
            dtleg.Rows.Add(new string[] { "", "" });
            dtleg.Rows.Add(new string[] { "+1", "B" });
            dtleg.Rows.Add(new string[] { "-1", "S" });

            cmbLeg1.DataSource = dtleg;
            cmbLeg1.DisplayMember = "Text";
            cmbLeg1.ValueMember = "Value";

            DataTable dtleg2 = dtleg.Copy();

            cmbLeg2.DataSource = dtleg2;
            cmbLeg2.DisplayMember = "Text";
            cmbLeg2.ValueMember = "Value";

        }
        private void SetGridStyle()
        {
            CommonFunction.SetColumnTextStyle(this.dgvData, "SecurityExchange", "Exchange", 50, true, true);

            CommonFunction.SetColumnTextStyle(this.dgvData, "Symbol1", "product1", 50, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "MaturityMonthYear1", "contract1", 50, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "PutOrCall1", "cp1", 50, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "StrikePrice1", "StrikePrice1", 50, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "", "BS1", 50, false, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "sign1", "sign1", 50, true, true);

            CommonFunction.SetColumnTextStyle(this.dgvData, "Symbol2", "product2", 50, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "MaturityMonthYear2", "contract2", 50, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "PutOrCall2", "cp2", 50, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "StrikePrice2", "StrikePrice2", 50, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "", "BS2", 50, false, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "sign2", "sign2", 50, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "GW", "GW", 50, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "locator", "locator", 50, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "code", "code", 50, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "AddUser", "AddUser", 100, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "AddDate", "AddDate", 100, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "UpdUser", "UpdUser", 100, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "UpdDate", "UpdDate", 100, true, true);
            //CommonFunction.SetColumnTextStyle(this.dgvData, "SecurityType", 100, true, true);
        }
        void dgvData_SelectionChanged(object sender, EventArgs e)
        {
            try
            {

                if (this.dgvData.CurrentRow.Index > -1)
                {
                    DataGridViewRow dr = this.dgvData.Rows[this.dgvData.CurrentRow.Index];
                    DataView dv = ((DataTable)this.dgvData.DataSource).DefaultView;
                    DataRowView dvr = dv[this.dgvData.CurrentRow.Index];
                    cmbExchange.Text = dvr["SecurityExchange"].ToString();
                    txtProduct.Text = dvr["Symbol1"].ToString();
                    txtMaturityMonthYear.Text = dvr["MaturityMonthYear1"].ToString();
                    txtCp.Text = dvr["PutOrCall1"].ToString();
                    txtStrike.Text = dvr["StrikePrice1"].ToString();
                    cmbLeg1.SelectedValue = dvr["BS1"].ToString();

                    txtProduct2.Text = dvr["Symbol2"].ToString();
                    txtMaturityMonthYear2.Text = dvr["MaturityMonthYear2"].ToString();
                    txtCp2.Text = dvr["PutOrCall2"].ToString();
                    txtStrike2.Text = dvr["StrikePrice2"].ToString();

                    cmbLeg2.SelectedValue = dvr["BS2"].ToString();
                    cmbGw.Text = dvr["Gw"].ToString();

                    txtLocator.Text = dvr["locator"].ToString();

                    txtCode.Text = dvr["code"].ToString();
                }
            }
            catch (Exception ex)
            {
                try
                {
                    DataAgent._LM.WriteLog("UIErrorLog", this.GetType().Name
                        + " " + System.Reflection.MethodInfo.GetCurrentMethod().Name + " " + ex.Message);
                }
                catch (Exception exe)
                {
                }
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                //if (cmbLeg1.SelectedIndex != 0 || cmbLeg2.SelectedIndex != 0)
                //{
                //    CommonFunction.ShowWarningMessageBox(this, "商品輸入錯誤!");
                //    return;
                //}

                if (txtProduct.Text.Trim().Length == 0 || txtMaturityMonthYear.Text.Trim().Length == 0)
                {
                    CommonFunction.ShowWarningMessageBox(this, "product 或 contract 輸入錯誤!");
                    return;
                }
                int Locator = 0;


                try
                {
                    Locator = int.Parse(txtLocator.Text.Trim());
                }
                catch (Exception ex)
                {
                    CommonFunction.ShowWarningMessageBox(this, "Locator 請輸入數值!");
                }


                string SecurityType = "";
                string StrikePrice = "0";
                string StrikePrice2 = "0";
                string BS1 = "";
                string BS2 = "";
                txtCp.Text = txtCp.Text.Trim().ToUpper();
                if (txtCp.Text != "C" || txtCp.Text != "P")
                {
                    SecurityType = "FUT";
                }
                else SecurityType = "OPT";
                if (txtStrike.Text.Trim().Length == 0)
                {
                    StrikePrice = "0";
                }
                else StrikePrice = txtStrike.Text.Trim();
                //if (cmbLeg1.SelectedIndex > -1 && cmbLeg2.SelectedIndex > -1)
                //{
                //    BS1 = cmbLeg1.SelectedValue.ToString();
                //    BS2 = cmbLeg2.SelectedValue.ToString();
                //}

                DataTable dt = (DataTable)dgvData.DataSource;
                if (dt != null)
                    foreach (DataRow dr in dt.Rows)
                    {
                        if (txtProduct.Text.Trim() == dr["Symbol1"].ToString().Trim()
                            && txtMaturityMonthYear.Text.Trim() == dr["MaturityMonthYear1"].ToString().Trim()
                            )
                        {
                            if (dr["locator"].ToString().Trim() != Locator.ToString())
                            {
                                CommonFunction.ShowWarningMessageBox(this, "locator 輸入錯誤");
                                return;
                            }
                        }
                        if (dr["Symbol2"].ToString().Trim().Length > 0)
                        {
                            if (txtProduct.Text.Trim() == dr["Symbol2"].ToString().Trim()
                                  && txtMaturityMonthYear.Text.Trim() == dr["MaturityMonthYear2"].ToString().Trim()
                                )
                            {
                                if (dr["locator"].ToString().Trim() != Locator.ToString())
                                {
                                    CommonFunction.ShowWarningMessageBox(this, "locator 輸入錯誤");
                                    return;
                                }
                            }
                        }


                    }


                bool ret = frmMain.mobjDataAgent.WS_LService.WS_updSecurityList("ADD", cmbExchange.Text, SecurityType
           , txtProduct.Text.Trim(), txtMaturityMonthYear.Text.Trim(), txtCp.Text.Trim(), StrikePrice
           , BS1
           , txtProduct2.Text.Trim(), txtMaturityMonthYear2.Text.Trim(), txtCp2.Text.Trim(), StrikePrice2, BS2

           , cmbGw.Text, Locator, txtCode.Text.Trim());
                if (ret)
                {
                    CommonFunction.ShowWarningMessageBox(this, "存檔成功");
                    btnSearch_Click(this.btnSearch, EventArgs.Empty);
                }
                else
                    CommonFunction.ShowWarningMessageBox(this, "存檔失敗");
            }
            catch (Exception ex)
            {
                try
                {
                    DataAgent._LM.WriteLog("UIErrorLog", this.GetType().Name
                        + " " + System.Reflection.MethodInfo.GetCurrentMethod().Name + " " + ex.Message);
                }
                catch (Exception exe)
                {
                }
            }


        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {

                int Locator = 0;
                try
                {
                    Locator = int.Parse(txtLocator.Text.Trim());
                }
                catch (Exception ex)
                {
                    CommonFunction.ShowWarningMessageBox(this, "Locator 請輸入數值!");
                }


                string SecurityType = "";
                string StrikePrice = "0";
                string StrikePrice2 = "0";
                string BS1 = "";
                string BS2 = "";
                txtCp.Text = txtCp.Text.Trim().ToUpper();
                if (txtCp.Text != "C" || txtCp.Text != "P")
                {
                    SecurityType = "FUT";
                }
                else SecurityType = "OPT";
                if (txtStrike.Text.Trim().Length == 0)
                {
                    StrikePrice = "0";
                }
                else StrikePrice = txtStrike.Text.Trim();


                if (cmbLeg1.SelectedIndex > -1 && cmbLeg2.SelectedIndex > -1)
                {
                    BS1 = cmbLeg1.SelectedValue.ToString();
                    BS2 = cmbLeg2.SelectedValue.ToString();
                }
                bool ret = frmMain.mobjDataAgent.WS_LService.WS_updSecurityList("UPD", cmbExchange.Text, SecurityType
             , txtProduct.Text.Trim(), txtMaturityMonthYear.Text.Trim(), txtCp.Text.Trim(), StrikePrice
           , BS1
           , txtProduct2.Text.Trim(), txtMaturityMonthYear2.Text.Trim(), txtCp2.Text.Trim(), StrikePrice2, BS2

           , cmbGw.Text, Locator, txtCode.Text.Trim());
                if (ret)
                {
                    CommonFunction.ShowWarningMessageBox(this, "存檔成功");
                    btnSearch_Click(this.btnSearch, EventArgs.Empty);
                }
                else
                    CommonFunction.ShowWarningMessageBox(this, "存檔失敗");

            }
            catch (Exception ex)
            {
                try
                {
                    DataAgent._LM.WriteLog("UIErrorLog", this.GetType().Name
                        + " " + System.Reflection.MethodInfo.GetCurrentMethod().Name + " " + ex.Message);
                }
                catch (Exception exe)
                {
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                int Locator = 0;
                try
                {
                    Locator = int.Parse(txtLocator.Text.Trim());
                }
                catch (Exception ex)
                {
                    CommonFunction.ShowWarningMessageBox(this, "Locator 請輸入數值!");
                }


                string SecurityType = "";
                string StrikePrice = "0";
                string StrikePrice2 = "0";
                string BS1 = "";
                string BS2 = "";
                txtCp.Text = txtCp.Text.Trim().ToUpper();
                if (txtCp.Text != "C" || txtCp.Text != "P")
                {
                    SecurityType = "FUT";
                }
                else SecurityType = "OPT";
                if (txtStrike.Text.Trim().Length == 0)
                {
                    StrikePrice = "0";
                }
                else StrikePrice = txtStrike.Text.Trim();
                if (cmbLeg1.SelectedIndex > -1 && cmbLeg2.SelectedIndex > -1)
                {
                    BS1 = cmbLeg1.SelectedValue.ToString();
                    BS2 = cmbLeg2.SelectedValue.ToString();
                }
                bool ret = frmMain.mobjDataAgent.WS_LService.WS_updSecurityList("DEL", cmbExchange.Text, SecurityType
           , txtProduct.Text.Trim(), txtMaturityMonthYear.Text.Trim(), txtCp.Text.Trim(), StrikePrice
           , BS1
           , txtProduct2.Text.Trim(), txtMaturityMonthYear2.Text.Trim(), txtCp2.Text.Trim(), StrikePrice2, BS2

           , cmbGw.Text, Locator, txtCode.Text.Trim());
                if (ret)
                {
                    CommonFunction.ShowWarningMessageBox(this, "存檔成功");
                    btnSearch_Click(this.btnSearch, EventArgs.Empty);
                }
                else
                    CommonFunction.ShowWarningMessageBox(this, "存檔失敗");

            }
            catch (Exception ex)
            {
                try
                {
                    DataAgent._LM.WriteLog("UIErrorLog", this.GetType().Name
                        + " " + System.Reflection.MethodInfo.GetCurrentMethod().Name + " " + ex.Message);
                }
                catch (Exception exe)
                {
                }
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            byte[] bb = frmMain.mobjDataAgent.WS_LService.WS_SecurityList();

            DataSet ds = CommonFunction.SerialUnZip(bb);

            if (ds.Tables.Count > 0)
            {
                DataTable dt = ds.Tables[0];
                dt.Columns.Add("sign1");
                dt.Columns.Add("sign2");
                dt.Columns["sign1"].Expression = "IIF(BS1='B','+1',IIF(BS1='S','-1',''))";
                dt.Columns["sign2"].Expression = "IIF(BS2='B','+1',IIF(BS2='S','-1',''))";

                dgvData.DataSource = dt;

            }
        }

        private void btnAddSpread_Click(object sender, EventArgs e)
        {
            try
            {
                if (cmbLeg1.SelectedIndex == 0 || cmbLeg2.SelectedIndex == 0)
                {
                    CommonFunction.ShowWarningMessageBox(this, "商品輸入錯誤!");
                    return;
                }

                if (txtProduct.Text.Trim().Length == 0 || txtMaturityMonthYear.Text.Trim().Length == 0)
                {
                    CommonFunction.ShowWarningMessageBox(this, "product 或 contract 輸入錯誤!");
                    return;
                }
                if (txtProduct2.Text.Trim().Length == 0 || txtMaturityMonthYear2.Text.Trim().Length == 0)
                {
                    CommonFunction.ShowWarningMessageBox(this, "product 或 contract 輸入錯誤!");
                    return;
                }

                int Locator = 0;

                try
                {
                    Locator = int.Parse(txtLocator.Text.Trim());
                }
                catch (Exception ex)
                {
                    CommonFunction.ShowWarningMessageBox(this, "Locator 請輸入數值!");
                }




                string SecurityType = "";
                string StrikePrice = "0";
                string StrikePrice2 = "0";
                string BS1 = "";
                string BS2 = "";
                txtCp.Text = txtCp.Text.Trim().ToUpper();
                if (txtCp.Text != "C" || txtCp.Text != "P")
                {
                    SecurityType = "FUT";
                }
                else SecurityType = "OPT";
                if (txtStrike.Text.Trim().Length == 0)
                {
                    StrikePrice = "0";
                }
                else StrikePrice = txtStrike.Text.Trim();
                if (cmbLeg1.SelectedIndex != 0 && cmbLeg2.SelectedIndex != 0)
                {
                    BS1 = cmbLeg1.SelectedValue.ToString();
                    BS2 = cmbLeg2.SelectedValue.ToString();
                }

                DataTable dt = (DataTable)dgvData.DataSource;
                //判斷單隻腳商品是否有先建立，如果沒有SPEAD商品就不能建立
                bool leg1flag = false;
                bool leg2flag = false;
                foreach (DataRow dr in dt.Rows)
                {
                    if (txtProduct.Text.Trim() == dr["Symbol1"].ToString().Trim()
                        && txtMaturityMonthYear.Text.Trim() == dr["MaturityMonthYear1"].ToString().Trim()
                        )
                    {
                        if (dr["locator"].ToString().Trim() != Locator.ToString())
                        {
                            CommonFunction.ShowWarningMessageBox(this, "locator 輸入錯誤");
                            return;
                        }
                        leg1flag = true;
                    }
                    if (dr["Symbol2"].ToString().Trim().Length > 0)
                    {
                        if (txtProduct.Text.Trim() == dr["Symbol2"].ToString().Trim()
                              && txtMaturityMonthYear.Text.Trim() == dr["MaturityMonthYear2"].ToString().Trim()
                            )
                        {
                            if (dr["locator"].ToString().Trim() != Locator.ToString())
                            {
                                CommonFunction.ShowWarningMessageBox(this, "locator 輸入錯誤");
                                return;
                            }
                        }
                    }



                    if (txtProduct2.Text.Trim() == dr["Symbol1"].ToString().Trim()
                       && txtMaturityMonthYear2.Text.Trim() == dr["MaturityMonthYear1"].ToString().Trim()
                       )
                    {
                        if (dr["locator"].ToString().Trim() != Locator.ToString())
                        {
                            CommonFunction.ShowWarningMessageBox(this, "locator 輸入錯誤");
                            return;
                        }
                        leg2flag = true;
                    }
                    if (dr["Symbol2"].ToString().Trim().Length > 0)
                    {
                        if (txtProduct2.Text.Trim() == dr["Symbol2"].ToString().Trim()
                              && txtMaturityMonthYear2.Text.Trim() == dr["MaturityMonthYear2"].ToString().Trim()
                            )
                        {
                            if (dr["locator"].ToString().Trim() != Locator.ToString())
                            {
                                CommonFunction.ShowWarningMessageBox(this, "locator 輸入錯誤");
                                return;
                            }
                        }
                    }


                }
                if (!leg2flag || !leg1flag)
                {
                    CommonFunction.ShowWarningMessageBox(this, "請新增單式商品");
                    return;
                }

                bool ret = frmMain.mobjDataAgent.WS_LService.WS_updSecurityList("ADD", cmbExchange.Text, SecurityType
           , txtProduct.Text.Trim(), txtMaturityMonthYear.Text.Trim(), txtCp.Text.Trim(), StrikePrice
           , BS1
           , txtProduct2.Text.Trim(), txtMaturityMonthYear2.Text.Trim(), txtCp2.Text.Trim(), StrikePrice2, BS2

           , cmbGw.Text, Locator, txtCode.Text.Trim());
                if (ret)
                {
                    CommonFunction.ShowWarningMessageBox(this, "存檔成功");
                    btnSearch_Click(this.btnSearch, EventArgs.Empty);
                }
                else
                    CommonFunction.ShowWarningMessageBox(this, "存檔失敗");
            }
            catch (Exception ex)
            {
                try
                {
                    DataAgent._LM.WriteLog("UIErrorLog", this.GetType().Name
                        + " " + System.Reflection.MethodInfo.GetCurrentMethod().Name + " " + ex.Message);
                }
                catch (Exception exe)
                {
                }
            }

        }




    }
}
