﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using VIPTradingSystem.MYcls;
namespace VIPTradingSystem.ui.Main
{
    public partial class frmAccountSet :BaseForm
    {
        public frmAccountSet()
        {
            InitializeComponent();
            SetGridStyle();
            //this.dgvData.DefaultCellStyle.SelectionBackColor = Color.AliceBlue;
            dgvData.SelectionChanged += new EventHandler(dgvData_SelectionChanged);
        }

        private void SetGridStyle()
        {

            CommonFunction.SetColumnTextStyle(this.dgvData, "Account", "Account", 100, true, true);

            CommonFunction.SetColumnTextStyle(this.dgvData, "name", "name", 100, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "BrokerId", "BrokerId", 100, false, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "InvestorActno", "InvestorActno", 100, false, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "AddUser", "AddUser", 100, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "AddDate", "AddDate", 100, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "UpdUser", "UpdUser", 100, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "UpdDate", "UpdDate", 100, true, true);
        
        }
         void dgvData_SelectionChanged(object sender, EventArgs e)
        {
            try
            {

                if (this.dgvData.CurrentRow.Index > -1)
                {
                    DataGridViewRow dr = this.dgvData.Rows[this.dgvData.CurrentRow.Index];
                    DataView dv = ((DataTable)this.dgvData.DataSource).DefaultView;
                    DataRowView dvr = dv[this.dgvData.CurrentRow.Index];

                    txtAccount.Text = dvr["Account"].ToString();
                    txtName.Text = dvr["Name"].ToString();
 
                }
            }
            catch (Exception ex)
            {
                try
                {
                    DataAgent._LM.WriteLog("UIErrorLog", this.GetType().Name
                        + " " + System.Reflection.MethodInfo.GetCurrentMethod().Name + " " + ex.Message);
                }
                catch (Exception exe)
                {
                }
            }
        }


        private void btnSearch_Click(object sender, EventArgs e)
        {
            byte[] bb = frmMain.mobjDataAgent.WS_LService.WS_AccountList();

            DataSet ds = CommonFunction.SerialUnZip(bb);

            if (ds.Tables.Count > 0)
            {
                dgvData.DataSource = ds.Tables[0];
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {

            bool ret = frmMain.mobjDataAgent.WS_LService.WS_updAccountList("ADD", txtAccount.Text.Trim()
               , txtName.Text.Trim()
         );
            if (ret)
            {
                CommonFunction.ShowWarningMessageBox(this, "存檔成功");
                btnSearch_Click(this.btnSearch, EventArgs.Empty);
            }
            else
                CommonFunction.ShowWarningMessageBox(this, "存檔失敗");
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {

                bool ret = frmMain.mobjDataAgent.WS_LService.WS_updAccountList("UPD", txtAccount.Text.Trim()
                   , txtName.Text.Trim()
             );
                if (ret)
                {
                    CommonFunction.ShowWarningMessageBox(this, "存檔成功");
                    btnSearch_Click(this.btnSearch, EventArgs.Empty);
                }
                else
                    CommonFunction.ShowWarningMessageBox(this, "存檔失敗");

            }
            catch (Exception ex)
            {
                try
                {
                    DataAgent._LM.WriteLog("UIErrorLog", this.GetType().Name
                        + " " + System.Reflection.MethodInfo.GetCurrentMethod().Name + " " + ex.Message);
                }
                catch (Exception exe)
                {
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {


                bool ret = frmMain.mobjDataAgent.WS_LService.WS_updAccountList("DEL", txtAccount.Text.Trim()
                   ,txtName.Text.Trim()
             );
                if (ret)
                {
                    CommonFunction.ShowWarningMessageBox(this, "存檔成功");
                    btnSearch_Click(this.btnSearch, EventArgs.Empty);
                }
                else
                    CommonFunction.ShowWarningMessageBox(this, "存檔失敗");

            }
            catch (Exception ex)
            {
                try
                {
                    DataAgent._LM.WriteLog("UIErrorLog", this.GetType().Name
                        + " " + System.Reflection.MethodInfo.GetCurrentMethod().Name + " " + ex.Message);
                }
                catch (Exception exe)
                {
                }
            }
        }
    }
}
