﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace VIPTradingSystem.ui.Order
{
    public partial class frmTimeSet : Form
    {
      
        public DateTime seltime  ;
        public frmTimeSet()
        {
            InitializeComponent();
            DateTime tmp= DateTime.Now.AddSeconds(60);
            cal.TodayDate = tmp;
            time.Value = tmp;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {



            seltime = new DateTime(cal.SelectionEnd.Year, cal.SelectionEnd.Month, cal.SelectionEnd.Day
                , time.Value.Hour, time.Value.Minute, time.Value.Second);
            this.DialogResult = System.Windows.Forms.DialogResult.OK;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
        }
    }
}
