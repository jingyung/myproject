﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using VIPTradingSystem.MYcls;
namespace VIPTradingSystem.ui.Order
{
    public partial class frmTrade : BaseForm
    {
        private string SecurityExchange { set; get; }
        private string SecurityType1 { set; get; }
        private string Symbol1 { set; get; }
        private string MaturityMonthYear1 { set; get; }
        private string Cp1 { set; get; }
        private decimal Strike1 { set; get; }

        private string Side1 { set; get; }
        private string SecurityType2 { set; get; }
        private string Symbol2 { set; get; }
        private string MaturityMonthYear2 { set; get; }
        private string Cp2 { set; get; }
        private decimal Strike2 { set; get; }
        private string Side2 { set; get; }


        public string Type { get; set; }
        public int TotalQty { get; set; }
        public DateTime BeginDateTime { get; set; }
        public DateTime EndDateTime { get; set; }
        public int Interval { get; set; }
        public int Qty { get; set; }
        public decimal Ratio { get; set; }


        DateTime _atTime;
        DateTime _untilTime;

        public frmTrade()
        {
            InitializeComponent();



            DataTable dtTIF = new DataTable();
            dtTIF.Columns.Add("value");
            dtTIF.Columns.Add("name");
            dtTIF.Rows.Add(new string[] { "N", "None" });
            dtTIF.Rows.Add(new string[] { "0", "Day" });
            //dtTIF.Rows.Add(new string[] { "1", "GTC" });
            // dtTIF.Rows.Add(new string[] { "2", "OPG" });
            dtTIF.Rows.Add(new string[] { "3", "IOC" });
            dtTIF.Rows.Add(new string[] { "4", "FOK" });
            // dtTIF.Rows.Add(new string[] { "6", "GTD" });
            cmbTIF.DataSource = dtTIF;
            cmbTIF.DisplayMember = "name";
            cmbTIF.ValueMember = "value";
            cmbTIF.SelectedIndex = 1;

            DataTable dtOrderType = new DataTable();
            dtOrderType.Columns.Add("value");
            dtOrderType.Columns.Add("name");
            dtOrderType.Rows.Add(new string[] { "1", "Market" });
            dtOrderType.Rows.Add(new string[] { "2", "Limit" });
            dtOrderType.Rows.Add(new string[] { "3", "Stop" });
            dtOrderType.Rows.Add(new string[] { "4", "Stop Limit" });
            cmbOrdertype.DataSource = dtOrderType;
            cmbOrdertype.DisplayMember = "name";
            cmbOrdertype.ValueMember = "value";
            cmbOrdertype.SelectedIndex = 1;

            DataTable dtOpenClose = new DataTable();
            dtOpenClose.Columns.Add("value");
            dtOpenClose.Columns.Add("name");
            dtOpenClose.Rows.Add(new string[] { "O", "Open" });
            dtOpenClose.Rows.Add(new string[] { "C", "Close" });

            cmbPositionEffect.DataSource = dtOpenClose;
            cmbPositionEffect.DisplayMember = "name";
            cmbPositionEffect.ValueMember = "value";

            byte[] bb = frmMain.mobjDataAgent.WS_LService.WS_AccountList();

            DataSet ds = CommonFunction.SerialUnZip(bb);

            if (ds.Tables.Count > 0)
            {
                this.cmbAccount.DataSource = ds.Tables[0];
                this.cmbAccount.ValueMember = "account";
                this.cmbAccount.DisplayMember = "account";
            }

            // lblAccount_name.Text = "";

            Type = "0";
            TotalQty = 0;

            Interval = 0;
            Qty = 0;
            Ratio = 0;

            bb = frmMain.mobjDataAgent.WS_LService.getAEData();

            ds = CommonFunction.SerialUnZip(bb);
            if (ds.Tables.Count > 0)
            {


                cmbAENO.DataSource = ds.Tables[0];
                cmbAENO.DisplayMember = "ae";
                cmbAENO.ValueMember = "ae";
            }
            cmbAccount.SelectedIndex = 0;
            reset();
        }

        private void reset()
        {
            Type = "0";
            TotalQty = 0;

            Interval = 0;
            Qty = 0;
            Ratio = 0;
            chkAt.Text = "At";
            chkUntil.Text = "Until";
            lblText.Text = "";
            lblSetting.Text = "None";

            _atTime = DateTime.MinValue;
            _untilTime = DateTime.MaxValue;
            chkAt.Checked = false;
            chkUntil.Checked = false;
        }

        private void chkAt_Click(object sender, EventArgs e)
        {
            //if (Type == "0")
            //{
            //    MessageBox.Show("請選擇Advanced Settings");
            //    chkAt.Checked = false;
            //    return;
            //}
            if (chkAt.Checked)
            {

                frmTimeSet frm = new frmTimeSet();
                if (frm.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {

                    _atTime = frm.seltime;
                    chkAt.Text += " " + frm.seltime.ToString("yyyy/MM/dd HH:mm:ss");
                }
            }
            else
            {
                _atTime = DateTime.MinValue;
                chkAt.Text = "At";
            }

            DataAgent._LM.WriteLog("UIEventLog", "submittime at " + chkAt.Text);
        }

        private void chkUntil_Click(object sender, EventArgs e)
        {
            //if (Type == "0")
            //{
            //    MessageBox.Show("請選擇Advanced Settings");
            //    chkUntil.Checked = false;
            //    return;
            //}
            if (chkUntil.Checked)
            {
                frmTimeSet frm = new frmTimeSet();
                if (frm.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    _untilTime = frm.seltime;
                    chkUntil.Text += " " + frm.seltime.ToString("yyyy/MM/dd HH:mm:ss");
                }


            }
            else
            {
                _untilTime = DateTime.MaxValue;
                chkUntil.Text = "Until";
            }

            DataAgent._LM.WriteLog("UIEventLog", "submittime Until" + chkUntil.Text);
        }

        private void btnSetting_Click(object sender, EventArgs e)
        {
            try
            {




                int qty = 0;

                if (int.TryParse(this.txtQty.Text, out qty))
                {

                }
                if (qty == 0)
                {
                    MessageBox.Show("請輸入委託口數!");
                    return;
                }
                frmAdTimeSet frm = new frmAdTimeSet(_atTime, _untilTime);

                frm.TotalQty = qty;
                if (frm.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    Type = frm.Type;
                    TotalQty = frm.TotalQty;
                    BeginDateTime = frm.BeginDateTime;
                    EndDateTime = frm.EndDateTime;
                    Interval = frm.Interval;
                    Qty = frm.Qty;
                    Ratio = frm.Ratio;
                    lblSetting.Text = (Type == "1" ? "Time Slice" : (Type == "2" ? "Time Duration" : "None"));

                    string Text = "";



                    if (Type != "0")
                    {
                        Text += "Disclose " + Qty.ToString();
                        Text += "\nInterval " + Interval.ToString();
                        Text += "\nAt " + BeginDateTime.ToString("yyyy/MM/dd HH:mm:ss.fff");
                        if (EndDateTime != DateTime.MaxValue && EndDateTime != DateTime.MinValue)
                            Text += "\nUntil " + EndDateTime.ToString("yyyy/MM/dd HH:mm:ss.fff");

                     
                     
                        if (BeginDateTime != DateTime.MinValue)
                        {
                            chkAt.Checked = true;
                            chkAt.Text = "At " + BeginDateTime.ToString("yyyy/MM/dd HH:mm:ss.fff");
                        }
                        if (EndDateTime != DateTime.MaxValue)
                        {
                            chkUntil.Checked = true;
                            chkUntil.Text = "Until " + EndDateTime.ToString("yyyy/MM/dd HH:mm:ss.fff");
                        }
                        _atTime = BeginDateTime;
                        _untilTime = EndDateTime;
                    }
                    else
                    {
                        reset();
                        Text = "";
                    }

                    lblText.Text = Text;
                }

                DataAgent._LM.WriteLog("UIEventLog", "Advanced Settings " + lblText.Text);
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("UIErrorLog", this.GetType().Name
                       + " " + System.Reflection.MethodInfo.GetCurrentMethod().Name + " " + ex.Message);

            }
        }

        private void btnBuy_Click(object sender, EventArgs e)
        {
            try
            {




                if (chkconfirm.Checked)
                {
                    frmViewOrder fm = new frmViewOrder();


                    fm.lblOrder.Text += "Buy " + txtQty.Text;
                    fm.lblContract.Text += this.txtItem.Text;
                    fm.lblPriceType.Text += this.cmbOrdertype.Text;
                    fm.lblOpenclose.Text += this.cmbPositionEffect.Text;
                    fm.lbltimeinforce.Text += this.cmbTIF.Text;
                    fm.lblaccount.Text += this.cmbAccount.Text;

                    if (BeginDateTime.ToString("yyyyMMddHHmmss") != DateTime.MaxValue.ToString("yyyyMMddHHmmss")
                        && BeginDateTime.ToString("yyyyMMddHHmmss") != DateTime.MinValue.ToString("yyyyMMddHHmmss"))
                        fm.lblstartime.Text += BeginDateTime.ToString("yyyy/MM/dd HH:mm:ss.fff");
                    if (EndDateTime.ToString("yyyyMMddHHmmss") != DateTime.MaxValue.ToString("yyyyMMddHHmmss")
                        && EndDateTime.ToString("yyyyMMddHHmmss") != DateTime.MinValue.ToString("yyyyMMddHHmmss"))
                        fm.lblworkuntil.Text += EndDateTime.ToString("yyyy/MM/dd HH:mm:ss.fff");
                    fm.lblworkorderas.Text += (Type == "1" ? "Time Slice" : (Type == "2" ? "Time Duration" : "None"));
                    //if (Type == "1" || Type == "2")
                    //    fm.lblworkorderas.Text += " " + (EndDateTime - BeginDateTime).TotalSeconds.ToString("0") + "Sec";

                    fm.lblIsclosedqty.Text += Qty.ToString();
                    fm.lblInterval.Text += Interval.ToString();



                    if (fm.ShowDialog() != System.Windows.Forms.DialogResult.OK)
                        return;
                }

                if (Type == "0")
                    Order("B");
                else
                {
                    if (DateTime.Now > BeginDateTime || DateTime.Now > EndDateTime)
                    {
                        MessageBox.Show("Advance Time's over !");

                    }
                    else
                    {
                        OrderStrategy("B");

                    }
                    reset();
                }
                //frmMain.mobjDataAgent.objTradeStringHandle.sendOrder(
                DataAgent._LM.WriteLog("UIEventLog", "Buy Type" + Type);
            }

            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("UIErrorLog", this.GetType().Name
                       + " " + System.Reflection.MethodInfo.GetCurrentMethod().Name + " " + ex.Message);

            }
        }

        private void btnSell_Click(object sender, EventArgs e)
        {

            try
            {
                if (chkconfirm.Checked)
                {
                    frmViewOrder fm = new frmViewOrder();

                    fm.lblOrder.Text += "Sell " + txtQty.Text;
                    fm.lblContract.Text += this.txtItem.Text;
                    fm.lblPriceType.Text += this.txtOrderPrice.Text + " " + this.cmbOrdertype.Text;
                    fm.lblOpenclose.Text += this.cmbPositionEffect.Text;
                    fm.lbltimeinforce.Text += this.cmbTIF.Text;

                    if (BeginDateTime.ToString("yyyyMMddHHmmss") != DateTime.MaxValue.ToString("yyyyMMddHHmmss") && BeginDateTime.ToString("yyyyMMddHHmmss") != DateTime.MinValue.ToString("yyyyMMddHHmmss"))
                        fm.lblstartime.Text += BeginDateTime.ToString("yyyy/MM/dd HH:mm:ss.fff");
                    if (EndDateTime.ToString("yyyyMMddHHmmss") != DateTime.MaxValue.ToString("yyyyMMddHHmmss") && EndDateTime.ToString("yyyyMMddHHmmss") != DateTime.MinValue.ToString("yyyyMMddHHmmss"))
                        fm.lblworkuntil.Text += EndDateTime.ToString("yyyy/MM/dd HH:mm:ss.fff");
                    fm.lblworkorderas.Text += (Type == "1" ? "Time Slice" : (Type == "2" ? "Time Duration" : "None"));
                    //if (Type == "1" || Type == "2")
                    //    fm.lblworkorderas.Text += " " + (EndDateTime - BeginDateTime).TotalSeconds.ToString("0") + "Sec";

                    fm.lblIsclosedqty.Text += Qty.ToString();
                    fm.lblInterval.Text += Interval.ToString();

                    if (fm.ShowDialog() != System.Windows.Forms.DialogResult.OK)
                        return;
                }
                if (Type == "0")
                    Order("S");
                else
                {
                    if (DateTime.Now > BeginDateTime || DateTime.Now > EndDateTime)
                    {
                        MessageBox.Show("Advance Time's over !");

                    }
                    else
                    {
                        OrderStrategy("S");
                    }
                    reset();
                }
                DataAgent._LM.WriteLog("UIEventLog", "Sell Type" + Type);
            }

            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("UIErrorLog", this.GetType().Name
                       + " " + System.Reflection.MethodInfo.GetCurrentMethod().Name + " " + ex.Message);

            }
        }

        private void btnSelItem_Click(object sender, EventArgs e)
        {
            try
            {

                frmProductSelect fm = new frmProductSelect();
                if (fm.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    SecurityExchange = fm.SecurityExchange;
                    SecurityType1 = fm.SecurityType1;
                    Symbol1 = fm.Symbol1;
                    MaturityMonthYear1 = fm.MaturityMonthYear1;
                    Cp1 = fm.Cp1;
                    Strike1 = fm.Strike1;
                    Side1 = fm.Side1;
                    SecurityType2 = fm.SecurityType2;
                    Symbol2 = fm.Symbol2;
                    MaturityMonthYear2 = fm.MaturityMonthYear2;
                    Cp2 = fm.Cp2;
                    Strike2 = fm.Strike2;
                    Side2 = fm.Side2;
                    string contract = "";

                    if (Symbol2.Trim().Length == 0)
                        contract = Symbol1 + MaturityMonthYear1 + Cp1
                            + (SecurityType1 == "FUT" ? "" : Strike1.ToString("#.######"));
                    else
                        contract = Symbol1 + (Side1 == "B" ? "+1*" : "-1*") + MaturityMonthYear1 + Cp1 + (SecurityType1 == "FUT" ? "" : Strike1.ToString("#.######"))
                                           + (Side2 == "B" ? "+1*" : "-1*") + MaturityMonthYear2 + Cp2 + (SecurityType2 == "FUT" ? "" : Strike2.ToString("#.######"));

                    txtItem.Text = SecurityExchange + contract;

                    DataAgent._LM.WriteLog("UIEventLog", "Select Item" + txtItem.Text);
                }
            }

            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("UIErrorLog", this.GetType().Name
                       + " " + System.Reflection.MethodInfo.GetCurrentMethod().Name + " " + ex.Message);

            }
        }

        private void Order(string bs)
        {
            try
            {
                //Added by peter v1.0.0.4. on 20170309 
                //新增當1.
                //下單介面目前若AdvancedSettings選none，SubmitTime擇一選擇，此時按Buy/Sell會下出單筆委託
                //請調整為只有AdvancedSettings選none，SubmitTime都不選，此時按Buy/Sell才會下出單筆託
                if (chkAt.Checked || chkUntil.Checked)
                {
                    MessageBox.Show("無單筆定時下單功能!");
                    return;
                }
                if (Symbol1.Trim().Length == 0) return;

                string PRODUCTKIND = "";

                if (SecurityType1 != "" && SecurityType2 != "")
                {
                    if (SecurityType1 == "FUT" && SecurityType2 == "FUT")
                        PRODUCTKIND = "4";
                    else if (SecurityType1 == "OPT" && SecurityType2 == "OPT")
                        PRODUCTKIND = "3";
                }
                else
                {
                    if (SecurityType1 == "FUT")
                        PRODUCTKIND = "1";
                    else if (SecurityType1 == "OPT")
                        PRODUCTKIND = "2";
                }

                string EXECTYPE = "0";
                string BROKERID = "";
                string ORDERNO = "";
                string INVESTORACNO = this.cmbAccount.SelectedValue.ToString(); ;
                string SUBACT = cmbAENO.Text.Trim();
                string SECURITYEXCHANGE = SecurityExchange;
                string SECURITYTYPE1 = SecurityType1;
                string SYMBOL1 = Symbol1;
                string MATURITYMONTHYEAR1 = MaturityMonthYear1;
                string PUTORCALL1 = Cp1;
                decimal STRIKEPRICE1 = Strike1;
                string SIDE1 = Side1;
                string SECURITYTYPE2 = SecurityType2;
                string SYMBOL2 = Symbol2;
                string MATURITYMONTHYEAR2 = MaturityMonthYear2;
                string PUTORCALL2 = Cp2;
                decimal STRIKEPRICE2 = Strike2;
                string SIDE2 = Side2;
                string BS = bs;
                string ORDERTYPE = cmbOrdertype.SelectedValue.ToString(); ;
                decimal PRICE = 0;
                if (ORDERTYPE == "1")
                {
                    PRICE = 0;
                }
                else
                {
                    PRICE = decimal.Parse(txtOrderPrice.Text);
                }


                decimal STOPPRICE = 0;
                if (ORDERTYPE == "4")
                {
                    STOPPRICE = decimal.Parse(txtStopPrice.Text);
                }
                int ORDERQTY = int.Parse(txtQty.Text);

                if (ORDERQTY == 0) return;

                if (ORDERQTY > 500)
                {
                    VIPTradingSystem.MYcls.CommonFunction.ShowWarningMessageBox(this, "Order qty >500!!!");
                    return;
                }

                string TIMEINFORCE = cmbTIF.SelectedValue.ToString(); ;
                string OPENCLOSE = cmbPositionEffect.SelectedValue.ToString();
                string DTRADE = "";
                string CLORDID = "";
                string EXPIREDATE = "";
                string SOURCECODE = "d";

                string keepData = "";
                keepData = string.Format("OrderKind=1^OrderTag={0}^AE={1}^", txtOrderTag.Text.Trim(), cmbAENO.Text);

                string ret = frmMain.mobjDataAgent.objTradeStringHandle.sendOrder(PRODUCTKIND
                 , EXECTYPE
                 , BROKERID
                 , ORDERNO
                 , INVESTORACNO
                 , SUBACT
                 , SECURITYEXCHANGE
                 , SECURITYTYPE1
                 , SYMBOL1
                 , MATURITYMONTHYEAR1
                 , PUTORCALL1
                 , STRIKEPRICE1
                 , SIDE1
                 , SECURITYTYPE2
                 , SYMBOL2
                 , MATURITYMONTHYEAR2
                 , PUTORCALL2
                 , STRIKEPRICE2
                 , SIDE2
                 , BS
                 , ORDERTYPE
                 , PRICE
                 , STOPPRICE
                 , ORDERQTY
                 , TIMEINFORCE
                 , OPENCLOSE
                 , DTRADE
                 , CLORDID
                 , EXPIREDATE
                 , SOURCECODE, keepData);
                reset();
                DataAgent._LM.WriteLog("UIEventLog", "Order " + ret);
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("UIErrorLog", this.GetType().Name
                           + " " + System.Reflection.MethodInfo.GetCurrentMethod().Name + " " + ex.Message);
            }
        }


        private void OrderStrategy(string bs)
        {
            try
            {
                if (Symbol1.Trim().Length == 0) return;
                string PRODUCTKIND = "";

                if (SecurityType1 != "" && SecurityType2 != "")
                {
                    if (SecurityType1 == "FUT" && SecurityType2 == "FUT")
                        PRODUCTKIND = "4";
                    else if (SecurityType1 == "OPT" && SecurityType2 == "OPT")
                        PRODUCTKIND = "3";
                }
                else
                {
                    if (SecurityType1 == "FUT")
                        PRODUCTKIND = "1";
                    else if (SecurityType1 == "OPT")
                        PRODUCTKIND = "2";
                }

                string EXECTYPE = "0";
                string BROKERID = "";
                string ORDERNO = "";
                string INVESTORACNO = this.cmbAccount.SelectedValue.ToString(); ;
                string SUBACT = cmbAENO.Text.Trim();
                string SECURITYEXCHANGE = SecurityExchange;
                string SECURITYTYPE1 = SecurityType1;
                string SYMBOL1 = Symbol1;
                string MATURITYMONTHYEAR1 = MaturityMonthYear1;
                string PUTORCALL1 = Cp1;
                decimal STRIKEPRICE1 = Strike1;
                string SIDE1 = Side1;
                string SECURITYTYPE2 = SecurityType2;
                string SYMBOL2 = Symbol2;
                string MATURITYMONTHYEAR2 = MaturityMonthYear2;
                string PUTORCALL2 = Cp2;
                decimal STRIKEPRICE2 = Strike2;
                string SIDE2 = Side2;
                string BS = bs;
                string ORDERTYPE = cmbOrdertype.SelectedValue.ToString(); ;
                decimal PRICE = 0;

                if (ORDERTYPE == "1")
                {
                    PRICE = 0;
                }
                else
                {
                    PRICE = decimal.Parse(txtOrderPrice.Text);
                }
                decimal STOPPRICE = decimal.Parse(txtStopPrice.Text);
                int ORDERQTY = int.Parse(txtQty.Text);
                if (ORDERQTY == 0) return;
                string TIMEINFORCE = cmbTIF.SelectedValue.ToString(); ;
                string OPENCLOSE = cmbPositionEffect.SelectedValue.ToString();
                string DTRADE = "";
                string CLORDID = "";
                string EXPIREDATE = "";
                string SOURCECODE = "d";
                string ADVANCED_TEXT = "";

                ADVANCED_TEXT = (Type == "1" ? "Time Slice" : (Type == "2" ? "Time Duration" : ""))
              + "|" + Type
                + "|" + TotalQty.ToString()
                + "|" + BeginDateTime.ToString("yyyyMMddHHmmssfff")
                + "|" + EndDateTime.ToString("yyyyMMddHHmmssfff")
                + "|" + Interval.ToString()
                + "|" + Qty.ToString()
                + "|" + Ratio.ToString();

                string keepData = "";
                keepData = string.Format("OrderKind=P^OrderTag={0}^AE={1}^AD={2}^"
                    , txtOrderTag.Text.Trim(), cmbAENO.Text, ADVANCED_TEXT);

                string ret = frmMain.mobjDataAgent.objTradeStringHandle.sendOrderStrategy(PRODUCTKIND
                     , EXECTYPE
                     , BROKERID
                     , ORDERNO
                     , INVESTORACNO
                     , SUBACT
                     , SECURITYEXCHANGE
                     , SECURITYTYPE1
                     , SYMBOL1
                     , MATURITYMONTHYEAR1
                     , PUTORCALL1
                     , STRIKEPRICE1
                     , SIDE1
                     , SECURITYTYPE2
                     , SYMBOL2
                     , MATURITYMONTHYEAR2
                     , PUTORCALL2
                     , STRIKEPRICE2
                     , SIDE2
                     , BS
                     , ORDERTYPE
                     , PRICE
                     , STOPPRICE
                     , ORDERQTY
                     , TIMEINFORCE
                     , OPENCLOSE
                     , DTRADE
                     , CLORDID
                     , EXPIREDATE
                     , SOURCECODE, keepData);

                DataAgent._LM.WriteLog("UIEventLog", "OrderStrategy " + ret);
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("UIErrorLog", this.GetType().Name
                           + " " + System.Reflection.MethodInfo.GetCurrentMethod().Name + " " + ex.Message);
            }
        }

        private void btnQty_Click(object sender, EventArgs e)
        {
            try
            {
                TextBox obj = (TextBox)this.txtQty;
                Button srcobj = (Button)sender;
                decimal qty = 0;

                if (decimal.TryParse(obj.Text, out qty))
                {
                    this.txtQty.Text = (qty + decimal.Parse(srcobj.Text)).ToString("#");
                }
            }
            catch (Exception ex)
            {
                this.txtQty.Text = "0";
            }
        }

        private void cmbOrdertype_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbOrdertype.SelectedValue == "1")//market
            {
                txtOrderPrice.Text = "0";
                txtOrderPrice.Enabled = false;

            }
            else
            {
                txtOrderPrice.Enabled = true;
            }
            if (cmbOrdertype.SelectedValue == "4")//Stop Limit
            {
                txtStopPrice.Text = "0";
                txtStopPrice.Enabled = true;
            }
            else
            {
                txtStopPrice.Text = "0";
                txtStopPrice.Enabled = false;
            }




        }

        private void cmbAccount_TextChanged(object sender, EventArgs e)
        {


        }

        private void cmbAccount_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbAccount.SelectedIndex < 0) return;
            DataTable dt = (DataTable)cmbAccount.DataSource;

            if (dt.Rows.Count > 0)
            {
                lblAccount_name.Text = dt.Rows[cmbAccount.SelectedIndex]["name"].ToString();

                DataAgent._LM.WriteLog("UIEventLog", "cmbAccount_SelectedIndexChanged " + dt.Rows[cmbAccount.SelectedIndex]["name"].ToString());
            }
        }
    }
}
