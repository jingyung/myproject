﻿namespace VIPTradingSystem.ui.Order
{
    partial class frmTrade
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmTrade));
            this.txtItem = new System.Windows.Forms.TextBox();
            this.btnSell = new System.Windows.Forms.Button();
            this.btnBuy = new System.Windows.Forms.Button();
            this.txtOrderPrice = new System.Windows.Forms.TextBox();
            this.txtQty = new System.Windows.Forms.TextBox();
            this.btnQty500 = new System.Windows.Forms.Button();
            this.btnQty100 = new System.Windows.Forms.Button();
            this.btnQty10 = new System.Windows.Forms.Button();
            this.btnQty5 = new System.Windows.Forms.Button();
            this.btnQty1 = new System.Windows.Forms.Button();
            this.cmbAccount = new System.Windows.Forms.ComboBox();
            this.cmbAENO = new System.Windows.Forms.ComboBox();
            this.lblOrderTemplate = new System.Windows.Forms.Label();
            this.cmbPositionEffect = new System.Windows.Forms.ComboBox();
            this.cmbTIF = new System.Windows.Forms.ComboBox();
            this.cmbOrdertype = new System.Windows.Forms.ComboBox();
            this.lblAdvancedSettings = new System.Windows.Forms.Label();
            this.btnSetting = new System.Windows.Forms.Button();
            this.lblSubmitTime = new System.Windows.Forms.Label();
            this.chkUntil = new System.Windows.Forms.CheckBox();
            this.chkAt = new System.Windows.Forms.CheckBox();
            this.chkconfirm = new System.Windows.Forms.CheckBox();
            this.txtOrderTag = new System.Windows.Forms.TextBox();
            this.btnSelItem = new System.Windows.Forms.Button();
            this.txtStopPrice = new System.Windows.Forms.TextBox();
            this.lblSetting = new System.Windows.Forms.Label();
            this.lblText = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblAccount_name = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.Images.SetKeyName(0, "sign-out.ico");
            this.imageList1.Images.SetKeyName(1, "sign-in.ico");
            // 
            // txtItem
            // 
            this.txtItem.Location = new System.Drawing.Point(21, 21);
            this.txtItem.Name = "txtItem";
            this.txtItem.ReadOnly = true;
            this.txtItem.Size = new System.Drawing.Size(305, 25);
            this.txtItem.TabIndex = 1;
            // 
            // btnSell
            // 
            this.btnSell.BackColor = System.Drawing.Color.Red;
            this.btnSell.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnSell.Location = new System.Drawing.Point(135, 131);
            this.btnSell.Name = "btnSell";
            this.btnSell.Size = new System.Drawing.Size(110, 55);
            this.btnSell.TabIndex = 18;
            this.btnSell.Text = "Sell";
            this.btnSell.UseVisualStyleBackColor = false;
            this.btnSell.Click += new System.EventHandler(this.btnSell_Click);
            // 
            // btnBuy
            // 
            this.btnBuy.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnBuy.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnBuy.Location = new System.Drawing.Point(21, 131);
            this.btnBuy.Name = "btnBuy";
            this.btnBuy.Size = new System.Drawing.Size(108, 55);
            this.btnBuy.TabIndex = 17;
            this.btnBuy.Text = "Buy";
            this.btnBuy.UseVisualStyleBackColor = false;
            this.btnBuy.Click += new System.EventHandler(this.btnBuy_Click);
            // 
            // txtOrderPrice
            // 
            this.txtOrderPrice.Font = new System.Drawing.Font("新細明體", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtOrderPrice.Location = new System.Drawing.Point(242, 67);
            this.txtOrderPrice.Name = "txtOrderPrice";
            this.txtOrderPrice.Size = new System.Drawing.Size(100, 28);
            this.txtOrderPrice.TabIndex = 16;
            this.txtOrderPrice.Text = "0";
            this.txtOrderPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtQty
            // 
            this.txtQty.Font = new System.Drawing.Font("新細明體", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtQty.Location = new System.Drawing.Point(136, 67);
            this.txtQty.Name = "txtQty";
            this.txtQty.Size = new System.Drawing.Size(100, 28);
            this.txtQty.TabIndex = 15;
            this.txtQty.Text = "0";
            this.txtQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnQty500
            // 
            this.btnQty500.Location = new System.Drawing.Point(79, 97);
            this.btnQty500.Name = "btnQty500";
            this.btnQty500.Size = new System.Drawing.Size(50, 28);
            this.btnQty500.TabIndex = 14;
            this.btnQty500.Text = "500";
            this.btnQty500.UseVisualStyleBackColor = true;
            this.btnQty500.Click += new System.EventHandler(this.btnQty_Click);
            // 
            // btnQty100
            // 
            this.btnQty100.Location = new System.Drawing.Point(21, 97);
            this.btnQty100.Name = "btnQty100";
            this.btnQty100.Size = new System.Drawing.Size(55, 28);
            this.btnQty100.TabIndex = 13;
            this.btnQty100.Text = "100";
            this.btnQty100.UseVisualStyleBackColor = true;
            this.btnQty100.Click += new System.EventHandler(this.btnQty_Click);
            // 
            // btnQty10
            // 
            this.btnQty10.Location = new System.Drawing.Point(91, 67);
            this.btnQty10.Name = "btnQty10";
            this.btnQty10.Size = new System.Drawing.Size(38, 28);
            this.btnQty10.TabIndex = 12;
            this.btnQty10.Text = "10";
            this.btnQty10.UseVisualStyleBackColor = true;
            this.btnQty10.Click += new System.EventHandler(this.btnQty_Click);
            // 
            // btnQty5
            // 
            this.btnQty5.Location = new System.Drawing.Point(56, 67);
            this.btnQty5.Name = "btnQty5";
            this.btnQty5.Size = new System.Drawing.Size(35, 28);
            this.btnQty5.TabIndex = 11;
            this.btnQty5.Text = "5";
            this.btnQty5.UseVisualStyleBackColor = true;
            this.btnQty5.Click += new System.EventHandler(this.btnQty_Click);
            // 
            // btnQty1
            // 
            this.btnQty1.Location = new System.Drawing.Point(21, 67);
            this.btnQty1.Name = "btnQty1";
            this.btnQty1.Size = new System.Drawing.Size(34, 28);
            this.btnQty1.TabIndex = 10;
            this.btnQty1.Text = "1";
            this.btnQty1.UseVisualStyleBackColor = true;
            this.btnQty1.Click += new System.EventHandler(this.btnQty_Click);
            // 
            // cmbAccount
            // 
            this.cmbAccount.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbAccount.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbAccount.FormattingEnabled = true;
            this.cmbAccount.Location = new System.Drawing.Point(405, 23);
            this.cmbAccount.Name = "cmbAccount";
            this.cmbAccount.Size = new System.Drawing.Size(118, 23);
            this.cmbAccount.TabIndex = 19;
            this.cmbAccount.SelectedIndexChanged += new System.EventHandler(this.cmbAccount_SelectedIndexChanged);
            this.cmbAccount.TextChanged += new System.EventHandler(this.cmbAccount_TextChanged);
            // 
            // cmbAENO
            // 
            this.cmbAENO.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbAENO.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbAENO.FormattingEnabled = true;
            this.cmbAENO.Location = new System.Drawing.Point(405, 72);
            this.cmbAENO.MaxLength = 7;
            this.cmbAENO.Name = "cmbAENO";
            this.cmbAENO.Size = new System.Drawing.Size(118, 23);
            this.cmbAENO.TabIndex = 20;
            // 
            // lblOrderTemplate
            // 
            this.lblOrderTemplate.AutoSize = true;
            this.lblOrderTemplate.Location = new System.Drawing.Point(571, 26);
            this.lblOrderTemplate.Name = "lblOrderTemplate";
            this.lblOrderTemplate.Size = new System.Drawing.Size(93, 15);
            this.lblOrderTemplate.TabIndex = 21;
            this.lblOrderTemplate.Text = "OrderTemplate";
            this.lblOrderTemplate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cmbPositionEffect
            // 
            this.cmbPositionEffect.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPositionEffect.FormattingEnabled = true;
            this.cmbPositionEffect.Location = new System.Drawing.Point(619, 103);
            this.cmbPositionEffect.Name = "cmbPositionEffect";
            this.cmbPositionEffect.Size = new System.Drawing.Size(68, 23);
            this.cmbPositionEffect.TabIndex = 24;
            // 
            // cmbTIF
            // 
            this.cmbTIF.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTIF.FormattingEnabled = true;
            this.cmbTIF.Location = new System.Drawing.Point(619, 72);
            this.cmbTIF.Name = "cmbTIF";
            this.cmbTIF.Size = new System.Drawing.Size(68, 23);
            this.cmbTIF.TabIndex = 23;
            // 
            // cmbOrdertype
            // 
            this.cmbOrdertype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbOrdertype.FormattingEnabled = true;
            this.cmbOrdertype.Items.AddRange(new object[] {
            "LIMIT"});
            this.cmbOrdertype.Location = new System.Drawing.Point(549, 72);
            this.cmbOrdertype.Name = "cmbOrdertype";
            this.cmbOrdertype.Size = new System.Drawing.Size(68, 23);
            this.cmbOrdertype.TabIndex = 22;
            this.cmbOrdertype.SelectedIndexChanged += new System.EventHandler(this.cmbOrdertype_SelectedIndexChanged);
            // 
            // lblAdvancedSettings
            // 
            this.lblAdvancedSettings.AutoSize = true;
            this.lblAdvancedSettings.Location = new System.Drawing.Point(697, 25);
            this.lblAdvancedSettings.Name = "lblAdvancedSettings";
            this.lblAdvancedSettings.Size = new System.Drawing.Size(112, 15);
            this.lblAdvancedSettings.TabIndex = 25;
            this.lblAdvancedSettings.Text = "Advanced Settings";
            this.lblAdvancedSettings.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnSetting
            // 
            this.btnSetting.Location = new System.Drawing.Point(806, 64);
            this.btnSetting.Name = "btnSetting";
            this.btnSetting.Size = new System.Drawing.Size(27, 23);
            this.btnSetting.TabIndex = 26;
            this.btnSetting.Text = "...";
            this.btnSetting.UseVisualStyleBackColor = true;
            this.btnSetting.Click += new System.EventHandler(this.btnSetting_Click);
            // 
            // lblSubmitTime
            // 
            this.lblSubmitTime.AutoSize = true;
            this.lblSubmitTime.Location = new System.Drawing.Point(897, 24);
            this.lblSubmitTime.Name = "lblSubmitTime";
            this.lblSubmitTime.Size = new System.Drawing.Size(82, 15);
            this.lblSubmitTime.TabIndex = 27;
            this.lblSubmitTime.Text = "Submit Time";
            this.lblSubmitTime.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // chkUntil
            // 
            this.chkUntil.AutoSize = true;
            this.chkUntil.Location = new System.Drawing.Point(900, 121);
            this.chkUntil.Name = "chkUntil";
            this.chkUntil.Size = new System.Drawing.Size(58, 19);
            this.chkUntil.TabIndex = 29;
            this.chkUntil.Text = "Until";
            this.chkUntil.UseVisualStyleBackColor = true;
            this.chkUntil.Click += new System.EventHandler(this.chkUntil_Click);
            // 
            // chkAt
            // 
            this.chkAt.AutoSize = true;
            this.chkAt.Location = new System.Drawing.Point(900, 65);
            this.chkAt.Name = "chkAt";
            this.chkAt.Size = new System.Drawing.Size(43, 19);
            this.chkAt.TabIndex = 28;
            this.chkAt.Text = "At";
            this.chkAt.UseVisualStyleBackColor = true;
            this.chkAt.Click += new System.EventHandler(this.chkAt_Click);
            // 
            // chkconfirm
            // 
            this.chkconfirm.AutoSize = true;
            this.chkconfirm.Location = new System.Drawing.Point(136, 101);
            this.chkconfirm.Name = "chkconfirm";
            this.chkconfirm.Size = new System.Drawing.Size(74, 19);
            this.chkconfirm.TabIndex = 30;
            this.chkconfirm.Text = "confirm";
            this.chkconfirm.UseVisualStyleBackColor = true;
            // 
            // txtOrderTag
            // 
            this.txtOrderTag.Location = new System.Drawing.Point(549, 132);
            this.txtOrderTag.MaxLength = 10;
            this.txtOrderTag.Name = "txtOrderTag";
            this.txtOrderTag.Size = new System.Drawing.Size(138, 25);
            this.txtOrderTag.TabIndex = 31;
            // 
            // btnSelItem
            // 
            this.btnSelItem.Location = new System.Drawing.Point(332, 21);
            this.btnSelItem.Name = "btnSelItem";
            this.btnSelItem.Size = new System.Drawing.Size(27, 23);
            this.btnSelItem.TabIndex = 32;
            this.btnSelItem.Text = "...";
            this.btnSelItem.UseVisualStyleBackColor = true;
            this.btnSelItem.Click += new System.EventHandler(this.btnSelItem_Click);
            // 
            // txtStopPrice
            // 
            this.txtStopPrice.Location = new System.Drawing.Point(549, 160);
            this.txtStopPrice.Name = "txtStopPrice";
            this.txtStopPrice.Size = new System.Drawing.Size(138, 25);
            this.txtStopPrice.TabIndex = 33;
            this.txtStopPrice.Text = "0";
            // 
            // lblSetting
            // 
            this.lblSetting.AutoSize = true;
            this.lblSetting.Location = new System.Drawing.Point(688, 68);
            this.lblSetting.Name = "lblSetting";
            this.lblSetting.Size = new System.Drawing.Size(37, 15);
            this.lblSetting.TabIndex = 34;
            this.lblSetting.Text = "None";
            this.lblSetting.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblText
            // 
            this.lblText.AutoSize = true;
            this.lblText.Location = new System.Drawing.Point(694, 91);
            this.lblText.Name = "lblText";
            this.lblText.Size = new System.Drawing.Size(0, 15);
            this.lblText.TabIndex = 35;
            this.lblText.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(373, 75);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(26, 15);
            this.label1.TabIndex = 36;
            this.label1.Text = "AE";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(481, 135);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 15);
            this.label2.TabIndex = 37;
            this.label2.Text = "OrderTag";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(481, 163);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 15);
            this.label3.TabIndex = 38;
            this.label3.Text = "StopPrice";
            // 
            // lblAccount_name
            // 
            this.lblAccount_name.AutoSize = true;
            this.lblAccount_name.Location = new System.Drawing.Point(405, 51);
            this.lblAccount_name.Name = "lblAccount_name";
            this.lblAccount_name.Size = new System.Drawing.Size(0, 15);
            this.lblAccount_name.TabIndex = 39;
            // 
            // frmTrade
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1119, 197);
            this.Controls.Add(this.lblAccount_name);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblText);
            this.Controls.Add(this.lblSetting);
            this.Controls.Add(this.txtStopPrice);
            this.Controls.Add(this.btnSelItem);
            this.Controls.Add(this.txtOrderTag);
            this.Controls.Add(this.chkconfirm);
            this.Controls.Add(this.chkUntil);
            this.Controls.Add(this.chkAt);
            this.Controls.Add(this.lblSubmitTime);
            this.Controls.Add(this.btnSetting);
            this.Controls.Add(this.lblAdvancedSettings);
            this.Controls.Add(this.cmbPositionEffect);
            this.Controls.Add(this.cmbTIF);
            this.Controls.Add(this.cmbOrdertype);
            this.Controls.Add(this.lblOrderTemplate);
            this.Controls.Add(this.cmbAENO);
            this.Controls.Add(this.cmbAccount);
            this.Controls.Add(this.btnSell);
            this.Controls.Add(this.btnBuy);
            this.Controls.Add(this.txtOrderPrice);
            this.Controls.Add(this.txtQty);
            this.Controls.Add(this.btnQty500);
            this.Controls.Add(this.btnQty100);
            this.Controls.Add(this.btnQty10);
            this.Controls.Add(this.btnQty5);
            this.Controls.Add(this.btnQty1);
            this.Controls.Add(this.txtItem);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1137, 244);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(1137, 244);
            this.Name = "frmTrade";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "frmTrade";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtItem;
        private System.Windows.Forms.Button btnSell;
        private System.Windows.Forms.Button btnBuy;
        private System.Windows.Forms.TextBox txtOrderPrice;
        private System.Windows.Forms.TextBox txtQty;
        private System.Windows.Forms.Button btnQty500;
        private System.Windows.Forms.Button btnQty100;
        private System.Windows.Forms.Button btnQty10;
        private System.Windows.Forms.Button btnQty5;
        private System.Windows.Forms.Button btnQty1;
        private System.Windows.Forms.ComboBox cmbAccount;
        private System.Windows.Forms.ComboBox cmbAENO;
        private System.Windows.Forms.Label lblOrderTemplate;
        private System.Windows.Forms.ComboBox cmbPositionEffect;
        private System.Windows.Forms.ComboBox cmbTIF;
        private System.Windows.Forms.ComboBox cmbOrdertype;
        private System.Windows.Forms.Label lblAdvancedSettings;
        private System.Windows.Forms.Button btnSetting;
        private System.Windows.Forms.Label lblSubmitTime;
        private System.Windows.Forms.CheckBox chkUntil;
        private System.Windows.Forms.CheckBox chkAt;
        private System.Windows.Forms.CheckBox chkconfirm;
        private System.Windows.Forms.TextBox txtOrderTag;
        private System.Windows.Forms.Button btnSelItem;
        private System.Windows.Forms.TextBox txtStopPrice;
        private System.Windows.Forms.Label lblSetting;
        private System.Windows.Forms.Label lblText;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblAccount_name;

    }
}