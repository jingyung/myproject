﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using VIPTradingSystem.MYcls;
namespace VIPTradingSystem.ui.Order
{

    public partial class frmAdTimeSet : Form
    {
        public string Type { get; set; }
        public int TotalQty { get; set; }
        public DateTime BeginDateTime { get; set; }
        public DateTime EndDateTime { get; set; }
        public int Interval { get; set; }
        public int Qty { get; set; }
        public decimal Ratio { get; set; }


        private DateTime _BeginDateTime;
        private DateTime _EndDateTime;

        private DateTime tmpBeginDateTime;
        private DateTime tmpEndDateTime;
        private DateTime ClearTime;

        DataTable _dtData;
        public frmAdTimeSet(DateTime b, DateTime e)
        {
            _BeginDateTime = b;
            _EndDateTime = e;
            tmpBeginDateTime = b;
            tmpEndDateTime = e;
            InitializeComponent();

            int year = int.Parse(frmMain.UserConfigs.ClearDataDate.Substring(0, 4));
            int monoth = int.Parse(frmMain.UserConfigs.ClearDataDate.Substring(4, 2));
            int day = int.Parse(frmMain.UserConfigs.ClearDataDate.Substring(6, 2));
            int hh = int.Parse(frmMain.UserConfigs.ClearDataTime.Substring(0, 2));
            int mm = int.Parse(frmMain.UserConfigs.ClearDataTime.Substring(2, 2));
            ClearTime = new DateTime(year, monoth, day, hh, mm, 0);


            this.lstType.Items.Add("none");
            this.lstType.Items.Add("Time Sliced");
            this.lstType.Items.Add("Time Duration");

            this.cmbUnit_Slice.Items.Add("Qty");
            this.cmbUnit_Slice.Items.Add("%");

            this.cmbUnit_Duration.Items.Add("Qty");
            this.cmbUnit_Duration.Items.Add("%");
            this.cmbUnit_Duration.SelectedIndex = 0;
            this.cmbUnit_Slice.SelectedIndex = 0;


            _dtData = new DataTable();

            _dtData.Columns.Add("Time");
            _dtData.Columns.Add("Qty");
            this.dgvData.DataSource = _dtData;
            this.dgvData.AllowUserToAddRows = false;
            this.dgvData.RowHeadersVisible = false;
            this.lstType.SelectedIndexChanged += new EventHandler(lstType_SelectedIndexChanged);


            Type = "";
            TotalQty = 0;
            Interval = 0;
            Qty = 0;
            Ratio = 0;
        }


        void lstType_SelectedIndexChanged(object sender, EventArgs e)
        {
            SetTypeDisplay();
        }

        private void SetTypeDisplay()
        {
            tmpBeginDateTime = _BeginDateTime;
            tmpEndDateTime = _EndDateTime;

            if (lstType.SelectedIndex == 0)
            {
                gpDuration.Visible = false;
                gpSlice.Visible = false;
                _dtData.Clear();
                btnOK.Enabled = true;



            }
            else if (lstType.SelectedIndex == 1)
            {
          
                gpDuration.Visible = false;
                gpSlice.Visible = true;
                _dtData.Clear();
                btnOK.Enabled = false;
            }
            else if (lstType.SelectedIndex == 2)
            {
                gpDuration.Visible = true;
                gpSlice.Visible = false;
                _dtData.Clear();
                btnOK.Enabled = false;

                if (tmpBeginDateTime == DateTime.MinValue)
                {
                    this.numUnit_Duration_begin.Value = DateTime.Now.AddSeconds(60);
                }
                else
                {
                    this.numUnit_Duration_begin.Value = tmpBeginDateTime;
                }
                if (tmpEndDateTime == DateTime.MaxValue)
                {
                    this.numUnit_Duration_end.Value = this.numUnit_Duration_begin.Value;
                }
                else
                {
                    this.numUnit_Duration_end.Value = tmpEndDateTime;
                }


            }

            Type = lstType.SelectedIndex.ToString();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if (_dtData.Rows.Count > 0)
            {
                this.DialogResult = System.Windows.Forms.DialogResult.OK;
            }
            else
            {
                if (Type == "0")
                {
                    this.DialogResult = System.Windows.Forms.DialogResult.OK;
                }
                else
                    return;
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            try
            {

                TimerOrder T = new TimerOrder();
                int pInterval = 0;
                if (lstType.SelectedIndex == 1)
                {

                    if (tmpBeginDateTime == DateTime.MinValue)
                    {
                        MessageBox.Show("請先選擇時間!");
                        return;
                    }
                    if (tmpBeginDateTime < DateTime.Now)
                    {

                        MessageBox.Show("時間條件輸入錯誤!");
                        Reset();
                        return;
                    }
                    if (numUnit_Slice.Value <= 0)
                        return;

                    if (numUnit_Slice_HH.Value <= 0
                       && numUnit_Slice_mm.Value <= 0
                        && numUnit_Slice_ss.Value <= 0
                        && numUnit_Slice_ms.Value <= 0)
                        return;

                    if (cmbUnit_Slice.SelectedIndex == 0)
                    {
                        Qty = Convert.ToInt32(numUnit_Slice.Value);
                    }
                    else
                    {
                        if (numUnit_Slice.Value > 0)
                            Ratio = numUnit_Slice.Value / 100;
                    }
                    //if (tmpEndDateTime == DateTime.MinValue)
                    if (tmpEndDateTime == DateTime.MaxValue)//代表UI沒選擇
                    {
                        //tmpEndDateTime = ClearTime;
                    }
                    else
                    {
                    }


                    Interval = Convert.ToInt32(numUnit_Slice_HH.Value * 60 * 60 * 1000 + numUnit_Slice_mm.Value * 60 * 1000 + numUnit_Slice_ss.Value * 1000 + numUnit_Slice_ms.Value);
                    //假設沒設定UNTIL時間預設最大值



                    if (tmpBeginDateTime > ClearTime)
                    {

                        MessageBox.Show("時間條件輸入錯誤!");
                        Reset();
                        return;
                    }
                    //if (tmpEndDateTime != DateTime.MaxValue)//代表UI有選擇，才進去勾選
                    //{
                    //    if (tmpEndDateTime > ClearTime)
                    //    {
                    //        MessageBox.Show("時間條件輸入錯誤!");
                    //        Reset();
                    //        return;
                    //    }
                    //}
                    int Times = 0;
                    if (Ratio == 0)//判斷是不是依照比率
                    {
                        Times = TotalQty / Qty;
                        if (TotalQty % Qty > 0)
                            Times = Times + 1;
                    }
                    else
                    {
                        Times = Convert.ToInt16(Math.Ceiling(1 / Ratio));//無條件進位
                        Qty = TotalQty / Times;
                    }




                    DateTime tmp = tmpBeginDateTime.AddMilliseconds(Interval * Times);
                    if (tmpEndDateTime != DateTime.MaxValue)//代表UI沒選擇
                    {
                        if (tmp > tmpEndDateTime)
                        {
                            MessageBox.Show("時間條件輸入錯誤!");
                            Reset();
                            return;
                        }
                    }

                    if (tmpBeginDateTime > tmpEndDateTime)
                    {
                        MessageBox.Show("時間條件輸入錯誤!");
                        Reset();
                        return;
                    }
                    BeginDateTime = tmpBeginDateTime;
                    EndDateTime = tmpEndDateTime;

                    pInterval = Interval;
                    T.setParam(TotalQty, Qty, Ratio
                        , ref pInterval, BeginDateTime, EndDateTime);

                    ;
                }
                else if (lstType.SelectedIndex == 2)
                {
                    if (numUnit_Duration.Value <= 0)
                        return;
                    if (cmbUnit_Duration.SelectedIndex == 0)
                    {
                        Qty = Convert.ToInt32(numUnit_Duration.Value);
                    }
                    else
                    {
                        if (numUnit_Duration.Value > 0)
                            Ratio = numUnit_Duration.Value / 100;
                    }

                    if (tmpBeginDateTime == DateTime.MinValue)
                    {

                    }
                    else
                    {
                        DateTime tmp = numUnit_Duration_begin.Value;
                        numUnit_Duration_begin.Value = new DateTime(tmpBeginDateTime.Year, tmpBeginDateTime.Month, tmpBeginDateTime.Day
                                                                    , tmp.Hour, tmp.Minute, tmp.Second); ;
                    }
                    if (numUnit_Duration_begin.Value < DateTime.Now)
                    {

                        MessageBox.Show("時間條件輸入錯誤!");
                        Reset();
                        return;
                    }
                    if (tmpEndDateTime == DateTime.MinValue)
                    {
                        //如果沒有勾 UNTIL ，且迄時間小於啟時間，自動運算出次日時間
                        if (numUnit_Duration_end.Value < numUnit_Duration_begin.Value)
                        {
                            DateTime tmp = numUnit_Duration_end.Value;
                            numUnit_Duration_end.Value = new DateTime(ClearTime.Year, ClearTime.Month, ClearTime.Day
                                                                        , tmp.Hour, tmp.Minute, tmp.Second); ;
                        }
                    }
                    else
                    {
                        DateTime tmp = numUnit_Duration_end.Value;
                        numUnit_Duration_end.Value = new DateTime(tmpEndDateTime.Year, tmpEndDateTime.Month, tmpEndDateTime.Day
                                                                    , tmp.Hour, tmp.Minute, tmp.Second); ;
                    }

                    if (numUnit_Duration_begin.Value > ClearTime || numUnit_Duration_end.Value > ClearTime
                        || numUnit_Duration_begin.Value > numUnit_Duration_end.Value
                        || numUnit_Duration_begin.Value < DateTime.Now)
                    {

                        MessageBox.Show("時間條件輸入錯誤!");
                        Reset();
                        return;
                    }



                    T.setParam(TotalQty, Qty, Ratio
                        , ref pInterval, numUnit_Duration_begin.Value, numUnit_Duration_end.Value);
                    Interval = pInterval;

                    BeginDateTime = numUnit_Duration_begin.Value;
                    EndDateTime = numUnit_Duration_end.Value;
                }
                if (T.OrderList.Values.Count > 0)
                {
                    _dtData.Clear();
                    foreach (TimerOrder.TimeItem t in T.OrderList.Values)
                    {
                        _dtData.Rows.Add(new object[] { t.TIME.ToString("HH:mm:ss.fff"), t.QTY });
                    }
                }

                if (_dtData.Rows.Count > 0)
                    btnOK.Enabled = true;


            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("UIErrorLog", this.GetType().Name
                       + " " + System.Reflection.MethodInfo.GetCurrentMethod().Name + " " + ex.Message);

            }
        }

        void Reset()
        {
            _dtData.Clear();
            btnOK.Enabled = false;
        }

        private void numUnit_Duration_end_ValueChanged(object sender, EventArgs e)
        {

            tmpEndDateTime = numUnit_Duration_end.Value;

        }

        private void numUnit_Duration_begin_ValueChanged(object sender, EventArgs e)
        {
            //tmpEndDateTime

            tmpBeginDateTime = numUnit_Duration_begin.Value;
        }

    }
}


