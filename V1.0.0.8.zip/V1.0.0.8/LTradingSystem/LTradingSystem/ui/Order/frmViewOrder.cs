﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace VIPTradingSystem.ui.Order
{
    public partial class frmViewOrder : Form
    {
        public bool view = false;
        public frmViewOrder()
        {
            InitializeComponent();
        }
       

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.OK;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.No;
        }

        private void frmViewOrder_Load(object sender, EventArgs e)
        {
            if (view)
            {
                btnSubmit.Text = "ok";
            }
        }
    }
}
