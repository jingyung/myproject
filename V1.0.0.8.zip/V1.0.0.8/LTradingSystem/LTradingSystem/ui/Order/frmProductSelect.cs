﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using VIPTradingSystem.MYcls;
namespace VIPTradingSystem.ui.Order
{
    public partial class frmProductSelect : Form
    {
        public string SecurityExchange { set; get; }
        public string SecurityType1 { set; get; }
        public string Symbol1 { set; get; }
        public string MaturityMonthYear1 { set; get; }
        public string Cp1 { set; get; }
        public decimal Strike1 { set; get; }

        public string Side1 { set; get; }
        public string SecurityType2 { set; get; }
        public string Symbol2 { set; get; }
        public string MaturityMonthYear2 { set; get; }
        public string Cp2 { set; get; }
        public decimal Strike2 { set; get; }
        public string Side2 { set; get; }
        public frmProductSelect()
        {
            InitializeComponent();

            SecurityExchange = "";
            SecurityType1 = "";
            Symbol1 = "";
            MaturityMonthYear1 = "";
            Cp1 = "";
            Strike1 = 0;
            Side1 = "";
            SecurityType2 = "";
            Symbol2 = "";
            MaturityMonthYear2 = "";
            Cp2 = "";
            Strike2 = 0;
            Side2 = "";
            SetGridStyle();
            this.dgvData.AllowUserToAddRows = false;
            this.dgvData.AllowUserToDeleteRows = false;
            this.dgvData.ReadOnly = true;
            dgvData.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            byte[] bb = frmMain.mobjDataAgent.WS_LService.WS_SecurityList();

            DataSet ds = CommonFunction.SerialUnZip(bb);

            if (ds.Tables.Count > 0)
            {
                DataTable dt = ds.Tables[0];
                dt.Columns.Add("sign1");
                dt.Columns.Add("sign2");
                dt.Columns["sign1"].Expression = "IIF(BS1='B','+1',IIF(BS1='S','-1',''))";
                dt.Columns["sign2"].Expression = "IIF(BS2='B','+1',IIF(BS2='S','-1',''))";
                dgvData.DataSource = ds.Tables[0];
            }
        }

        private void SetGridStyle()
        {
            CommonFunction.SetColumnTextStyle(this.dgvData, "SecurityExchange", "Exchange", 50, true, true);

            CommonFunction.SetColumnTextStyle(this.dgvData, "Symbol1", "product1", 50, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "MaturityMonthYear1", "contract1", 50, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "PutOrCall1", "cp1", 50, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "StrikePrice1", "StrikePrice1", 50, true, true);
            //CommonFunction.SetColumnTextStyle(this.dgvData, "BS1", "BS1", 50, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "sign1", "sign1", 50, true, true);

            CommonFunction.SetColumnTextStyle(this.dgvData, "Symbol2", "product2", 50, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "MaturityMonthYear2", "contract2", 50, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "PutOrCall2", "cp2", 50, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "StrikePrice2", "StrikePrice2", 50, true, true);
            // CommonFunction.SetColumnTextStyle(this.dgvData, "BS2", "BS2", 50, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "sign2", "sign2", 50, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "GW", "GW", 50, true, true);

            CommonFunction.SetColumnTextStyle(this.dgvData, "AddUser", "AddUser", 100, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "AddDate", "AddDate", 100, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "UpdUser", "UpdUser", 100, true, true);
            CommonFunction.SetColumnTextStyle(this.dgvData, "UpdDate", "UpdDate", 100, true, true);
            //CommonFunction.SetColumnTextStyle(this.dgvData, "SecurityType", 100, true, true);
        }
        private void btnSelect_Click(object sender, EventArgs e)
        {
            try
            {

                if (this.dgvData.CurrentRow.Index > -1)
                {
                    DataView dv = ((DataTable)this.dgvData.DataSource).DefaultView;
                    DataRowView dvr = dv[this.dgvData.CurrentRow.Index];
                    SecurityExchange = dvr["SecurityExchange"].ToString();
                    SecurityType1 = dvr["SecurityType"].ToString();
                    Symbol1 = dvr["Symbol1"].ToString();

                    MaturityMonthYear1 = dvr["MaturityMonthYear1"].ToString();
                    Cp1 = dvr["PutOrCall1"].ToString();
                    Strike1 = decimal.Parse(dvr["StrikePrice1"].ToString());
                    Side1 = dvr["BS1"].ToString();


                    Symbol2 = dvr["Symbol2"].ToString();
                    if (Symbol2.Trim().Length > 0)
                    {
                        SecurityType2 = SecurityType1;
                    }
                    MaturityMonthYear2 = dvr["MaturityMonthYear2"].ToString();
                    Cp2 = dvr["PutOrCall2"].ToString();
                    Strike2 = decimal.Parse(dvr["StrikePrice2"].ToString());
                    Side2 = dvr["BS2"].ToString();
                    this.DialogResult =  System.Windows.Forms.DialogResult.OK;
                }
            }
            catch (Exception ex)
            {
                try
                {
                    DataAgent._LM.WriteLog("UIErrorLog", this.GetType().Name
                        + " " + System.Reflection.MethodInfo.GetCurrentMethod().Name + " " + ex.Message);
                }
                catch (Exception exe)
                {
                }
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.DialogResult  = System.Windows.Forms.DialogResult.No;
        }
    }
}
