﻿namespace VIPTradingSystem.ui.Order
{
    partial class frmViewOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblOrder = new System.Windows.Forms.Label();
            this.lblContract = new System.Windows.Forms.Label();
            this.lblPriceType = new System.Windows.Forms.Label();
            this.lblOpenclose = new System.Windows.Forms.Label();
            this.lbltimeinforce = new System.Windows.Forms.Label();
            this.lblstartime = new System.Windows.Forms.Label();
            this.lblworkuntil = new System.Windows.Forms.Label();
            this.lblaccount = new System.Windows.Forms.Label();
            this.lblworkorderas = new System.Windows.Forms.Label();
            this.lblIsclosedqty = new System.Windows.Forms.Label();
            this.lblInterval = new System.Windows.Forms.Label();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblOrder
            // 
            this.lblOrder.AutoSize = true;
            this.lblOrder.Location = new System.Drawing.Point(80, 33);
            this.lblOrder.Name = "lblOrder";
            this.lblOrder.Size = new System.Drawing.Size(55, 15);
            this.lblOrder.TabIndex = 0;
            this.lblOrder.Text = "Order：";
            // 
            // lblContract
            // 
            this.lblContract.AutoSize = true;
            this.lblContract.Location = new System.Drawing.Point(65, 63);
            this.lblContract.Name = "lblContract";
            this.lblContract.Size = new System.Drawing.Size(70, 15);
            this.lblContract.TabIndex = 1;
            this.lblContract.Text = "Contract：";
            // 
            // lblPriceType
            // 
            this.lblPriceType.AutoSize = true;
            this.lblPriceType.Location = new System.Drawing.Point(27, 95);
            this.lblPriceType.Name = "lblPriceType";
            this.lblPriceType.Size = new System.Drawing.Size(108, 15);
            this.lblPriceType.TabIndex = 2;
            this.lblPriceType.Text = "Price and Type：";
            // 
            // lblOpenclose
            // 
            this.lblOpenclose.AutoSize = true;
            this.lblOpenclose.Location = new System.Drawing.Point(48, 123);
            this.lblOpenclose.Name = "lblOpenclose";
            this.lblOpenclose.Size = new System.Drawing.Size(87, 15);
            this.lblOpenclose.TabIndex = 3;
            this.lblOpenclose.Text = "Open/Close：";
            // 
            // lbltimeinforce
            // 
            this.lbltimeinforce.AutoSize = true;
            this.lbltimeinforce.Location = new System.Drawing.Point(32, 153);
            this.lbltimeinforce.Name = "lbltimeinforce";
            this.lbltimeinforce.Size = new System.Drawing.Size(103, 15);
            this.lbltimeinforce.TabIndex = 4;
            this.lbltimeinforce.Text = "Time in Force：";
            // 
            // lblstartime
            // 
            this.lblstartime.AutoSize = true;
            this.lblstartime.Location = new System.Drawing.Point(52, 183);
            this.lblstartime.Name = "lblstartime";
            this.lblstartime.Size = new System.Drawing.Size(83, 15);
            this.lblstartime.TabIndex = 5;
            this.lblstartime.Text = "Start Time：";
            // 
            // lblworkuntil
            // 
            this.lblworkuntil.AutoSize = true;
            this.lblworkuntil.Location = new System.Drawing.Point(52, 211);
            this.lblworkuntil.Name = "lblworkuntil";
            this.lblworkuntil.Size = new System.Drawing.Size(84, 15);
            this.lblworkuntil.TabIndex = 6;
            this.lblworkuntil.Text = "Work until：";
            // 
            // lblaccount
            // 
            this.lblaccount.AutoSize = true;
            this.lblaccount.Location = new System.Drawing.Point(67, 242);
            this.lblaccount.Name = "lblaccount";
            this.lblaccount.Size = new System.Drawing.Size(69, 15);
            this.lblaccount.TabIndex = 7;
            this.lblaccount.Text = "Account：";
            // 
            // lblworkorderas
            // 
            this.lblworkorderas.AutoSize = true;
            this.lblworkorderas.Location = new System.Drawing.Point(33, 280);
            this.lblworkorderas.Name = "lblworkorderas";
            this.lblworkorderas.Size = new System.Drawing.Size(103, 15);
            this.lblworkorderas.TabIndex = 8;
            this.lblworkorderas.Text = "Work order as：";
            // 
            // lblIsclosedqty
            // 
            this.lblIsclosedqty.AutoSize = true;
            this.lblIsclosedqty.Location = new System.Drawing.Point(48, 333);
            this.lblIsclosedqty.Name = "lblIsclosedqty";
            this.lblIsclosedqty.Size = new System.Drawing.Size(88, 15);
            this.lblIsclosedqty.TabIndex = 9;
            this.lblIsclosedqty.Text = "isclosed qty：";
            // 
            // lblInterval
            // 
            this.lblInterval.AutoSize = true;
            this.lblInterval.Location = new System.Drawing.Point(70, 371);
            this.lblInterval.Name = "lblInterval";
            this.lblInterval.Size = new System.Drawing.Size(66, 15);
            this.lblInterval.TabIndex = 10;
            this.lblInterval.Text = "Interval：";
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(266, 419);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(75, 32);
            this.btnSubmit.TabIndex = 11;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(383, 418);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 33);
            this.btnCancel.TabIndex = 12;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // frmViewOrder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(493, 454);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.lblInterval);
            this.Controls.Add(this.lblIsclosedqty);
            this.Controls.Add(this.lblworkorderas);
            this.Controls.Add(this.lblaccount);
            this.Controls.Add(this.lblworkuntil);
            this.Controls.Add(this.lblstartime);
            this.Controls.Add(this.lbltimeinforce);
            this.Controls.Add(this.lblOpenclose);
            this.Controls.Add(this.lblPriceType);
            this.Controls.Add(this.lblContract);
            this.Controls.Add(this.lblOrder);
            this.Name = "frmViewOrder";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "View Order";
            this.Load += new System.EventHandler(this.frmViewOrder_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Button btnCancel;
        public System.Windows.Forms.Label lblOrder;
        public System.Windows.Forms.Label lblContract;
        public System.Windows.Forms.Label lblPriceType;
        public System.Windows.Forms.Label lblOpenclose;
        public System.Windows.Forms.Label lbltimeinforce;
        public System.Windows.Forms.Label lblstartime;
        public System.Windows.Forms.Label lblworkuntil;
        public System.Windows.Forms.Label lblaccount;
        public System.Windows.Forms.Label lblworkorderas;
        public System.Windows.Forms.Label lblIsclosedqty;
        public System.Windows.Forms.Label lblInterval;

    }
}