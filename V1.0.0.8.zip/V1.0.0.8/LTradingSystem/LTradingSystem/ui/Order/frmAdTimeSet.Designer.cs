﻿namespace VIPTradingSystem.ui.Order
{
    partial class frmAdTimeSet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstType = new System.Windows.Forms.ListBox();
            this.gpSlice = new System.Windows.Forms.GroupBox();
            this.numUnit_Slice_ms = new System.Windows.Forms.NumericUpDown();
            this.numUnit_Slice_mm = new System.Windows.Forms.NumericUpDown();
            this.numUnit_Slice_ss = new System.Windows.Forms.NumericUpDown();
            this.numUnit_Slice_HH = new System.Windows.Forms.NumericUpDown();
            this.numUnit_Slice = new System.Windows.Forms.NumericUpDown();
            this.cmbUnit_Slice = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.gpDuration = new System.Windows.Forms.GroupBox();
            this.numUnit_Duration_end = new System.Windows.Forms.DateTimePicker();
            this.numUnit_Duration_begin = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.numUnit_Duration = new System.Windows.Forms.NumericUpDown();
            this.cmbUnit_Duration = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.dgvData = new System.Windows.Forms.DataGridView();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.btnOK = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.gpSlice.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numUnit_Slice_ms)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUnit_Slice_mm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUnit_Slice_ss)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUnit_Slice_HH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUnit_Slice)).BeginInit();
            this.gpDuration.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numUnit_Duration)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvData)).BeginInit();
            this.SuspendLayout();
            // 
            // lstType
            // 
            this.lstType.FormattingEnabled = true;
            this.lstType.ItemHeight = 15;
            this.lstType.Location = new System.Drawing.Point(12, 12);
            this.lstType.Name = "lstType";
            this.lstType.Size = new System.Drawing.Size(142, 154);
            this.lstType.TabIndex = 0;
            // 
            // gpSlice
            // 
            this.gpSlice.Controls.Add(this.numUnit_Slice_ms);
            this.gpSlice.Controls.Add(this.numUnit_Slice_mm);
            this.gpSlice.Controls.Add(this.numUnit_Slice_ss);
            this.gpSlice.Controls.Add(this.numUnit_Slice_HH);
            this.gpSlice.Controls.Add(this.numUnit_Slice);
            this.gpSlice.Controls.Add(this.cmbUnit_Slice);
            this.gpSlice.Controls.Add(this.label2);
            this.gpSlice.Controls.Add(this.label1);
            this.gpSlice.Location = new System.Drawing.Point(160, 13);
            this.gpSlice.Name = "gpSlice";
            this.gpSlice.Size = new System.Drawing.Size(318, 153);
            this.gpSlice.TabIndex = 1;
            this.gpSlice.TabStop = false;
            this.gpSlice.Text = "Parameters";
            this.gpSlice.Visible = false;
            // 
            // numUnit_Slice_ms
            // 
            this.numUnit_Slice_ms.Location = new System.Drawing.Point(140, 59);
            this.numUnit_Slice_ms.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.numUnit_Slice_ms.Name = "numUnit_Slice_ms";
            this.numUnit_Slice_ms.Size = new System.Drawing.Size(57, 25);
            this.numUnit_Slice_ms.TabIndex = 7;
            this.numUnit_Slice_ms.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numUnit_Slice_mm
            // 
            this.numUnit_Slice_mm.Location = new System.Drawing.Point(140, 28);
            this.numUnit_Slice_mm.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.numUnit_Slice_mm.Name = "numUnit_Slice_mm";
            this.numUnit_Slice_mm.Size = new System.Drawing.Size(57, 25);
            this.numUnit_Slice_mm.TabIndex = 6;
            this.numUnit_Slice_mm.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numUnit_Slice_ss
            // 
            this.numUnit_Slice_ss.Location = new System.Drawing.Point(78, 59);
            this.numUnit_Slice_ss.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.numUnit_Slice_ss.Name = "numUnit_Slice_ss";
            this.numUnit_Slice_ss.Size = new System.Drawing.Size(56, 25);
            this.numUnit_Slice_ss.TabIndex = 5;
            this.numUnit_Slice_ss.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numUnit_Slice_HH
            // 
            this.numUnit_Slice_HH.Location = new System.Drawing.Point(78, 28);
            this.numUnit_Slice_HH.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.numUnit_Slice_HH.Name = "numUnit_Slice_HH";
            this.numUnit_Slice_HH.Size = new System.Drawing.Size(56, 25);
            this.numUnit_Slice_HH.TabIndex = 4;
            this.numUnit_Slice_HH.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numUnit_Slice
            // 
            this.numUnit_Slice.Location = new System.Drawing.Point(140, 103);
            this.numUnit_Slice.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.numUnit_Slice.Name = "numUnit_Slice";
            this.numUnit_Slice.Size = new System.Drawing.Size(57, 25);
            this.numUnit_Slice.TabIndex = 3;
            this.numUnit_Slice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // cmbUnit_Slice
            // 
            this.cmbUnit_Slice.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbUnit_Slice.FormattingEnabled = true;
            this.cmbUnit_Slice.Location = new System.Drawing.Point(78, 102);
            this.cmbUnit_Slice.Name = "cmbUnit_Slice";
            this.cmbUnit_Slice.Size = new System.Drawing.Size(56, 23);
            this.cmbUnit_Slice.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 102);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Disclose";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Interval";
            // 
            // gpDuration
            // 
            this.gpDuration.Controls.Add(this.numUnit_Duration_end);
            this.gpDuration.Controls.Add(this.numUnit_Duration_begin);
            this.gpDuration.Controls.Add(this.label5);
            this.gpDuration.Controls.Add(this.label4);
            this.gpDuration.Controls.Add(this.numUnit_Duration);
            this.gpDuration.Controls.Add(this.cmbUnit_Duration);
            this.gpDuration.Controls.Add(this.label3);
            this.gpDuration.Location = new System.Drawing.Point(160, 12);
            this.gpDuration.Name = "gpDuration";
            this.gpDuration.Size = new System.Drawing.Size(318, 153);
            this.gpDuration.TabIndex = 6;
            this.gpDuration.TabStop = false;
            this.gpDuration.Text = "Parameters";
            this.gpDuration.Visible = false;
            // 
            // numUnit_Duration_end
            // 
            this.numUnit_Duration_end.CustomFormat = "HH:mm:ss";
            this.numUnit_Duration_end.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.numUnit_Duration_end.Location = new System.Drawing.Point(87, 111);
            this.numUnit_Duration_end.Name = "numUnit_Duration_end";
            this.numUnit_Duration_end.ShowUpDown = true;
            this.numUnit_Duration_end.Size = new System.Drawing.Size(118, 25);
            this.numUnit_Duration_end.TabIndex = 7;
            this.numUnit_Duration_end.Value = new System.DateTime(2016, 9, 30, 0, 0, 0, 0);
            this.numUnit_Duration_end.ValueChanged += new System.EventHandler(this.numUnit_Duration_end_ValueChanged);
            // 
            // numUnit_Duration_begin
            // 
            this.numUnit_Duration_begin.CustomFormat = "HH:mm:ss";
            this.numUnit_Duration_begin.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.numUnit_Duration_begin.Location = new System.Drawing.Point(87, 79);
            this.numUnit_Duration_begin.Name = "numUnit_Duration_begin";
            this.numUnit_Duration_begin.ShowUpDown = true;
            this.numUnit_Duration_begin.Size = new System.Drawing.Size(118, 25);
            this.numUnit_Duration_begin.TabIndex = 6;
            this.numUnit_Duration_begin.Value = new System.DateTime(2016, 9, 30, 17, 3, 13, 0);
            this.numUnit_Duration_begin.ValueChanged += new System.EventHandler(this.numUnit_Duration_begin_ValueChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(27, 115);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(30, 15);
            this.label5.TabIndex = 5;
            this.label5.Text = "End";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(27, 82);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 15);
            this.label4.TabIndex = 4;
            this.label4.Text = "Begin";
            // 
            // numUnit_Duration
            // 
            this.numUnit_Duration.Location = new System.Drawing.Point(145, 34);
            this.numUnit_Duration.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.numUnit_Duration.Name = "numUnit_Duration";
            this.numUnit_Duration.Size = new System.Drawing.Size(60, 25);
            this.numUnit_Duration.TabIndex = 3;
            this.numUnit_Duration.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // cmbUnit_Duration
            // 
            this.cmbUnit_Duration.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbUnit_Duration.FormattingEnabled = true;
            this.cmbUnit_Duration.Location = new System.Drawing.Point(88, 33);
            this.cmbUnit_Duration.Name = "cmbUnit_Duration";
            this.cmbUnit_Duration.Size = new System.Drawing.Size(55, 23);
            this.cmbUnit_Duration.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(27, 33);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 15);
            this.label3.TabIndex = 1;
            this.label3.Text = "Disclose";
            // 
            // dgvData
            // 
            this.dgvData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvData.Location = new System.Drawing.Point(484, 24);
            this.dgvData.Name = "dgvData";
            this.dgvData.RowTemplate.Height = 27;
            this.dgvData.Size = new System.Drawing.Size(251, 142);
            this.dgvData.TabIndex = 2;
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(12, 172);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(130, 39);
            this.btnCalculate.TabIndex = 3;
            this.btnCalculate.Text = "recalculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // btnOK
            // 
            this.btnOK.Enabled = false;
            this.btnOK.Location = new System.Drawing.Point(484, 174);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(92, 39);
            this.btnOK.TabIndex = 4;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(640, 174);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(92, 39);
            this.btnCancel.TabIndex = 5;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // frmAdTimeSet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(744, 222);
            this.Controls.Add(this.gpDuration);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.dgvData);
            this.Controls.Add(this.gpSlice);
            this.Controls.Add(this.lstType);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(762, 269);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(762, 269);
            this.Name = "frmAdTimeSet";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Advanced Settings";
            this.gpSlice.ResumeLayout(false);
            this.gpSlice.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numUnit_Slice_ms)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUnit_Slice_mm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUnit_Slice_ss)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUnit_Slice_HH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUnit_Slice)).EndInit();
            this.gpDuration.ResumeLayout(false);
            this.gpDuration.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numUnit_Duration)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvData)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lstType;
        private System.Windows.Forms.GroupBox gpSlice;
        private System.Windows.Forms.ComboBox cmbUnit_Slice;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown numUnit_Slice;
        private System.Windows.Forms.NumericUpDown numUnit_Slice_ms;
        private System.Windows.Forms.NumericUpDown numUnit_Slice_mm;
        private System.Windows.Forms.NumericUpDown numUnit_Slice_ss;
        private System.Windows.Forms.NumericUpDown numUnit_Slice_HH;
        private System.Windows.Forms.DataGridView dgvData;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.GroupBox gpDuration;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown numUnit_Duration;
        private System.Windows.Forms.ComboBox cmbUnit_Duration;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker numUnit_Duration_end;
        private System.Windows.Forms.DateTimePicker numUnit_Duration_begin;
    }
}