﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
namespace VIPTradingSystem
{
    public partial class BaseForm : com.ddsc.tool.window.baseForm 
    {
        public Dictionary<string, object> dicControls = new Dictionary<string, object>();
     
        public bool bolMdiChild
        {
            get
            {
                return mbolMdiChild;
            }
            set
            {
                mbolMdiChild = value;
            }
        }
        private bool  mbolMdiChild = true;
        public int focusSeq
        {
            get
            {
                return mintFocusSeq;
            }
            set
            {
                mintFocusSeq = value;
            }
        }
        private int mintFocusSeq = 0;
        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
             //   cp.ExStyle |= 0x02000000;  // Turn on WS_EX_COMPOSITED

          //   cp.Style &= ~0x02000000;  // Turn off WS_CLIPCHILDREN
                return cp;
            }
        } 
       
        private ArrayList buttonArray = new ArrayList();
        
        public void addMDIButton(Button btnMDI)
        {
            buttonArray.Add(btnMDI);
            btnMDI.Click += new EventHandler(btnMDI_Click);
            btnMDI.ImageList = imageList1;
            btnMDI.ImageKey = "sign-out.ico";
            toolTip1.SetToolTip(btnMDI, "窗外窗");
        }

        public void btnMDI_Click(object sender, EventArgs e)
        {
            mbolMdiChild = mbolMdiChild ? false : true;
            changeParent();
            
        }
        
        protected override void OnMove(EventArgs e)
        {
        //    this.Refresh();
            base.OnMove(e);
         //   frmMain.mobjDataAgent.objControlManager.V_frmMain.Refresh();
           
        }
        public void changeParent()
        {
            CheckBox chkobj = new CheckBox();
            if (!mbolMdiChild)
            {
                foreach (object btn in buttonArray)
                {
                    ((Button)btn).ImageKey = "sign-in.ico";
                    ((Button)btn).BackColor = Color.Yellow;
                }
                chkobj.Checked = true; 
            }
            else
            {
                foreach (object btn in buttonArray)
                {
                    ((Button)btn).ImageKey = "sign-out.ico";
                    ((Button)btn).BackColor = Color.LightGray;
                }
                chkobj.Checked = false; 
            }
            base.chkMDI_CheckedChanged(chkobj, new EventArgs(), false); 
        }
        public BaseForm()
        {
            InitializeComponent();
            this.DoubleBuffered = true;
            this.SetStyle(ControlStyles.SupportsTransparentBackColor |
               ControlStyles.OptimizedDoubleBuffer |
               ControlStyles.AllPaintingInWmPaint |
              ControlStyles.UserPaint |
              ControlStyles.ResizeRedraw |
              ControlStyles.DoubleBuffer, true);
            this.SetStyle(ControlStyles.Opaque, false);

            try
            {
                //Bitmap bmp = Properties.Resources._16x16;
                //Icon ic = Icon.FromHandle(bmp.GetHicon());
                //this.Icon = ic;
            }
            catch (Exception ex)
            {
            }
        }
        protected internal void _chkMDI_CheckedChanged(object sender, EventArgs e, bool owner)
        {
       
            base.chkMDI_CheckedChanged(sender, e, owner);
        }

        private void BaseForm_Shown(object sender, EventArgs e)
        {
            if (!mbolMdiChild)
            {
                int x = this.Location.X;
                int y= this.Location.Y;
                
                changeParent();
                if (this.WindowState == System.Windows.Forms.FormWindowState.Maximized || this.WindowState == System.Windows.Forms.FormWindowState.Minimized)
                {
                    Location = new Point(0, 0);
                }
                else
                {
                    Location = new Point(x, y);
                }
               
            }
        }
        
        private void BaseForm_Enter(object sender, EventArgs e)
        {
         
        }

        private void BaseForm_Click(object sender, EventArgs e)
        {
            frmMain.mobjDataAgent.objControlManager.V_frmMain.checkbtn(this.Name);
            if (this.WindowState == System.Windows.Forms.FormWindowState.Minimized)
            {
                this.WindowState = System.Windows.Forms.FormWindowState.Normal;
            }
        }

        private void BaseForm_Activated(object sender, EventArgs e)
        {
            try
            {
                frmMain.mobjDataAgent.objControlManager.V_frmMain.checkbtn(this.Name);
                setFocusArray();
            }
            catch (Exception ex)
            {
                MYcls.DataAgent._LM.WriteLog("UIErrorLog", ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }

        }
        public void setFocusArray()
        {
            //int idx = frmMain.mobjDataAgent.objControlManager._FocusArray.IndexOf(this.Name);
            //if (idx > -1)
            //{
            //    frmMain.mobjDataAgent.objControlManager._FocusArray.Remove(this.Name);
            //}
            //frmMain.mobjDataAgent.objControlManager._FocusArray.Add(this.Name);
            //foreach (string prog_name in frmMain.mobjDataAgent.objControlManager.dic_Programs.Keys)
            //{
            //    if (frmMain.mobjDataAgent.objControlManager.dic_Programs[prog_name] != null)
            //    {
                  
            //        { 
            //            Dictionary<string, Form> dicForm = null; 
            //            ProgramInfo p = MYcls.CommonFunction.getProgramInfo(prog_name )  ;
            //            if (p.MutiFlag  )
            //            {
            //                dicForm=(Dictionary<string, Form>)frmMain.mobjDataAgent.objControlManager.dic_Programs[prog_name];
            //            }
            //            else
            //            {
            //                dicForm = new Dictionary<string, Form>();
            //                dicForm.Add( prog_name,(Form)frmMain.mobjDataAgent.objControlManager.dic_Programs[prog_name]);
            //            }
            //            foreach (Form form in dicForm.Values)
            //            {
            //                ((BaseForm)form).focusSeq = frmMain.mobjDataAgent.objControlManager._FocusArray.IndexOf(form.Name); 
            //            }
                       

            //        }
            //    }
            //}
        }
        //[Description("get Height"), Category("視窗高度")]
        //public int _Height
        //{
        //    set
        //    {
        //        this.Height=value ;
        //    }
        //    get
        //    {
        //        if (this.WindowState == System.Windows.Forms.FormWindowState.Minimized || this.WindowState == System.Windows.Forms.FormWindowState.Maximized )
        //        {
        //            return this.BeforeSize.Height;
        //        }
        //        else
        //        {
        //            return this.Height;
        //        }
        //    }
        //}
        //[Description("get Width"), Category("視窗寬度")]
        //public int _Width
        //{
        //    set
        //    {
        //        this.Width  = value;
        //    }
        //    get
        //    {
        //        if (this.WindowState == System.Windows.Forms.FormWindowState.Minimized || this.WindowState == System.Windows.Forms.FormWindowState.Maximized)
        //        {
        //            return this.BeforeSize.Width;
        //        }
        //        else
        //        {
        //            return this.Width;
        //        }
        //    }
        //}
        //protected internal void chkMDI_CheckedChanged(object sender, EventArgs e )
        //{
        //    CheckBox chkMDI = (CheckBox)sender;

        //    if (chkMDI.Checked)
        //    {
        //        //tempParent = this.MdiParent;
        //        Point tmpP = this.PointToScreen(new Point(0 - SystemInformation.FrameBorderSize.Height, 0 - SystemInformation.FrameBorderSize.Height - SystemInformation.CaptionHeight));

              

        //        this.Location = tmpP;

            
        //        this.MdiParent = null;
      
         
        //    }
        //    else
        //    {
                
        //        System.Windows.Forms.MdiClient MC = new MdiClient();
        //        foreach (System.Windows.Forms.Control myControl in tempParent.Controls)
        //        {
        //            if (myControl is System.Windows.Forms.MdiClient)
        //            {
        //                MC = (System.Windows.Forms.MdiClient)myControl;
        //                break;
        //            }
        //        }
        //        Point tmpP;
        //        if (this.Left == 0 && this.Top == 0 || MC.ClientSize.Height == 0 && MC.ClientSize.Width == 0)
        //            tmpP = new Point(0, 0);
        //        else
        //        {
        //            if (this.tempParent.Top < this.Top && tempParent.Left < this.Left)
        //            {
        //                tmpP = MC.PointToClient(new Point(this.Location.X, this.Location.Y));
        //                if (tmpP.X < 0 || tmpP.Y < 0 || tmpP.X > MC.ClientSize.Width || tmpP.Y > MC.ClientSize.Height)
        //                    tmpP = new Point(0, 0);
        //            }
        //            else
        //                tmpP = new Point(0, 0);
        //        }

         

        //        this.MdiParent = tempParent;

        //        this.Location = tmpP;
                 
             

        //    }
        //    this.Invalidate();
        //}

    }
}
