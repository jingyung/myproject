﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
namespace VIPTradingSystem
{
    public class ProgramInfo
    {
        public ProgramInfo()
        {
            mod_id = "";
            prog_name = "";
            prog_desc = "";
            productid = "";
            collectId = "";
            remark = "";
            classid = "";
            MutiFlag = false;
        }
        public string mod_id { get; set; }
        public string prog_name { get; set; }
        public string prog_desc { get; set; }
        public string productid { get; set; }
        public string collectId { get; set; }
        public string remark { get; set; }
        public string classid { get; set; }
        public bool MutiFlag { get; set; }
    }

    public class ProgramSet
    {
        private Dictionary<string, BaseForm> _Programs;

        public Dictionary<string, BaseForm> Programs
        {
            get { return _Programs; }
            set { _Programs = value; }
        }
        public ProgramInfo ProgramInfo { get; set; }
        public BaseForm Form { get; set; }
        public ProgramSet()
        {
            _Programs = new Dictionary<string, BaseForm>();
        }
        public void Add(string name, BaseForm form)
        {
            _Programs[name] = form;
        }
        public BaseForm GetData(string name)
        {
            BaseForm form = null;
            if (_Programs.TryGetValue(name, out form))
            {
                return form;
            }
            return null;
        }
        public string[] GetKeys()
        {
            return _Programs.Keys.ToArray();
        }
        public int Count
        {
            get { return _Programs.Count; }
        }
    }


    public class ProgramProvider
    {
        public class Dictionary
        {
            ProgramInfo _ProgramInfo;

            public ProgramInfo ProgramInfo
            {
                get { return _ProgramInfo; }
                set { _ProgramInfo = value; }
            }
            private string _Name;

            public string Name
            {
                get { return _Name; }
                set { _Name = value; }
            }
            private System.Collections.Generic.Dictionary<string, BaseForm> _data = new System.Collections.Generic.Dictionary<string, BaseForm>();

            public Dictionary(string name)
            {
                _ProgramInfo = new ProgramInfo();
                _Name = name;
            }
            public void SetString(string key, BaseForm val)
            {
                _data[key] = val;
            }
            public BaseForm GetString(string key)
            {
                BaseForm val = null;
                if (!_data.TryGetValue(key, out val))
                    return null;
                return val;
            }

        }
        // private Dictionary<string, object> _Programs;
        private Dictionary<string, ProgramSet> _Programs;
        public ProgramProvider()
        {
            _Programs = new Dictionary<string, ProgramSet>();
        }
        ~ProgramProvider()
        {
            Dispose();
        }

        public void Dispose()
        {
            try
            {
                string[] ks = _Programs.Keys.ToArray<string>();
                foreach (string prog_name in ks)
                {

                    if (_Programs[prog_name] != null)
                    {
                        ProgramSet set = _Programs[prog_name];
                        if (set.ProgramInfo.MutiFlag)
                        {
                            foreach (string k in set.GetKeys())
                            {
                                set.GetData(k).Close();
                                set.GetData(k).Dispose();
                            }

                        }
                        else
                        {
                            set.Form.Close();
                            set.Form.Dispose();
                        }

                    }
                }
                _Programs.Clear();
            }
            catch (Exception ex)
            {
            }
        }

        public void AddProgram(string name, ProgramSet set)
        {
            _Programs[name] = set;
        }

        public string Add(string name, BaseForm obj)
        {
            return Add(false, name, obj);
        }
        public string Add(bool MutiFlag, string name, BaseForm obj)
        {
            ProgramSet set = null;
            if (MutiFlag)
            {
                _Programs.TryGetValue(name, out set);


                if (set == null)
                {
                    set = new ProgramSet();
                    set.Programs = new Dictionary<string, BaseForm>();
                    obj.ID = name + ":" + (set.Count + 1).ToString();
                    set.ProgramInfo = frmMain.UserConfigs.ProgramSet.GetData(name);
                    set.Add(obj.ID, obj);
                    _Programs[name] = set;
                }
                else
                {
                    obj.ID = name + ":" + (set.Count + 1).ToString();
                    set.Add(obj.ID, obj);
                }

                return obj.ID;
            }
            else
            {
                _Programs.TryGetValue(name, out set);
               
                    if (set == null)
                    {
                        set = new ProgramSet();
                        set.ProgramInfo = frmMain.UserConfigs.ProgramSet.GetData(name);
                        set.Form = obj;
                        _Programs[name] = set;
                    }
                    else
                        set.Form = obj;
               
                return name;
            }
        }

        public ProgramSet GetData(string name)
        {
            ProgramSet obj;
            if (!_Programs.TryGetValue(name, out obj))
            {
                return null;
            }
            return obj;
        }
        public string[] GetKey()
        {

            return _Programs.Keys.ToArray();
        }
        public void Remove(string name)
        {
            _Programs.Remove(name);
        }

    }
}
