﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using VIPTradingSystem.MYcls;
using System.Diagnostics;
using System.Deployment.Application;
using System.Reflection;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using com.ddsc.tool.window;
namespace VIPTradingSystem
{
    public partial class frmMain : Form
    {
        public static DataAgent mobjDataAgent;
        public static userconfigs UserConfigs;
        public static string logid = "";// Guid.NewGuid().ToString();
        ClearTimeDataHandler _ClearTimeDataHandler;
        public frmMain()
        {
            InitializeComponent();
            frmMain.UserConfigs = new userconfigs();
            CheckForShortcut();
            live_update();
            mobjDataAgent = new MYcls.DataAgent();
            mobjDataAgent.objControlManager.V_frmMain = this;
            try
            {
                //Bitmap bmp = Properties.Resources._16x16;
                //Icon ic = Icon.FromHandle(bmp.GetHicon());
                //this.Icon = ic;
                _ClearTimeDataHandler = new ClearTimeDataHandler(ClearTimeData);

            }
            catch (Exception ex)
            {
            }

        }

        public VIPTradingSystem.MYcls.DataAgent objDataAgent
        {
            get
            {
                return mobjDataAgent;
            }
            set
            {
                mobjDataAgent = value;
            }
        }
        /// <summary>
        /// 選單點選事件
        /// </summary>
        public void mnuProgram_Click(object sender, EventArgs e)
        {
            try
            {

                ToolStripMenuItem mnuSender = (ToolStripMenuItem)sender;
                string strModId = mnuSender.OwnerItem.Name.Substring(3, mnuSender.OwnerItem.Name.Length - 3);
                string strProgName = mnuSender.Name.Substring(3, mnuSender.Name.Length - 3);
                string classid = mnuSender.Tag.ToString().Split('@')[0];
                string remark = mnuSender.Tag.ToString().Split('@')[1];
                string MULTIFORM = mnuSender.Tag.ToString().Split('@')[2];

                ProgramInfo Item = new ProgramInfo();
                Item.mod_id = strModId;
                Item.prog_name = strProgName;
                Item.prog_desc = mnuSender.Text.Replace("[" + classid + "]", "");
                Item.classid = classid;
                Item.remark = remark;
                Item.MutiFlag = MULTIFORM == "Y" ? true : false;
                mobjDataAgent.objControlManager.open_Form(Item);
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("UIErrorLog", ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }

        private void MenuItem_Setting_Click(object sender, EventArgs e)
        {
            try
            {

            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("UIErrorLog", ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }

        private void mnuSignOut_Click(object sender, EventArgs e)
        {
            try
            {
                if (mobjDataAgent.DataLoadFlag)
                {
                    return;
                }
                DataAgent._LM.WriteLog("UIEventLog", "點選系統登出");

                if (toolItem_LoginId.Text != "")
                {
                    //////停止所有服務
                    enabledDataAgent(false);
                    //this.closeforms(); 
                }

            }
            catch (Exception ex)
            {

            }
        }

        private void mnuSignIn_Click(object sender, EventArgs e)
        {
            try
            {
                if (mobjDataAgent.DataLoadFlag)
                {
                
                    return;
                }
                DataAgent._LM.WriteLog("UIEventLog", "點選系統登入");

                if (toolItem_LoginId.Text != "")
                {
                    enabledDataAgent(false);
                }
                init();
            }
            catch (Exception ex)
            {

            }
        }

        private void mnuExit_Click(object sender, EventArgs e)
        {
            try
            {
                DataAgent._LM.WriteLog("UIEventLog", "點選離開");

                enabledDataAgent(false);
                Close();
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("UIErrorLog", ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }

        private void mnuDefault_Click(object sender, EventArgs e)
        {
            try
            {

            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("UIErrorLog", ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        void dipslayCollectItem()
        {
            //清除
            int idx_t = mnuCollectSet.DropDownItems.Count;
            while (idx_t > 4)
            {
                idx_t--;
                mnuCollectSet.DropDownItems.Remove(mnuCollectSet.DropDownItems[idx_t]);
                idx_t = mnuCollectSet.DropDownItems.Count;
            }
            //增加
            foreach (DataRow dr in UserConfigs.CollectionSet.Select("ISDEFUALT='N'  "))
            {
                ToolStripMenuItem t = new ToolStripMenuItem();
                t.Text = dr["Collect_id"].ToString();
                t.Click += new EventHandler(t_Click);
                mnuCollectSet.DropDownItems.Add(t);
            }
        }
        void t_Click(object sender, EventArgs e)
        {
            try
            {
                objDataAgent.objControlManager.openCollection(((ToolStripMenuItem)sender).Text, "N");
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("UIErrorLog", ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }

        private void mnuSaveDefault_Click(object sender, EventArgs e)
        {
            try
            {
                saveCollection("Default", "Y");
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("UIErrorLog", ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }

        private void mnuIni_Click(object sender, EventArgs e)
        {
            try
            {
                objDataAgent.getSystemIni();
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("UIErrorLog", ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }

 
        private delegate void MyDelegate();
        public void toolbtnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                if (mobjDataAgent.DataLoadFlag)
                {
 
                    return;
                }
                DataAgent._LM.WriteLog("UIEventLog", "點選重新登入");

                string userid = "";
                if (frmMain.UserConfigs.bolIDlogin)
                    userid = frmMain.UserConfigs.LoginID;
                else
                    userid = frmMain.UserConfigs.LoginACNO;

                string pw = frmMain.UserConfigs.PW;
                string LoginerverIp = objDataAgent.mstr_LoginerverIp;
                enabledDataAgent(false);
                enabledDataAgent(true);

                string ms = objDataAgent.login(LoginerverIp, userid, pw);
                DataAgent._LM.WriteLog("UIEventLog", ms);
                toolItem_LoginId.Text = frmMain.UserConfigs.LoginID;
                toolbar_RegisterClientStatus.Visible = true;
                toolbar_InfoSocketClientStatus.Visible = true;
                toolbar_OrderClientStatus.Visible = true;
                //this.mnuIni.Visible = true;
                this.toolbtnLogin.Visible = true;
                //toolEnterForm.Visible = true;
                // toolbtnStop.Visible = true;
                //  mnuCollectSet.Visible = true;
                dipslayCollectItem();
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("UIErrorLog", ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }




        private void toolstripBtn_Click(object sender, EventArgs e)
        {
            try
            {
                checkbtn(((System.Windows.Forms.ToolStripItem)(sender)).Name);
                mobjDataAgent.objControlManager.focusForm(((DDSCToolStripButton)(sender)).Name
                                            );
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("UIErrorLog", ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }

        private void frmMain_MdiChildActivate(object sender, EventArgs e)
        {
            try
            {

                //V1.0.0.37當MDI有異動 重新更新畫面 以防殘影
                this.Refresh();
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("UIErrorLog", ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                //V1.0.0.37 公版沒MARK FOR 客製版而MARK，如有問題請恢復成公版
                //DataAgent._LM.WriteLog("UIEventLog", "系統關閉儲存版面");
                //saveCollection();
                enabledDataAgent(false);
            }
            catch (Exception ex)
            {

            }
        }
        private void frmMain_Load(object sender, EventArgs e)
        {
            try
            {
                string version = "";
                if (ApplicationDeployment.IsNetworkDeployed)
                {
                    version = ApplicationDeployment.CurrentDeployment.CurrentVersion.ToString();
                }
                else
                {
                    version = Application.ProductVersion;
                }
                this.Text = Application.ProductName + "(" + version + ")";
#if TESTMODE
                this.Text += "(測試版)";
#else
                this.Text += "(正式版)";
#endif
                init();
            }
            catch (Exception ex)
            {
                /// DataAgent._LM.WriteLog("UIErrorLog", ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        private void toolEnterForm_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.Enter)
                {
                    if (toolEnterForm.Text.Length == 3)
                    {

                        DataRow[] drs = frmMain.UserConfigs.ProgramSet.Select("class='" + toolEnterForm.Text + "'");
                        if (drs.Length > 0)
                        {
                            string mod_id = drs[0]["MODID"].ToString();
                            string prog_name = drs[0]["prog_name"].ToString();
                            string prog_desc = drs[0]["prog_desc"].ToString();
                            string remark = drs[0]["remark"].ToString();
                            string classid = drs[0]["class"].ToString();
                            string MULTIFORM = drs[0]["MULTIFORM"].ToString();
                            ProgramInfo Item = new ProgramInfo();
                            Item.mod_id = mod_id;
                            Item.prog_name = prog_name;
                            Item.prog_desc = prog_desc;
                            Item.classid = classid;
                            Item.remark = remark;
                            Item.MutiFlag = MULTIFORM == "Y" ? true : false; ;



                            objDataAgent.objControlManager.open_Form(Item);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("UIErrorLog", ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        private void toolbtnStop_Click(object sender, EventArgs e)
        {
            try
            {

            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("UIErrorLog", ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }

        }


        public void enabledDataAgent(bool enabled)
        {
            try
            {
                if (enabled)
                {
                    /// 初始dataagent物件

                    mobjDataAgent.start();


                }
                else
                {
                    if (this.toolItem_LoginId.Text != "")
                    {
                        DataAgent._LM.WriteLog("UIEventLog", "系統重登儲存版面");


                    }
                    mnuCollectSet.Visible = false;
                    //saveCollection("Default", "Y");
                    if (frmMain.UserConfigs.logTime != null)
                        mobjDataAgent.WS_LService.WS_saveLogOut(frmMain.UserConfigs.LoginID, frmMain.UserConfigs.logDate, frmMain.UserConfigs.logTime);
                    mobjDataAgent.close();
                    this.toolItem_LoginId.Text = "";
                    toolbar_Msg.Text = "";
                    this.mnuIni.Visible = false;
                    this.toolbtnLogin.Visible = false;
                    toolEnterForm.Visible = false;
                    //toolbtnStop.Visible = false;

                    toolbar_RegisterClientStatus.Visible = false;
                    toolbar_InfoSocketClientStatus.Visible = false;
                    toolbar_OrderClientStatus.Visible = false;
                }
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("UIErrorLog", ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        /// <summary>
        /// 開啟登入視窗
        /// </summary>
        private void init()
        {
            try
            {
                DataTable dtData = new DataTable("ServerSet");
                dtData.Columns.Add("Seq", typeof(string));
                dtData.Columns.Add("ServerIp", typeof(string));
                dtData.Columns.Add("ServerPort", typeof(string));
                dtData.Columns.Add("ServerDsc", typeof(string));
                dtData.Columns.Add("DGServerIp", typeof(string));
                dtData.Columns.Add("IsDefault", typeof(string));
                dtData.Columns.Add("sortno", typeof(string));
#if TESTMODE

                DataRow drData = dtData.NewRow();
                drData = dtData.NewRow();
                drData["Seq"] = "0";
                drData["ServerIp"] = "172.16.204.89";
                drData["ServerDsc"] = "測試機";
                drData["ServerPort"] = "";
                drData["IsDefault"] = "1";
                drData["sortno"] = "1";
                dtData.Rows.Add(drData);
#else
                DataRow drData = dtData.NewRow();
                drData = dtData.NewRow();
                drData["Seq"] = "0";
                drData["ServerIp"] = "172.16.204.87";
                drData["ServerDsc"] = "正式機1";
                drData["ServerPort"] = "";
                drData["IsDefault"] = "1";
                drData["sortno"] = "1";
                dtData.Rows.Add(drData);
                drData = dtData.NewRow();
                drData = dtData.NewRow();
                drData["Seq"] = "1";
                drData["ServerIp"] = "172.16.204.88";
                drData["ServerDsc"] = "正式機2";
                drData["ServerPort"] = "";
                drData["IsDefault"] = "1";
                drData["sortno"] = "1";
                dtData.Rows.Add(drData);
#endif
                frmMain.UserConfigs.LoginServerSet = dtData.Copy();

                frmLogin IfrmLogin = new frmLogin();
                loadini();
                IfrmLogin.Owner = this;
                IfrmLogin.StartPosition = FormStartPosition.CenterScreen;
                if (IfrmLogin.ShowDialog() == DialogResult.OK)
                {
                    saveini();
                    enabledDataAgent(true);
                    toolItem_LoginId.Text = frmMain.UserConfigs.LoginID;
                    toolbar_RegisterClientStatus.Visible = true;
                    toolbar_InfoSocketClientStatus.Visible = true;
                    toolbar_OrderClientStatus.Visible = true;
                    //this.mnuIni.Visible = true;
                    this.toolbtnLogin.Visible = true;
                    // toolEnterForm.Visible = true;
                    //  toolbtnStop.Visible = true;
                    // mnuCollectSet.Visible = true;
                    IfrmLogin.Owner = null;
                    dipslayCollectItem();
                }
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("UIErrorLog", ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        /// <summary>
        /// 程式版本檢核更新
        /// </summary>
        private void live_update()
        {
            try
            {
                if (ApplicationDeployment.IsNetworkDeployed)
                {
                    ApplicationDeployment ap = ApplicationDeployment.CurrentDeployment;
                    if (ap.CheckForUpdate())
                    {
                        //    AEFutureMaster.SubForm.frmUpdate frm = new AEFutureMaster.SubForm.frmUpdate();
                        // frm.ShowDialog();
                    }
                }
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("UIErrorLog", ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        static void CheckForShortcut()
        {
            try
            {
                //if (System.Deployment.Application.ApplicationDeployment.IsNetworkDeployed)
                {
                    //  ApplicationDeployment ad = ApplicationDeployment.CurrentDeployment;
                    //if (ad.IsFirstRun)  //first time user has run the app
                    //{
                    Assembly code = Assembly.GetExecutingAssembly();
                    string company = string.Empty;
                    string description = string.Empty;
                    if (Attribute.IsDefined(code, typeof(AssemblyCompanyAttribute)))
                    {
                        AssemblyCompanyAttribute ascompany =
                          (AssemblyCompanyAttribute)Attribute.GetCustomAttribute(code,
                          typeof(AssemblyCompanyAttribute));
                        company = ascompany.Company;
                    }
                    if (Attribute.IsDefined(code, typeof(AssemblyDescriptionAttribute)))
                    {
                        AssemblyDescriptionAttribute asdescription =
                          (AssemblyDescriptionAttribute)Attribute.GetCustomAttribute(code,
                            typeof(AssemblyDescriptionAttribute));
                        description = asdescription.Description;
                    }
                    if (company != string.Empty && description != string.Empty)
                    {
                        string desktopPath = string.Empty;
                        desktopPath =
                          string.Concat(Environment.GetFolderPath(Environment.SpecialFolder.Desktop),
                            "\\", description, ".appref-ms");
                        string shortcutName = string.Empty;
                        shortcutName =
                          string.Concat(Environment.GetFolderPath(Environment.SpecialFolder.Programs),
                            "\\", company, "\\", description, ".appref-ms");
                        System.IO.File.Copy(shortcutName, desktopPath, true);
                    }
                    //}
                }
            }
            catch (Exception ex)
            {
                //   DataAgent._LM.WriteLog("UIErrorLog", ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());

            }
        }

        /// <summary>
        /// 新增toolbar按鈕
        /// </summary>
        public void new_tbButton(string id, string text, baseForm fm)//建立新的Btn
        {
            try
            {
                DDSCToolStripButton toolstripBtn = new DDSCToolStripButton();
                toolstripBtn.baseForm = fm;
                toolstripBtn.Name = id;
                toolstripBtn.Text = text;
                toolstripBtn.Click += new System.EventHandler(this.toolstripBtn_Click);
                toolBar.Items.Add(toolstripBtn);
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("UIErrorLog", ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        public void checkbtn(string frm_name)//focus toolbarbtn
        {
            try
            {
                for (int i = 4; i < toolBar.Items.Count; i++)
                {
                    ToolStripButton toolstripBtn = (ToolStripButton)toolBar.Items[i];
                    toolstripBtn.BackgroundImage = null;
                    toolstripBtn.Image = null;
                    if (toolBar.Items[i].Name == frm_name)
                    {
                        toolstripBtn.BackgroundImage = Properties.Resources.back;
                        toolstripBtn.BackgroundImageLayout = ImageLayout.Stretch;
                        toolstripBtn.Image = Properties.Resources.icon;
                    }
                }

            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("UIErrorLog", ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        public bool saveCollection(string configName, string strDefault)
        {
            return true;
            //string configName = "Default";
            //string strDefault = "Y";
            bool isOk = false;

            if (configName != "")
            {
                mobjDataAgent.objControlManager.saveCollect(configName, strDefault);

                //DataView dv = new DataView(frmMain.UserConfigs.FORM_SET);
                //dv.RowFilter = "Collect_ID='" + configName + "'  ";

                //DataView dvGridSet = new DataView( objDataAgent.objControlManager.GridSet);
                //dvGridSet.RowFilter = "Collect_ID='" + configName + "'";
                //BinaryFormatter ser = new BinaryFormatter();
                //MemoryStream unMS = new MemoryStream();
                //ser.Serialize(unMS, dv.ToTable());
                //BinaryFormatter ser2 = new BinaryFormatter();
                //MemoryStream unMS2 = new MemoryStream();
                //ser2.Serialize(unMS2, dvGridSet.ToTable());

                DataRow[] drGrids = objDataAgent.objControlManager.GridSet.Select("Collect_ID='" + configName + "' and Collect_ID<>''");
                DataRow[] drForms = frmMain.UserConfigs.FORM_SET.Select("Collect_ID='" + configName + "' and Collect_ID<>''");

                string[] arrForms = new string[drForms.Length];
                string[] arrGrids = new string[drGrids.Length];
                for (int i = 0; i < drForms.Length; i++)
                {
                    arrForms[i] = padSpace(drForms[i]["PROG_NAME"].ToString(), 30) + padSpace(drForms[i]["SET_NAME"].ToString(), 50) + padSpace(drForms[i]["SET_VALUE"].ToString(), 50) + padSpace(drForms[i]["TYPE"].ToString(), 200);
                }
                for (int i = 0; i < drGrids.Length; i++)
                {
                    arrGrids[i] = padSpace(drGrids[i]["PROG_NAME"].ToString(), 30) + padSpace(drGrids[i]["GRID_NAME"].ToString(), 20)
                    + padSpace(drGrids[i]["COLUMN_NAME"].ToString(), 20) + padSpace(drGrids[i]["HEADER_TEXT"].ToString(), 50) + padSpace(drGrids[i]["WIDTH"].ToString(), 6)
                    + padSpace(drGrids[i]["DISPLAY_INDEX"].ToString(), 6) + padSpace(drGrids[i]["VISIBLE"].ToString(), 1)
                            + padSpace(drGrids[i]["TAB"].ToString(), 1) + padSpace(drGrids[i]["SORT"].ToString(), 1) + padSpace(drGrids[i]["TYPE"].ToString(), 10);

                }
                Byte[] bytForms = MYcls.CommonFunction.zipdata(arrForms);
                Byte[] bytGrids = MYcls.CommonFunction.zipdata(arrGrids);
                //    isOk = mobjDataAgent.WS_VIPService.WS_COLLECTION_SET(frmMain.UserConfigs.LoginID, configName, strDefault, bytForms, bytGrids);

                if (isOk)
                {
                    DataAgent._LM.WriteLog("UIEventLog", "儲存版面成功");
                }
                else
                {
                    DataAgent._LM.WriteLog("UIEventLog", "儲存版面ws錯誤");

                }
            }
            return isOk;
        }
        private string padSpace(string data, int len)
        {
            byte[] byt = new byte[len];
            byte[] bytSource = Encoding.Default.GetBytes(data);
            Array.Copy(bytSource, 0, byt, 0, bytSource.Length);
            for (int i = bytSource.Length; i < byt.Length; i++)
            {
                Array.Copy(new byte[] { 0x20 }, 0, byt, i, 1);
            }
            //   Encoding.Default.GetBytes(data).Length
            //.PadRight(30, ' ') 
            return Encoding.Default.GetString(byt);
        }
        private void mnuCascade_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.Cascade);
        }

        private void mnuTileVertical_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.TileVertical);
        }

        private void mnuTileHorizontal_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.TileHorizontal);
        }

        private void mnuToolBar_Click(object sender, EventArgs e)
        {
            toolBar.Visible = mnuToolBar.Checked;
        }

        private void 期貨ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                mobjDataAgent.objControlManager.openCollection("Future", "Y");
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("UIErrorLog", ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());

            }
        }

        private void 選擇權ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                mobjDataAgent.objControlManager.openCollection("Option", "Y");
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("UIErrorLog", ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());

            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {

            }
            catch (Exception ex)
            {
                MYcls.DataAgent._LM.WriteLog("UIErrorLog", ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }



        private void frmMain_Deactivate(object sender, EventArgs e)
        {
            try
            {
                frmMain.UserConfigs.bolCtrlKeyDown = false;
            }
            catch (Exception ex)
            {
                MYcls.DataAgent._LM.WriteLog("UIErrorLog", ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            try
            {

            }
            catch (Exception ex)
            {
                MYcls.DataAgent._LM.WriteLog("UIErrorLog", ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            objDataAgent.objInfoStringHandle.parseData("21TXFE5@102750@9764@1@44975@23031@23285@10275012@102750@0@");
            //objDataAgent.objInfoStringHandle.parseData("21TXFE5@102750@9600@1@44975@23031@23285@10275012@102750@0@");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            for (int i = 9600; i <= 9700; i++)
            {
                objDataAgent.objInfoStringHandle.parseData("21TXFE5@102750@" + i.ToString() + "@1@44975@23031@23285@10275012@102750@0@");
            }
            objDataAgent.objInfoStringHandle.parseData("21TXFE5@102750@9764@1@44975@23031@23285@10275012@102750@0@");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            for (int i = 9600; i <= 9700; i++)
            {
                objDataAgent.objInfoStringHandle.parseData("21TXFE5@102750@" + i.ToString() + "@1@44975@23031@23285@10275012@102750@0@");
            }
            objDataAgent.objInfoStringHandle.parseData("21TXFE5@102750@9764@1@44975@23031@23285@10275012@102750@0@");
            for (int i = 9600; i <= 9700; i++)
            {
                objDataAgent.objInfoStringHandle.parseData("21TXFE5@102750@" + i.ToString() + "@1@44975@23031@23285@10275012@102750@0@");
            }
            objDataAgent.objInfoStringHandle.parseData("21TXFE5@102750@9764@1@44975@23031@23285@10275012@102750@0@");
        }

        private void frmMain_Resize(object sender, EventArgs e)
        {
            this.Refresh();
        }




        private void loadini()
        {
            try
            {
                StreamWriter sw_Log;
                if (!Directory.Exists(DataAgent.BASEPATH + "\\log"))
                {
                    Directory.CreateDirectory(DataAgent.BASEPATH + "\\log");
                }
                string testMode = "";
#if TESTMODE
                testMode = "test";
#else
                testMode = "";
#endif
                string path = DataAgent.BASEPATH + @"\log\UserSet" + testMode + ".ini";

                DataSet dsData = new DataSet();

                if (!File.Exists(path))
                {
                    sw_Log = File.CreateText(path);
                    sw_Log.Close();
                    sw_Log.Dispose();


                    DataTable dtUserSet = new DataTable("UserSet");
                    dtUserSet.Columns.Add("IDLOGIN", typeof(bool));
                    dtUserSet.Columns.Add("BROKER", typeof(string));
                    dtUserSet.Columns.Add("ID", typeof(string));
                    dtUserSet.Columns.Add("PW", typeof(string));
                    dtUserSet.Columns.Add("EnabledSave", typeof(bool));
                    dtUserSet.Columns.Add("EnabledSavePW", typeof(bool));
                    dtUserSet.Rows.Add(new object[] { true, "", "", "", false, false });
                    dsData.Tables.Add(dtUserSet);

                    dsData.WriteXml(path);
                }
                else
                {
                    dsData.ReadXml(path);


                }

                if (dsData.Tables["UserSet"].Rows.Count > 0)
                {
                    frmMain.UserConfigs.LoginID = dsData.Tables["UserSet"].Rows[0]["id"].ToString();
                    frmMain.UserConfigs.LoginACNO = dsData.Tables["UserSet"].Rows[0]["id"].ToString();

                    frmMain.UserConfigs.bolEnabledSave = bool.Parse(dsData.Tables["UserSet"].Rows[0]["EnabledSave"].ToString());
                    if (dsData.Tables["UserSet"].Columns.Contains("EnabledSavePW"))
                    {
                        frmMain.UserConfigs.bolEnabledSavePW = bool.Parse(dsData.Tables["UserSet"].Rows[0]["EnabledSavePW"].ToString());
                    }
                    if (dsData.Tables["UserSet"].Columns.Contains("BROKER"))
                    {
                        frmMain.UserConfigs.Company = dsData.Tables["UserSet"].Rows[0]["BROKER"].ToString();
                    }
                    if (dsData.Tables["UserSet"].Columns.Contains("IDLOGIN"))
                    {
                        frmMain.UserConfigs.bolIDlogin = bool.Parse(dsData.Tables["UserSet"].Rows[0]["IDLOGIN"].ToString());
                    }
                    if (frmMain.UserConfigs.bolEnabledSavePW)
                        frmMain.UserConfigs.PW = MYcls.CommonFunction.TripleDESDecode(dsData.Tables["UserSet"].Rows[0]["pw"].ToString(), "");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("loadini:" + ex.Message);
            }
        }
        private void saveini()
        {
            try
            {
                StreamWriter sw_Log;
                if (!Directory.Exists(DataAgent.BASEPATH + "\\log"))
                {
                    Directory.CreateDirectory(DataAgent.BASEPATH + "\\log");
                }
                string testMode = "";
#if TESTMODE
                testMode = "test";
#else
                testMode = "";
#endif
                string path = DataAgent.BASEPATH + @"\log\UserSet" + testMode + ".ini";

                DataSet dsData = new DataSet();
                dsData.Tables.Add(frmMain.UserConfigs.LoginServerSet.Copy());
                DataTable dtUserSet = new DataTable("UserSet");
                dtUserSet.Columns.Add("IDLOGIN", typeof(bool));
                dtUserSet.Columns.Add("BROKER", typeof(string));
                dtUserSet.Columns.Add("ID", typeof(string));
                dtUserSet.Columns.Add("PW", typeof(string));
                dtUserSet.Columns.Add("EnabledSave", typeof(bool));
                dtUserSet.Columns.Add("EnabledSavePW", typeof(bool));

                DataRow drNew = dtUserSet.NewRow();
                drNew["IDLOGIN"] = frmMain.UserConfigs.bolIDlogin;
                drNew["BROKER"] = frmMain.UserConfigs.Company;

                drNew["EnabledSave"] = frmMain.UserConfigs.bolEnabledSave;
                drNew["EnabledSavePW"] = frmMain.UserConfigs.bolEnabledSavePW;

                if (frmMain.UserConfigs.bolEnabledSave)
                {
                    if (frmMain.UserConfigs.bolIDlogin)
                        drNew["ID"] = frmMain.UserConfigs.LoginID;
                    else
                        drNew["ID"] = frmMain.UserConfigs.LoginACNO;
                }
                else
                    drNew["ID"] = "";
                if (frmMain.UserConfigs.bolEnabledSavePW)
                    drNew["PW"] = MYcls.CommonFunction.TripleDESEncode(frmMain.UserConfigs.PW, "");
                else
                    drNew["PW"] = "";
                dtUserSet.Rows.Add(drNew);
                dsData.Tables.Add(dtUserSet);
                dsData.WriteXml(path);

            }
            catch (Exception ex)
            {
                MessageBox.Show("saveini:" + ex.Message);
            }
        }


        delegate void ClearTimeDataHandler();


        private void ClearTimeData()
        {

            VIPTradingSystem.MYcls.CommonFunction.ShowWarningMessageBox(this, "Clear Data and restart!");
            toolbtnLogin_Click(this.toolbtnLogin, EventArgs.Empty);
        }

        public void CheckClearTime()
        {

            int now = int.Parse(frmMain.UserConfigs.ServerDateTime.Substring(8, 4));//yyyyMMddHHmmssfff
            int begin = int.Parse(frmMain.UserConfigs.ClearDataTime);//mmss


            SeqDataProvider _TransferDate = new SeqDataProvider("TransferDate", DataAgent.BASEPATH + "\\log\\current");

            string data = _TransferDate.Get(DateTime.Now.ToString("yyyyMMdd"));
            _TransferDate.close(); //為了要COPY所以要先CLOSE
            if (data != "Y")
            {
                if (now > begin)//跨日
                {

                    this.Invoke(_ClearTimeDataHandler);

                }
            }


        }

    }
}
