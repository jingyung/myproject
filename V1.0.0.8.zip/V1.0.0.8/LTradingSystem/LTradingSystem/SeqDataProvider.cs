﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;

namespace VIPTradingSystem
{
    public class SeqDataProvider
    {
        public bool RealKeepFile { get; set; }
        object locker = new object();
        Dictionary<string, string> _item;
        string _name;
        private int _count;
        string _LogName = "";
        private System.IO.FileStream _seqNumsFile;
        public int Count
        {
            get
            {
                lock (locker)
                { return _count; }
            }
        }
        public SeqDataProvider(string filename, string path)
        {
            RealKeepFile = true;
            if (!System.IO.Directory.Exists(path))
                System.IO.Directory.CreateDirectory(path);
            _LogName = System.IO.Path.Combine(path, filename + ".txt");
            _name = filename;
            _item = new Dictionary<string, string>();
            _count = 0;
            if (System.IO.File.Exists(_LogName))
            {
                using (System.IO.StreamReader seqNumReader = new System.IO.StreamReader(_LogName, Encoding.Default))
                {
                    while (true)
                    {

                        string data = seqNumReader.ReadLine();
                        if (data == "" || data == null) break;
                        //data.Split(new char[] { ',' }, 2)[1];
                        AddData(data.Split(new char[] { ',' }, 2)[0], data.Split(new char[] { ',' }, 2)[1]);
                        //AddData(data.Split(',')[0], data.Split(',')[1]);
                    }
                }
            }
            _seqNumsFile = new System.IO.FileStream(_LogName, System.IO.FileMode.OpenOrCreate, System.IO.FileAccess.ReadWrite);

            _seqNumsFile.Seek(0, System.IO.SeekOrigin.End);
        }
        private void AddData(string key, string data)
        {
            lock (locker)
            {
                _item[key] = data;
                _count++;
            }

        }
        public void Add(string key, string data)
        {
            lock (locker)
            {
                _item[key] = data;
                _count++;
                if (RealKeepFile)
                    WriteData(key, data);
            }

        }

        private void WriteData(string key, string data)
        {
            // _seqNumsFile.Seek(0, System.IO.SeekOrigin.End);
            string wdata = key + "," + data + "\n";
            byte[] b = ASCIIEncoding.Default.GetBytes(wdata);
            _seqNumsFile.Write(b, 0, b.Length);
            _seqNumsFile.Flush();
        }
        public string Get(string key)
        {
            string ret = "";
            lock (locker)
            {
                if (_item.TryGetValue(key, out ret))
                    return ret;
            }
            return "";
        }
        public bool check(string key)
        {
            return _item.ContainsKey(key);
        }
        public string[] GetArray(int start, int end)
        {
            try
            {
                if (end == 0) return null;
                if ((end - start) < 0) return null;



                ArrayList arr = new ArrayList();
                Dictionary<string, string>.Enumerator f = _item.GetEnumerator();
                int i = 0;
                while (f.MoveNext())
                {
                    KeyValuePair<string, string> pair = f.Current;
                    lock (locker)
                    {
                        if (start <= (i + 1) && end >= (i + 1))
                            arr.Add(pair.Value);
                    }
                    i++;
                }
                return (string[])arr.ToArray(typeof(string));
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        public Dictionary<string, string> GetItem()
        {
            lock (locker)
            {
                return _item;
            }
        }

        public void close()
        {
            try
            {


                if (!RealKeepFile)
                {
                    _seqNumsFile.SetLength(0);
                    foreach (string key in _item.Keys)
                    {
                        WriteData(key, _item[key]);
                    }
                }
                _item.Clear();
                if (_seqNumsFile != null)
                    _seqNumsFile.Close();

            }
            catch (Exception ex)
            {
            }

        }

    } 
}
