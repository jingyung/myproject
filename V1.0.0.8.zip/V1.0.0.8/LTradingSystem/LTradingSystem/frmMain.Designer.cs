﻿namespace VIPTradingSystem
{
    partial class frmMain
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.mnuMain = new System.Windows.Forms.MenuStrip();
            this.mnuSystemManager = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuPassWordSetting = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuRing = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuSignIn = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuSignOut = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuSystemsetting = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuCollectSet = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuDefault = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.期貨ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.選擇權ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuIni = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuExit = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuWidows = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuCascade = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuTileVertical = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuTileHorizontal = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuToolBar = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuConnection = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuOrder = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuOpenOrderConnection = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuEndOrderConnection = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuReply = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuOpenReplyConnection = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuEndReplyConnection = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuInfo = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuOpenInfoConnection = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuEndInfoConnection = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.toolbar_RegisterClientStatus = new System.Windows.Forms.ToolStripMenuItem();
            this.toolbar_InfoSocketClientStatus = new System.Windows.Forms.ToolStripMenuItem();
            this.toolbar_OrderClientStatus = new System.Windows.Forms.ToolStripMenuItem();
            this.toolbar_ReplyClientStatus = new System.Windows.Forms.ToolStripMenuItem();
            this.toolbar_MobServerRequestStatus = new System.Windows.Forms.ToolStripMenuItem();
            this.toolbar_MobServerResponseStatus = new System.Windows.Forms.ToolStripMenuItem();
            this.toolItem_LoginId = new System.Windows.Forms.ToolStripMenuItem();
            this.toolbar_Msg = new System.Windows.Forms.ToolStripMenuItem();
            this.toolBar = new System.Windows.Forms.ToolStrip();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolEnterForm = new System.Windows.Forms.ToolStripTextBox();
            this.toolbtnLogin = new System.Windows.Forms.ToolStripButton();
            this.toolbtnStop = new System.Windows.Forms.ToolStripButton();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.mnuMain.SuspendLayout();
            this.toolBar.SuspendLayout();
            this.SuspendLayout();
            // 
            // mnuMain
            // 
            this.mnuMain.BackColor = System.Drawing.SystemColors.Control;
            this.mnuMain.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.mnuMain.GripMargin = new System.Windows.Forms.Padding(0);
            this.mnuMain.ImageScalingSize = new System.Drawing.Size(12, 12);
            this.mnuMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuSystemManager,
            this.mnuWidows,
            this.toolStripMenuItem1,
            this.mnuConnection,
            this.mnuAbout,
            this.toolbar_RegisterClientStatus,
            this.toolbar_InfoSocketClientStatus,
            this.toolbar_OrderClientStatus,
            this.toolbar_ReplyClientStatus,
            this.toolbar_MobServerRequestStatus,
            this.toolbar_MobServerResponseStatus,
            this.toolItem_LoginId,
            this.toolbar_Msg});
            this.mnuMain.Location = new System.Drawing.Point(0, 0);
            this.mnuMain.Name = "mnuMain";
            this.mnuMain.Padding = new System.Windows.Forms.Padding(0);
            this.mnuMain.Size = new System.Drawing.Size(789, 24);
            this.mnuMain.TabIndex = 14;
            this.mnuMain.Text = "menuMain";
            // 
            // mnuSystemManager
            // 
            this.mnuSystemManager.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuPassWordSetting,
            this.mnuRing,
            this.mnuSignIn,
            this.mnuSignOut,
            this.mnuSystemsetting,
            this.mnuCollectSet,
            this.mnuIni,
            this.mnuExit});
            this.mnuSystemManager.Name = "mnuSystemManager";
            this.mnuSystemManager.Size = new System.Drawing.Size(49, 24);
            this.mnuSystemManager.Text = "系統";
            // 
            // mnuPassWordSetting
            // 
            this.mnuPassWordSetting.Name = "mnuPassWordSetting";
            this.mnuPassWordSetting.Size = new System.Drawing.Size(134, 22);
            this.mnuPassWordSetting.Text = "密碼設定";
            this.mnuPassWordSetting.Visible = false;
            // 
            // mnuRing
            // 
            this.mnuRing.Name = "mnuRing";
            this.mnuRing.Size = new System.Drawing.Size(134, 22);
            this.mnuRing.Text = "鈴聲設定";
            this.mnuRing.Visible = false;
            // 
            // mnuSignIn
            // 
            this.mnuSignIn.Name = "mnuSignIn";
            this.mnuSignIn.Size = new System.Drawing.Size(134, 22);
            this.mnuSignIn.Text = "系統登入";
            this.mnuSignIn.Click += new System.EventHandler(this.mnuSignIn_Click);
            // 
            // mnuSignOut
            // 
            this.mnuSignOut.Name = "mnuSignOut";
            this.mnuSignOut.Size = new System.Drawing.Size(134, 22);
            this.mnuSignOut.Text = "系統登出";
            this.mnuSignOut.Click += new System.EventHandler(this.mnuSignOut_Click);
            // 
            // mnuSystemsetting
            // 
            this.mnuSystemsetting.Name = "mnuSystemsetting";
            this.mnuSystemsetting.Size = new System.Drawing.Size(134, 22);
            this.mnuSystemsetting.Text = "系統設定";
            this.mnuSystemsetting.Visible = false;
            // 
            // mnuCollectSet
            // 
            this.mnuCollectSet.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuDefault,
            this.toolStripSeparator1,
            this.期貨ToolStripMenuItem,
            this.選擇權ToolStripMenuItem});
            this.mnuCollectSet.Name = "mnuCollectSet";
            this.mnuCollectSet.Size = new System.Drawing.Size(134, 22);
            this.mnuCollectSet.Text = "版面設定";
            this.mnuCollectSet.Visible = false;
            this.mnuCollectSet.Click += new System.EventHandler(this.MenuItem_Setting_Click);
            // 
            // mnuDefault
            // 
            this.mnuDefault.Name = "mnuDefault";
            this.mnuDefault.Size = new System.Drawing.Size(134, 22);
            this.mnuDefault.Text = "自訂版面";
            this.mnuDefault.Click += new System.EventHandler(this.mnuDefault_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(131, 6);
            // 
            // 期貨ToolStripMenuItem
            // 
            this.期貨ToolStripMenuItem.Name = "期貨ToolStripMenuItem";
            this.期貨ToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.期貨ToolStripMenuItem.Text = "期貨";
            this.期貨ToolStripMenuItem.Click += new System.EventHandler(this.期貨ToolStripMenuItem_Click);
            // 
            // 選擇權ToolStripMenuItem
            // 
            this.選擇權ToolStripMenuItem.Name = "選擇權ToolStripMenuItem";
            this.選擇權ToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.選擇權ToolStripMenuItem.Text = "選擇權";
            this.選擇權ToolStripMenuItem.Click += new System.EventHandler(this.選擇權ToolStripMenuItem_Click);
            // 
            // mnuIni
            // 
            this.mnuIni.Name = "mnuIni";
            this.mnuIni.Size = new System.Drawing.Size(134, 22);
            this.mnuIni.Text = "更新商品";
            this.mnuIni.Visible = false;
            this.mnuIni.Click += new System.EventHandler(this.mnuIni_Click);
            // 
            // mnuExit
            // 
            this.mnuExit.Name = "mnuExit";
            this.mnuExit.Size = new System.Drawing.Size(134, 22);
            this.mnuExit.Text = "離開(&X)";
            this.mnuExit.Click += new System.EventHandler(this.mnuExit_Click);
            // 
            // mnuWidows
            // 
            this.mnuWidows.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuCascade,
            this.mnuTileVertical,
            this.mnuTileHorizontal,
            this.mnuToolBar});
            this.mnuWidows.Name = "mnuWidows";
            this.mnuWidows.Size = new System.Drawing.Size(49, 24);
            this.mnuWidows.Text = "視窗";
            // 
            // mnuCascade
            // 
            this.mnuCascade.Name = "mnuCascade";
            this.mnuCascade.Size = new System.Drawing.Size(134, 22);
            this.mnuCascade.Text = "重疊排列";
            this.mnuCascade.Click += new System.EventHandler(this.mnuCascade_Click);
            // 
            // mnuTileVertical
            // 
            this.mnuTileVertical.Name = "mnuTileVertical";
            this.mnuTileVertical.Size = new System.Drawing.Size(134, 22);
            this.mnuTileVertical.Text = "垂直排列";
            this.mnuTileVertical.Click += new System.EventHandler(this.mnuTileVertical_Click);
            // 
            // mnuTileHorizontal
            // 
            this.mnuTileHorizontal.Name = "mnuTileHorizontal";
            this.mnuTileHorizontal.Size = new System.Drawing.Size(134, 22);
            this.mnuTileHorizontal.Text = "水平排列";
            this.mnuTileHorizontal.Click += new System.EventHandler(this.mnuTileHorizontal_Click);
            // 
            // mnuToolBar
            // 
            this.mnuToolBar.Checked = true;
            this.mnuToolBar.CheckOnClick = true;
            this.mnuToolBar.CheckState = System.Windows.Forms.CheckState.Checked;
            this.mnuToolBar.Name = "mnuToolBar";
            this.mnuToolBar.Size = new System.Drawing.Size(134, 22);
            this.mnuToolBar.Text = "工具列";
            this.mnuToolBar.Click += new System.EventHandler(this.mnuToolBar_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(79, 24);
            this.toolStripMenuItem1.Text = "電子憑證";
            this.toolStripMenuItem1.Visible = false;
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // mnuConnection
            // 
            this.mnuConnection.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuOrder,
            this.mnuReply,
            this.mnuInfo});
            this.mnuConnection.Name = "mnuConnection";
            this.mnuConnection.Size = new System.Drawing.Size(79, 24);
            this.mnuConnection.Text = "通訊連線";
            this.mnuConnection.Visible = false;
            // 
            // mnuOrder
            // 
            this.mnuOrder.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuOpenOrderConnection,
            this.mnuEndOrderConnection});
            this.mnuOrder.Name = "mnuOrder";
            this.mnuOrder.Size = new System.Drawing.Size(104, 22);
            this.mnuOrder.Text = "委託";
            this.mnuOrder.Visible = false;
            // 
            // mnuOpenOrderConnection
            // 
            this.mnuOpenOrderConnection.Name = "mnuOpenOrderConnection";
            this.mnuOpenOrderConnection.Size = new System.Drawing.Size(134, 22);
            this.mnuOpenOrderConnection.Text = "開啟連線";
            // 
            // mnuEndOrderConnection
            // 
            this.mnuEndOrderConnection.Name = "mnuEndOrderConnection";
            this.mnuEndOrderConnection.Size = new System.Drawing.Size(134, 22);
            this.mnuEndOrderConnection.Text = "關閉連線";
            // 
            // mnuReply
            // 
            this.mnuReply.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuOpenReplyConnection,
            this.mnuEndReplyConnection});
            this.mnuReply.Name = "mnuReply";
            this.mnuReply.Size = new System.Drawing.Size(104, 22);
            this.mnuReply.Text = "回報";
            this.mnuReply.Visible = false;
            // 
            // mnuOpenReplyConnection
            // 
            this.mnuOpenReplyConnection.Name = "mnuOpenReplyConnection";
            this.mnuOpenReplyConnection.Size = new System.Drawing.Size(134, 22);
            this.mnuOpenReplyConnection.Text = "開啟連線";
            // 
            // mnuEndReplyConnection
            // 
            this.mnuEndReplyConnection.Name = "mnuEndReplyConnection";
            this.mnuEndReplyConnection.Size = new System.Drawing.Size(134, 22);
            this.mnuEndReplyConnection.Text = "關閉連線";
            // 
            // mnuInfo
            // 
            this.mnuInfo.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuOpenInfoConnection,
            this.mnuEndInfoConnection});
            this.mnuInfo.Name = "mnuInfo";
            this.mnuInfo.Size = new System.Drawing.Size(104, 22);
            this.mnuInfo.Text = "行情";
            // 
            // mnuOpenInfoConnection
            // 
            this.mnuOpenInfoConnection.Name = "mnuOpenInfoConnection";
            this.mnuOpenInfoConnection.Size = new System.Drawing.Size(134, 22);
            this.mnuOpenInfoConnection.Text = "開啟連線";
            // 
            // mnuEndInfoConnection
            // 
            this.mnuEndInfoConnection.Name = "mnuEndInfoConnection";
            this.mnuEndInfoConnection.Size = new System.Drawing.Size(134, 22);
            this.mnuEndInfoConnection.Text = "關閉連線";
            // 
            // mnuAbout
            // 
            this.mnuAbout.Name = "mnuAbout";
            this.mnuAbout.Size = new System.Drawing.Size(49, 24);
            this.mnuAbout.Text = "說明";
            this.mnuAbout.Visible = false;
            // 
            // toolbar_RegisterClientStatus
            // 
            this.toolbar_RegisterClientStatus.Name = "toolbar_RegisterClientStatus";
            this.toolbar_RegisterClientStatus.Size = new System.Drawing.Size(12, 24);
            this.toolbar_RegisterClientStatus.Visible = false;
            // 
            // toolbar_InfoSocketClientStatus
            // 
            this.toolbar_InfoSocketClientStatus.Name = "toolbar_InfoSocketClientStatus";
            this.toolbar_InfoSocketClientStatus.Size = new System.Drawing.Size(12, 24);
            this.toolbar_InfoSocketClientStatus.Visible = false;
            // 
            // toolbar_OrderClientStatus
            // 
            this.toolbar_OrderClientStatus.Name = "toolbar_OrderClientStatus";
            this.toolbar_OrderClientStatus.Size = new System.Drawing.Size(12, 24);
            this.toolbar_OrderClientStatus.Visible = false;
            // 
            // toolbar_ReplyClientStatus
            // 
            this.toolbar_ReplyClientStatus.Name = "toolbar_ReplyClientStatus";
            this.toolbar_ReplyClientStatus.Size = new System.Drawing.Size(12, 24);
            this.toolbar_ReplyClientStatus.Visible = false;
            // 
            // toolbar_MobServerRequestStatus
            // 
            this.toolbar_MobServerRequestStatus.Name = "toolbar_MobServerRequestStatus";
            this.toolbar_MobServerRequestStatus.Size = new System.Drawing.Size(12, 24);
            this.toolbar_MobServerRequestStatus.Visible = false;
            // 
            // toolbar_MobServerResponseStatus
            // 
            this.toolbar_MobServerResponseStatus.Name = "toolbar_MobServerResponseStatus";
            this.toolbar_MobServerResponseStatus.Size = new System.Drawing.Size(12, 24);
            this.toolbar_MobServerResponseStatus.Visible = false;
            // 
            // toolItem_LoginId
            // 
            this.toolItem_LoginId.Name = "toolItem_LoginId";
            this.toolItem_LoginId.Size = new System.Drawing.Size(12, 24);
            // 
            // toolbar_Msg
            // 
            this.toolbar_Msg.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.toolbar_Msg.ForeColor = System.Drawing.Color.Red;
            this.toolbar_Msg.Name = "toolbar_Msg";
            this.toolbar_Msg.Size = new System.Drawing.Size(12, 24);
            // 
            // toolBar
            // 
            this.toolBar.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.toolBar.GripMargin = new System.Windows.Forms.Padding(0);
            this.toolBar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator2,
            this.toolEnterForm,
            this.toolbtnLogin,
            this.toolbtnStop});
            this.toolBar.Location = new System.Drawing.Point(0, 24);
            this.toolBar.Name = "toolBar";
            this.toolBar.Padding = new System.Windows.Forms.Padding(0);
            this.toolBar.Size = new System.Drawing.Size(789, 25);
            this.toolBar.TabIndex = 15;
            this.toolBar.Text = "toolBar";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // toolEnterForm
            // 
            this.toolEnterForm.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.toolEnterForm.Font = new System.Drawing.Font("新細明體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.toolEnterForm.Margin = new System.Windows.Forms.Padding(1, 3, 1, 1);
            this.toolEnterForm.Name = "toolEnterForm";
            this.toolEnterForm.Size = new System.Drawing.Size(45, 27);
            this.toolEnterForm.Visible = false;
            this.toolEnterForm.KeyDown += new System.Windows.Forms.KeyEventHandler(this.toolEnterForm_KeyDown);
            // 
            // toolbtnLogin
            // 
            this.toolbtnLogin.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolbtnLogin.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolbtnLogin.Name = "toolbtnLogin";
            this.toolbtnLogin.Size = new System.Drawing.Size(71, 22);
            this.toolbtnLogin.Text = "重新登入";
            this.toolbtnLogin.Visible = false;
            this.toolbtnLogin.Click += new System.EventHandler(this.toolbtnLogin_Click);
            // 
            // toolbtnStop
            // 
            this.toolbtnStop.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolbtnStop.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolbtnStop.Name = "toolbtnStop";
            this.toolbtnStop.Size = new System.Drawing.Size(71, 22);
            this.toolbtnStop.Text = "暫時登出";
            this.toolbtnStop.Visible = false;
            this.toolbtnStop.Click += new System.EventHandler(this.toolbtnStop_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(93, 65);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 29);
            this.button1.TabIndex = 17;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(201, 65);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(100, 29);
            this.button2.TabIndex = 19;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Visible = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(309, 65);
            this.button3.Margin = new System.Windows.Forms.Padding(4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(100, 29);
            this.button3.TabIndex = 20;
            this.button3.Text = "button3";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Visible = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(789, 344);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.toolBar);
            this.Controls.Add(this.mnuMain);
            this.IsMdiContainer = true;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmMain";
            this.Text = "法人國外下單系統";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Deactivate += new System.EventHandler(this.frmMain_Deactivate);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.MdiChildActivate += new System.EventHandler(this.frmMain_MdiChildActivate);
            this.Resize += new System.EventHandler(this.frmMain_Resize);
            this.mnuMain.ResumeLayout(false);
            this.mnuMain.PerformLayout();
            this.toolBar.ResumeLayout(false);
            this.toolBar.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        protected internal System.Windows.Forms.MenuStrip mnuMain;
        private System.Windows.Forms.ToolStripMenuItem mnuSystemManager;
        private System.Windows.Forms.ToolStripMenuItem mnuPassWordSetting;
        private System.Windows.Forms.ToolStripMenuItem mnuRing;
        private System.Windows.Forms.ToolStripMenuItem mnuSignIn;
        private System.Windows.Forms.ToolStripMenuItem mnuSignOut;
        private System.Windows.Forms.ToolStripMenuItem mnuSystemsetting;
        protected internal System.Windows.Forms.ToolStripMenuItem mnuCollectSet;
        private System.Windows.Forms.ToolStripMenuItem mnuDefault;
        private System.Windows.Forms.ToolStripMenuItem mnuIni;
        private System.Windows.Forms.ToolStripMenuItem mnuExit;
        private System.Windows.Forms.ToolStripMenuItem mnuWidows;
        private System.Windows.Forms.ToolStripMenuItem mnuCascade;
        private System.Windows.Forms.ToolStripMenuItem mnuTileVertical;
        private System.Windows.Forms.ToolStripMenuItem mnuTileHorizontal;
        private System.Windows.Forms.ToolStripMenuItem mnuToolBar;
        private System.Windows.Forms.ToolStripMenuItem mnuConnection;
        private System.Windows.Forms.ToolStripMenuItem mnuOrder;
        private System.Windows.Forms.ToolStripMenuItem mnuOpenOrderConnection;
        private System.Windows.Forms.ToolStripMenuItem mnuEndOrderConnection;
        private System.Windows.Forms.ToolStripMenuItem mnuReply;
        private System.Windows.Forms.ToolStripMenuItem mnuOpenReplyConnection;
        private System.Windows.Forms.ToolStripMenuItem mnuEndReplyConnection;
        private System.Windows.Forms.ToolStripMenuItem mnuInfo;
        private System.Windows.Forms.ToolStripMenuItem mnuOpenInfoConnection;
        private System.Windows.Forms.ToolStripMenuItem mnuEndInfoConnection;
        private System.Windows.Forms.ToolStripMenuItem mnuAbout;
        protected internal System.Windows.Forms.ToolStripMenuItem toolbar_RegisterClientStatus;
        protected internal System.Windows.Forms.ToolStripMenuItem toolbar_InfoSocketClientStatus;
        protected internal System.Windows.Forms.ToolStripMenuItem toolbar_OrderClientStatus;
        private System.Windows.Forms.ToolStripMenuItem toolbar_ReplyClientStatus;
        private System.Windows.Forms.ToolStripMenuItem toolbar_MobServerRequestStatus;
        private System.Windows.Forms.ToolStripMenuItem toolbar_MobServerResponseStatus;
        protected internal System.Windows.Forms.ToolStrip toolBar;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripTextBox toolEnterForm;
        private System.Windows.Forms.ToolStripButton toolbtnLogin;
        private System.Windows.Forms.ToolStripButton toolbtnStop;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem 期貨ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 選擇權ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        protected internal System.Windows.Forms.ToolStripMenuItem toolItem_LoginId;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        public System.Windows.Forms.ToolStripMenuItem toolbar_Msg;

    }
}

