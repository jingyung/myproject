﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Windows.Forms ;
namespace VIPTradingSystem.usercontrol
{
    public partial class noKeyRadioBTN : RadioButton 
    {
        public noKeyRadioBTN()
        {
            InitializeComponent();
        }

        public noKeyRadioBTN(IContainer container)
        {
            container.Add(this);

            InitializeComponent();
        }

        protected override void OnPreviewKeyDown(PreviewKeyDownEventArgs e)
        {
            ////if (e.KeyCode == Keys.Left || e.KeyCode == Keys.Right)
            ////{
            // e.KeyValue
            ////}
            //base.OnPreviewKeyDown(e);

        }
    }
}
