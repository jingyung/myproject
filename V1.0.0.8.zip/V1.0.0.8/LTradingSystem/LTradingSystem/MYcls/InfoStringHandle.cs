﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Threading;
namespace VIPTradingSystem.MYcls
{
    public class InfoStringHandle
    {
        public enum RegitemKind
        {
            I010 = 10, I020 = 20, I021 = 21, I022 = 22, I023 = 23, I080 = 80, I082 = 82
        }
        private DataTable mdt_I020;
        private DataTable mdt_I080;

        private DataTable mdt_I022;
        private DataTable mdt_I082;

        private DataTable mdt_I021;
        private DataTable mdt_I023;
        private DataTable mdt_I060;

        Dictionary<string, Dictionary<string, I020UIObject>> _I020UIObjects;
        Dictionary<string, Dictionary<string, I021UIObject>> _I021UIObjects;
        Dictionary<string, Dictionary<string, I022UIObject>> _I022UIObjects;
        Dictionary<string, Dictionary<string, I080UIObject>> _I080UIObjects;
        Dictionary<string, Dictionary<string, I082UIObject>> _I082UIObjects;

        Dictionary<string, I020_PRODCUT> _I020_PRODCUTS;
        Dictionary<string, I080_PRODCUT> _I080_PRODCUTS;


        private System.Threading.Thread _ThreadDisplay;
        private delegate void DisplayHandler();
        public InfoStringHandle()
        {

            iniI020();
            iniI021();

            iniI080();
            //V1.0.0.36 Added by peter on 20140320
            iniI022();
            iniI082();
            _I020UIObjects = new Dictionary<string, Dictionary<string, I020UIObject>>(); ;
            _I022UIObjects = new Dictionary<string, Dictionary<string, I022UIObject>>(); ;
            _I021UIObjects = new Dictionary<string, Dictionary<string, I021UIObject>>(); ;
            _I080UIObjects = new Dictionary<string, Dictionary<string, I080UIObject>>(); ;
            _I082UIObjects = new Dictionary<string, Dictionary<string, I082UIObject>>();

            _I020_PRODCUTS = new Dictionary<string, I020_PRODCUT>();
            _I080_PRODCUTS = new Dictionary<string, I080_PRODCUT>();
            _ThreadDisplay = new Thread(new ThreadStart(execQueueDataDisplay));
            _ThreadDisplay.IsBackground = true;
            _ThreadDisplay.Start();
        }

        ~InfoStringHandle()
        {
            Dispose();
        }

        public void Dispose()
        {
            if (_ThreadDisplay != null)
            {
                _ThreadDisplay.Abort();
            }
        }

        /// <summary>
        /// 虛擬行情成交資訊
        /// </summary>
        public DataTable I022
        {
            get
            {
                return mdt_I022;
            }
            set
            {
                mdt_I022 = value;
            }
        }

        /// <summary>
        /// 虛擬行情五檔資訊
        /// </summary>
        public DataTable I082
        {
            get
            {
                return mdt_I082;
            }
            set
            {
                mdt_I082 = value;
            }
        }

        /// <summary>
        /// 行情成交資訊
        /// </summary>
        public DataTable I020
        {
            get
            {
                return mdt_I020;
            }
            set
            {
                mdt_I020 = value;
            }
        }

        /// <summary>
        /// 行情五檔資訊
        /// </summary>
        public DataTable I080
        {
            get
            {
                return mdt_I080;
            }
            set
            {
                mdt_I080 = value;
            }
        }

        /// <summary>
        /// 行情最高最低價
        /// </summary>
        public DataTable I021
        {
            get
            {
                return mdt_I021;
            }
            set
            {
                mdt_I021 = value;
            }
        }

        /// <summary>
        /// 行情開盤價
        /// </summary>
        public DataTable I023
        {
            get
            {
                return mdt_I023;
            }
            set
            {
                mdt_I023 = value;
            }
        }

        /// <summary>
        /// 現貨價
        /// </summary>
        public DataTable I060
        {
            get
            {
                return mdt_I060;
            }
            set
            {
                mdt_I060 = value;
            }
        }

        /// <summary>
        /// 初始i020資料表
        /// </summary>
        private void iniI020()
        {
            try
            {
                mdt_I020 = new DataTable();
                mdt_I020.Columns.Add("productId", typeof(string));
                mdt_I020.Columns.Add("type", typeof(string));


                mdt_I020.Columns.Add("matchprice", typeof(decimal));

                mdt_I020.Columns.Add("matchQuantity", typeof(decimal));
                mdt_I020.Columns.Add("matchTotalQty", typeof(decimal));
                mdt_I020.Columns.Add("matchBuyCnt", typeof(decimal));
                mdt_I020.Columns.Add("matchSellCnt", typeof(decimal));
                mdt_I020.Columns.Add("matchTime", typeof(decimal));
                mdt_I020.Columns.Add("maxPriceByTime", typeof(decimal));
                mdt_I020.Columns.Add("minPriceByTime", typeof(decimal));

                DataColumn[] dcPrimaryKey = { mdt_I020.Columns["productId"] };
                mdt_I020.PrimaryKey = dcPrimaryKey;
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("InfoStringHandleLog", "iniI020:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }

        /// <summary>
        /// 初始i080資料表
        /// </summary>
        private void iniI080()
        {
            try
            {
                mdt_I080 = new DataTable();
                mdt_I080.Columns.Add("productId", typeof(string));
                mdt_I080.Columns.Add("type", typeof(string));
                mdt_I080.Columns.Add("BP1", typeof(decimal));
                mdt_I080.Columns.Add("BP2", typeof(decimal));
                mdt_I080.Columns.Add("BP3", typeof(decimal));
                mdt_I080.Columns.Add("BP4", typeof(decimal));
                mdt_I080.Columns.Add("BP5", typeof(decimal));
                mdt_I080.Columns.Add("BQ1", typeof(decimal));
                mdt_I080.Columns.Add("BQ2", typeof(decimal));
                mdt_I080.Columns.Add("BQ3", typeof(decimal));
                mdt_I080.Columns.Add("BQ4", typeof(decimal));
                mdt_I080.Columns.Add("BQ5", typeof(decimal));
                mdt_I080.Columns.Add("SP1", typeof(decimal));
                mdt_I080.Columns.Add("SP2", typeof(decimal));
                mdt_I080.Columns.Add("SP3", typeof(decimal));
                mdt_I080.Columns.Add("SP4", typeof(decimal));
                mdt_I080.Columns.Add("SP5", typeof(decimal));
                mdt_I080.Columns.Add("SQ1", typeof(decimal));
                mdt_I080.Columns.Add("SQ2", typeof(decimal));
                mdt_I080.Columns.Add("SQ3", typeof(decimal));
                mdt_I080.Columns.Add("SQ4", typeof(decimal));
                mdt_I080.Columns.Add("SQ5", typeof(decimal));
                mdt_I080.Columns.Add("maxBP1ByTime", typeof(decimal));
                mdt_I080.Columns.Add("minBP1ByTime", typeof(decimal));
                mdt_I080.Columns.Add("maxSP1ByTime", typeof(decimal));
                mdt_I080.Columns.Add("minSP1ByTime", typeof(decimal));

                DataColumn[] dcPrimaryKey = { mdt_I080.Columns["productId"] };
                mdt_I080.PrimaryKey = dcPrimaryKey;
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("InfoStringHandleLog", "iniI080:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }




        /// <summary>
        /// 初始i022資料表   //V1.0.0.36 Added by peter on 20140320
        /// </summary>
        private void iniI022()
        {
            try
            {
                mdt_I022 = new DataTable();
                mdt_I022.Columns.Add("productId", typeof(string));
                mdt_I022.Columns.Add("type", typeof(string));


                mdt_I022.Columns.Add("matchprice", typeof(decimal));

                mdt_I022.Columns.Add("matchQuantity", typeof(decimal));
                mdt_I022.Columns.Add("matchTotalQty", typeof(decimal));
                mdt_I022.Columns.Add("matchBuyCnt", typeof(decimal));
                mdt_I022.Columns.Add("matchSellCnt", typeof(decimal));
                mdt_I022.Columns.Add("matchTime", typeof(decimal));


                DataColumn[] dcPrimaryKey = { mdt_I022.Columns["productId"] };
                mdt_I022.PrimaryKey = dcPrimaryKey;
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("InfoStringHandleLog", "iniI022:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }

        /// <summary>
        /// 初始i082資料表   //V1.0.0.36 Added by peter on 20140320
        /// </summary>
        private void iniI082()
        {
            try
            {
                mdt_I082 = new DataTable();
                mdt_I082.Columns.Add("productId", typeof(string));
                mdt_I082.Columns.Add("type", typeof(string));
                mdt_I082.Columns.Add("BP1", typeof(decimal));
                mdt_I082.Columns.Add("BP2", typeof(decimal));
                mdt_I082.Columns.Add("BP3", typeof(decimal));
                mdt_I082.Columns.Add("BP4", typeof(decimal));
                mdt_I082.Columns.Add("BP5", typeof(decimal));
                mdt_I082.Columns.Add("BQ1", typeof(decimal));
                mdt_I082.Columns.Add("BQ2", typeof(decimal));
                mdt_I082.Columns.Add("BQ3", typeof(decimal));
                mdt_I082.Columns.Add("BQ4", typeof(decimal));
                mdt_I082.Columns.Add("BQ5", typeof(decimal));
                mdt_I082.Columns.Add("SP1", typeof(decimal));
                mdt_I082.Columns.Add("SP2", typeof(decimal));
                mdt_I082.Columns.Add("SP3", typeof(decimal));
                mdt_I082.Columns.Add("SP4", typeof(decimal));
                mdt_I082.Columns.Add("SP5", typeof(decimal));
                mdt_I082.Columns.Add("SQ1", typeof(decimal));
                mdt_I082.Columns.Add("SQ2", typeof(decimal));
                mdt_I082.Columns.Add("SQ3", typeof(decimal));
                mdt_I082.Columns.Add("SQ4", typeof(decimal));
                mdt_I082.Columns.Add("SQ5", typeof(decimal));

                DataColumn[] dcPrimaryKey = { mdt_I082.Columns["productId"] };
                mdt_I082.PrimaryKey = dcPrimaryKey;
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("InfoStringHandleLog", "iniI082:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }

        /// <summary>
        /// 初始i021資料表
        /// </summary>
        private void iniI021()
        {
            try
            {
                mdt_I021 = new DataTable();
                mdt_I021.Columns.Add("productId", typeof(string));
                mdt_I021.Columns.Add("type", typeof(string));
                mdt_I021.Columns.Add("dayHighPrice", typeof(decimal));
                mdt_I021.Columns.Add("dayLowPrice", typeof(decimal));
                mdt_I021.Columns.Add("showTime", typeof(string));

                DataColumn[] dcPrimaryKey = { mdt_I021.Columns["productId"] };
                mdt_I021.PrimaryKey = dcPrimaryKey;
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("InfoStringHandleLog", "iniI021:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }



        /// <summary>
        /// 拆解行情
        /// </summary>
        public void parseData(string strData)
        {
            try
            {
                long start = DateTime.Now.Ticks;
                string strHead = strData.Substring(0, 1);
                string strType = strData.Substring(1, 1);
                //判斷頭碼
                if (strHead == "2" || strHead == "5")
                {
                    string[] arrData = strData.Substring(2, strData.Length - 2).Split('@');
                    string COMMODITYID = arrData[0].TrimEnd();

                    //判斷類型i020 or i080 or i021
                    if (strType == "1")
                    {
                        decimal dmlmatchprice = decimal.Parse(arrData[2]);
                        decimal dmlmatchQuantity = decimal.Parse(arrData[3]);
                        decimal dmlmatchTotalQty = decimal.Parse(arrData[4]);
                        decimal dmlmatchBuyCnt = decimal.Parse(arrData[5]);
                        decimal dmlmatchSellCnt = decimal.Parse(arrData[6]);
                        string strmatchTime = arrData[7].Substring(0, 6);
                        lock (mdt_I020)
                        {
                            DataRow drFind = mdt_I020.Rows.Find(COMMODITYID);
                            if (drFind != null)
                            {
                                drFind.BeginEdit();
                                drFind["MatchTime"] = strmatchTime;
                                drFind["MatchPrice"] = dmlmatchprice;
                                drFind["MatchQuantity"] = dmlmatchQuantity;
                                drFind["MatchTotalQty"] = dmlmatchTotalQty;
                                drFind["MatchBuyCnt"] = dmlmatchBuyCnt;
                                drFind["MatchSellCnt"] = dmlmatchSellCnt;
                                decimal preMaxprice = ((decimal)drFind["maxPriceByTime"]);
                                decimal preMinprice = ((decimal)drFind["minPriceByTime"]);
                                if (dmlmatchprice > preMaxprice)
                                {
                                    drFind["maxPriceByTime"] = dmlmatchprice;
                                }
                                else if (dmlmatchprice < preMinprice)
                                {
                                    drFind["minPriceByTime"] = dmlmatchprice;
                                } 

                                drFind.EndEdit();
                            }
                            else
                            {
                                drFind = mdt_I020.NewRow();
                                drFind["productId"] = COMMODITYID;
                                drFind["MatchTime"] = strmatchTime;
                                drFind["MatchPrice"] = dmlmatchprice;
                                drFind["MatchQuantity"] = dmlmatchQuantity;
                                drFind["MatchTotalQty"] = dmlmatchTotalQty;
                                drFind["MatchBuyCnt"] = dmlmatchBuyCnt;
                                drFind["MatchSellCnt"] = dmlmatchSellCnt;
                                drFind["maxPriceByTime"] = dmlmatchprice;
                                drFind["minPriceByTime"] = dmlmatchprice; 
                             
                          
                                mdt_I020.Rows.Add(drFind);
                            }
                        }
                        lock (_I020_PRODCUTS)
                        {
                            I020_PRODCUT objI020 =new I020_PRODCUT() ; 
                            objI020._matchTime = strmatchTime;
                            objI020._matchprice = dmlmatchprice;
                            objI020._matchQuantity = dmlmatchQuantity;
                            objI020._matchTotalQty = dmlmatchTotalQty;
                            objI020._matchBuyCnt = dmlmatchBuyCnt;
                            objI020._matchSellCnt = dmlmatchSellCnt; 
                            if (_I020_PRODCUTS.ContainsKey(COMMODITYID)) 
                                _I020_PRODCUTS[COMMODITYID] = objI020;  
                            else 
                                _I020_PRODCUTS.Add(COMMODITYID, objI020); 
                        }

                    }
                    else if (strType == "2")
                    {
                        decimal dmlBP1 = decimal.Parse(arrData[1]);
                        decimal dmlBP2 = decimal.Parse(arrData[3]);
                        decimal dmlBP3 = decimal.Parse(arrData[5]);
                        decimal dmlBP4 = decimal.Parse(arrData[7]);
                        decimal dmlBP5 = decimal.Parse(arrData[9]);
                        decimal dmlBQ1 = decimal.Parse(arrData[2]);
                        decimal dmlBQ2 = decimal.Parse(arrData[4]);
                        decimal dmlBQ3 = decimal.Parse(arrData[6]);
                        decimal dmlBQ4 = decimal.Parse(arrData[8]);
                        decimal dmlBQ5 = decimal.Parse(arrData[10]);
                        decimal dmlSP1 = decimal.Parse(arrData[11]);
                        decimal dmlSP2 = decimal.Parse(arrData[13]);
                        decimal dmlSP3 = decimal.Parse(arrData[15]);
                        decimal dmlSP4 = decimal.Parse(arrData[17]);
                        decimal dmlSP5 = decimal.Parse(arrData[19]);
                        decimal dmlSQ1 = decimal.Parse(arrData[12]);
                        decimal dmlSQ2 = decimal.Parse(arrData[14]);
                        decimal dmlSQ3 = decimal.Parse(arrData[16]);
                        decimal dmlSQ4 = decimal.Parse(arrData[18]);
                        decimal dmlSQ5 = decimal.Parse(arrData[20]);
                        lock (mdt_I080)
                        {
                            DataRow drFind = mdt_I080.Rows.Find(COMMODITYID);
                            if (drFind != null)
                            {
                                drFind.BeginEdit();
                                drFind["BP1"] = dmlBP1;
                                drFind["BP2"] = dmlBP2;
                                drFind["BP3"] = dmlBP3;
                                drFind["BP4"] = dmlBP4;
                                drFind["BP5"] = dmlBP5;
                                drFind["BQ1"] = dmlBQ1;
                                drFind["BQ2"] = dmlBQ2;
                                drFind["BQ3"] = dmlBQ3;
                                drFind["BQ4"] = dmlBQ4;
                                drFind["BQ5"] = dmlBQ5;
                                drFind["SP1"] = dmlSP1;
                                drFind["SP2"] = dmlSP2;
                                drFind["SP3"] = dmlSP3;
                                drFind["SP4"] = dmlSP4;
                                drFind["SP5"] = dmlSP5;
                                drFind["SQ1"] = dmlSQ1;
                                drFind["SQ2"] = dmlSQ2;
                                drFind["SQ3"] = dmlSQ3;
                                drFind["SQ4"] = dmlSQ4;
                                drFind["SQ5"] = dmlSQ5;
                                decimal preMaxBP1 = ((decimal)drFind["maxBP1ByTime"]);
                                decimal preMinBP1 = ((decimal)drFind["minBP1ByTime"]);
                                if (dmlBP1 > preMaxBP1)
                                {
                                    drFind["maxBP1ByTime"] = dmlBP1;
                                }
                                else if (dmlBP1 < preMinBP1)
                                {
                                    drFind["minBP1ByTime"] = dmlBP1;
                                }
                                decimal preMaxSP1 = ((decimal)drFind["maxSP1ByTime"]);
                                decimal preMinSP1 = ((decimal)drFind["minSP1ByTime"]);
                                if (dmlSP1 > preMaxSP1)
                                {
                                    drFind["maxSP1ByTime"] = dmlSP1;
                                }
                                else if (dmlSP1 < preMinSP1)
                                {
                                    drFind["minSP1ByTime"] = dmlSP1;
                                } 
                                drFind.EndEdit();
                            }
                            else
                            {
                                drFind = mdt_I080.NewRow();
                                drFind["productId"] = COMMODITYID;
                                drFind["BP1"] = dmlBP1;
                                drFind["BP2"] = dmlBP2;
                                drFind["BP3"] = dmlBP3;
                                drFind["BP4"] = dmlBP4;
                                drFind["BP5"] = dmlBP5;
                                drFind["BQ1"] = dmlBQ1;
                                drFind["BQ2"] = dmlBQ2;
                                drFind["BQ3"] = dmlBQ3;
                                drFind["BQ4"] = dmlBQ4;
                                drFind["BQ5"] = dmlBQ5;
                                drFind["SP1"] = dmlSP1;
                                drFind["SP2"] = dmlSP2;
                                drFind["SP3"] = dmlSP3;
                                drFind["SP4"] = dmlSP4;
                                drFind["SP5"] = dmlSP5;
                                drFind["SQ1"] = dmlSQ1;
                                drFind["SQ2"] = dmlSQ2;
                                drFind["SQ3"] = dmlSQ3;
                                drFind["SQ4"] = dmlSQ4;
                                drFind["SQ5"] = dmlSQ5;
                                drFind["maxBP1ByTime"] = dmlBP1;
                                drFind["minBP1ByTime"] = dmlBP1;
                                drFind["maxSP1ByTime"] = dmlSP1;
                                drFind["minSP1ByTime"] = dmlSP1;
                                mdt_I080.Rows.Add(drFind);
                            }
                        }
                        lock (_I080_PRODCUTS)
                        {
                            I080_PRODCUT objI080 = new I080_PRODCUT();
                            objI080._BP1 = dmlBP1;
                            objI080._BP2 = dmlBP2;
                            objI080._BP3 = dmlBP3;
                            objI080._BP4 = dmlBP4;
                            objI080._BP5 = dmlBP5;
                            objI080._BQ1 = dmlBQ1;
                            objI080._BQ2 = dmlBQ2;
                            objI080._BQ3 = dmlBQ3;
                            objI080._BQ4 = dmlBQ4;
                            objI080._BQ5 = dmlBQ5;
                            objI080._SP1 = dmlSP1;
                            objI080._SP2 = dmlSP2;
                            objI080._SP3 = dmlSP3;
                            objI080._SP4 = dmlSP4;
                            objI080._SP5 = dmlSP5;
                            objI080._SQ1 = dmlSQ1;
                            objI080._SQ2 = dmlSQ2;
                            objI080._SQ3 = dmlSQ3;
                            objI080._SQ4 = dmlSQ4;
                            objI080._SQ5 = dmlSQ5;
                            if (_I080_PRODCUTS.ContainsKey(COMMODITYID))
                                _I080_PRODCUTS[COMMODITYID] = objI080;
                            else
                                _I080_PRODCUTS.Add(COMMODITYID, objI080);
                        }
                    }
                    else if (strType == "5")
                    {
                        decimal dmldayHighPrice = decimal.Parse(arrData[2]);
                        decimal dmldayLowPrice = decimal.Parse(arrData[3]);
                        string strshowTime = arrData[1];
                        lock (mdt_I021)
                        {
                            DataRow drFind = mdt_I021.Rows.Find(COMMODITYID);
                            if (drFind != null)
                            {
                                drFind.BeginEdit();
                                drFind["dayHighPrice"] = dmldayHighPrice;
                                drFind["dayLowPrice"] = dmldayLowPrice;

                                drFind["showTime"] = strshowTime;
                                drFind.EndEdit();
                            }
                            else
                            {
                                drFind = mdt_I021.NewRow();
                                drFind["productId"] = COMMODITYID;
                                drFind["dayHighPrice"] = dmldayHighPrice;
                                drFind["dayLowPrice"] = dmldayLowPrice;

                                drFind["showTime"] = strshowTime;
                                mdt_I021.Rows.Add(drFind);
                            }
                        }

                    }
                    //V1.0.0.36 Added by peter on 20140320
                    else if (strType == "7")
                    {
                        decimal dmlmatchprice = decimal.Parse(arrData[2]);
                        decimal dmlmatchQuantity = decimal.Parse(arrData[3]);
                        decimal dmlmatchTotalQty = decimal.Parse(arrData[4]);
                        decimal dmlmatchBuyCnt = decimal.Parse(arrData[5]);
                        decimal dmlmatchSellCnt = decimal.Parse(arrData[6]);
                        string strmatchTime = arrData[7].Substring(0, 6);
                        lock (mdt_I022)
                        {
                            DataRow drFind = mdt_I022.Rows.Find(COMMODITYID);
                            if (drFind != null)
                            {
                                drFind.BeginEdit();
                                drFind["MatchTime"] = strmatchTime;
                                drFind["MatchPrice"] = dmlmatchprice;
                                drFind["MatchQuantity"] = dmlmatchQuantity;
                                drFind["MatchTotalQty"] = dmlmatchTotalQty;
                                drFind["MatchBuyCnt"] = dmlmatchBuyCnt;
                                drFind["MatchSellCnt"] = dmlmatchSellCnt;
                                drFind.EndEdit();
                            }
                            else
                            {
                                drFind = mdt_I022.NewRow();
                                drFind["productId"] = COMMODITYID;
                                drFind["MatchTime"] = strmatchTime;
                                drFind["MatchPrice"] = dmlmatchprice;
                                drFind["MatchQuantity"] = dmlmatchQuantity;
                                drFind["MatchTotalQty"] = dmlmatchTotalQty;
                                drFind["MatchBuyCnt"] = dmlmatchBuyCnt;
                                drFind["MatchSellCnt"] = dmlmatchSellCnt;
                                mdt_I022.Rows.Add(drFind);
                            }
                        }
                    }

                   //V1.0.0.36 Added by peter on 20140320
                    else if (strType == "8")
                    {
                        decimal dmlBP1 = decimal.Parse(arrData[1]);
                        decimal dmlBP2 = decimal.Parse(arrData[3]);
                        decimal dmlBP3 = decimal.Parse(arrData[5]);
                        decimal dmlBP4 = decimal.Parse(arrData[7]);
                        decimal dmlBP5 = decimal.Parse(arrData[9]);
                        decimal dmlBQ1 = decimal.Parse(arrData[2]);
                        decimal dmlBQ2 = decimal.Parse(arrData[4]);
                        decimal dmlBQ3 = decimal.Parse(arrData[6]);
                        decimal dmlBQ4 = decimal.Parse(arrData[8]);
                        decimal dmlBQ5 = decimal.Parse(arrData[10]);
                        decimal dmlSP1 = decimal.Parse(arrData[11]);
                        decimal dmlSP2 = decimal.Parse(arrData[13]);
                        decimal dmlSP3 = decimal.Parse(arrData[15]);
                        decimal dmlSP4 = decimal.Parse(arrData[17]);
                        decimal dmlSP5 = decimal.Parse(arrData[19]);
                        decimal dmlSQ1 = decimal.Parse(arrData[12]);
                        decimal dmlSQ2 = decimal.Parse(arrData[14]);
                        decimal dmlSQ3 = decimal.Parse(arrData[16]);
                        decimal dmlSQ4 = decimal.Parse(arrData[18]);
                        decimal dmlSQ5 = decimal.Parse(arrData[20]);
                        lock (mdt_I082)
                        {
                            DataRow drFind = mdt_I082.Rows.Find(COMMODITYID);
                            if (drFind != null)
                            {
                                drFind.BeginEdit();
                                drFind["BP1"] = dmlBP1;
                                drFind["BP2"] = dmlBP2;
                                drFind["BP3"] = dmlBP3;
                                drFind["BP4"] = dmlBP4;
                                drFind["BP5"] = dmlBP5;
                                drFind["BQ1"] = dmlBQ1;
                                drFind["BQ2"] = dmlBQ2;
                                drFind["BQ3"] = dmlBQ3;
                                drFind["BQ4"] = dmlBQ4;
                                drFind["BQ5"] = dmlBQ5;
                                drFind["SP1"] = dmlSP1;
                                drFind["SP2"] = dmlSP2;
                                drFind["SP3"] = dmlSP3;
                                drFind["SP4"] = dmlSP4;
                                drFind["SP5"] = dmlSP5;
                                drFind["SQ1"] = dmlSQ1;
                                drFind["SQ2"] = dmlSQ2;
                                drFind["SQ3"] = dmlSQ3;
                                drFind["SQ4"] = dmlSQ4;
                                drFind["SQ5"] = dmlSQ5;
                                drFind.EndEdit();
                            }
                            else
                            {
                                drFind = mdt_I082.NewRow();
                                drFind["productId"] = COMMODITYID;
                                drFind["BP1"] = dmlBP1;
                                drFind["BP2"] = dmlBP2;
                                drFind["BP3"] = dmlBP3;
                                drFind["BP4"] = dmlBP4;
                                drFind["BP5"] = dmlBP5;
                                drFind["BQ1"] = dmlBQ1;
                                drFind["BQ2"] = dmlBQ2;
                                drFind["BQ3"] = dmlBQ3;
                                drFind["BQ4"] = dmlBQ4;
                                drFind["BQ5"] = dmlBQ5;
                                drFind["SP1"] = dmlSP1;
                                drFind["SP2"] = dmlSP2;
                                drFind["SP3"] = dmlSP3;
                                drFind["SP4"] = dmlSP4;
                                drFind["SP5"] = dmlSP5;
                                drFind["SQ1"] = dmlSQ1;
                                drFind["SQ2"] = dmlSQ2;
                                drFind["SQ3"] = dmlSQ3;
                                drFind["SQ4"] = dmlSQ4;
                                drFind["SQ5"] = dmlSQ5;
                                mdt_I082.Rows.Add(drFind);
                            }
                        }
                    }


                }


             //  DataAgent._LM.WriteLog("InfoStringHandleLog","-"+ (DateTime.Now.Ticks - start).ToString());

            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("InfoStringHandleLog", "parseData:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }

        }

        private void execQueueDataDisplay()
        {


            while (true)
            {
                try
                {
                    frmMain.mobjDataAgent.objControlManager.V_frmMain.Invoke(new DisplayHandler(display));
                    Thread.Sleep(50);
                }
                catch (Exception ex)
                {
                }

            }
        }
        private void display()
        {
            DataTable dti020, dti021, dti080, dti022, dti082;
            string ProductID = "";
            try
            {
                int tick = Environment.TickCount;
                lock (mdt_I020)
                {
                    dti020 = mdt_I020.Copy();
                    mdt_I020.Clear();
                }
                for (int i = 0; i < dti020.Rows.Count; i++)
                {
                    DataRow dr = dti020.Rows[i];
                    ProductID = dr["productId"].ToString();
                    if (_I020UIObjects.ContainsKey(ProductID))
                    {


                        foreach (I020UIObject obj in _I020UIObjects[ProductID].Values)
                        {

                            obj._matchprice = (decimal)dr["MatchPrice"];
                            obj._matchQuantity = (decimal)dr["MatchQuantity"]; ;
                            obj._matchTotalQty = (decimal)dr["MatchTotalQty"]; ;
                            obj._matchBuyCnt = (decimal)dr["MatchBuyCnt"]; ;
                            obj._matchSellCnt = (decimal)dr["MatchSellCnt"]; ;
                            obj._matchTime = dr["MatchTime"].ToString();

                            obj._maxPriceByTime = (decimal)dr["maxPriceByTime"];
                            obj._minPriceByTime = (decimal)dr["minPriceByTime"];
                            obj.raiseReceiveI020();
                        }
                    }
                }


                lock (mdt_I021)
                {
                    dti021 = mdt_I021.Copy();
                    mdt_I021.Clear();
                    mdt_I021.Clear();
                }

                for (int i = 0; i < dti021.Rows.Count; i++)
                {
                    DataRow dr = dti021.Rows[i];
                    ProductID = dr["productId"].ToString();
                    if (_I021UIObjects.ContainsKey(ProductID))
                    {


                        foreach (I021UIObject obj in _I021UIObjects[ProductID].Values)
                        {
                            obj._dayHighPrice = (decimal)dr["dayHighPrice"];
                            obj._dayLowPrice = (decimal)dr["dayLowPrice"];
                            obj._showTime = dr["showTime"].ToString();
                            obj.raiseReceiveI021();
                        }
                    }
                }

                lock (mdt_I022)
                {
                    dti022 = mdt_I022.Copy();
                    mdt_I022.Clear();
                }
                for (int i = 0; i < dti022.Rows.Count; i++)
                {
                    DataRow dr = dti022.Rows[i];
                    ProductID = dr["productId"].ToString();
                    if (_I022UIObjects.ContainsKey(ProductID))
                    {
                        foreach (I022UIObject obj in _I022UIObjects[ProductID].Values)
                        {
                            obj._matchprice = (decimal)dr["MatchPrice"];
                            obj._matchQuantity = (decimal)dr["MatchQuantity"]; ;
                            obj._matchTotalQty = (decimal)dr["MatchTotalQty"]; ;
                            obj._matchBuyCnt = (decimal)dr["MatchBuyCnt"]; ;
                            obj._matchSellCnt = (decimal)dr["MatchSellCnt"]; ;
                            obj._matchTime = dr["MatchTime"].ToString();                            
                            obj.raiseReceiveI022();
                        }
                    }
                }

                lock (mdt_I080)
                {
                    dti080 = mdt_I080.Copy();
                    mdt_I080.Clear();
                  
                }

                for (int i = 0; i < dti080.Rows.Count; i++)
                {
                    DataRow dr = dti080.Rows[i];
                    ProductID = dr["productId"].ToString();
                    if (_I080UIObjects.ContainsKey(ProductID))
                    {


                        foreach (I080UIObject obj in _I080UIObjects[ProductID].Values)
                        {
                            obj._BP1 = (decimal)dr["BP1"];
                            obj._BP2 = (decimal)dr["BP2"];
                            obj._BP3 = (decimal)dr["BP3"];
                            obj._BP4 = (decimal)dr["BP4"];
                            obj._BP5 = (decimal)dr["BP5"];
                            obj._BQ1 = (decimal)dr["BQ1"];
                            obj._BQ2 = (decimal)dr["BQ2"];
                            obj._BQ3 = (decimal)dr["BQ3"];
                            obj._BQ4 = (decimal)dr["BQ4"];
                            obj._BQ5 = (decimal)dr["BQ5"];
                            obj._SP1 = (decimal)dr["SP1"];
                            obj._SP2 = (decimal)dr["SP2"];
                            obj._SP3 = (decimal)dr["SP3"];
                            obj._SP4 = (decimal)dr["SP4"];
                            obj._SP5 = (decimal)dr["SP5"];
                            obj._SQ1 = (decimal)dr["SQ1"];
                            obj._SQ2 = (decimal)dr["SQ2"];
                            obj._SQ3 = (decimal)dr["SQ3"];
                            obj._SQ4 = (decimal)dr["SQ4"];
                            obj._SQ5 = (decimal)dr["SQ5"];
                            obj._maxBP1ByTime = (decimal)dr["maxBP1ByTime"];
                            obj._minBP1ByTime = (decimal)dr["minBP1ByTime"];
                            obj._maxSP1ByTime = (decimal)dr["maxSP1ByTime"];
                            obj._minSP1ByTime = (decimal)dr["minSP1ByTime"];
                            obj.raiseReceiveI080();
                        }
                    }

                }

                lock (mdt_I082)
                {
                    dti082 = mdt_I082.Copy();
                    mdt_I082.Clear();
                }
                for (int i = 0; i < dti082.Rows.Count; i++)
                {
                    DataRow dr = dti082.Rows[i];
                    ProductID = dr["productId"].ToString();
                    if (_I082UIObjects.ContainsKey(ProductID))
                    {
                        foreach (I082UIObject obj in _I082UIObjects[ProductID].Values)
                        {
                            obj._BP1 = (decimal)dr["BP1"];
                            obj._BP2 = (decimal)dr["BP2"];
                            obj._BP3 = (decimal)dr["BP3"];
                            obj._BP4 = (decimal)dr["BP4"];
                            obj._BP5 = (decimal)dr["BP5"];
                            obj._BQ1 = (decimal)dr["BQ1"];
                            obj._BQ2 = (decimal)dr["BQ2"];
                            obj._BQ3 = (decimal)dr["BQ3"];
                            obj._BQ4 = (decimal)dr["BQ4"];
                            obj._BQ5 = (decimal)dr["BQ5"];
                            obj._SP1 = (decimal)dr["SP1"];
                            obj._SP2 = (decimal)dr["SP2"];
                            obj._SP3 = (decimal)dr["SP3"];
                            obj._SP4 = (decimal)dr["SP4"];
                            obj._SP5 = (decimal)dr["SP5"];
                            obj._SQ1 = (decimal)dr["SQ1"];
                            obj._SQ2 = (decimal)dr["SQ2"];
                            obj._SQ3 = (decimal)dr["SQ3"];
                            obj._SQ4 = (decimal)dr["SQ4"];
                            obj._SQ5 = (decimal)dr["SQ5"];
                            obj.raiseReceiveI082();
                        }
                    }
                }
                frmMain.mobjDataAgent.objControlManager.V_frmMain.Update();
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("InfoStringHandleLog", "display:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        /// <summary>
        /// 依商品取得I020內容
        /// </summary>
        public I020_PRODCUT getI020(string productid)
        {
            I020_PRODCUT obj = new I020_PRODCUT();
            try
            { 
                lock (_I020_PRODCUTS)
                {
                    if (_I020_PRODCUTS.ContainsKey(productid))
                    {
                        obj._matchTime = _I020_PRODCUTS[productid]._matchTime;
                        obj._matchprice = _I020_PRODCUTS[productid]._matchprice;
                        obj._matchQuantity = _I020_PRODCUTS[productid]._matchQuantity;
                        obj._matchTotalQty = _I020_PRODCUTS[productid]._matchTotalQty;
                        obj._matchBuyCnt = _I020_PRODCUTS[productid]._matchBuyCnt;
                        obj._matchSellCnt = _I020_PRODCUTS[productid]._matchSellCnt;
                    }
                }
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("InfoStringHandleLog", "getI020:" + productid+":" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
            return obj;
        }
        /// <summary>
        /// 依商品取得I080內容
        /// </summary>
        public I080_PRODCUT getI080(string productid)
        {
            I080_PRODCUT obj = new I080_PRODCUT();
            try
            {
                lock (_I080_PRODCUTS)
                {
                    if (_I080_PRODCUTS.ContainsKey(productid))
                    {
                        obj._BP1 = _I080_PRODCUTS[productid]._BP1;
                        obj._BP2 = _I080_PRODCUTS[productid]._BP2;
                        obj._BP3 = _I080_PRODCUTS[productid]._BP3;
                        obj._BP4 = _I080_PRODCUTS[productid]._BP4;
                        obj._BP5 = _I080_PRODCUTS[productid]._BP5;
                        obj._BQ1 = _I080_PRODCUTS[productid]._BQ1;
                        obj._BQ2 = _I080_PRODCUTS[productid]._BQ2;
                        obj._BQ3 = _I080_PRODCUTS[productid]._BQ3;
                        obj._BQ4 = _I080_PRODCUTS[productid]._BQ4;
                        obj._BQ5 = _I080_PRODCUTS[productid]._BQ5;

                        obj._SP1 = _I080_PRODCUTS[productid]._SP1;
                        obj._SP2 = _I080_PRODCUTS[productid]._SP2;
                        obj._SP3 = _I080_PRODCUTS[productid]._SP3;
                        obj._SP4 = _I080_PRODCUTS[productid]._SP4;
                        obj._SP5 = _I080_PRODCUTS[productid]._SP5;
                        obj._SQ1 = _I080_PRODCUTS[productid]._SQ1;
                        obj._SQ2 = _I080_PRODCUTS[productid]._SQ2;
                        obj._SQ3 = _I080_PRODCUTS[productid]._SQ3;
                        obj._SQ4 = _I080_PRODCUTS[productid]._SQ4;
                        obj._SQ5 = _I080_PRODCUTS[productid]._SQ5;
                    }
                }
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("InfoStringHandleLog", "getI020:" + productid + ":" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
            return obj;
        }
        public void AddUIItem(RegitemKind Kind, string productId, string progname)
        {
            try
            {

                switch (Kind)
                {
                    case RegitemKind.I020:
                        I020UIObject objI020UI = new I020UIObject();
                        objI020UI.productId = productId;
                        if (_I020UIObjects.ContainsKey(productId))
                        {
                            _I020UIObjects[productId][progname] = objI020UI;
                        }
                        else
                        {
                            Dictionary<string, I020UIObject> prog = new Dictionary<string, I020UIObject>();
                            prog.Add(progname, objI020UI);
                            _I020UIObjects.Add(productId, prog);
                        }

                        break;
                    case RegitemKind.I021:
                        I021UIObject objI021UI = new I021UIObject();
                        objI021UI.productId = productId;
                        if (_I021UIObjects.ContainsKey(productId))
                        {
                            _I021UIObjects[productId][progname] = objI021UI;
                        }
                        else
                        {
                            Dictionary<string, I021UIObject> prog = new Dictionary<string, I021UIObject>();
                            prog.Add(progname, objI021UI);
                            _I021UIObjects.Add(productId, prog);
                        }

                        break;
                    case RegitemKind.I080:
                        I080UIObject objI080UI = new I080UIObject();
                        objI080UI.productId = productId;
                        if (_I080UIObjects.ContainsKey(productId))
                        {
                            _I080UIObjects[productId][progname] = objI080UI;
                        }
                        else
                        {
                            Dictionary<string, I080UIObject> prog = new Dictionary<string, I080UIObject>();
                            prog.Add(progname, objI080UI);
                            _I080UIObjects.Add(productId, prog);
                        }

                        break;
                    case RegitemKind.I022:
                        I022UIObject objI022UI = new I022UIObject();
                        objI022UI.productId = productId;
                        if (_I022UIObjects.ContainsKey(productId))
                        {
                            _I022UIObjects[productId][progname] = objI022UI;
                        }
                        else
                        {
                            Dictionary<string, I022UIObject> prog = new Dictionary<string, I022UIObject>();
                            prog.Add(progname, objI022UI);
                            _I022UIObjects.Add(productId, prog);
                        }
                        break;
                    case RegitemKind.I082:
                        I082UIObject objI082UI = new I082UIObject();
                        objI082UI.productId = productId;
                        if (_I082UIObjects.ContainsKey(productId))
                        {
                            _I082UIObjects[productId][progname] = objI082UI;
                        }
                        else
                        {
                            Dictionary<string, I082UIObject> prog = new Dictionary<string, I082UIObject>();
                            prog.Add(progname, objI082UI);
                            _I082UIObjects.Add(productId, prog);
                        }
                        break;

                }





            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("InfoStringHandleLog", "AddUIItem:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }

        public void RemoveUIItem(RegitemKind Kind, string productId, string progname)
        {
            try
            {

                switch (Kind)
                {
                    case RegitemKind.I020:

                        if (_I020UIObjects.ContainsKey(productId))
                        {
                            _I020UIObjects[productId].Remove(progname);
                        }
                        break;
                    case RegitemKind.I021:

                        if (_I021UIObjects.ContainsKey(productId))
                        {
                            _I021UIObjects[productId].Remove(progname);
                        }
                        break;
                    case RegitemKind.I080:

                        if (_I080UIObjects.ContainsKey(productId))
                        {
                            _I080UIObjects[productId].Remove(progname);
                        }

                        break;
                    case RegitemKind.I022:

                        if (_I022UIObjects.ContainsKey(productId))
                        {
                            _I022UIObjects[productId].Remove(progname);
                        }

                        break;
                    case RegitemKind.I082:

                        if (_I082UIObjects.ContainsKey(productId))
                        {
                            _I082UIObjects[productId].Remove(progname);
                        }

                        break;

                }





            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("InfoStringHandleLog", "RemoveUIItem:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }


        /// <summary>
        /// 註冊方法
        /// </summary>
        public void registerItem(string progname, string productId, string kind, string type)
        {
            try
            {
                bool isSend = false;
                if (kind.Trim() == "" || type.Trim() == "" || productId.Trim() == "")
                {
                    DataAgent._LM.WriteLog("InfoStringHandleLog", "註冊失敗 kind=" + kind + " type=" + type + " productId=" + productId);
                    return;
                }
                if (kind != "1" && kind != "2" && kind != "5" && kind != "7" && kind != "8")   //V1.0.0.36 Added by peter on 20140318
                {
                    DataAgent._LM.WriteLog("InfoStringHandleLog", "註冊失敗 kind 錯誤 kind=" + kind + " type=" + type + " productId=" + productId);
                    return;
                }
                if (type != "1" && type != "2" && type != "4")
                {
                    DataAgent._LM.WriteLog("InfoStringHandleLog", "註冊失敗 type 錯誤 kind=" + kind + " type=" + type + " productId=" + productId);
                    return;
                }
                //宣告電文傳出字串每個欄位用@隔開
                string strRegisterData = kind + type + "@" + productId + "@";
                int count = 1;
                //判斷註冊種類1.成交價量2.最佳五檔價量5最高最低價
                if (kind == "1")
                {
                    I020UIObject objI020UI = new I020UIObject();
                    objI020UI.productId = productId;
                    objI020UI.type = type;
                    lock (mdt_I020)
                    {
                        //判斷是否找到
                        DataRow drFind = mdt_I020.Rows.Find(productId);
                        if (drFind != null)
                        {
                            drFind.BeginEdit();
                            ((Dictionary<string, I020UIObject>)drFind["UICollection"]).Add(progname, objI020UI);

                            drFind.EndEdit();
                        }
                        else
                        {
                            DataRow drNew = mdt_I020.NewRow();
                            drNew["productId"] = productId;
                            drNew["type"] = type;
                            drNew["UICollection"] = new Dictionary<string, I020UIObject>();
                            ((Dictionary<string, I020UIObject>)drNew["UICollection"]).Add(progname, objI020UI);

                            mdt_I020.Rows.Add(drNew);
                            isSend = true;
                        }
                    }
                }
                else if (kind == "2")
                {
                    I080UIObject objI080UI = new I080UIObject();
                    objI080UI.productId = productId;
                    objI080UI.type = type;
                    //判斷是否找到
                    lock (mdt_I080)
                    {
                        DataRow drFind = mdt_I080.Rows.Find(productId);
                        if (drFind != null)
                        {
                            drFind.BeginEdit();
                            ((Dictionary<string, I080UIObject>)drFind["UICollection"]).Add(progname, objI080UI);

                            drFind.EndEdit();
                        }
                        else
                        {
                            DataRow drNew = mdt_I080.NewRow();
                            drNew["productId"] = productId;
                            drNew["type"] = type;
                            drNew["UICollection"] = new Dictionary<string, I080UIObject>();
                            ((Dictionary<string, I080UIObject>)drNew["UICollection"]).Add(progname, objI080UI);

                            mdt_I080.Rows.Add(drNew);
                            isSend = true;
                        }
                    }
                }
                else if (kind == "5")
                {
                    I021UIObject objI021UI = new I021UIObject();
                    objI021UI.productId = productId;
                    objI021UI.type = type;
                    //判斷是否找到
                    lock (mdt_I021)
                    {
                        DataRow drFind = mdt_I021.Rows.Find(productId);
                        if (drFind != null)
                        {
                            drFind.BeginEdit();
                            ((Dictionary<string, I021UIObject>)drFind["UICollection"]).Add(progname, objI021UI);

                            drFind.EndEdit();
                        }
                        else
                        {
                            DataRow drNew = mdt_I021.NewRow();
                            drNew["productId"] = productId;
                            drNew["type"] = type;
                            drNew["UICollection"] = new Dictionary<string, I021UIObject>();
                            ((Dictionary<string, I021UIObject>)drNew["UICollection"]).Add(progname, objI021UI);

                            mdt_I021.Rows.Add(drNew);
                            isSend = true;
                        }
                    }
                }




                else if (kind == "7")   //V1.0.0.36 Added by peter on 20140318
                {
                    I022UIObject objI022UI = new I022UIObject();
                    objI022UI.productId = productId;
                    objI022UI.type = type;
                    lock (mdt_I022)
                    {
                        //判斷是否找到
                        DataRow drFind = mdt_I022.Rows.Find(productId);
                        if (drFind != null)
                        {
                            drFind.BeginEdit();
                            ((Dictionary<string, I022UIObject>)drFind["UICollection"]).Add(progname, objI022UI);

                            drFind.EndEdit();
                        }
                        else
                        {
                            DataRow drNew = mdt_I022.NewRow();
                            drNew["productId"] = productId;
                            drNew["type"] = type;
                            drNew["UICollection"] = new Dictionary<string, I022UIObject>();
                            ((Dictionary<string, I022UIObject>)drNew["UICollection"]).Add(progname, objI022UI);

                            mdt_I022.Rows.Add(drNew);
                            isSend = true;
                        }
                    }
                }
                else if (kind == "8")
                {
                    I082UIObject objI082UI = new I082UIObject();
                    objI082UI.productId = productId;
                    objI082UI.type = type;
                    //判斷是否找到
                    lock (mdt_I082)
                    {
                        DataRow drFind = mdt_I082.Rows.Find(productId);
                        if (drFind != null)
                        {
                            drFind.BeginEdit();
                            ((Dictionary<string, I082UIObject>)drFind["UICollection"]).Add(progname, objI082UI);

                            drFind.EndEdit();
                        }
                        else
                        {
                            DataRow drNew = mdt_I082.NewRow();
                            drNew["productId"] = productId;
                            drNew["type"] = type;
                            drNew["UICollection"] = new Dictionary<string, I082UIObject>();
                            ((Dictionary<string, I082UIObject>)drNew["UICollection"]).Add(progname, objI082UI);

                            mdt_I082.Rows.Add(drNew);
                            isSend = true;
                        }
                    }
                }


                //去除最後一個@
                strRegisterData = strRegisterData.Substring(0, strRegisterData.Length - 1);
                ////傳送註冊資訊到Gateway
                if (isSend)
                {
                    //if (mobj_DataAgent.mobj_RegisterSocketClient != null)
                    //{
                    //    mobj_DataAgent.mobj_RegisterSocketClient.m_ObjTcpSocketSendData("15R" + strRegisterData);

                    //    DataAgent._LM.WriteLog("InfoStringHandleLog", "註冊內容" + strRegisterData);

                    //}
                }

            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("InfoStringHandleLog", "registerItem:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        /// <summary>
        /// 反註冊方法
        /// </summary>
        public void unRegisterItem(string progname, string productId, string kind, string type)
        {
            try
            {
                if (kind.Trim() == "" || type.Trim() == "" || productId.Trim() == "")
                {
                    DataAgent._LM.WriteLog("InfoStringHandleLog", "反註冊失敗 kind=" + kind + " type=" + type + " productId=" + productId);

                    return;
                }

                bool isSend = false;
                //宣告電文傳出字串每個欄位用@隔開 type 1 期貨 2選擇權
                string strRegisterData = kind + type + "@" + productId + "@";
                //判斷註冊種類1.成交價量2.最佳五檔價量5最高最低價
                if (kind == "1")
                {
                    //判斷是否找到
                    lock (mdt_I020)
                    {
                        DataRow drFind = mdt_I020.Rows.Find(productId);
                        if (drFind != null)
                        {
                            drFind.BeginEdit();
                            Dictionary<string, I020UIObject> dicI020 = ((Dictionary<string, I020UIObject>)drFind["UICollection"]);

                            dicI020.Remove(progname);
                            drFind.EndEdit();
                            if (dicI020.Count == 0)
                            {
                                isSend = true;

                                mdt_I020.Rows.Remove(drFind);
                            }

                        }
                    }

                }
                else if (kind == "2")
                {
                    //判斷是否找到

                    lock (mdt_I080)
                    {
                        DataRow drFind = mdt_I080.Rows.Find(productId);
                        if (drFind != null)
                        {

                            drFind.BeginEdit();

                            Dictionary<string, I080UIObject> dicI080 = ((Dictionary<string, I080UIObject>)drFind["UICollection"]);

                            dicI080.Remove(progname);
                            drFind.EndEdit();
                            if (dicI080.Count == 0)
                            {
                                isSend = true;
                                mdt_I080.Rows.Remove(drFind);
                            }


                        }
                    }
                }
                //V1.0.0.36 Added by peter on 20140320
                else if (kind == "7")
                {
                    //判斷是否找到
                    lock (mdt_I022)
                    {
                        DataRow drFind = mdt_I022.Rows.Find(productId);
                        if (drFind != null)
                        {
                            drFind.BeginEdit();
                            Dictionary<string, I020UIObject> dicI022 = ((Dictionary<string, I020UIObject>)drFind["UICollection"]);

                            dicI022.Remove(progname);
                            drFind.EndEdit();
                            if (dicI022.Count == 0)
                            {
                                isSend = true;

                                mdt_I022.Rows.Remove(drFind);
                            }

                        }
                    }

                }         //V1.0.0.36 Added by peter on 20140320
                else if (kind == "8")
                {
                    //判斷是否找到

                    lock (mdt_I082)
                    {
                        DataRow drFind = mdt_I082.Rows.Find(productId);
                        if (drFind != null)
                        {

                            drFind.BeginEdit();

                            Dictionary<string, I082UIObject> dicI082 = ((Dictionary<string, I082UIObject>)drFind["UICollection"]);

                            dicI082.Remove(progname);
                            drFind.EndEdit();
                            if (dicI082.Count == 0)
                            {
                                isSend = true;
                                mdt_I082.Rows.Remove(drFind);
                            }


                        }
                    }
                }
                else if (kind == "5")
                {
                    //判斷是否找到

                    lock (mdt_I021)
                    {
                        DataRow drFind = mdt_I021.Rows.Find(productId);
                        if (drFind != null)
                        {

                            drFind.BeginEdit();

                            Dictionary<string, I021UIObject> dicI021 = ((Dictionary<string, I021UIObject>)drFind["UICollection"]);

                            dicI021.Remove(progname);
                            drFind.EndEdit();
                            if (dicI021.Count == 0)
                            {
                                isSend = true;
                                mdt_I021.Rows.Remove(drFind);
                            }


                        }
                    }
                }
                if (isSend)
                {
                    //去除最後一個@
                    strRegisterData = strRegisterData.Substring(0, strRegisterData.Length - 1);
                    //傳送反註冊資訊到Gateway
                    //if (mobj_DataAgent.mobj_RegisterSocketClient != null)
                    //{
                    //    mobj_DataAgent.mobj_RegisterSocketClient.m_ObjTcpSocketSendData("15U" + strRegisterData);

                    //    DataAgent._LM.WriteLog("InfoStringHandleLog", "反註冊內容" + strRegisterData);
                    //}
                }

            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("InfoStringHandleLog", "unRegisterItem:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        /// <summary>
        /// 補送已註冊
        /// </summary>
        public void registerAll()
        {
            try
            {
                foreach (DataRow dr in mdt_I020.Rows)
                {
                    string strRegisterData = "1" + dr["type"].ToString() + "@" + dr["productId"].ToString();
                    //if (   mobj_DataAgent.mobj_RegisterSocketClient!= null)
                    //{
                    //       mobj_DataAgent.mobj_RegisterSocketClient.m_ObjTcpSocketSendData("15R" + strRegisterData);
                    //    DataAgent._LM.WriteLog("InfoStringHandleLog", "補送註冊內容" + strRegisterData); 
                    //}
                }
                foreach (DataRow dr in mdt_I080.Rows)
                {
                    string strRegisterData = "2" + dr["type"].ToString() + "@" + dr["productId"].ToString();
                    //if (mobj_DataAgent.mobj_RegisterSocketClient != null)
                    //{
                    //    mobj_DataAgent.mobj_RegisterSocketClient.m_ObjTcpSocketSendData("15R" + strRegisterData);
                    //    DataAgent._LM.WriteLog("InfoStringHandleLog", "補送註冊內容" + strRegisterData); 
                    //}
                }
                //lock (mdt_I060)//新增註冊i060 added by samantha 20110623
                //{
                //    foreach (DataRow dr in mdt_I060.Rows)
                //    {
                //        string strRegisterData = "3" + dr["type"].ToString() + "@" + dr["productId"].ToString();
                //        mobj_DataAgent.mobj_RegisterSocketClient.m_ObjTcpSocketSendData("15R" + strRegisterData);
                //        DataAgent._LM.WriteLog("InfoStringHandleLog", "補送註冊內容" + strRegisterData); 
                //    }
                //}
                lock (mdt_I021)//新增註冊i021 added by samantha 20120504
                {
                    foreach (DataRow dr in mdt_I021.Rows)
                    {
                        string strRegisterData = "5" + dr["type"].ToString() + "@" + dr["productId"].ToString();
                        //mobj_DataAgent.mobj_RegisterSocketClient.m_ObjTcpSocketSendData("15R" + strRegisterData);
                        DataAgent._LM.WriteLog("InfoStringHandleLog", "補送註冊內容" + strRegisterData);
                    }
                }



                //V1.0.0.36 Added by peter on 20140320
                foreach (DataRow dr in mdt_I022.Rows)
                {
                    string strRegisterData = "7" + dr["type"].ToString() + "@" + dr["productId"].ToString();
                    //if (mobj_DataAgent.mobj_RegisterSocketClient != null)
                    //{
                    //    mobj_DataAgent.mobj_RegisterSocketClient.m_ObjTcpSocketSendData("15R" + strRegisterData);
                    //    DataAgent._LM.WriteLog("InfoStringHandleLog", "補送註冊內容" + strRegisterData);
                    //}
                }
                foreach (DataRow dr in mdt_I082.Rows)
                {
                    string strRegisterData = "8" + dr["type"].ToString() + "@" + dr["productId"].ToString();
                    //if (mobj_DataAgent.mobj_RegisterSocketClient != null)
                    //{
                    //    mobj_DataAgent.mobj_RegisterSocketClient.m_ObjTcpSocketSendData("15R" + strRegisterData);
                    //    DataAgent._LM.WriteLog("InfoStringHandleLog", "補送註冊內容" + strRegisterData);
                    //}
                }

            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("InfoStringHandleLog", "registerAll:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }

        public struct  I020_PRODCUT
        {
            public decimal _matchprice;
            public decimal _matchQuantity;
            public decimal _matchTotalQty;
            public decimal _matchBuyCnt;
            public decimal _matchSellCnt;
            public string _matchTime;
        }
        public struct I080_PRODCUT
        {
            public decimal _BP1;
            public decimal _BP2;
            public decimal _BP3;
            public decimal _BP4;
            public decimal _BP5;
            public decimal _BQ1;
            public decimal _BQ2;
            public decimal _BQ3;
            public decimal _BQ4;
            public decimal _BQ5;
            public decimal _SP1;
            public decimal _SP2;
            public decimal _SP3;
            public decimal _SP4;
            public decimal _SP5;
            public decimal _SQ1;
            public decimal _SQ2;
            public decimal _SQ3;
            public decimal _SQ4;
            public decimal _SQ5;
        }
        /// <summary>
        /// 取得I020UI物件
        /// </summary>
        public I020UIObject getI020UIObject(string progname, string productId)
        {
            I020UIObject obj = null;
            try
            {
                if (_I020UIObjects.ContainsKey(productId))
                {
                    obj = _I020UIObjects[productId][progname];
                }

            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("InfoStringHandleLog", "getI020UIObject:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
            return obj;
        }
        /// <summary>
        /// 取得I021UI物件
        /// </summary>
        public I021UIObject getI021UIObject(string progname, string productId)
        {
            I021UIObject obj = null;
            try
            {
                if (_I021UIObjects.ContainsKey(productId))
                {
                    obj = _I021UIObjects[productId][progname];
                }

            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("InfoStringHandleLog", "getI021UIObject:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
            return obj;
        }
        /// <summary>
        /// 取得I080UI物件
        /// </summary>
        public I080UIObject getI080UIObject(string progname, string productId)
        {
            I080UIObject obj = null;
            try
            {

                if (_I080UIObjects.ContainsKey(productId))
                {
                    obj = _I080UIObjects[productId][progname];
                }
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("InfoStringHandleLog", "getI080UIObject:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
            return obj;
        }


        /// <summary>
        /// 取得I022UI物件
        /// </summary>
        public I022UIObject getI022UIObject(string progname, string productId)
        {
            I022UIObject obj = null;
            try
            {

                if (_I022UIObjects.ContainsKey(productId))
                {
                    obj = _I022UIObjects[productId][progname];
                }
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("InfoStringHandleLog", "getI022UIObject:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
            return obj;
        }

        /// <summary>
        /// 取得I082UI物件
        /// </summary>
        public I082UIObject getI082UIObject(string progname, string productId)
        {
            I082UIObject obj = null;
            try
            {

                if (_I082UIObjects.ContainsKey(productId))
                {
                    obj = _I082UIObjects[productId][progname];
                }
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("InfoStringHandleLog", "getI082UIObject:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
            return obj;
        }
    }
    public class I020UIObject
    {

        public struct I020EventArgs
        {
            public string _productId;
            public string _type;
            public decimal _matchprice;
            public decimal _matchQuantity;
            public decimal _matchTotalQty;
            public decimal _matchBuyCnt;
            public decimal _matchSellCnt; 
            public decimal _maxPriceByTime;
            public decimal _minPriceByTime;
            public string _matchTime;
        }
        public string _productId;
        public string _type;//商品類型 
        public decimal _matchprice;
        public decimal _matchQuantity;
        public decimal _matchTotalQty;
        public decimal _matchBuyCnt;
        public decimal _matchSellCnt;
        public decimal _maxPriceByTime;
        public decimal _minPriceByTime;
        public string _matchTime;
        public delegate
  void ReceiveI020Callback(I020EventArgs e);
        public event ReceiveI020Callback _ReceiveI020;

        public string productId
        {
            set { this._productId = value; }
            get { return this._productId; }
        }
        public string type
        {
            set { this._type = value; }
            get { return this._type; }
        }
        public I020UIObject()
        {
        }
        public void raiseReceiveI020()
        {
            I020EventArgs ee = new I020EventArgs();
            ee._productId = _productId;
            ee._type = _type;
            ee._matchprice = _matchprice;
            ee._matchQuantity = _matchQuantity;
            ee._matchTotalQty = _matchTotalQty;
            ee._matchBuyCnt = _matchBuyCnt;
            ee._matchSellCnt = _matchSellCnt;
            ee._matchTime = _matchTime;
            ee._maxPriceByTime = _maxPriceByTime;
            ee._minPriceByTime = _minPriceByTime;
            if (_ReceiveI020 != null)
            {
                _ReceiveI020(ee);
            }
        }
    }
    public class I021UIObject
    {

        public struct I021EventArgs
        {
            public string _productId;
            public string _type;
            public decimal _dayHighPrice;
            public decimal _dayLowPrice;
            public string _showTime;
        }
        public string _productId;
        public string _type;//商品類型 
        public decimal _dayHighPrice;
        public decimal _dayLowPrice;
        public string _showTime;
        public delegate
  void ReceiveI021Callback(I021EventArgs e);
        public event ReceiveI021Callback _ReceiveI021;

        public string productId
        {
            set { this._productId = value; }
            get { return this._productId; }
        }
        public string type
        {
            set { this._type = value; }
            get { return this._type; }
        }
        public I021UIObject()
        {
        }
        public void raiseReceiveI021()
        {
            I021EventArgs ee = new I021EventArgs();
            ee._productId = _productId;
            ee._type = _type;
            ee._dayHighPrice = _dayHighPrice;
            ee._dayLowPrice = _dayLowPrice;
            ee._showTime = _showTime;
            if (_ReceiveI021 != null)
            {
                _ReceiveI021(ee);
            }
        }
    }
    public class I080UIObject
    {

        public struct I080EventArgs
        {
            public string _productId;
            public string _type;
            public decimal _BP1;
            public decimal _BP2;
            public decimal _BP3;
            public decimal _BP4;
            public decimal _BP5;
            public decimal _BQ1;
            public decimal _BQ2;
            public decimal _BQ3;
            public decimal _BQ4;
            public decimal _BQ5;
            public decimal _SP1;
            public decimal _SP2;
            public decimal _SP3;
            public decimal _SP4;
            public decimal _SP5;
            public decimal _SQ1;
            public decimal _SQ2;
            public decimal _SQ3;
            public decimal _SQ4;
            public decimal _SQ5;
            public decimal _maxBP1ByTime;
            public decimal _minBP1ByTime;
            public decimal _maxSP1ByTime;
            public decimal _minSP1ByTime;
        }
        public string _productId;
        public string _type;//商品類型 
        public decimal _BP1;
        public decimal _BP2;
        public decimal _BP3;
        public decimal _BP4;
        public decimal _BP5;
        public decimal _BQ1;
        public decimal _BQ2;
        public decimal _BQ3;
        public decimal _BQ4;
        public decimal _BQ5;
        public decimal _SP1;
        public decimal _SP2;
        public decimal _SP3;
        public decimal _SP4;
        public decimal _SP5;
        public decimal _SQ1;
        public decimal _SQ2;
        public decimal _SQ3;
        public decimal _SQ4;
        public decimal _SQ5;
        public decimal _maxBP1ByTime;
        public decimal _minBP1ByTime;
        public decimal _maxSP1ByTime;
        public decimal _minSP1ByTime;
        public delegate
  void ReceiveI080Callback(I080EventArgs e);
        public event ReceiveI080Callback _ReceiveI080;

        public string productId
        {
            set { this._productId = value; }
            get { return this._productId; }
        }
        public string type
        {
            set { this._type = value; }
            get { return this._type; }
        }
        public I080UIObject()
        {
        }
        public void raiseReceiveI080()
        {
            I080EventArgs ee = new I080EventArgs();
            ee._productId = _productId;
            ee._type = _type;
            ee._BP1 = _BP1;
            ee._BP2 = _BP2;
            ee._BP3 = _BP3;
            ee._BP4 = _BP4;
            ee._BP5 = _BP5;
            ee._BQ1 = _BQ1;
            ee._BQ2 = _BQ2;
            ee._BQ3 = _BQ3;
            ee._BQ4 = _BQ4;
            ee._BQ5 = _BQ5;
            ee._SP1 = _SP1;
            ee._SP2 = _SP2;
            ee._SP3 = _SP3;
            ee._SP4 = _SP4;
            ee._SP5 = _SP5;
            ee._SQ1 = _SQ1;
            ee._SQ2 = _SQ2;
            ee._SQ3 = _SQ3;
            ee._SQ4 = _SQ4;
            ee._SQ5 = _SQ5;
            ee._maxBP1ByTime = _maxBP1ByTime;
            ee._minBP1ByTime = _minBP1ByTime;
            ee._maxSP1ByTime = _maxSP1ByTime;
            ee._minSP1ByTime = _minSP1ByTime;
            if (_ReceiveI080 != null)
            {
                _ReceiveI080(ee);
            }
        }
    }
    public class I022UIObject
    {

        public struct I022EventArgs
        {
            public string _productId;
            public string _type;
            public decimal _matchprice;
            public decimal _matchQuantity;
            public decimal _matchTotalQty;
            public decimal _matchBuyCnt;
            public decimal _matchSellCnt;
            public string _matchTime;
        }
        public string _productId;
        public string _type;//商品類型 
        public decimal _matchprice;
        public decimal _matchQuantity;
        public decimal _matchTotalQty;
        public decimal _matchBuyCnt;
        public decimal _matchSellCnt;
        public string _matchTime;
        public delegate
  void ReceiveI022Callback(I022EventArgs e);
        public event ReceiveI022Callback _ReceiveI022;

        public string productId
        {
            set { this._productId = value; }
            get { return this._productId; }
        }
        public string type
        {
            set { this._type = value; }
            get { return this._type; }
        }
        public I022UIObject()
        {
        }
        public void raiseReceiveI022()
        {
            I022EventArgs ee = new I022EventArgs();
            ee._productId = _productId;
            ee._type = _type;
            ee._matchprice = _matchprice;
            ee._matchQuantity = _matchQuantity;
            ee._matchTotalQty = _matchTotalQty;
            ee._matchBuyCnt = _matchBuyCnt;
            ee._matchSellCnt = _matchSellCnt;
            ee._matchTime = _matchTime;
            if (_ReceiveI022 != null)
            {
                _ReceiveI022(ee);
            }
        }
    }

    public class I082UIObject
    {

        public struct I082EventArgs
        {
            public string _productId;
            public string _type;
            public decimal _BP1;
            public decimal _BP2;
            public decimal _BP3;
            public decimal _BP4;
            public decimal _BP5;
            public decimal _BQ1;
            public decimal _BQ2;
            public decimal _BQ3;
            public decimal _BQ4;
            public decimal _BQ5;
            public decimal _SP1;
            public decimal _SP2;
            public decimal _SP3;
            public decimal _SP4;
            public decimal _SP5;
            public decimal _SQ1;
            public decimal _SQ2;
            public decimal _SQ3;
            public decimal _SQ4;
            public decimal _SQ5;
        }
        public string _productId;
        public string _type;//商品類型 
        public decimal _BP1;
        public decimal _BP2;
        public decimal _BP3;
        public decimal _BP4;
        public decimal _BP5;
        public decimal _BQ1;
        public decimal _BQ2;
        public decimal _BQ3;
        public decimal _BQ4;
        public decimal _BQ5;
        public decimal _SP1;
        public decimal _SP2;
        public decimal _SP3;
        public decimal _SP4;
        public decimal _SP5;
        public decimal _SQ1;
        public decimal _SQ2;
        public decimal _SQ3;
        public decimal _SQ4;
        public decimal _SQ5;
        public delegate
  void ReceiveI082Callback(I082EventArgs e);
        public event ReceiveI082Callback _ReceiveI082;

        public string productId
        {
            set { this._productId = value; }
            get { return this._productId; }
        }
        public string type
        {
            set { this._type = value; }
            get { return this._type; }
        }
        public I082UIObject()
        {
        }
        public void raiseReceiveI082()
        {
            I082EventArgs ee = new I082EventArgs();
            ee._productId = _productId;
            ee._type = _type;
            ee._BP1 = _BP1;
            ee._BP2 = _BP2;
            ee._BP3 = _BP3;
            ee._BP4 = _BP4;
            ee._BP5 = _BP5;
            ee._BQ1 = _BQ1;
            ee._BQ2 = _BQ2;
            ee._BQ3 = _BQ3;
            ee._BQ4 = _BQ4;
            ee._BQ5 = _BQ5;
            ee._SP1 = _SP1;
            ee._SP2 = _SP2;
            ee._SP3 = _SP3;
            ee._SP4 = _SP4;
            ee._SP5 = _SP5;
            ee._SQ1 = _SQ1;
            ee._SQ2 = _SQ2;
            ee._SQ3 = _SQ3;
            ee._SQ4 = _SQ4;
            ee._SQ5 = _SQ5;
            if (_ReceiveI082 != null)
            {
                _ReceiveI082(ee);
            }
        }
    }
}
