﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
namespace VIPTradingSystem.MYcls
{
    public class MatchTotalItem
    {
        public MatchTotalItem()
        {
            PRODUCTKIND = "";
            BROKERID = "";
            INVESTORACNO = "";
            SUBACT = "";
            SECURITYEXCHANGE = "";
            SECURITYTYPE1 = "";
            SYMBOL1 = "";
            MATURITYMONTHYEAR1 = "";
            PUTORCALL1 = "";
            STRIKEPRICE1 = 0;
            SIDE1 = "";
            SECURITYTYPE2 = "";
            SYMBOL2 = "";
            MATURITYMONTHYEAR2 = "";
            PUTORCALL2 = "";
            STRIKEPRICE2 = 0;
            SIDE2 = "";
        }
        public string BROKERID { get; set; }
        public string INVESTORACNO { get; set; }
        public string SUBACT { get; set; }
        public string PRODUCTKIND { get; set; }
        public string SECURITYEXCHANGE { get; set; }
        public string SECURITYTYPE1 { get; set; }
        public string SYMBOL1 { get; set; }
        public string MATURITYMONTHYEAR1 { get; set; }
        public string PUTORCALL1 { get; set; }
        public decimal STRIKEPRICE1 { get; set; }
        public string SIDE1 { get; set; }
        public string SECURITYTYPE2 { get; set; }
        public string SYMBOL2 { get; set; }
        public string MATURITYMONTHYEAR2 { get; set; }
        public string PUTORCALL2 { get; set; }
        public decimal STRIKEPRICE2 { get; set; }
        public string SIDE2 { get; set; }

        public string getKey()
        {
            return BROKERID.Trim()
+ INVESTORACNO.Trim()
+ SUBACT.Trim()
+ SECURITYEXCHANGE.Trim()
+ SECURITYTYPE1.Trim()
+ SYMBOL1.Trim()
+ MATURITYMONTHYEAR1.Trim()
+ PUTORCALL1.Trim()
+ STRIKEPRICE1
+ SIDE1.Trim()
+ SECURITYTYPE2.Trim()
+ SYMBOL2.Trim()
+ MATURITYMONTHYEAR2.Trim()
+ PUTORCALL2.Trim()
+ STRIKEPRICE2
+ SIDE2.Trim();
        }
    }


    public class MatchTotalProvider
    {
        private object _locker = new object();

        Dictionary<string, string> checklist = new Dictionary<string, string>();


        public void AddCheck(string val)
        {
            lock (checklist)
            {
                checklist[val] = val;
            }
        }
        public void RemoveCheck(string val)
        {
            lock (checklist)
            {
                checklist.Remove(val);
            }

        }
        public string[] GetCheckList()
        {
            lock (checklist)
            {
                if (checklist.Keys.Count > 0)
                    return checklist.Keys.ToArray();
                else return null;
            }
        }

        private Dictionary<string, DataRow> _Data;

        private DataTable _MatchTotal;

        public DataTable MatchTotal
        {
            get { return _MatchTotal; }
            set { _MatchTotal = value; }
        }
        public MatchTotalProvider()
        {
            _Data = new Dictionary<string, DataRow>();
            initMatchTotal();
        }
        ~MatchTotalProvider()
        {
            Dispose();
        }

        public void ClearData()
        {
            _Data.Clear();
            _MatchTotal.Rows.Clear();
        }

        public void Dispose()
        {
            ClearData();
        }
        private void initMatchTotal()
        {
            _MatchTotal = new DataTable();

            _MatchTotal.Columns.Add("BROKERID");
            _MatchTotal.Columns.Add("INVESTORACNO");
            _MatchTotal.Columns.Add("SUBACT");
            _MatchTotal.Columns.Add("PRODUCTKIND", typeof(string));//商品種類
            _MatchTotal.Columns.Add("SECURITYEXCHANGE");
            _MatchTotal.Columns.Add("SECURITYTYPE1");
            _MatchTotal.Columns.Add("SYMBOL1");
            _MatchTotal.Columns.Add("MATURITYMONTHYEAR1");
            _MatchTotal.Columns.Add("PUTORCALL1");
            _MatchTotal.Columns.Add("STRIKEPRICE1", typeof(decimal));
            _MatchTotal.Columns.Add("SIDE1");
            _MatchTotal.Columns.Add("SECURITYTYPE2");
            _MatchTotal.Columns.Add("SYMBOL2");
            _MatchTotal.Columns.Add("MATURITYMONTHYEAR2");
            _MatchTotal.Columns.Add("PUTORCALL2");
            _MatchTotal.Columns.Add("STRIKEPRICE2", typeof(decimal));
            _MatchTotal.Columns.Add("SIDE2");
            _MatchTotal.Columns.Add("BQty", typeof(int));
            _MatchTotal.Columns.Add("SQty", typeof(int));
            _MatchTotal.Columns.Add("TotalQty", typeof(int));
            _MatchTotal.Columns.Add("NetPost", typeof(int));
            _MatchTotal.Columns.Add("WrkBuy", typeof(int));
            _MatchTotal.Columns.Add("WrkSell", typeof(int));
            _MatchTotal.Columns.Add("AvgBuyPrice", typeof(decimal));
            _MatchTotal.Columns.Add("AvgSellPrice", typeof(decimal));

            _MatchTotal.Columns.Add("product", typeof(string));
            _MatchTotal.Columns.Add("contract", typeof(string));
            _MatchTotal.Columns["product"].Expression = CommonFunction.ProductExpression;
            _MatchTotal.Columns["contract"].Expression = CommonFunction.ContractExpression;

            _MatchTotal.Columns["BQty"].DefaultValue = 0;
            _MatchTotal.Columns["SQty"].DefaultValue = 0;
            _MatchTotal.Columns["TotalQty"].DefaultValue = 0;
            _MatchTotal.Columns["NetPost"].DefaultValue = 0;
            _MatchTotal.Columns["WrkBuy"].DefaultValue = 0;
            _MatchTotal.Columns["WrkSell"].DefaultValue = 0;
            _MatchTotal.Columns["AvgBuyPrice"].DefaultValue = 0;
            _MatchTotal.Columns["AvgSellPrice"].DefaultValue = 0;
            _MatchTotal.CaseSensitive = true;
        }


        public void SetWrkQty(ReplyUIObject ee, DataRow srcdr)
        {
            //判斷如沒有勾選委託回報就必運算
            if (!checklist.ContainsKey(ee.ORDERNO.Trim()))
            {
                return;
            }
            MatchTotalItem Item = new MatchTotalItem();
            Item.BROKERID = ee.BROKERID;
            Item.INVESTORACNO = ee.INVESTORACNO;
            Item.SUBACT = "";//ee.SUBACT;
            Item.SECURITYEXCHANGE = ee.SECURITYEXCHANGE;
            Item.SECURITYTYPE1 = ee.SECURITYTYPE1;
            Item.SYMBOL1 = ee.SYMBOL1;
            Item.MATURITYMONTHYEAR1 = ee.MATURITYMONTHYEAR1;
            Item.PUTORCALL1 = ee.PUTORCALL1;
            Item.STRIKEPRICE1 = ee.STRIKEPRICE1;
            Item.SIDE1 = ee.SIDE1;
            Item.SECURITYTYPE2 = ee.SECURITYTYPE2;
            Item.SYMBOL2 = ee.SYMBOL2;
            Item.MATURITYMONTHYEAR2 = ee.MATURITYMONTHYEAR2;
            Item.PUTORCALL2 = ee.PUTORCALL2;
            Item.STRIKEPRICE2 = ee.STRIKEPRICE2;
            Item.SIDE2 = ee.SIDE2;
            Item.PRODUCTKIND = ee.PRODUCTKIND;
            string BS = ee.BS;
            int qty = ee.NOMATCHQTY;
            int orderqty = ee.ORDERQTY;
            int delqty = ee.DELQTY;
            int matchqty = ee.MATCHQTY;

            string key = Item.getKey();
            DataRow dr = null;
            lock (_locker)
            {
                if (_Data.TryGetValue(key, out dr))
                {
                    dr.BeginEdit();
                    if (ee.EXECTYPE == "0")
                    {


                        if (BS == "B")
                        {
                            dr["WrkBuy"] = (int)dr["WrkBuy"] + qty;
                        }
                        else
                        {
                            dr["WrkSell"] = (int)dr["WrkSell"] + qty;
                        }
                    }
                    else if (ee.EXECTYPE == "1" || ee.EXECTYPE == "2" || ee.EXECTYPE == "4" || ee.EXECTYPE == "5")
                    {

                        if (BS == "B")
                        {
                            dr["WrkBuy"] = (int)dr["WrkBuy"] - (int)srcdr["BEFORENOMATCHQTY"] + qty;
                        }
                        else
                        {
                            dr["WrkSell"] = (int)dr["WrkSell"] - (int)srcdr["BEFORENOMATCHQTY"] + qty;
                        }
                    }


                    if ((int)dr["BQty"] == 0
                     && (int)dr["SQty"] == 0
                     && (int)dr["WrkBuy"] == 0
                     && (int)dr["WrkSell"] == 0)
                    {
                        dr.Delete();
                        _Data.Remove(key);
                    }

                    dr.EndEdit();
                }
                else
                {
                    dr = _MatchTotal.NewRow();
                    dr["BROKERID"] = Item.BROKERID;
                    dr["INVESTORACNO"] = Item.INVESTORACNO;
                    dr["PRODUCTKIND"] = Item.PRODUCTKIND;

                    dr["SUBACT"] = Item.SUBACT;
                    dr["SECURITYEXCHANGE"] = Item.SECURITYEXCHANGE;
                    dr["SECURITYTYPE1"] = Item.SECURITYTYPE1;
                    dr["SYMBOL1"] = Item.SYMBOL1;
                    dr["MATURITYMONTHYEAR1"] = Item.MATURITYMONTHYEAR1;
                    dr["PUTORCALL1"] = Item.PUTORCALL1;
                    dr["STRIKEPRICE1"] = Item.STRIKEPRICE1;
                    dr["SIDE1"] = Item.SIDE1;
                    dr["SECURITYTYPE2"] = Item.SECURITYTYPE2;
                    dr["SYMBOL2"] = Item.SYMBOL2;
                    dr["MATURITYMONTHYEAR2"] = Item.MATURITYMONTHYEAR2;
                    dr["PUTORCALL2"] = Item.PUTORCALL2;
                    dr["STRIKEPRICE2"] = Item.STRIKEPRICE2;
                    dr["SIDE2"] = Item.SIDE2;
                    if (ee.EXECTYPE == "0")
                    {


                        if (BS == "B")
                        {
                            dr["WrkBuy"] = (int)dr["WrkBuy"] + qty;
                        }
                        else
                        {
                            dr["WrkSell"] = (int)dr["WrkSell"] + qty;
                        }
                    }
                    else if (ee.EXECTYPE == "1" || ee.EXECTYPE == "2" || ee.EXECTYPE == "4" || ee.EXECTYPE == "5")
                    {

                        if (BS == "B")
                        {
                            dr["WrkBuy"] = (int)dr["WrkBuy"] - (int)srcdr["BEFORENOMATCHQTY"] + qty;
                        }
                        else
                        {
                            dr["WrkSell"] = (int)dr["WrkSell"] - (int)srcdr["BEFORENOMATCHQTY"] + qty;
                        }
                    }
                    _Data[key] = dr;

                    if ((int)dr["WrkBuy"] > 0 || (int)dr["WrkSell"] > 0 || (int)dr["BQty"] > 0 || (int)dr["SQty"] > 0)
                        _MatchTotal.Rows.Add(dr);

                }
            }
        }

        public void SetMatchQty(MatchUIObject ee)
        {
            //判斷如沒有勾選委託回報就必運算
            if (!checklist.ContainsKey(ee.ORDERNO.Trim()))
            {
                return;
            }
            if (ee.EXECTRANSTYPE != "0")
            {
                return;
            }
            MatchTotalItem Item = new MatchTotalItem();
            Item.BROKERID = ee.BROKERID;
            Item.INVESTORACNO = ee.INVESTORACNO;
            Item.SUBACT = "";//ee.SUBACT;
            Item.SECURITYEXCHANGE = ee.SECURITYEXCHANGE;
            Item.SECURITYTYPE1 = ee.SECURITYTYPE1;
            Item.SYMBOL1 = ee.SYMBOL1;
            Item.MATURITYMONTHYEAR1 = ee.MATURITYMONTHYEAR1;
            Item.PUTORCALL1 = ee.PUTORCALL1;
            Item.STRIKEPRICE1 = ee.STRIKEPRICE1;
            Item.SIDE1 = ee.SIDE1;
            Item.SECURITYTYPE2 = ee.SECURITYTYPE2;
            Item.SYMBOL2 = ee.SYMBOL2;
            Item.MATURITYMONTHYEAR2 = ee.MATURITYMONTHYEAR2;
            Item.PUTORCALL2 = ee.PUTORCALL2;
            Item.STRIKEPRICE2 = ee.STRIKEPRICE2;
            Item.SIDE2 = ee.SIDE2;
            Item.PRODUCTKIND = ee.PRODUCTKIND;
            string BS = ee.BS;
            int qty = ee.MATCHQTY;

            decimal price = ee.MATCHPRICE;

            price = Decimal.Parse(price.ToString("0.#######"));//防止價格格式跑掉
            string key = Item.getKey();
            DataRow dr = null;
            lock (_locker)
            {
                if (_Data.TryGetValue(key, out dr))
                {
                    dr.BeginEdit();

                    if (BS == "B")
                    {
                        dr["AvgBuyPrice"] = (((decimal)dr["AvgBuyPrice"] * (int)dr["BQty"]) + price * qty) / ((int)dr["BQty"] + qty);

                        dr["BQty"] = (int)dr["BQty"] + qty;
                        dr["TotalQty"] = (int)dr["BQty"] + (int)dr["SQty"];
                        dr["NetPost"] = (int)dr["BQty"] - (int)dr["SQty"];


                    }
                    else
                    {
                        dr["AvgSellPrice"] = (((decimal)dr["AvgSellPrice"] * (int)dr["SQty"]) + price * qty) / ((int)dr["SQty"] + qty);
                        dr["SQty"] = (int)dr["SQty"] + qty;
                        dr["TotalQty"] = (int)dr["BQty"] + (int)dr["SQty"];
                        dr["NetPost"] = (int)dr["BQty"] - (int)dr["SQty"];

                    }
                    if ((int)dr["BQty"] == 0
                      && (int)dr["SQty"] == 0
                      && (int)dr["WrkBuy"] == 0
                      && (int)dr["WrkSell"] == 0)
                    {
                        dr.Delete();
                        _Data.Remove(key);
                    }
                    dr.EndEdit();
                }
                else
                {
                    dr = _MatchTotal.NewRow();
                    dr["BROKERID"] = Item.BROKERID;
                    dr["INVESTORACNO"] = Item.INVESTORACNO;
                    dr["SUBACT"] = Item.SUBACT;
                    dr["PRODUCTKIND"] = Item.PRODUCTKIND;
                    dr["SECURITYEXCHANGE"] = Item.SECURITYEXCHANGE;
                    dr["SECURITYTYPE1"] = Item.SECURITYTYPE1;
                    dr["SYMBOL1"] = Item.SYMBOL1;
                    dr["MATURITYMONTHYEAR1"] = Item.MATURITYMONTHYEAR1;
                    dr["PUTORCALL1"] = Item.PUTORCALL1;
                    dr["STRIKEPRICE1"] = Item.STRIKEPRICE1;
                    dr["SIDE1"] = Item.SIDE1;
                    dr["SECURITYTYPE2"] = Item.SECURITYTYPE2;
                    dr["SYMBOL2"] = Item.SYMBOL2;
                    dr["MATURITYMONTHYEAR2"] = Item.MATURITYMONTHYEAR2;
                    dr["PUTORCALL2"] = Item.PUTORCALL2;
                    dr["STRIKEPRICE2"] = Item.STRIKEPRICE2;
                    dr["SIDE2"] = Item.SIDE2;
                    if (BS == "B")
                    {
                        dr["AvgBuyPrice"] = (((decimal)dr["AvgBuyPrice"] * (int)dr["BQty"]) + price * qty) / ((int)dr["BQty"] + qty);

                        dr["BQty"] = (int)dr["BQty"] + qty;
                        dr["TotalQty"] = (int)dr["BQty"] + (int)dr["SQty"];
                        dr["NetPost"] = (int)dr["BQty"] - (int)dr["SQty"];


                    }
                    else
                    {
                        dr["AvgSellPrice"] = (((decimal)dr["AvgSellPrice"] * (int)dr["SQty"]) + price * qty) / ((int)dr["SQty"] + qty);
                        dr["SQty"] = (int)dr["SQty"] + qty;
                        dr["TotalQty"] = (int)dr["BQty"] + (int)dr["SQty"];
                        dr["NetPost"] = (int)dr["BQty"] - (int)dr["SQty"];

                    }

                    _Data[key] = dr;
                    if ((int)dr["WrkBuy"] > 0 || (int)dr["WrkSell"] > 0 || (int)dr["BQty"] > 0 || (int)dr["SQty"] > 0)
                        _MatchTotal.Rows.Add(dr);
                }
            }
        }

        public void AddWrkQty(string orderno, MatchTotalItem item, string BS, int qty)
        {
            //判斷如沒有勾選委託回報就必運算
            if (orderno.Trim().Length > 0)
                if (!checklist.ContainsKey(orderno.Trim())) return;
            string key = item.getKey();
            DataRow dr = null;
            lock (_locker)
            {
                if (_Data.TryGetValue(key, out dr))
                {
                    dr.BeginEdit();
                    if (BS == "B")
                    {
                        dr["WrkBuy"] = (int)dr["WrkBuy"] + qty;
                    }
                    else
                    {
                        dr["WrkSell"] = (int)dr["WrkSell"] + qty;
                    }
                    dr.EndEdit();
                }
                else
                {
                    dr = _MatchTotal.NewRow();
                    dr["BROKERID"] = item.BROKERID;
                    dr["INVESTORACNO"] = item.INVESTORACNO;
                    dr["SUBACT"] = item.SUBACT;
                    dr["PRODUCTKIND"] = item.PRODUCTKIND;
                    dr["SECURITYEXCHANGE"] = item.SECURITYEXCHANGE;
                    dr["SECURITYTYPE1"] = item.SECURITYTYPE1;
                    dr["SYMBOL1"] = item.SYMBOL1;
                    dr["MATURITYMONTHYEAR1"] = item.MATURITYMONTHYEAR1;
                    dr["PUTORCALL1"] = item.PUTORCALL1;
                    dr["STRIKEPRICE1"] = item.STRIKEPRICE1;
                    dr["SIDE1"] = item.SIDE1;
                    dr["SECURITYTYPE2"] = item.SECURITYTYPE2;
                    dr["SYMBOL2"] = item.SYMBOL2;
                    dr["MATURITYMONTHYEAR2"] = item.MATURITYMONTHYEAR2;
                    dr["PUTORCALL2"] = item.PUTORCALL2;
                    dr["STRIKEPRICE2"] = item.STRIKEPRICE2;
                    dr["SIDE2"] = item.SIDE2;
                    if (BS == "B")
                    {
                        dr["WrkBuy"] = (int)dr["WrkBuy"] + qty;
                    }
                    else
                    {
                        dr["WrkSell"] = (int)dr["WrkSell"] + qty;
                    }

                    _Data[key] = dr;
                    _MatchTotal.Rows.Add(dr);
                }
            }
        }



        public void DelWrkQty(MatchTotalItem item, string BS, int qty)
        {

            string key = item.getKey();
            DataRow dr = null;
            lock (_locker)
            {
                if (_Data.TryGetValue(key, out dr))
                {
                    dr.BeginEdit();
                    if (BS == "B")
                    {
                        dr["WrkBuy"] = (int)dr["WrkBuy"] - qty;
                    }
                    else
                    {
                        dr["WrkSell"] = (int)dr["WrkSell"] - qty;
                    }
                    if (key == "F0080009904619SGXFUTCN2016120SFUTCN2017010B")
                    {


                    }
                    if ((int)dr["BQty"] == 0
                         && (int)dr["SQty"] == 0
                         && (int)dr["WrkBuy"] == 0
                         && (int)dr["WrkSell"] == 0)
                    {
                        dr.Delete();
                        _Data.Remove(key);
                    }
                    dr.EndEdit();


                }
                else
                {
                    //理論上不會有
                }
            }
        }


        public void AddMatchQty(string orderno, MatchTotalItem item, string BS, decimal price, int qty)
        {//判斷如沒有勾選委託回報就必運算 和維護部位
            if (orderno.Trim().Length > 0)
                if (!checklist.ContainsKey(orderno.Trim())) return;

            price = Decimal.Parse(price.ToString("0.#######"));
            string key = item.getKey();
            DataRow dr = null;
            lock (_locker)
            {
                if (_Data.TryGetValue(key, out dr))
                {
                    dr.BeginEdit();
                    if (BS == "B")
                    {
                        dr["AvgBuyPrice"] = (((decimal)dr["AvgBuyPrice"] * (int)dr["BQty"]) + price * qty) / ((int)dr["BQty"] + qty);

                        dr["BQty"] = (int)dr["BQty"] + qty;
                        dr["TotalQty"] = (int)dr["BQty"] + (int)dr["SQty"];
                        dr["NetPost"] = (int)dr["BQty"] - (int)dr["SQty"];


                    }
                    else
                    {
                        dr["AvgSellPrice"] = (((decimal)dr["AvgSellPrice"] * (int)dr["SQty"]) + price * qty) / ((int)dr["SQty"] + qty);
                        dr["SQty"] = (int)dr["SQty"] + qty;
                        dr["TotalQty"] = (int)dr["BQty"] + (int)dr["SQty"];
                        dr["NetPost"] = (int)dr["BQty"] - (int)dr["SQty"];

                    }
                    dr.EndEdit();
                }
                else
                {
                    dr = _MatchTotal.NewRow();
                    dr["BROKERID"] = item.BROKERID;
                    dr["INVESTORACNO"] = item.INVESTORACNO;
                    dr["SUBACT"] = item.SUBACT;
                    dr["PRODUCTKIND"] = item.PRODUCTKIND;
                    dr["SECURITYEXCHANGE"] = item.SECURITYEXCHANGE;
                    dr["SECURITYTYPE1"] = item.SECURITYTYPE1;
                    dr["SYMBOL1"] = item.SYMBOL1;
                    dr["MATURITYMONTHYEAR1"] = item.MATURITYMONTHYEAR1;
                    dr["PUTORCALL1"] = item.PUTORCALL1;
                    dr["STRIKEPRICE1"] = item.STRIKEPRICE1;
                    dr["SIDE1"] = item.SIDE1;
                    dr["SECURITYTYPE2"] = item.SECURITYTYPE2;
                    dr["SYMBOL2"] = item.SYMBOL2;
                    dr["MATURITYMONTHYEAR2"] = item.MATURITYMONTHYEAR2;
                    dr["PUTORCALL2"] = item.PUTORCALL2;
                    dr["STRIKEPRICE2"] = item.STRIKEPRICE2;
                    dr["SIDE2"] = item.SIDE2;
                    if (BS == "B")
                    {
                        dr["AvgBuyPrice"] = (((decimal)dr["AvgBuyPrice"] * (int)dr["BQty"]) + price * qty) / ((int)dr["BQty"] + qty);

                        dr["BQty"] = (int)dr["BQty"] + qty;
                        dr["TotalQty"] = (int)dr["BQty"] + (int)dr["SQty"];
                        dr["NetPost"] = (int)dr["BQty"] - (int)dr["SQty"];


                    }
                    else
                    {
                        dr["AvgSellPrice"] = (((decimal)dr["AvgSellPrice"] * (int)dr["SQty"]) + price * qty) / ((int)dr["SQty"] + qty);
                        dr["SQty"] = (int)dr["SQty"] + qty;
                        dr["TotalQty"] = (int)dr["BQty"] + (int)dr["SQty"];
                        dr["NetPost"] = (int)dr["BQty"] - (int)dr["SQty"];

                    }

                    _Data[key] = dr;
                    _MatchTotal.Rows.Add(dr);
                }
            }
        }

        public void DelMatchQty(string orderno, MatchTotalItem item, string BS, decimal price, int qty)
        {

            string key = item.getKey();
            DataRow dr = null;
            lock (_locker)
            {
                if (_Data.TryGetValue(key, out dr))
                {
                    dr.BeginEdit();
                    if (BS == "B")
                    {
                        if (((int)dr["BQty"] - qty) == 0)
                            dr["AvgBuyPrice"] = 0;
                        else
                            dr["AvgBuyPrice"] = (((decimal)dr["AvgBuyPrice"] * (int)dr["BQty"]) - price * qty) / ((int)dr["BQty"] - qty);

                        dr["BQty"] = (int)dr["BQty"] - qty;
                        dr["TotalQty"] = (int)dr["BQty"] + (int)dr["SQty"];
                        dr["NetPost"] = (int)dr["BQty"] - (int)dr["SQty"];


                    }
                    else
                    {

                        if (((int)dr["SQty"] - qty) == 0)
                            dr["AvgSellPrice"] = 0;
                        else
                            dr["AvgSellPrice"] = (((decimal)dr["AvgSellPrice"] * (int)dr["SQty"]) - price * qty) / ((int)dr["SQty"] - qty);


                        dr["SQty"] = (int)dr["SQty"] - qty;
                        dr["TotalQty"] = (int)dr["BQty"] + (int)dr["SQty"];
                        dr["NetPost"] = (int)dr["BQty"] - (int)dr["SQty"];

                    }

                    if ((int)dr["BQty"] == 0
     && (int)dr["SQty"] == 0
     && (int)dr["WrkBuy"] == 0
     && (int)dr["WrkSell"] == 0)
                    {
                        dr.Delete();
                        _Data.Remove(key);
                    }
                    dr.EndEdit();
                }
                else
                {
                    //    dr = _MatchTotal.NewRow();
                    //    dr["BROKERID"] = item.BROKERID;
                    //    dr["INVESTORACNO"] = item.INVESTORACNO;
                    //    dr["SUBACT"] = item.SUBACT;
                    //    dr["PRODUCTKIND"] = item.PRODUCTKIND;
                    //    dr["SECURITYEXCHANGE"] = item.SECURITYEXCHANGE;
                    //    dr["SECURITYTYPE1"] = item.SECURITYTYPE1;
                    //    dr["SYMBOL1"] = item.SYMBOL1;
                    //    dr["MATURITYMONTHYEAR1"] = item.MATURITYMONTHYEAR1;
                    //    dr["PUTORCALL1"] = item.PUTORCALL1;
                    //    dr["STRIKEPRICE1"] = item.STRIKEPRICE1;
                    //    dr["SIDE1"] = item.SIDE1;
                    //    dr["SECURITYTYPE2"] = item.SECURITYTYPE2;
                    //    dr["SYMBOL2"] = item.SYMBOL2;
                    //    dr["MATURITYMONTHYEAR2"] = item.MATURITYMONTHYEAR2;
                    //    dr["PUTORCALL2"] = item.PUTORCALL2;
                    //    dr["STRIKEPRICE2"] = item.STRIKEPRICE2;
                    //    dr["SIDE2"] = item.SIDE2;
                    //    if (BS == "B")
                    //    {
                    //        dr["AvgBuyPrice"] = (((decimal)dr["AvgBuyPrice"] * (int)dr["BQty"]) - price * qty) / ((int)dr["BQty"] - qty);

                    //        dr["BQty"] = (int)dr["BQty"] - qty;
                    //        dr["TotalQty"] = (int)dr["BQty"] + (int)dr["SQty"];
                    //        dr["NetPost"] = (int)dr["BQty"] - (int)dr["SQty"];


                    //    }
                    //    else
                    //    {
                    //        dr["AvgSellPrice"] = (((decimal)dr["AvgSellPrice"] * (int)dr["SQty"]) - price * qty) / ((int)dr["SQty"] - qty);
                    //        dr["SQty"] = (int)dr["SQty"] - qty;
                    //        dr["TotalQty"] = (int)dr["BQty"] + (int)dr["SQty"];
                    //        dr["NetPost"] = (int)dr["BQty"] - (int)dr["SQty"];

                    //    }
                    //    _Data[key] = dr;
                    //    _MatchTotal.Rows.Add(dr);
                }
            }
        }


    }
}
