﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using com.ddsc.BI.F;
using System.Runtime.InteropServices;
namespace VIPTradingSystem.MYcls
{
    public class StrategyProvider
    {
        public static ReplyUIObject Parse2ReplyUIObject(byte[] buffer)
        {
            string seq = SockClientParserFunction.getDDSCRawDataOldSeq(buffer);
            string NewSeq = SockClientParserFunction.getDDSCRawDataNewSeq(buffer);
            string MessageTime = SockClientParserFunction.getDDSCMessageTime(buffer);

            ReplyUIObject ee = new ReplyUIObject();
            SockClientParserFunction.Reply obj = new SockClientParserFunction.Reply();
            ParserStruct<SockClientParserFunction.Reply>.ByteArrayToStructure(buffer, 50, ref obj);


            string KeepData = ASCIIEncoding.Default.GetString(buffer, 50 + Marshal.SizeOf(obj), buffer.Length - 50 - Marshal.SizeOf(obj) - 1);

            string OrderKind = "";
            string OrderTag = "";
            string AE = "";
            string AD = "";
            string pseq = "";
            //KeepData

            ////OrderKind=P^OrderTag=^AE=^AD=Time Slice|2|500|20161004172843726|20161004182843000|35000|5|0^

            foreach (string f in KeepData.Split('^'))
            {
                if (f.IndexOf("OrderKind") > -1)
                {
                    OrderKind = f.Split('=')[1];
                }
                if (f.IndexOf("AD") > -1)
                {
                    AD = f.Split('=')[1];
                }
                if (f.IndexOf("pseq") > -1)
                {
                    pseq = f.Split('=')[1];
                }
                if (f.IndexOf("OrderTag") > -1)
                {
                    OrderTag = f.Split('=')[1];
                }
                if (f.IndexOf("AE") > -1)
                {
                    AE = f.Split('=')[1];
                }

            }


            string TRADEDATE = ASCIIEncoding.ASCII.GetString(obj.TRADEDATE);
            string ORDERTIME = ASCIIEncoding.ASCII.GetString(obj.ORDERTIME);
            string EXECTYPE = ASCIIEncoding.ASCII.GetString(obj.EXECTYPE);
            string BROKERID = ASCIIEncoding.ASCII.GetString(obj.BROKERID);
            string ORDERNO = ASCIIEncoding.ASCII.GetString(obj.ORDERNO);
            string INVESTORACNO = ASCIIEncoding.ASCII.GetString(obj.INVESTORACNO);
            string SUBACT = ASCIIEncoding.ASCII.GetString(obj.SUBACT);
            string PRODUCTKIND = ASCIIEncoding.ASCII.GetString(obj.PRODUCTKIND);
            string SECURITYEXCHANGE = ASCIIEncoding.ASCII.GetString(obj.SECURITYEXCHANGE);
            string SECURITYTYPE1 = ASCIIEncoding.ASCII.GetString(obj.SECURITYTYPE1);
            string SYMBOL1 = ASCIIEncoding.ASCII.GetString(obj.SYMBOL1);
            string MATURITYMONTHYEAR1 = ASCIIEncoding.ASCII.GetString(obj.MATURITYMONTHYEAR1);
            string PUTORCALL1 = ASCIIEncoding.ASCII.GetString(obj.PUTORCALL1);
            string STRIKEPRICE1 = ASCIIEncoding.ASCII.GetString(obj.STRIKEPRICE1);
            string SIDE1 = ASCIIEncoding.ASCII.GetString(obj.SIDE1);
            string SECURITYTYPE2 = ASCIIEncoding.ASCII.GetString(obj.SECURITYTYPE2);
            string SYMBOL2 = ASCIIEncoding.ASCII.GetString(obj.SYMBOL2);
            string MATURITYMONTHYEAR2 = ASCIIEncoding.ASCII.GetString(obj.MATURITYMONTHYEAR2);
            string PUTORCALL2 = ASCIIEncoding.ASCII.GetString(obj.PUTORCALL2);
            string STRIKEPRICE2 = ASCIIEncoding.ASCII.GetString(obj.STRIKEPRICE2);
            string SIDE2 = ASCIIEncoding.ASCII.GetString(obj.SIDE2);
            string BS = ASCIIEncoding.ASCII.GetString(obj.BS);
            decimal PRICE = decimal.Parse(ASCIIEncoding.ASCII.GetString(obj.PRICE));
            decimal STOPPRICE = decimal.Parse(ASCIIEncoding.ASCII.GetString(obj.STOPPRICE));
            int ORDERQTY = int.Parse(ASCIIEncoding.ASCII.GetString(obj.ORDERQTY));
            string TIMEINFORCE = ASCIIEncoding.ASCII.GetString(obj.TIMEINFORCE);
            string OPENCLOSE = ASCIIEncoding.ASCII.GetString(obj.OPENCLOSE);
            string ORDERTYPE = ASCIIEncoding.ASCII.GetString(obj.ORDERTYPE);


            string SOURCECODE = ASCIIEncoding.ASCII.GetString(obj.SOURCECODE);
            string CLORDID = ASCIIEncoding.ASCII.GetString(obj.CLORDID);
            string STATUSCODE = ASCIIEncoding.Default.GetString(obj.STATUSCODE);
            string ORDERSTATUS = ASCIIEncoding.Default.GetString(obj.ORDERSTATUS);
            string EXPIREDATE = ASCIIEncoding.ASCII.GetString(obj.EXPIREDATE);
            string ORDERID = ASCIIEncoding.ASCII.GetString(obj.ORDERID);
            string TARGETID = ASCIIEncoding.ASCII.GetString(obj.TARGETID);

            string ACCOUNT = ASCIIEncoding.ASCII.GetString(obj.ACCOUNT);

            int LASTSHARES = int.Parse(ASCIIEncoding.ASCII.GetString(obj.LASTSHARES));
            decimal LASTPX = decimal.Parse(ASCIIEncoding.ASCII.GetString(obj.LASTPX));

            int LEAVESQTY = int.Parse(ASCIIEncoding.ASCII.GetString(obj.LEAVESQTY));
            int CUMQTY = int.Parse(ASCIIEncoding.ASCII.GetString(obj.CUMQTY));

            decimal AVGPX = decimal.Parse(ASCIIEncoding.ASCII.GetString(obj.AVGPX));
            decimal PRICE1 = decimal.Parse(ASCIIEncoding.ASCII.GetString(obj.PRICE1));
            decimal PRICE2 = decimal.Parse(ASCIIEncoding.ASCII.GetString(obj.PRICE2));

            string EXECID = ASCIIEncoding.ASCII.GetString(obj.EXECID);
            string EXECREFID = ASCIIEncoding.ASCII.GetString(obj.EXECREFID);


            // ReplyObject.Exectype = EXECTYPE;
            ee.ORDERKIND = OrderKind;

            ee.EXECTYPE = EXECTYPE;
            ee.TRADEDATE = TRADEDATE;
            ee.ORDERNO = ORDERNO;
            ee.ORDERTIME = ORDERTIME;
            ee.BROKERID = BROKERID;
            ee.INVESTORACNO = INVESTORACNO;
            ee.SUBACT = SUBACT;
            ee.BS = BS;
            ee.PRODUCTKIND = PRODUCTKIND;
            ee.SECURITYEXCHANGE = SECURITYEXCHANGE;
            ee.SECURITYTYPE1 = SECURITYTYPE1;
            ee.SYMBOL1 = SYMBOL1;
            ee.MATURITYMONTHYEAR1 = MATURITYMONTHYEAR1;
            ee.PUTORCALL1 = PUTORCALL1;
            ee.STRIKEPRICE1 = decimal.Parse(STRIKEPRICE1);
            ee.SIDE1 = SIDE1;
            ee.SECURITYTYPE2 = SECURITYTYPE2;
            ee.SYMBOL2 = SYMBOL2;
            ee.MATURITYMONTHYEAR2 = MATURITYMONTHYEAR2;
            ee.PUTORCALL2 = PUTORCALL2;
            ee.STRIKEPRICE2 = decimal.Parse(STRIKEPRICE2);
            ee.SIDE2 = SIDE2;
            ee.PRICE = PRICE;
            ee.STOPPRICE = STOPPRICE;
            ee.ORDERQTY = ORDERQTY;
            ee.MATCHQTY = 0;
            ee.NOMATCHQTY = LEAVESQTY;
            ee.DELQTY = 0;
            ee.STATUSCODE = STATUSCODE;
            ee.ORDERSTATUS = ORDERSTATUS;
            ee.CLORDID = CLORDID;
            ee.OPENCLOSE = OPENCLOSE;
            ee.TIMEINFORCE = TIMEINFORCE;
            ee.ORDERTYPE = ORDERTYPE;
            ee.EXPIREDATE = EXPIREDATE;

            ee.MDATE = DateTime.Now.ToString("HH:mm:ss.fff");
            ee.SEQ = seq;
            ee.SOURCECODE = SOURCECODE;

            ee.ORDERID = ORDERID;
            ee.TARGETID = TARGETID;
            ee.ACCOUNT = ACCOUNT;
            ee.AD = AD;
            ee.KEEPDATA = KeepData;
            ee.PSEQ = seq;
            return ee;
        }
    }
}
