﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
namespace VIPTradingSystem.MYcls
{
    public class AccountManager
    {
        ArrayList tmp = new ArrayList();
        private DataAgent mobj_DataAgent;
        private DataSet mds_Master = new DataSet();
        public Dictionary<string, AccountUIObject> accountUICollection = new Dictionary<string, AccountUIObject>();
        public Dictionary<string, DetailUIObject> detailUICollection = new Dictionary<string, DetailUIObject>();
        public Dictionary<string, FloatUIObject> floatUICollection = new Dictionary<string, FloatUIObject>();
        public Dictionary<string, FloatDetailUIObject> floatDetailUICollection = new Dictionary<string, FloatDetailUIObject>();
        private DataTable _Postion;
        private DataTable _PostionDetail;
        private DataTable _Product;
        private DataTable _MatchDetailReply;
        private int mint_queryPositionCount = 0;
        public AccountManager(DataAgent da)
        {
            try
            {
                mobj_DataAgent = da;
               // frmMain.mobjDataAgent.WS_VIPService.WS_POSITION_DETAILCompleted += new VIPService.WS_POSITION_DETAILCompletedEventHandler(WS_VIPService_WS_POSITION_DETAILCompleted);
                _MatchDetailReply = new DataTable();
                _MatchDetailReply.Columns.Add("INVESTORACNO", typeof(string));//下單帳號
                _MatchDetailReply.Columns.Add("BROKER_ID", typeof(string));//下單帳號
                _MatchDetailReply.Columns.Add("ORDERNO", typeof(string));//委託書號 
                _MatchDetailReply.Columns.Add("BS", typeof(string));//買賣別
                _MatchDetailReply.Columns.Add("PRODUCTID", typeof(string));//商品代碼 
                _MatchDetailReply.Columns.Add("MATCH_PRICE", typeof(decimal));//成交價格 
                _MatchDetailReply.Columns.Add("MATCHQTY", typeof(int));//成交數量 
                _MatchDetailReply.Columns.Add("MATCHSEQ", typeof(string));//回報序號 
                _MatchDetailReply.Columns.Add("B_MATCHQTY", typeof(int)).Expression = "IIF(BS='B',MATCHQTY,0)";
                _MatchDetailReply.Columns.Add("S_MATCHQTY", typeof(int)).Expression = "IIF(BS='S',MATCHQTY,0)";
                _MatchDetailReply.Columns.Add("B_TOTAL_PRICE", typeof(decimal)).Expression = "B_MATCHQTY*MATCH_PRICE";
                _MatchDetailReply.Columns.Add("S_TOTAL_PRICE", typeof(decimal)).Expression = "S_MATCHQTY*MATCH_PRICE";
                _MatchDetailReply.PrimaryKey = new DataColumn[] { _MatchDetailReply.Columns["BROKER_ID"], _MatchDetailReply.Columns["ORDERNO"], _MatchDetailReply.Columns["MATCHSEQ"] };
                mds_Master.Tables.Add(_MatchDetailReply);
                _Product = new DataTable();
                _Product.Columns.Add("PRODUCTID", typeof(string));
                _Product.Columns.Add("PRODUCTDESC", typeof(string));
                _Product.Columns.Add("MARKET_PRICE", typeof(decimal));
                _Product.Columns.Add("CLOSE_PRICE", typeof(decimal));
                _Product.Columns.Add("CONTRACT_SIZE", typeof(decimal));
                _Product.Columns.Add("FEE", typeof(decimal)).DefaultValue = 0;
                _Product.Columns.Add("TAX", typeof(decimal)).DefaultValue = 0;
                _Product.Columns.Add("COMTYPE", typeof(int));
                _Product.Columns.Add("KIND_ID", typeof(string));
                _Product.Columns.Add("STRIKE_PRICE", typeof(decimal));
                _Product.Columns.Add("CP", typeof(string));
                _Product.Columns.Add("MONTH", typeof(int));
                _Product.Columns.Add("YEAR", typeof(int));
                _Product.PrimaryKey = new DataColumn[] { _Product.Columns["PRODUCTID"] };
                mds_Master.Tables.Add(_Product);

                _PostionDetail = new DataTable();
                _PostionDetail.Columns.Add("BROKER_ID", typeof(string));//分公司
                _PostionDetail.Columns.Add("INVESTORACNO", typeof(string));//客戶帳號
                _PostionDetail.Columns.Add("TRADEDATE", typeof(string));//交易日期
                _PostionDetail.Columns.Add("MATCHTIME", typeof(string));//成交時間
                _PostionDetail.Columns.Add("ORDERNO", typeof(string));//委託書號
                _PostionDetail.Columns.Add("BS", typeof(string));//買賣別
                _PostionDetail.Columns.Add("PRODUCTID", typeof(string));//商品代碼
                _PostionDetail.Columns.Add("MATCHQTY", typeof(int));//成交口數
                _PostionDetail.Columns.Add("MATCH_PRICE", typeof(decimal));//成交價格
                _PostionDetail.Columns.Add("TOTAL_PRICE", typeof(decimal)).Expression = "MATCHQTY*MATCH_PRICE";//成交價格
                _PostionDetail.Columns.Add("MATCHSEQ", typeof(string));//成交序號
                _PostionDetail.Columns.Add("DTRADE", typeof(string));//當沖別
                _PostionDetail.Columns.Add("YES_MATCHQTY", typeof(int)).Expression = "IIF(TRADEDATE<>'" + DateTime.Now.ToString("MMdd") + "',MATCHQTY,0)";//昨日成交口數

                mds_Master.Tables.Add(_PostionDetail);


                _Postion = new DataTable();
                _Postion.Columns.Add("BROKER_ID", typeof(string));
                _Postion.Columns.Add("INVESTORACNO", typeof(string));
                _Postion.Columns.Add("PRODUCTID", typeof(string));

                _Postion.PrimaryKey = new DataColumn[] { _Postion.Columns["BROKER_ID"], _Postion.Columns["INVESTORACNO"], _Postion.Columns["PRODUCTID"] };
                mds_Master.Tables.Add(_Postion);

                DataColumn[] dcParent = new DataColumn[] { _Postion.Columns["BROKER_ID"], _Postion.Columns["INVESTORACNO"], _Postion.Columns["PRODUCTID"] };
                DataColumn[] dcChild = new DataColumn[] { _PostionDetail.Columns["BROKER_ID"], _PostionDetail.Columns["INVESTORACNO"], _PostionDetail.Columns["PRODUCTID"] };
                DataRelation relPositionData;
                relPositionData = new DataRelation("positionMain_PositionData", dcParent, dcChild);
                mds_Master.Relations.Add(relPositionData);
                _Postion.Columns.Add("BS", typeof(string)).Expression = "max(child(positionMain_PositionData).BS)";        //買賣別        
                _Postion.Columns.Add("POSITION_QTY", typeof(int)).Expression = "sum(child(positionMain_PositionData).MATCHQTY)";        //部位口數        
                _Postion.Columns.Add("POSITION_PRICE", typeof(decimal)).Expression = "sum(child(positionMain_PositionData).TOTAL_PRICE)/sum(child(positionMain_PositionData).MATCHQTY)";        //部位均價       

                _Postion.Columns.Add("YES_POSITION", typeof(int)).Expression = "sum(child(positionMain_PositionData).YES_MATCHQTY)";        //昨日部位口數        


                DataColumn[] dcProductParent = new DataColumn[] { _Product.Columns["PRODUCTID"] };
                DataColumn[] dcProductChild = new DataColumn[] { _Postion.Columns["PRODUCTID"] };
                DataRelation relProductData;
                relProductData = new DataRelation("positionMain_ProductData", dcProductParent, dcProductChild);
                mds_Master.Relations.Add(relProductData);
                _Postion.Columns.Add("PRODUCTDESC", typeof(string)).Expression = " (parent(positionMain_ProductData).PRODUCTDESC)";
                _Postion.Columns.Add("COMTYPE", typeof(int)).Expression = " (parent(positionMain_ProductData).COMTYPE)";
                _Postion.Columns.Add("KIND_ID", typeof(string)).Expression = " (parent(positionMain_ProductData).KIND_ID)";
                _Postion.Columns.Add("STRIKE_PRICE", typeof(decimal)).Expression = " (parent(positionMain_ProductData).STRIKE_PRICE)";
                _Postion.Columns.Add("CP", typeof(string)).Expression = " (parent(positionMain_ProductData).CP)";
                _Postion.Columns.Add("MONTH", typeof(int)).Expression = " (parent(positionMain_ProductData).MONTH)";
                _Postion.Columns.Add("YEAR", typeof(int)).Expression = " (parent(positionMain_ProductData).YEAR)";
                _Postion.Columns.Add("CONTRACT_SIZE", typeof(int)).Expression = " (parent(positionMain_ProductData).CONTRACT_SIZE)";
                //_Postion.Columns.Add("MARKET_PRICE", typeof(decimal)).Expression = " (parent(positionMain_ProductData).MARKET_PRICE)";
                _Postion.Columns.Add("CLOSE_PRICE", typeof(decimal)).Expression = " (parent(positionMain_ProductData).CLOSE_PRICE)";
                _Postion.Columns.Add("PREMIUM", typeof(decimal)).Expression = " (parent(positionMain_ProductData).CONTRACT_SIZE)*POSITION_QTY*POSITION_PRICE";
                _Postion.Columns.Add("FEE", typeof(decimal)).Expression = " (parent(positionMain_ProductData).FEE) *POSITION_QTY";
                //_Postion.Columns.Add("MARKET_PREMIUM", typeof(decimal)).Expression = " (parent(positionMain_ProductData).CONTRACT_SIZE)*POSITION_QTY*MARKET_PRICE";
                _Postion.Columns.Add("CLOSE_PREMIUM", typeof(decimal)).Expression = " (parent(positionMain_ProductData).CONTRACT_SIZE)*POSITION_QTY*CLOSE_PRICE ";
                _Postion.Columns.Add("IN_TAX", typeof(decimal)).Expression = " PREMIUM*(parent(positionMain_ProductData).TAX) ";
                //_Postion.Columns.Add("MARKET_TAX", typeof(decimal)).Expression = " MARKET_PREMIUM*(parent(positionMain_ProductData).TAX) ";
                _Postion.Columns.Add("CLOSE_TAX", typeof(decimal)).Expression = " CLOSE_PREMIUM*(parent(positionMain_ProductData).TAX) ";

                //_Postion.Columns.Add("FLOAT_PROFIT", typeof(decimal)).Expression = "IIF(BS='B', MARKET_PREMIUM-PREMIUM, PREMIUM-MARKET_PREMIUM)-FEE*2-MARKET_TAX-IN_TAX";
                _Postion.Columns.Add("CLOSE_PROFIT", typeof(decimal)).Expression = "IIF(BS='B', CLOSE_PREMIUM-PREMIUM, PREMIUM-CLOSE_PREMIUM) ";//不含稅和手續費

                DataColumn[] dcMatchParent = new DataColumn[] { _Postion.Columns["BROKER_ID"], _Postion.Columns["INVESTORACNO"], _Postion.Columns["PRODUCTID"] };
                DataColumn[] dcMatchChild = new DataColumn[] { _MatchDetailReply.Columns["BROKER_ID"], _MatchDetailReply.Columns["INVESTORACNO"], _MatchDetailReply.Columns["PRODUCTID"] };
                DataRelation relMatchData;
                relMatchData = new DataRelation("positionMain_MatchtData", dcMatchParent, dcMatchChild);
                mds_Master.Relations.Add(relMatchData);


                _Postion.Columns.Add("B_MATCH_QTY", typeof(int)).Expression = "sum(child(positionMain_MatchtData).B_MATCHQTY)";
                _Postion.Columns.Add("S_MATCH_QTY", typeof(int)).Expression = "sum(child(positionMain_MatchtData).S_MATCHQTY)";

                _Postion.Columns.Add("B_MATCH_PRICE", typeof(decimal)).Expression = "IIF(B_MATCH_QTY>0,sum(child(positionMain_MatchtData).B_TOTAL_PRICE)/B_MATCH_QTY,0)";
                _Postion.Columns.Add("S_MATCH_PRICE", typeof(decimal)).Expression = "IIF(S_MATCH_QTY>0,sum(child(positionMain_MatchtData).S_TOTAL_PRICE)/S_MATCH_QTY,0)";

                _Postion.Columns.Add("NOW_QTY", typeof(decimal)).Expression = "B_MATCH_QTY-S_MATCH_QTY";

                _Postion.Columns.Add("INCOME_BALANCE", typeof(decimal));//平倉損益
                _Postion.Columns.Add("U_INCOME_BALANCE", typeof(decimal));//淨損益


                //註冊行情和成回
                registerUIObject();
                //取得成交資料
                getMatchData();
                //取得目前未平倉
                Query();




            }
            catch (Exception ex)
            {
                MYcls.DataAgent._LM.WriteLog("AccountManagerLog", "AccountManager:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }

          private void getMatchData()
        {
            try
            {
                foreach (DataRow dr in frmMain.UserConfigs.AccountData.Rows)
                {
                    DataTable dtData = null;// MYcls.CommonFunction.SerialUnZip(frmMain.mobjDataAgent.WS_LService.WS_MATCH_REPLY(dr["COMPANY"].ToString().Trim(), dr["ACTNO"].ToString().Trim())).Tables[0];
                    foreach (DataRow drReturn in dtData.Rows)
                    {
                        if (drReturn["PRODUCTID"].ToString().Trim() != "")
                        {
                            newMain(drReturn["BROKER_ID"].ToString().Trim(), drReturn["INVESTORACNO"].ToString().Trim(), drReturn["PRODUCTID"].ToString().Trim());
                            DataRow drNew = _MatchDetailReply.NewRow();
                            foreach (DataColumn dc in dtData.Columns)
                            {
                                drNew[dc.ColumnName] = drReturn[dc.ColumnName].ToString().Trim();
                            }
                            _MatchDetailReply.Rows.Add(drNew);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MYcls.DataAgent._LM.WriteLog("AccountManagerLog", "getMatchData:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        public void Query()
        {
            try
            {
                _PostionDetail.Rows.Clear();
                mint_queryPositionCount++;
                foreach (DataRow dr in frmMain.UserConfigs.AccountData.Rows)
                {
                    //lock (tmp)
                    //    tmp.Add(dr["COMPANY"].ToString().Trim()+ dr["ACTNO"].ToString().Trim());
                    //更新未平倉
                   // frmMain.mobjDataAgent.WS_VIPService.WS_POSITION_DETAILAsync(dr["COMPANY"].ToString().Trim(), dr["ACTNO"].ToString().Trim(), dr["COMPANY"].ToString().Trim()+ dr["ACTNO"].ToString().Trim());

                    byte[] bt = null;// frmMain.mobjDataAgent.WS_VIPService.WS_POSITION_DETAIL(dr["COMPANY"].ToString().Trim(), dr["ACTNO"].ToString().Trim());

                    DataTable dtData = MYcls.CommonFunction.SerialUnZip(bt).Tables[0];
                    if (dtData.Rows.Count > 0)
                    {

                        foreach (DataRow drReturn in dtData.Rows)
                        {
                            string COMBINATION = drReturn["COMBINATION"].ToString();
                            string ProductId = "";
                            string mutibs = "";
                            switch (COMBINATION)
                            {
                                case "0":
                                    drReturn["PRODUCTID"] = ProductId = CommonFunction.getProductId(drReturn["COMTYPE1"].ToString().Trim()
                                   , drReturn["COMNO1"].ToString().Trim()
                                   , drReturn["COMYM1"].ToString().Trim()
                                    , drReturn["STKPRC1"].ToString().Trim()
                                             , drReturn["CALLPUT1"].ToString());
                                    break;
                                case "/":
                                case ":":
                                case "-":
                                    //ProductId = getProductId(COMTYPE1, COMNO1, COMYM1, STKPRC1, CALLPUT1) +
                                    //getProductId(COMTYPE2, COMNO2, COMYM2, STKPRC2, CALLPUT2);
                                    drReturn["PRODUCTID"] = ProductId = CommonFunction.getProductId(drReturn["COMTYPE1"].ToString().Trim()
                                  , drReturn["COMNO1"].ToString().Trim()
                                  , drReturn["COMNO2"].ToString().Trim()
                                   , drReturn["COMYM1"].ToString().Trim()
                                            , drReturn["COMYM2"].ToString().Trim()
                                            , drReturn["CALLPUT1"].ToString(), drReturn["CALLPUT2"].ToString()
                                             , drReturn["STKPRC1"].ToString(), drReturn["STKPRC2"].ToString()
                                              , drReturn["BS1"].ToString(), drReturn["BS2"].ToString(), ref mutibs
                                             );


                                    break;

                            }


                            //  string PRODUCTID2 = CommonFunction.getProductId(drReturn["COMTYPE2"].ToString()
                            //, drReturn["COMNO2"].ToString()

                            //, drReturn["COMYM2"].ToString()
                            // , drReturn["STKPRC2"].ToString()
                            //          , drReturn["CALLPUT2"].ToString());


                            newMain(drReturn["BROKER_ID"].ToString(), drReturn["INVESTORACNO"].ToString(), drReturn["PRODUCTID"].ToString().Trim());
                            DataRow drNew = _PostionDetail.NewRow();
                            drNew["BROKER_ID"] = drReturn["BROKER_ID"].ToString();
                            drNew["INVESTORACNO"] = drReturn["INVESTORACNO"].ToString();
                            drNew["TRADEDATE"] = drReturn["TRADEDATE"].ToString();
                            drNew["MATCHTIME"] = drReturn["MATCHTIME"].ToString();
                            drNew["ORDERNO"] = drReturn["ORDERNO"].ToString();
                            drNew["BS"] = drReturn["BS"].ToString();
                            drNew["PRODUCTID"] = drReturn["PRODUCTID"].ToString().Trim();
                            drNew["MATCHQTY"] = drReturn["MATCHQTY"].ToString();
                            drNew["MATCH_PRICE"] = drReturn["MATCHPRICE"].ToString();
                            drNew["MATCHSEQ"] = drReturn["MATCHSEQ"].ToString();
                            drNew["DTRADE"] = drReturn["DTRADE"].ToString();
                            _PostionDetail.Rows.Add(drNew);
                        }
                        foreach (DataRow drFind in _Postion.Rows)
                        {
                            foreach (AccountUIObject obj in accountUICollection.Values)
                            {
                                raiseAccountEvent(drFind, obj);
                            }
                        }
                        foreach (DataRow drFind in _PostionDetail.Rows)
                        {
                            foreach (DetailUIObject obj in detailUICollection.Values)
                            {
                                raiseDetailEvent("U", drFind, obj);
                            }
                        }
                    }
                    //更新平倉損益
                }
            }
            catch (Exception ex)
            {
                MYcls.DataAgent._LM.WriteLog("UIErrorLog", "Query:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        public DataTable getPositionData()
        {
            DataTable dtReturn = new DataTable();
            try
            {
                foreach (DataColumn dc in _Postion.Columns)
                {
                    dtReturn.Columns.Add(dc.ColumnName);
                }
                foreach (DataRow drFind in _Postion.Select("POSITION_QTY>0"))
                {
                    DataRow drNew = dtReturn.NewRow();
                    foreach (DataColumn dc in _Postion.Columns)
                    {
                        drNew[dc.ColumnName] = drFind[dc.ColumnName].ToString();
                    }
                    dtReturn.Rows.Add(drNew);
                }
            }
            catch (Exception ex)
            {
                MYcls.DataAgent._LM.WriteLog("UIErrorLog", "getPositionData:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
            return dtReturn;
        }
        public void getLast(string key)
        {
            try
            {
                if (accountUICollection.ContainsKey(key))
                {
                    foreach (DataRow drFind in _Postion.Rows)
                    {
                        raiseAccountEvent(drFind, accountUICollection[key]);
                    }
                }
                if (detailUICollection.ContainsKey(key))
                {
                    foreach (DataRow drFind in _PostionDetail.Rows)
                    {
                        raiseDetailEvent("U", drFind, detailUICollection[key]);
                    }
                }
            }
            catch (Exception ex)
            {
                MYcls.DataAgent._LM.WriteLog("UIErrorLog", "getLast:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        public DataTable getLastMatch(string investorAcno, string productId)
        {
            DataTable dtReturn = new DataTable();
            try
            {
                dtReturn.Columns.Add("INVESTORACNO", typeof(string));//下單帳號
                dtReturn.Columns.Add("BROKER_ID", typeof(string));//下單帳號
                dtReturn.Columns.Add("ORDERNO", typeof(string));//委託書號 
                dtReturn.Columns.Add("BS", typeof(string));//買賣別
                dtReturn.Columns.Add("PRODUCTID", typeof(string));//商品代碼 
                dtReturn.Columns.Add("MATCH_PRICE", typeof(decimal));//成交價格 
                dtReturn.Columns.Add("MATCHQTY", typeof(int));//成交數量 
                dtReturn.Columns.Add("MATCHSEQ", typeof(string));//回報序號 
                foreach (DataRow drFind in _MatchDetailReply.Select("investorAcno='" + investorAcno + "' and productId='" + productId + "'"))
                {
                    DataRow drNew = dtReturn.NewRow();
                    drNew["INVESTORACNO"] = drFind["INVESTORACNO"].ToString();
                    drNew["BROKER_ID"] = drFind["BROKER_ID"].ToString();
                    drNew["ORDERNO"] = drFind["ORDERNO"].ToString();
                    drNew["BS"] = drFind["BS"].ToString();
                    drNew["PRODUCTID"] = drFind["PRODUCTID"].ToString();
                    drNew["MATCH_PRICE"] = drFind["MATCH_PRICE"].ToString();
                    drNew["MATCHQTY"] = drFind["MATCHQTY"].ToString();
                    drNew["MATCHSEQ"] = drFind["MATCHSEQ"].ToString();
                    dtReturn.Rows.Add(drNew);
                }

            }
            catch (Exception ex)
            {
                MYcls.DataAgent._LM.WriteLog("UIErrorLog", "getLast:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
            return dtReturn;
        }
        private void registerProduct(string prorductid)
        {
            string mstr_ProductKind = MYcls.CommonFunction.getProductInfoByProductId(prorductid).ProductKind;
            MarketParser.ProductKind productkind = MarketParser.ProductKind.Future;
            if (mstr_ProductKind == "2")
                productkind = MarketParser.ProductKind.Option;
            else if (mstr_ProductKind == "3")
                productkind = MarketParser.ProductKind.mFuture;
            frmMain.mobjDataAgent.MarketParser.RegItem(MarketParser.RegitemKind.I020, productkind, prorductid);
            frmMain.mobjDataAgent.objInfoStringHandle.AddUIItem(InfoStringHandle.RegitemKind.I020, prorductid, "AccountManager");
            frmMain.mobjDataAgent.objInfoStringHandle.getI020UIObject("AccountManager", prorductid)._ReceiveI020 += new I020UIObject.ReceiveI020Callback(usPosition__ReceiveI020);
        }
        void usPosition__ReceiveI020(I020UIObject.I020EventArgs e)
        {
            try
            {
                decimal CONTRACT_SIZE = 0;
                decimal TAX = 0;
                decimal FEE = 0;
                DataRow drProduct = _Product.Rows.Find(new object[] { e._productId });
                if (drProduct != null)
                {
                    drProduct["MARKET_PRICE"] = e._matchprice;
                    decimal.TryParse(drProduct["CONTRACT_SIZE"].ToString(), out CONTRACT_SIZE);
                    decimal.TryParse(drProduct["TAX"].ToString(), out TAX);
                    decimal.TryParse(drProduct["FEE"].ToString(), out FEE);
                }

                foreach (DataRow drFind in _Postion.Select("PRODUCTID='" + e._productId + "'"))
                {
                    decimal POSITION_PRICE = 0;
                    decimal.TryParse(drFind["POSITION_PRICE"].ToString(), out POSITION_PRICE);
                    decimal POSITION_QTY = 0;
                    decimal.TryParse(drFind["POSITION_QTY"].ToString(), out POSITION_QTY);
                    decimal PREMIUM = 0;
                    decimal.TryParse(drFind["PREMIUM"].ToString(), out PREMIUM);

                    foreach (FloatUIObject obj in floatUICollection.Values)
                    {
                        FloatUIObject.Float_EventArgs ee = new FloatUIObject.Float_EventArgs();
                        ee.BROKER_ID = drFind["BROKER_ID"].ToString();
                        ee.INVESTORACNO = drFind["INVESTORACNO"].ToString();
                        ee.PRODUCTID = drFind["PRODUCTID"].ToString();
                        ee.MARKET_PRICE = e._matchprice.ToString();
                        decimal MARKET_PREMIUM = POSITION_QTY * e._matchprice * CONTRACT_SIZE;
                        decimal MARKET_TAX = MARKET_PREMIUM * TAX;
                        decimal IN_TAX = 0;
                        decimal.TryParse(drFind["IN_TAX"].ToString(), out IN_TAX);
                        decimal FLOAT_PROFIT = (drFind["BS"].ToString() == "B" ? (MARKET_PREMIUM - PREMIUM) : (PREMIUM - MARKET_PREMIUM));

                        ee.FLOAT_PROFIT = decimal.Parse(FLOAT_PROFIT.ToString("#0.####"));

                        decimal U_FLOAT_PROFIT = FLOAT_PROFIT - (FEE * POSITION_QTY * 2) - MARKET_TAX - IN_TAX;

                        ee.U_FLOAT_PROFIT = decimal.Parse(U_FLOAT_PROFIT.ToString("#0.####"));
                        obj.raiseReceiveFloat(ee);
                    }
                }


                foreach (DataRow drFind in _PostionDetail.Select("PRODUCTID='" + e._productId + "'"))
                {
                    decimal MATCH_PRICE = 0;
                    decimal.TryParse(drFind["MATCH_PRICE"].ToString(), out MATCH_PRICE);
                    decimal MATCHQTY = 0;
                    decimal.TryParse(drFind["MATCHQTY"].ToString(), out MATCHQTY);
                    decimal PREMIUM = MATCHQTY * MATCH_PRICE * CONTRACT_SIZE;


                    foreach (FloatDetailUIObject obj in floatDetailUICollection.Values)
                    {
                        FloatDetailUIObject.FloatDetail_EventArgs ee = new FloatDetailUIObject.FloatDetail_EventArgs();
                        ee.BROKER_ID = drFind["BROKER_ID"].ToString();
                        ee.INVESTORACNO = drFind["INVESTORACNO"].ToString();
                        ee.PRODUCTID = drFind["PRODUCTID"].ToString();
                        ee.MARKET_PRICE = e._matchprice.ToString();
                        decimal MARKET_PREMIUM = MATCHQTY * e._matchprice * CONTRACT_SIZE;
                        decimal MARKET_TAX = MARKET_PREMIUM * TAX;

                        decimal FLOAT_PROFIT = (drFind["BS"].ToString() == "B" ? (MARKET_PREMIUM - PREMIUM) : (PREMIUM - MARKET_PREMIUM)) - (FEE * MATCHQTY * 2) - MARKET_TAX - (PREMIUM * TAX);
                        ee.MARKET_PREMIUM = decimal.Parse(FLOAT_PROFIT.ToString("#0.####"));
                        ee.FLOAT_PROFIT = decimal.Parse(FLOAT_PROFIT.ToString("#0.####"));
                        obj.raiseReceiveFloatDetail(ee);

                    }
                }
            }
            catch (Exception ex)
            {
                MYcls.DataAgent._LM.WriteLog("UIErrorLog", "usPosition__ReceiveI020:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        void ruimatch__ReceiveMatch(MatchUIObject e)
        {
            try
            {
                //newMain(e.BROKERID, e.INVESTORACNO, e.PRODUCTID);
                //DataRow drFindMatch = _MatchDetailReply.Rows.Find(new object[] { e.BROKERID, e.ORDERNO, e.MATCHSEQ });
                //if (drFindMatch == null)
                //{
                //    DataRow drNewMatch = _MatchDetailReply.NewRow();
                //    drNewMatch["BROKER_ID"] = e.BROKERID;
                //    drNewMatch["INVESTORACNO"] = e.INVESTORACNO;
                //    drNewMatch["ORDERNO"] = e.ORDERNO;
                //    drNewMatch["BS"] = e.BS;
                //    drNewMatch["PRODUCTID"] = e.PRODUCTID;
                //    drNewMatch["MATCH_PRICE"] = e.MATCHPRICE;
                //    drNewMatch["MATCHQTY"] = e.MATCHQTY;
                //    drNewMatch["MATCHSEQ"] = e.MATCHSEQ;
                //    _MatchDetailReply.Rows.Add(drNewMatch);
                //}


                ////1.先找回報資料
                //DataRow[] drGetDatas = _Postion.Select("BROKER_ID='" + e.BROKERID + "' and INVESTORACNO='" + e.INVESTORACNO + "' and PRODUCTID='" + e.PRODUCTID + "'  ");
                //if (drGetDatas.Length > 0)
                //{
                //    //原始部位
                //    decimal beforePositionQty = 0;
                //    decimal.TryParse(drGetDatas[0]["POSITION_QTY"].ToString(), out beforePositionQty);
                //    //原始買賣別
                //    string beforeBS = drGetDatas[0]["BS"].ToString();

                //    //如果買賣別相同,互相累加
                //    if (e.BS == beforeBS)
                //    {
                //        updUnLiquidationDetail(0, e);
                //    }
                //    else
                //    {
                //        INCOME rtrINCOME = new INCOME();
                //        if (beforePositionQty - e.MATCHQTY > 0)
                //        {
                //            rtrINCOME = updUnLiquidationDetail(1, e);
                //        }
                //        else if (beforePositionQty - e.MATCHQTY == 0)
                //        {
                //            rtrINCOME = updUnLiquidationDetail(2, e);
                //        }
                //        else
                //        {
                //            rtrINCOME = updUnLiquidationDetail(3, e);
                //        }
                //        decimal INCOME_BALANCE = 0;
                //        decimal.TryParse(drGetDatas[0]["INCOME_BALANCE"].ToString(), out INCOME_BALANCE);
                //        drGetDatas[0]["INCOME_BALANCE"] = INCOME_BALANCE + rtrINCOME.INCOME_BALANCE;
                //        decimal U_INCOME_BALANCE = 0;
                //        decimal.TryParse(drGetDatas[0]["U_INCOME_BALANCE"].ToString(), out U_INCOME_BALANCE);
                //        drGetDatas[0]["U_INCOME_BALANCE"] = U_INCOME_BALANCE + rtrINCOME.U_INCOME_BALANCE;
                //    }
                //}
                //else
                //{
                //    updUnLiquidationDetail(0, e);
                //}

                //DataRow drFind = _Postion.Rows.Find(new object[] { e.BROKERID, e.INVESTORACNO, e.PRODUCTID });
                //if (drFind != null)
                //{
                //    foreach (AccountUIObject obj in accountUICollection.Values)
                //    {
                //        raiseAccountEvent(drFind, obj);
                //    }
                //}
            }
            catch (Exception ex)
            {
                MYcls.DataAgent._LM.WriteLog("AccountManagerLog", "ruimatch__ReceiveMatch:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        private void newMain(string BROKERID, string INVESTORACNO, string PRODUCTID)
        {
            DataRow drProduct = _Product.Rows.Find(new object[] { PRODUCTID });
            if (drProduct == null)
            {
                DataRow drPrice = _Product.NewRow();
                drPrice["PRODUCTID"] = PRODUCTID;
                VIPTradingSystem.MYcls.CommonFunction.ProductInfo p = VIPTradingSystem.MYcls.CommonFunction.getProductInfoByProductId(PRODUCTID);
                drPrice["COMTYPE"] = p.ComType;
                drPrice["KIND_ID"] = p.ProductClass;
                decimal strikeprice = 0;
                decimal.TryParse(p.Strike, out strikeprice);
                drPrice["STRIKE_PRICE"] = strikeprice;
                drPrice["CP"] = p.Cp;
                drPrice["MONTH"] = p.Period.Substring(4);
                drPrice["YEAR"] = p.Period.Substring(0, 4);
                drPrice["CLOSE_PRICE"] = VIPTradingSystem.MYcls.CommonFunction.getFinalPrice(VIPTradingSystem.MYcls.CommonFunction.getProductInfoByProductId(PRODUCTID).ProductKind, PRODUCTID);
                DataRow[] drFinds = mobj_DataAgent.objInfoStringHandle.I020.Select("productId='" + PRODUCTID + "'");
                if (drFinds.Length > 0)
                {

                    drPrice["MARKET_PRICE"] = drFinds[0]["matchprice"].ToString();
                }
                else
                {
                    string[] arrData = null;// CommonFunction.SerialUnZipArray(frmMain.mobjDataAgent.WS_VIPService.WS_MARKETINFO(new string[] { PRODUCTID }));
                    if (arrData.Length > 0)
                    {
                        foreach (string str in arrData)
                        {
                            if (str.Split('@').Length >= 4)
                            {
                                drPrice["MARKET_PRICE"] = decimal.Parse(str.Split('@')[3]);
                                decimal MARKET_PRICE = 0;
                                decimal.TryParse(drPrice["MARKET_PRICE"].ToString(), out MARKET_PRICE);
                                drPrice["MARKET_PRICE"] = decimal.Parse(MARKET_PRICE.ToString("#0.####"));
                            }
                        }
                    }
                    else
                    {
                        drPrice["MARKET_PRICE"] = drPrice["CLOSE_PRICE"];
                    }
                }
                drPrice["PRODUCTDESC"] = p.ProductName;

                DataRow[] drSize = systemconfigs.ProductMain.Select("KIND_ID='" + PRODUCTID.Substring(0, 3) + "'");
                if (drSize.Length > 0)
                {
                    decimal CONTRACT_SIZE = 0;
                    decimal.TryParse(drSize[0]["CONTRACT_SIZE"].ToString(), out CONTRACT_SIZE);
                    drPrice["CONTRACT_SIZE"] = CONTRACT_SIZE;
                }

                DataRow[] drFee = frmMain.UserConfigs.FBMNFE.Select("KIND_ID='" + PRODUCTID.Substring(0, 3) + "'");
                if (drFee.Length > 0)
                {
                    decimal FEE = 0;
                    decimal.TryParse(drFee[0]["IFE_FEE"].ToString(), out FEE);
                    drPrice["FEE"] = FEE;

                    decimal TAX = 0;
                    decimal.TryParse(drFee[0]["TAX"].ToString(), out TAX);
                    drPrice["TAX"] = TAX;
                }
                registerProduct(PRODUCTID);
                _Product.Rows.Add(drPrice);
            }
            DataRow drFind = _Postion.Rows.Find(new object[] { BROKERID, INVESTORACNO, PRODUCTID });
            if (drFind == null)
            {
                DataRow drPrice = _Postion.NewRow();
                drPrice["BROKER_ID"] = BROKERID;
                drPrice["INVESTORACNO"] = INVESTORACNO;
                drPrice["PRODUCTID"] = PRODUCTID;
                _Postion.Rows.Add(drPrice);
                drFind = drPrice;
            }


        }
        /// <summary>
        /// 更新未明倉detail v3.0.0.17修改
        /// </summary>
        public INCOME updUnLiquidationDetail(int status, MatchUIObject e)
        {
            //status =0 新增部位
            //status =1 數量相減>零
            //status =2    數量相減 等於零
            //status =3     數量相減<零
            //

            decimal CONTRACT_SIZE = 0;
            decimal TAX = 0;
            decimal FEE = 0;
            //DataRow drProduct = _Product.Rows.Find(new object[] { e.PRODUCTID });
            //if (drProduct != null)
            //{
            //    decimal.TryParse(drProduct["CONTRACT_SIZE"].ToString(), out CONTRACT_SIZE);
            //    decimal.TryParse(drProduct["TAX"].ToString(), out TAX);
            //    decimal.TryParse(drProduct["FEE"].ToString(), out FEE);
            //}
            INCOME rtrINCOME = new INCOME();
            //decimal tmpDiff = 0;
            //decimal u_tmpDiff = 0;
            //int tmpQty = 0;
            //if (status == 0)
            //{
            //    DataRow drNew = _PostionDetail.NewRow();
            //    drNew["BROKER_ID"] = e.BROKERID;
            //    drNew["INVESTORACNO"] = e.INVESTORACNO;
            //    drNew["TRADEDATE"] = e.TRADEDATE.Substring(4);
            //    drNew["MATCHTIME"] = e.MATCHTIME;
            //    drNew["ORDERNO"] = e.ORDERNO;
            //    drNew["BS"] = e.BS;
            //    drNew["PRODUCTID"] = e.PRODUCTID;
            //    drNew["MATCHQTY"] = e.MATCHQTY;
            //    drNew["MATCH_PRICE"] = e.MATCHPRICE;
            //    drNew["MATCHSEQ"] = e.MATCHSEQ;
            //    drNew["DTRADE"] = e.DTRADE;
            //    _PostionDetail.Rows.Add(drNew);
            //    foreach (DetailUIObject obj in detailUICollection.Values)
            //    {
            //        raiseDetailEvent("U", drNew, obj);
            //    }
            //}
            //else if (status == 1 || status == 3)
            //{
            //    //先算當沖
            //    string strbs = "";
            //    string bs = "";
            //    if (e.BS == "S") bs = "B"; else bs = "S";
            //    strbs = "bs='" + bs + "'";
            //    int nowOTQTY = e.MATCHQTY;
            //    DataRow[] drUndetailTrade = _PostionDetail.Select(" BROKER_ID ='" + e.BROKERID + "' and INVESTORACNO='" + e.INVESTORACNO + "'  and PRODUCTID ='" + e.PRODUCTID + "' and " + strbs + " and DTRADE='Y'", "TRADEDATE asc,MATCHTIME asc");
            //    foreach (DataRow dr in drUndetailTrade)
            //    {
            //        if (nowOTQTY > 0)
            //        {
            //            if ((((int)dr["MATCHQTY"]) < nowOTQTY) || (((int)dr["MATCHQTY"]) == nowOTQTY))
            //            {
            //                tmpQty = ((int)dr["MATCHQTY"]);
            //                INCOME income = new INCOME();
            //                income = getINCOME(bs, ((decimal)dr["MATCH_PRICE"]), e.MATCHPRICE, tmpQty, CONTRACT_SIZE, TAX, FEE);
            //                tmpDiff += income.INCOME_BALANCE;
            //                u_tmpDiff += income.U_INCOME_BALANCE;
            //                nowOTQTY = nowOTQTY - tmpQty;
            //                foreach (DetailUIObject obj in detailUICollection.Values)
            //                {
            //                    raiseDetailEvent("D", dr, obj);
            //                }
            //                dr.Delete();
            //            }
            //            else if (((int)dr["MATCHQTY"]) > nowOTQTY)
            //            {
            //                tmpQty = nowOTQTY;
            //                INCOME income = new INCOME();
            //                income = getINCOME(bs, ((decimal)dr["MATCH_PRICE"]), e.MATCHPRICE, tmpQty, CONTRACT_SIZE, TAX, FEE);
            //                tmpDiff += income.INCOME_BALANCE;
            //                u_tmpDiff += income.U_INCOME_BALANCE;
            //                nowOTQTY = nowOTQTY - ((int)dr["MATCHQTY"]);
            //                dr["MATCHQTY"] = Math.Abs(nowOTQTY);
            //                foreach (DetailUIObject obj in detailUICollection.Values)
            //                {
            //                    raiseDetailEvent("U", dr, obj);
            //                }
            //                nowOTQTY = -1;
            //                break;
            //            }
            //        }
            //        else
            //            break;
            //    }
            //    if (nowOTQTY > 0)
            //    {
            //        DataRow[] drUndetail = _PostionDetail.Select("  BROKER_ID ='" + e.BROKERID + "' and INVESTORACNO='" + e.INVESTORACNO + "'  and PRODUCTID ='" + e.PRODUCTID + "' and " + strbs + " ", "TRADEDATE asc,MATCHTIME asc");
            //        foreach (DataRow dr in drUndetail)
            //        {

            //            if ((((int)dr["MATCHQTY"]) < nowOTQTY) || (int.Parse(dr["MATCHQTY"].ToString()) == nowOTQTY))
            //            {
            //                tmpQty = ((int)dr["MATCHQTY"]);
            //                INCOME income = new INCOME();
            //                income = getINCOME(bs, ((decimal)dr["MATCH_PRICE"]), e.MATCHPRICE, tmpQty, CONTRACT_SIZE, TAX, FEE);
            //                tmpDiff += income.INCOME_BALANCE;
            //                u_tmpDiff += income.U_INCOME_BALANCE;
            //                nowOTQTY = nowOTQTY - tmpQty;
            //                foreach (DetailUIObject obj in detailUICollection.Values)
            //                {
            //                    raiseDetailEvent("D", dr, obj);
            //                }
            //                dr.Delete();
            //            }
            //            else if (((int)dr["MATCHQTY"]) > nowOTQTY)
            //            {
            //                tmpQty = nowOTQTY;
            //                INCOME income = new INCOME();
            //                income = getINCOME(bs, ((decimal)dr["MATCH_PRICE"]), e.MATCHPRICE, tmpQty, CONTRACT_SIZE, TAX, FEE);
            //                tmpDiff += income.INCOME_BALANCE;
            //                u_tmpDiff += income.U_INCOME_BALANCE;
            //                nowOTQTY = nowOTQTY - ((int)dr["MATCHQTY"]);
            //                dr["MATCHQTY"] = Math.Abs(nowOTQTY);
            //                foreach (DetailUIObject obj in detailUICollection.Values)
            //                {
            //                    raiseDetailEvent("U", dr, obj);
            //                }
            //                nowOTQTY = -1;
            //                break;
            //            }
            //        }
            //        if (nowOTQTY > 0)
            //        {
            //            DataRow drNew = _PostionDetail.NewRow();
            //            drNew["BROKER_ID"] = e.BROKERID;
            //            drNew["INVESTORACNO"] = e.INVESTORACNO;
            //            drNew["TRADEDATE"] = e.TRADEDATE.Substring(4);
            //            drNew["MATCHTIME"] = e.MATCHTIME;
            //            drNew["ORDERNO"] = e.ORDERNO;
            //            drNew["BS"] = e.BS;
            //            drNew["PRODUCTID"] = e.PRODUCTID;
            //            drNew["MATCHQTY"] = nowOTQTY;
            //            drNew["MATCH_PRICE"] = e.MATCHPRICE;
            //            drNew["MATCHSEQ"] = e.MATCHSEQ;
            //            drNew["DTRADE"] = e.DTRADE;
            //            _PostionDetail.Rows.Add(drNew);
            //            foreach (DetailUIObject obj in detailUICollection.Values)
            //            {
            //                raiseDetailEvent("U", drNew, obj);
            //            }
            //        }
            //    }
            //}
            //else if (status == 2)
            //{
            //    string bs = "";
            //    if (e.BS == "S") bs = "B"; else bs = "S";
            //    DataRow[] drUndetail = _PostionDetail.Select("  BROKER_ID ='" + e.BROKERID + "' and INVESTORACNO='" + e.INVESTORACNO + "'  and PRODUCTID ='" + e.PRODUCTID + "' and bs='" + bs + "'  ", "tradedate asc,matchTime asc");
            //    foreach (DataRow dr in drUndetail)
            //    {

            //        tmpQty = ((int)dr["MATCHQTY"]);
            //        INCOME income = new INCOME();
            //        income = getINCOME(bs, ((decimal)dr["MATCH_PRICE"]), e.MATCHPRICE, tmpQty, CONTRACT_SIZE, TAX, FEE);
            //        tmpDiff += income.INCOME_BALANCE;
            //        u_tmpDiff += income.U_INCOME_BALANCE;

            //        foreach (DetailUIObject obj in detailUICollection.Values)
            //        {
            //            raiseDetailEvent("D", dr, obj);
            //        }
            //        dr.Delete();
            //    }

            //}
            //rtrINCOME.INCOME_BALANCE = tmpDiff;
            //rtrINCOME.U_INCOME_BALANCE = u_tmpDiff;
            return rtrINCOME;
        }
        void raiseAccountEvent(DataRow drFind, AccountUIObject obj)
        {
            AccountUIObject.AccountEventArgs ee = new AccountUIObject.AccountEventArgs();

            ee.BROKER_ID = drFind["BROKER_ID"].ToString();
            ee.INVESTORACNO = drFind["INVESTORACNO"].ToString();
            ee.PRODUCTID = drFind["PRODUCTID"].ToString();
            ee.PRODUCTDESC = drFind["PRODUCTDESC"].ToString();
            ee.BS = drFind["BS"].ToString();
            ee.POSITION_QTY = drFind["POSITION_QTY"].ToString();

            decimal PREMIUM = 0;
            decimal.TryParse(drFind["PREMIUM"].ToString(), out PREMIUM);
            ee.PREMIUM = decimal.Parse(PREMIUM.ToString("#0"));
            decimal IN_TAX = 0;
            decimal.TryParse(drFind["IN_TAX"].ToString(), out IN_TAX);

            decimal POSITION_PRICE = 0;
            decimal.TryParse(drFind["POSITION_PRICE"].ToString(), out POSITION_PRICE);
            ee.POSITION_PRICE = decimal.Parse(POSITION_PRICE.ToString("#0.####")); ;
            //改用搜尋成交價
            decimal MARKET_PRICE = 0;
            decimal CONTRACT_SIZE = 0;
            decimal TAX = 0;
            decimal FEE = 0;
            DataRow drProduct = _Product.Rows.Find(new object[] { ee.PRODUCTID });
            if (drProduct != null)
            {
                ee.MARKET_PRICE = drProduct["MARKET_PRICE"].ToString();
                decimal.TryParse(ee.MARKET_PRICE, out MARKET_PRICE);
                decimal.TryParse(drProduct["CONTRACT_SIZE"].ToString(), out CONTRACT_SIZE);
                decimal.TryParse(drProduct["TAX"].ToString(), out TAX);
                decimal.TryParse(drProduct["FEE"].ToString(), out FEE);
            }
            decimal POSITION_QTY = 0;
            decimal.TryParse(drFind["POSITION_QTY"].ToString(), out POSITION_QTY);
            decimal MARKET_PREMIUM = POSITION_QTY * MARKET_PRICE * CONTRACT_SIZE;
            ee.MARKET_PREMIUM = decimal.Parse(MARKET_PREMIUM.ToString("#0"));
            decimal MARKET_TAX = MARKET_PREMIUM * TAX;

            decimal FLOAT_PROFIT = (ee.BS == "B" ? (MARKET_PREMIUM - PREMIUM) : (PREMIUM - MARKET_PREMIUM));
            ee.FLOAT_PROFIT = decimal.Parse(FLOAT_PROFIT.ToString("#0.####"));


            decimal U_FLOAT_PROFIT = FLOAT_PROFIT - (FEE * POSITION_QTY * 2) - MARKET_TAX - IN_TAX;
            ee.U_FLOAT_PROFIT = decimal.Parse(U_FLOAT_PROFIT.ToString("#0.####"));



            decimal INCOME_BALANCE = 0;
            decimal.TryParse(drFind["INCOME_BALANCE"].ToString(), out INCOME_BALANCE);
            ee.INCOME_BALANCE = decimal.Parse(INCOME_BALANCE.ToString("#0.####"));

            decimal U_INCOME_BALANCE = 0;
            decimal.TryParse(drFind["U_INCOME_BALANCE"].ToString(), out U_INCOME_BALANCE);
            ee.U_INCOME_BALANCE = decimal.Parse(U_INCOME_BALANCE.ToString("#0.####"));


            ee.CLOSE_PRICE = drFind["CLOSE_PRICE"].ToString();

            decimal CLOSE_PREMIUM = 0;
            decimal.TryParse(drFind["CLOSE_PREMIUM"].ToString(), out CLOSE_PREMIUM);
            ee.CLOSE_PREMIUM = decimal.Parse(CLOSE_PREMIUM.ToString("#0"));

            decimal CLOSE_PROFIT = 0;
            decimal.TryParse(drFind["CLOSE_PROFIT"].ToString(), out CLOSE_PROFIT);
            ee.CLOSE_PROFIT = decimal.Parse(CLOSE_PROFIT.ToString("#0"));


            decimal B_MATCH_PRICE = 0;
            decimal.TryParse(drFind["B_MATCH_PRICE"].ToString(), out B_MATCH_PRICE);
            ee.B_MATCH_PRICE = decimal.Parse(B_MATCH_PRICE.ToString("#0.####"));


            decimal S_MATCH_PRICE = 0;
            decimal.TryParse(drFind["S_MATCH_PRICE"].ToString(), out S_MATCH_PRICE);
            ee.S_MATCH_PRICE = decimal.Parse(S_MATCH_PRICE.ToString("#0.####"));




            ee.B_MATCH_QTY = drFind["B_MATCH_QTY"].ToString();
            ee.S_MATCH_QTY = drFind["S_MATCH_QTY"].ToString();
            ee.YES_POSITION = drFind["YES_POSITION"].ToString();
            ee.NOW_QTY = drFind["NOW_QTY"].ToString();


            ee.COMTYPE = (int)drFind["COMTYPE"];
            ee.KIND_ID = drFind["KIND_ID"].ToString();
            ee.STRIKE_PRICE = (decimal)drFind["STRIKE_PRICE"];
            ee.CP = drFind["CP"].ToString();
            ee.MONTH = (int)drFind["MONTH"];
            ee.YEAR = (int)drFind["YEAR"];
            obj.raiseReceiveAccount(ee);
        }

        void raiseDetailEvent(string ACTION, DataRow drFind, DetailUIObject obj)
        {
            DetailUIObject.DetailEventArgs ee = new DetailUIObject.DetailEventArgs();
            ee.ACTION = ACTION;
            ee.BROKER_ID = drFind["BROKER_ID"].ToString();
            ee.INVESTORACNO = drFind["INVESTORACNO"].ToString();
            ee.TRADEDATE = drFind["TRADEDATE"].ToString();
            ee.ORDERNO = drFind["ORDERNO"].ToString();
            ee.PRODUCTID = drFind["PRODUCTID"].ToString();

            ee.BS = drFind["BS"].ToString();
            ee.MATCHQTY = drFind["MATCHQTY"].ToString();
            decimal MATCHQTY = 0;
            decimal.TryParse(drFind["MATCHQTY"].ToString(), out MATCHQTY);

            decimal MATCH_PRICE = 0;
            decimal.TryParse(drFind["MATCH_PRICE"].ToString(), out MATCH_PRICE);
            ee.MATCH_PRICE = decimal.Parse(MATCH_PRICE.ToString("#0.####"));


            //改用搜尋成交價
            decimal MARKET_PRICE = 0;
            decimal CONTRACT_SIZE = 0;
            decimal TAX = 0;
            decimal FEE = 0;
            DataRow drProduct = _Product.Rows.Find(new object[] { ee.PRODUCTID });
            if (drProduct != null)
            {
                ee.CLOSE_PRICE = drProduct["CLOSE_PRICE"].ToString();
                ee.MARKET_PRICE = drProduct["MARKET_PRICE"].ToString();
                ee.PRODUCTDESC = drProduct["PRODUCTDESC"].ToString();

                decimal.TryParse(ee.MARKET_PRICE, out MARKET_PRICE);
                decimal.TryParse(drProduct["CONTRACT_SIZE"].ToString(), out CONTRACT_SIZE);
                decimal.TryParse(drProduct["TAX"].ToString(), out TAX);
                decimal.TryParse(drProduct["FEE"].ToString(), out FEE);
            }

            ee.FEE = (FEE * MATCHQTY).ToString();
            decimal PREMIUM = MATCHQTY * MATCH_PRICE * CONTRACT_SIZE;

            decimal MARKET_PREMIUM = MATCHQTY * MARKET_PRICE * CONTRACT_SIZE;
            ee.MARKET_PREMIUM = decimal.Parse(MARKET_PREMIUM.ToString("#0"));
            decimal MARKET_TAX = MARKET_PREMIUM * TAX;
            ee.TAX = (TAX * PREMIUM).ToString();
            decimal FLOAT_PROFIT = (ee.BS == "B" ? (MARKET_PREMIUM - PREMIUM) : (PREMIUM - MARKET_PREMIUM)) - (FEE * MATCHQTY * 2) - MARKET_TAX - (TAX * PREMIUM);
            ee.FLOAT_PROFIT = decimal.Parse(FLOAT_PROFIT.ToString("#0.####"));


            ee.DTRADE = drFind["DTRADE"].ToString();
            ee.MATCHSEQ = drFind["MATCHSEQ"].ToString();

            obj.raiseReceiveDetail(ee);
        }
        INCOME getINCOME(string BS, decimal INPRICE, decimal OUTPRICE, decimal QTY, decimal CONTRACT_SIZE, decimal TAX, decimal FEE)
        {
            decimal IN_PREMIUM = INPRICE * CONTRACT_SIZE;
            decimal OUT_PREMIUM = OUTPRICE * CONTRACT_SIZE;
            decimal IN_TAX = IN_PREMIUM * TAX;
            decimal MARKET_TAX = OUT_PREMIUM * TAX;
            INCOME r = new INCOME();
            r.INCOME_BALANCE = (BS == "B" ? (OUT_PREMIUM - IN_PREMIUM) : (IN_PREMIUM - OUT_PREMIUM));
            r.U_INCOME_BALANCE = r.INCOME_BALANCE - (FEE * QTY * 2) - MARKET_TAX - IN_TAX;
            return r;
        }
        public void registerUIObject()
        {
            try
            {
                MYcls.MatchUIObject ruimatch = new VIPTradingSystem.MYcls.MatchUIObject();
                ruimatch._ReceiveMatch += new MatchUIObject.ReceiveMatchCallback(ruimatch__ReceiveMatch);
                frmMain.mobjDataAgent.objTradeStringHandle.matchUICollection.TryAdd("AccountManager", ruimatch);
            }
            catch (Exception ex)
            {
                MYcls.DataAgent._LM.WriteLog("AccountManagerLog", "registerUIObject:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        public void removeUIObject()
        {
            try
            {
                MatchUIObject objMatch = null;
                frmMain.mobjDataAgent.objTradeStringHandle.matchUICollection.TryRemove("AccountManager", out objMatch);
            }

            catch (Exception ex)
            {
                MYcls.DataAgent._LM.WriteLog("AccountManagerLog", "removeUIObject:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        public struct INCOME
        {
            public decimal INCOME_BALANCE;
            public decimal U_INCOME_BALANCE;
        }
        public void Dispose()
        {
            try
            {
                removeUIObject();
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("AccountManagerLog", "Dispose:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
            GC.SuppressFinalize(this);
        }

    }

    public class FloatUIObject
    {
        public struct Float_EventArgs
        {
            public string BROKER_ID;//分公司
            public string INVESTORACNO;//客戶帳號
            public string PRODUCTID;//商品代碼 
            public string MARKET_PRICE;//市價
            public decimal FLOAT_PROFIT;
            public decimal U_FLOAT_PROFIT;//淨浮損
        }
        public string BROKER_ID;//分公司
        public string INVESTORACNO;//客戶帳號
        public string PRODUCTID;//商品代碼 
        public string MARKET_PRICE;//市價
        public decimal FLOAT_PROFIT;
        public decimal U_FLOAT_PROFIT;//淨浮損
        public delegate
void ReceiveFloatCallback(Float_EventArgs e);
        public event ReceiveFloatCallback _ReceiveFloat;
        public FloatUIObject()
        {
        }
        public void raiseReceiveFloat(Float_EventArgs ee)
        {
            if (_ReceiveFloat != null)
            {
                _ReceiveFloat(ee);
            }
        }
    }

    public class FloatDetailUIObject
    {
        public struct FloatDetail_EventArgs
        {
            public string BROKER_ID;//分公司
            public string INVESTORACNO;//客戶帳號
            public string PRODUCTID;//商品代碼 
            public string MARKET_PRICE;//市價
            public decimal MARKET_PREMIUM;//市值
            public decimal FLOAT_PROFIT;
        }
        public string BROKER_ID;//分公司
        public string INVESTORACNO;//客戶帳號
        public string PRODUCTID;//商品代碼 
        public string MARKET_PRICE;//市價
        public decimal MARKET_PREMIUM;//市值 
        public decimal FLOAT_PROFIT;

        public delegate
void ReceiveFloatDetailCallback(FloatDetail_EventArgs e);
        public event ReceiveFloatDetailCallback _ReceiveFloatDetail;
        public FloatDetailUIObject()
        {
        }
        public void raiseReceiveFloatDetail(FloatDetail_EventArgs ee)
        {
            if (_ReceiveFloatDetail != null)
            {
                _ReceiveFloatDetail(ee);
            }
        }
    }

    public class AccountUIObject
    {
        public struct AccountEventArgs
        {
            public string BROKER_ID;//分公司
            public string INVESTORACNO;//客戶帳號
            public string PRODUCTID;//商品代碼
            public string PRODUCTDESC;//商品名稱
            public string BS;//買賣別
            public string POSITION_QTY;//部位口數
            public decimal POSITION_PRICE;//部位均價
            public string YES_POSITION;//昨日留倉
            public string NOW_QTY;//今日數
            public string MARKET_PRICE;//市價
            public string CLOSE_PRICE;//結算價
            public decimal B_MATCH_PRICE;//今日B均價
            public decimal S_MATCH_PRICE;//今日S均價
            public string B_MATCH_QTY;//今日B
            public string S_MATCH_QTY;//今日S
            public decimal FLOAT_PROFIT;//浮動損益
            public decimal U_FLOAT_PROFIT;//淨浮損
            public decimal INCOME_BALANCE;//平倉損益
            public decimal U_INCOME_BALANCE;//淨損益
            public decimal MARKET_PREMIUM;//市值
            public decimal PREMIUM;//總值
            public decimal CLOSE_PREMIUM;//結算價算總值
            public decimal CLOSE_PROFIT;//結算價算損益 
            public int COMTYPE;//商品種類 0期貨;1選擇權
            public string KIND_ID;//商品類型
            public decimal STRIKE_PRICE;//履約價格
            public string CP;//Call Put
            public int MONTH;//月份
            public int YEAR;//年
        }
        public string BROKER_ID;//分公司
        public string INVESTORACNO;//客戶帳號
        public string PRODUCTID;//商品代碼
        public string PRODUCTDESC;//商品名稱
        public string BS;//買賣別
        public string POSITION_QTY;//部位口數
        public decimal POSITION_PRICE;//部位均價
        public string YES_POSITION;//昨日留倉
        public string NOW_QTY;//今日數
        public string MARKET_PRICE;//市價
        public string CLOSE_PRICE;//結算價
        public decimal B_MATCH_PRICE;//今日B均價
        public decimal S_MATCH_PRICE;//今日S均價
        public string B_MATCH_QTY;//今日B
        public string S_MATCH_QTY;//今日S
        public decimal FLOAT_PROFIT;//浮動損益
        public decimal U_FLOAT_PROFIT;//淨浮損
        public decimal INCOME_BALANCE;//平倉損益
        public decimal U_INCOME_BALANCE;//淨損益
        public decimal MARKET_PREMIUM;//市值
        public decimal PREMIUM;//總值
        public decimal CLOSE_PREMIUM;//結算價算總值
        public decimal CLOSE_PROFIT;//結算價算損益 
        public int COMTYPE;//商品種類 0期貨;1選擇權
        public string KIND_ID;//商品類型
        public decimal STRIKE_PRICE;//履約價格
        public string CP;//Call Put
        public int MONTH;//月份
        public int YEAR;//年
        public delegate
  void ReceiveAccountCallback(AccountEventArgs e);
        public event ReceiveAccountCallback _ReceiveAccount;
        public AccountUIObject()
        {
        }
        public void raiseReceiveAccount(AccountEventArgs ee)
        {

            if (_ReceiveAccount != null)
            {
                _ReceiveAccount(ee);
            }
        }
    }

    public class DetailUIObject
    {
        public struct DetailEventArgs
        {
            public string ACTION;//動作 U:更新/D:刪除
            public string BROKER_ID;//分公司
            public string INVESTORACNO;//客戶帳號
            public string TRADEDATE;//交易日期
            public string ORDERNO;//委託書號
            public string PRODUCTID;//商品代碼
            public string PRODUCTDESC;//商品名稱
            public string BS;//買賣別
            public string MATCHQTY;//成交口數
            public decimal MATCH_PRICE;//成交均價
            public string MARKET_PRICE;//市價
            public string CLOSE_PRICE;//結算價 
            public decimal FLOAT_PROFIT;//浮動損益
            public decimal MARKET_PREMIUM;//市值
            public string TAX;//期交稅 
            public string FEE;//手續費 
            public string DTRADE;//當沖別 
            public string MATCHSEQ;//成交序號 
        }
        public string ACTION;//動作 U:更新/D:刪除
        public string BROKER_ID;//分公司
        public string INVESTORACNO;//客戶帳號
        public string TRADEDATE;//交易日期
        public string ORDERNO;//委託書號
        public string PRODUCTID;//商品代碼
        public string PRODUCTDESC;//商品名稱
        public string BS;//買賣別
        public string MATCHQTY;//成交口數
        public decimal MATCH_PRICE;//成交均價
        public string MARKET_PRICE;//市價
        public string CLOSE_PRICE;//結算價 
        public decimal FLOAT_PROFIT;//浮動損益
        public decimal MARKET_PREMIUM;//市值
        public string TAX;//期交稅 
        public string FEE;//手續費 
        public string DTRADE;//當沖別 
        public string MATCHSEQ;//成交序號 
        public delegate
  void ReceiveDetailCallback(DetailEventArgs e);
        public event ReceiveDetailCallback _ReceiveDetail;
        public DetailUIObject()
        {
        }
        public void raiseReceiveDetail(DetailEventArgs ee)
        {

            if (_ReceiveDetail != null)
            {
                _ReceiveDetail(ee);
            }
        }
    }
}
