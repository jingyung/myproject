﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Windows.Forms;
using System.Collections.Concurrent;
namespace VIPTradingSystem.MYcls
{
    public class TradeStringHandle
    {
        private delegate void displayErrorDelegate(string message);

        private DataAgent mobj_DataAgent;
        private DataSet mds_Master = new DataSet();
        private DataTable mdt_PriceWorkingQty;
        public object syncObj = new object();
        public ConcurrentDictionary<string, ReplyUIObject> replyUICollection = new ConcurrentDictionary<string, ReplyUIObject>();
        public ConcurrentDictionary<string, MatchUIObject> matchUICollection = new ConcurrentDictionary<string, MatchUIObject>();
        /// <summary>

        /// <summary>
        /// 成回委派 v5.0.0.1新增
        /// </summary>
        private delegate void displayMatchDelegate(MatchUIObject e);
        /// <summary>
        /// 成回更新委託口數委派 v5.0.0.1新增
        /// </summary>
        private delegate void displayMatchOrderQtyDelegate(MatchUIObject.OrderQtyEventArgs e);
        /// <summary>
        /// 委回委派 v5.0.0.1新增
        /// </summary>
        private delegate void displayReplyDelegate(ReplyUIObject e, MatchUIObject mee);

        private delegate void displayOrderQtyDelegate(ReplyUIObject e);
        displayMatchOrderQtyDelegate displayMatchOrderQtyHandle;
        displayOrderQtyDelegate displayOrderQtyHandle;
        displayMatchDelegate displayMatchHandle;
        displayReplyDelegate displayReplyHandle;

        void displayReply(ReplyUIObject ee, MatchUIObject mee)
        {
            if (ee.ORDERNO.Trim() == "T401HC")
            {
            }
            if (ee.ORDERKIND == "P")
            {
                _OrderReplyProvider.SetReplyStrategyData(ee, ee.AD);
                _OrderReplyProvider.SetReplyStrategyDataForMain(ee, ee.AD);
            }
            else
            {
                DataRow dr = _OrderReplyProvider.SetReplyData(ee, mee);
                _OrderReplyProvider.SetReplyDataForMain(ee, mee);
                if (dr != null)
                    _MatchTotalProvider.SetWrkQty(ee, dr);
            }
            ReplyUIObject[] objs = replyUICollection.Values.ToArray();
            foreach (ReplyUIObject obj in objs)
            {
                obj.raiseReceiveReply(ee);
            }

            if (mee != null)
            {
                displayMatch(mee);
            }
        }
        void displayMatch(MatchUIObject ee)
        {


            _MatchReplyProvider.SetData(ee);
            _MatchTotalProvider.SetMatchQty(ee);
            MatchUIObject[] objs = matchUICollection.Values.ToArray();
            foreach (MatchUIObject obj in objs)
            {
                obj.raiseReceiveMatch(ee);
            }


        }

        void displayOrderQty(ReplyUIObject ee)
        {
            ReplyUIObject[] objs = replyUICollection.Values.ToArray();
            foreach (ReplyUIObject obj in objs)
            {
                obj.raiseReceiveOrder(ee);
            }

        }
        void displayMatchOrderQty(MatchUIObject.OrderQtyEventArgs ee)
        {
            MatchUIObject[] objs = matchUICollection.Values.ToArray();
            foreach (MatchUIObject obj in objs)
            {
                obj.raiseReceiveOrderQty(ee);
            }


        }
        OrderReplyProvider _OrderReplyProvider;

        public OrderReplyProvider OrderReplyProvider
        {
            get { return _OrderReplyProvider; }
            set { _OrderReplyProvider = value; }
        }
        MatchReplyProvider _MatchReplyProvider;

        public MatchReplyProvider MatchReplyProvider
        {
            get { return _MatchReplyProvider; }
            set { _MatchReplyProvider = value; }
        }

        MatchTotalProvider _MatchTotalProvider;

        public MatchTotalProvider MatchTotalProvider
        {
            get { return _MatchTotalProvider; }
            set { _MatchTotalProvider = value; }
        }
        public TradeStringHandle(DataAgent da)
        {

            _OrderReplyProvider = new OrderReplyProvider();
            _MatchReplyProvider = new MatchReplyProvider();
            _MatchTotalProvider = new MYcls.MatchTotalProvider();
            displayMatchOrderQtyHandle = new displayMatchOrderQtyDelegate(displayMatchOrderQty);
            displayOrderQtyHandle = new displayOrderQtyDelegate(displayOrderQty);
            displayMatchHandle = new displayMatchDelegate(displayMatch);
            displayReplyHandle = new displayReplyDelegate(displayReply);
            mobj_DataAgent = da;
            //mobj_DataAgent.objReplyIntegration.OrderReply.Columns.Add("NoMatchQtyB", typeof(int)).Expression = "IIF( bs ='B',NoMatchQty,0)";//未成交數量
            //mobj_DataAgent.objReplyIntegration.OrderReply.Columns.Add("NoMatchQtyS", typeof(int)).Expression = "IIF( bs ='S',NoMatchQty,0)";//未成交數量
            //mdt_PriceWorkingQty = new DataTable();
            //mdt_PriceWorkingQty.Columns.Add("investorAcno", typeof(string));//客戶帳號
            //mdt_PriceWorkingQty.Columns.Add("BS", typeof(string));//買賣別
            //mdt_PriceWorkingQty.Columns.Add("productId", typeof(string));//商品代碼
            //mdt_PriceWorkingQty.Columns.Add("orderPrice", typeof(decimal));//委託價格

            //mds_Master.Tables.Add(mobj_DataAgent.objReplyIntegration.OrderReply);
            //mds_Master.Tables.Add(mdt_PriceWorkingQty);

            //DataColumn[] dcParent = new DataColumn[] { mdt_PriceWorkingQty.Columns["investorAcno"], mdt_PriceWorkingQty.Columns["bs"], mdt_PriceWorkingQty.Columns["productId"], mdt_PriceWorkingQty.Columns["orderPrice"] };
            //DataColumn[] dcChild = new DataColumn[] { mobj_DataAgent.objReplyIntegration.OrderReply.Columns["investorAcno"], mobj_DataAgent.objReplyIntegration.OrderReply.Columns["bs"], mobj_DataAgent.objReplyIntegration.OrderReply.Columns["productId"], mobj_DataAgent.objReplyIntegration.OrderReply.Columns["orderPrice"] };
            //DataRelation relPriceWorkingQty;
            //relPriceWorkingQty = new DataRelation("OrderReply_PriceWorkingQty", dcParent, dcChild);
            //mds_Master.Relations.Add(relPriceWorkingQty);
            //mdt_PriceWorkingQty.Columns.Add("NoMatchQty", typeof(int)).Expression = "sum(child(OrderReply_PriceWorkingQty).NoMatchQty)";
            //mdt_PriceWorkingQty.PrimaryKey = dcParent;
            //relPriceWorkingQty.ChildKeyConstraint.DeleteRule = Rule.None;

            //mobj_DataAgent.objReplyIntegration.OrderReply.RowChanging += new DataRowChangeEventHandler(OrderReply_RowChanging);
            //mobj_DataAgent.objReplyIntegration.OrderReply.RowChanged += new System.Data.DataRowChangeEventHandler(OrderReply_RowChanged);
            //mobj_DataAgent.objReplyIntegration.MatchDetailReply.RowChanged += new System.Data.DataRowChangeEventHandler(MatchDetailReply_RowChanged);
            mobj_DataAgent.objReplyIntegration.ReceivedReturn += new com.ddsc.BI.F.ReceivedReturnEventHandler(mobj_ReplyIntegration_ReceivedReturn);


        }


        public void ClearData()
        {
            _OrderReplyProvider.ClearData();
            _MatchReplyProvider.ClearData();
            _MatchTotalProvider.ClearData();
        }

        /// <summary>
        /// 收到回報事件 v5.0.0.1新增
        /// </summary>
        void mobj_ReplyIntegration_ReceivedReturn(com.ddsc.BI.F.ReceivedReturnEventArgs e)
        {
            try
            {
                string BeginTime = DateTime.Now.ToString("yyyyMMdd HH:mm:ss.fff");
                if (e.ReceiveAcion != com.ddsc.BI.F.ReceivedAcion.ReceivedOrder
                    && e.ReceiveAcion != com.ddsc.BI.F.ReceivedAcion.ReceivedConnected)
                {
                    string ORDERSTATUS = "";
                    ReplyUIObject ee = new ReplyUIObject();
                    ee.EXECTYPE = e.ReplyObject.Exectype;
                    ee.TRADEDATE = e.ReplyObject.ReplyDr["TRADEDATE"].ToString();
                    ee.ORDERNO = e.ReplyObject.ReplyDr["ORDERNO"].ToString();
                    ee.ORDERTIME = e.ReplyObject.ReplyDr["ORDERTIME"].ToString();
                    ee.BROKERID = e.ReplyObject.ReplyDr["BROKERID"].ToString();
                    ee.INVESTORACNO = e.ReplyObject.ReplyDr["INVESTORACNO"].ToString();
                    ee.SUBACT = e.ReplyObject.ReplyDr["SUBACT"].ToString();
                    ee.BS = e.ReplyObject.ReplyDr["BS"].ToString();
                    ee.PRODUCTKIND = e.ReplyObject.ReplyDr["PRODUCTKIND"].ToString();
                    ee.SECURITYEXCHANGE = e.ReplyObject.ReplyDr["SECURITYEXCHANGE"].ToString();
                    ee.SECURITYTYPE1 = e.ReplyObject.ReplyDr["SECURITYTYPE1"].ToString();
                    ee.SYMBOL1 = e.ReplyObject.ReplyDr["SYMBOL1"].ToString();
                    ee.MATURITYMONTHYEAR1 = e.ReplyObject.ReplyDr["MATURITYMONTHYEAR1"].ToString();
                    ee.PUTORCALL1 = e.ReplyObject.ReplyDr["PUTORCALL1"].ToString();
                    ee.STRIKEPRICE1 = decimal.Parse(e.ReplyObject.ReplyDr["STRIKEPRICE1"].ToString());

                    ee.STRIKEPRICE1 = Decimal.Parse(ee.STRIKEPRICE1.ToString("0.#######"));


                    ee.SIDE1 = e.ReplyObject.ReplyDr["SIDE1"].ToString();
                    ee.SECURITYTYPE2 = e.ReplyObject.ReplyDr["SECURITYTYPE2"].ToString();
                    ee.SYMBOL2 = e.ReplyObject.ReplyDr["SYMBOL2"].ToString();
                    ee.MATURITYMONTHYEAR2 = e.ReplyObject.ReplyDr["MATURITYMONTHYEAR2"].ToString();
                    ee.PUTORCALL2 = e.ReplyObject.ReplyDr["PUTORCALL2"].ToString();
                    ee.STRIKEPRICE2 = decimal.Parse(e.ReplyObject.ReplyDr["STRIKEPRICE2"].ToString());

                    ee.STRIKEPRICE2 = Decimal.Parse(ee.STRIKEPRICE2.ToString("0.#######"));

                    ee.SIDE2 = e.ReplyObject.ReplyDr["SIDE2"].ToString();
                    ee.PRICE = decimal.Parse(e.ReplyObject.ReplyDr["PRICE"].ToString());
                    ee.STOPPRICE = decimal.Parse(e.ReplyObject.ReplyDr["STOPPRICE"].ToString());
                    ee.ORDERQTY = int.Parse(e.ReplyObject.ReplyDr["ORDERQTY"].ToString());
                    ee.MATCHQTY = int.Parse(e.ReplyObject.ReplyDr["MATCHQTY"].ToString());
                    ee.NOMATCHQTY = int.Parse(e.ReplyObject.ReplyDr["NOMATCHQTY"].ToString());
                    ee.DELQTY = int.Parse(e.ReplyObject.ReplyDr["DELQTY"].ToString());
                    ee.STATUSCODE = e.ReplyObject.ReplyDr["STATUSCODE"].ToString();
                    ee.ORDERSTATUS = e.ReplyObject.ReplyDr["ORDERSTATUS"].ToString();
                    ee.CLORDID = e.ReplyObject.ReplyDr["CLORDID"].ToString();
                    ee.OPENCLOSE = e.ReplyObject.ReplyDr["OPENCLOSE"].ToString();
                    ee.TIMEINFORCE = e.ReplyObject.ReplyDr["TIMEINFORCE"].ToString();
                    ee.ORDERTYPE = e.ReplyObject.ReplyDr["ORDERTYPE"].ToString();
                    ee.EXPIREDATE = e.ReplyObject.ReplyDr["EXPIREDATE"].ToString();
                    ee.DTRADE = e.ReplyObject.ReplyDr["DTRADE"].ToString();
                    ee.MDATE = e.ReplyObject.ReplyDr["MDATE"].ToString();
                    ee.SEQ = e.ReplyObject.ReplyDr["SEQ"].ToString();
                    ee.SOURCECODE = e.ReplyObject.ReplyDr["SOURCECODE"].ToString();
                    ee.IP = e.ReplyObject.ReplyDr["IP"].ToString();
                    ee.ORDERID = e.ReplyObject.ReplyDr["ORDERID"].ToString();
                    ee.TARGETID = e.ReplyObject.ReplyDr["TARGETID"].ToString();
                    ee.ACCOUNT = e.ReplyObject.ReplyDr["ACCOUNT"].ToString();
                    ee.EXECTRANSTYPE = e.ReplyObject.ExecTransType;
                    ee.KEEPDATA = e.ReplyObject.ReplyDr["Data"].ToString();
                    string Data = e.ReplyObject.ReplyDr["Data"].ToString();

                    string OrderKind = "";
                    string OrderTag = "";
                    string AE = "";
                    string AD = "";
                    string pseq = "";
                    //KeepData
                    //AD=Time Slice|2|500|20161004172843726|20161004182843000|35000|5|0^          代表委託母單
                    //AD=Time Slice|2|5|20161006114551410|20161006114851000|34000|1|0^pseq=A000C0002^ 代表委託出去的單子 子單
                    foreach (string f in ee.KEEPDATA.Split('^'))
                    {
                        if (f.IndexOf("OrderKind") > -1)
                        {
                            OrderKind = f.Split('=')[1];
                        }
                        if (f.IndexOf("AD") > -1)
                        {
                            AD = f.Split('=')[1];
                        }
                        if (f.IndexOf("pseq") > -1)
                        {
                            pseq = f.Split('=')[1];
                        }
                        if (f.IndexOf("OrderTag") > -1)
                        {
                            OrderTag = f.Split('=')[1];
                        }
                        if (f.IndexOf("AE") > -1)
                        {
                            AE = f.Split('=')[1];
                        }

                    }
                    ee.ORDERTAG = OrderTag;
                    ee.AE = AE;
                    ee.PSEQ = pseq;
                    MatchUIObject mee = null;
                    if ((e.ReplyObject.Exectype == "1" || e.ReplyObject.Exectype == "2"))
                    {

                        mee = new MatchUIObject();

                        mee.TRADEDATE = e.ReplyObject.ReplyMatchDr["TRADEDATE"].ToString();
                        mee.MATCHTIME = e.ReplyObject.ReplyMatchDr["MATCHTIME"].ToString();
                        mee.BROKERID = e.ReplyObject.ReplyMatchDr["BROKERID"].ToString();
                        mee.INVESTORACNO = e.ReplyObject.ReplyMatchDr["INVESTORACNO"].ToString();
                        mee.SUBACT = e.ReplyObject.ReplyMatchDr["SUBACT"].ToString();
                        mee.ORDERNO = e.ReplyObject.ReplyMatchDr["ORDERNO"].ToString();
                        mee.PRODUCTKIND = e.ReplyObject.ReplyMatchDr["PRODUCTKIND"].ToString();
                        mee.BS = e.ReplyObject.ReplyMatchDr["BS"].ToString();
                        mee.SECURITYEXCHANGE = e.ReplyObject.ReplyMatchDr["SECURITYEXCHANGE"].ToString();
                        mee.SECURITYTYPE1 = e.ReplyObject.ReplyMatchDr["SECURITYTYPE1"].ToString();
                        mee.SYMBOL1 = e.ReplyObject.ReplyMatchDr["SYMBOL1"].ToString();
                        mee.MATURITYMONTHYEAR1 = e.ReplyObject.ReplyMatchDr["MATURITYMONTHYEAR1"].ToString();
                        mee.PUTORCALL1 = e.ReplyObject.ReplyMatchDr["PUTORCALL1"].ToString();
                        mee.STRIKEPRICE1 = decimal.Parse(e.ReplyObject.ReplyMatchDr["STRIKEPRICE1"].ToString());

                        mee.STRIKEPRICE1 = Decimal.Parse(mee.STRIKEPRICE1.ToString("0.#######"));
                        mee.SIDE1 = e.ReplyObject.ReplyMatchDr["SIDE1"].ToString();
                        mee.PRICE1 = decimal.Parse(e.ReplyObject.ReplyMatchDr["PRICE1"].ToString());
                        mee.SECURITYTYPE2 = e.ReplyObject.ReplyMatchDr["SECURITYTYPE2"].ToString();
                        mee.SYMBOL2 = e.ReplyObject.ReplyMatchDr["SYMBOL2"].ToString();
                        mee.MATURITYMONTHYEAR2 = e.ReplyObject.ReplyMatchDr["MATURITYMONTHYEAR2"].ToString();
                        mee.PUTORCALL2 = e.ReplyObject.ReplyMatchDr["PUTORCALL2"].ToString();
                        mee.STRIKEPRICE2 = decimal.Parse(e.ReplyObject.ReplyMatchDr["STRIKEPRICE2"].ToString());
                        mee.STRIKEPRICE2 = Decimal.Parse(mee.STRIKEPRICE2.ToString("0.#######"));
                        mee.SIDE2 = e.ReplyObject.ReplyMatchDr["SIDE2"].ToString();
                        mee.PRICE2 = decimal.Parse(e.ReplyObject.ReplyMatchDr["PRICE2"].ToString());
                        mee.PRICE2 = Decimal.Parse(mee.PRICE2.ToString("0.#######"));
                        mee.MATCHPRICE = decimal.Parse(e.ReplyObject.ReplyMatchDr["MATCHPRICE"].ToString());
                        mee.MATCHPRICE = Decimal.Parse(mee.MATCHPRICE.ToString("0.#######"));
                        mee.MATCHQTY = int.Parse(e.ReplyObject.ReplyMatchDr["MATCHQTY"].ToString());
                        mee.CLORDID = e.ReplyObject.ReplyMatchDr["CLORDID"].ToString();
                        mee.OPENCLOSE = e.ReplyObject.ReplyMatchDr["OPENCLOSE"].ToString();
                        mee.EXECID = e.ReplyObject.ReplyMatchDr["EXECID"].ToString();
                        mee.MDATE = e.ReplyObject.ReplyMatchDr["MDATE"].ToString();
                        mee.ORDERID = e.ReplyObject.ReplyMatchDr["ORDERID"].ToString();
                        mee.TARGETID = e.ReplyObject.ReplyMatchDr["TARGETID"].ToString();
                        mee.ACCOUNT = e.ReplyObject.ReplyMatchDr["ACCOUNT"].ToString();

                        mee.ORDERTAG = OrderTag;
                        mee.AE = AE;
                        mee.PSEQ = pseq;
                        mee.EXECTRANSTYPE = e.ReplyObject.ExecTransType;
                        mee.EXECREFID = e.ReplyObject.ReplyMatchDr["EXECREFID"].ToString();
                        if (e.ReplyObject.Exectype == "1")
                            mee.STATE = "P";
                        else mee.STATE = "F";
                    }




                    mobj_DataAgent.objControlManager.V_frmMain.Invoke(displayReplyHandle, new object[] { ee, mee });




                    DataAgent._LM.WriteLog("TradeStringHandleReply", "reply:" + BeginTime + e.ReplyObject.ReplyDr["investorAcno"].ToString()
                        + e.ReplyObject.ReplyDr["seq"].ToString()
                        + e.ReplyObject.ReplyDr["CLORDID"].ToString() + e.ReplyObject.ReplyDr["Data"].ToString());

                }
                return;
                if (e.ReceiveAcion == com.ddsc.BI.F.ReceivedAcion.ReceivedReply
                    && (e.ReplyObject.Exectype == "1" || e.ReplyObject.Exectype == "2"))
                {
                    MatchUIObject ee = new MatchUIObject();

                    ee.TRADEDATE = e.ReplyObject.ReplyMatchDr["TRADEDATE"].ToString();
                    ee.MATCHTIME = e.ReplyObject.ReplyMatchDr["MATCHTIME"].ToString();
                    ee.BROKERID = e.ReplyObject.ReplyMatchDr["BROKERID"].ToString();
                    ee.INVESTORACNO = e.ReplyObject.ReplyMatchDr["INVESTORACNO"].ToString();
                    ee.SUBACT = e.ReplyObject.ReplyMatchDr["SUBACT"].ToString();
                    ee.ORDERNO = e.ReplyObject.ReplyMatchDr["ORDERNO"].ToString();
                    ee.PRODUCTKIND = e.ReplyObject.ReplyMatchDr["PRODUCTKIND"].ToString();
                    ee.BS = e.ReplyObject.ReplyMatchDr["BS"].ToString();
                    ee.SECURITYEXCHANGE = e.ReplyObject.ReplyMatchDr["SECURITYEXCHANGE"].ToString();
                    ee.SECURITYTYPE1 = e.ReplyObject.ReplyMatchDr["SECURITYTYPE1"].ToString();
                    ee.SYMBOL1 = e.ReplyObject.ReplyMatchDr["SYMBOL1"].ToString();
                    ee.MATURITYMONTHYEAR1 = e.ReplyObject.ReplyMatchDr["MATURITYMONTHYEAR1"].ToString();
                    ee.PUTORCALL1 = e.ReplyObject.ReplyMatchDr["PUTORCALL1"].ToString();
                    ee.STRIKEPRICE1 = decimal.Parse(e.ReplyObject.ReplyMatchDr["STRIKEPRICE1"].ToString());
                    ee.SIDE1 = e.ReplyObject.ReplyMatchDr["SIDE1"].ToString();
                    ee.PRICE1 = decimal.Parse(e.ReplyObject.ReplyMatchDr["PRICE1"].ToString());
                    ee.SECURITYTYPE2 = e.ReplyObject.ReplyMatchDr["SECURITYTYPE2"].ToString();
                    ee.SYMBOL2 = e.ReplyObject.ReplyMatchDr["SYMBOL2"].ToString();
                    ee.MATURITYMONTHYEAR2 = e.ReplyObject.ReplyMatchDr["MATURITYMONTHYEAR2"].ToString();
                    ee.PUTORCALL2 = e.ReplyObject.ReplyMatchDr["PUTORCALL2"].ToString();
                    ee.STRIKEPRICE2 = decimal.Parse(e.ReplyObject.ReplyMatchDr["STRIKEPRICE2"].ToString());
                    ee.SIDE2 = e.ReplyObject.ReplyMatchDr["SIDE2"].ToString();
                    ee.PRICE2 = decimal.Parse(e.ReplyObject.ReplyMatchDr["PRICE2"].ToString());
                    ee.MATCHPRICE = decimal.Parse(e.ReplyObject.ReplyMatchDr["MATCHPRICE"].ToString());
                    ee.MATCHQTY = int.Parse(e.ReplyObject.ReplyMatchDr["MATCHQTY"].ToString());
                    ee.CLORDID = e.ReplyObject.ReplyMatchDr["CLORDID"].ToString();
                    ee.OPENCLOSE = e.ReplyObject.ReplyMatchDr["OPENCLOSE"].ToString();
                    ee.EXECID = e.ReplyObject.ReplyMatchDr["EXECID"].ToString();
                    ee.MDATE = e.ReplyObject.ReplyMatchDr["MDATE"].ToString();
                    ee.ORDERID = e.ReplyObject.ReplyMatchDr["ORDERID"].ToString();
                    ee.TARGETID = e.ReplyObject.ReplyMatchDr["TARGETID"].ToString();
                    ee.ACCOUNT = e.ReplyObject.ReplyMatchDr["ACCOUNT"].ToString();
                    ee.EXECTRANSTYPE = e.ReplyObject.ExecTransType;
                    ee.EXECREFID = e.ReplyObject.ReplyMatchDr["EXECREFID"].ToString();

                    mobj_DataAgent.objControlManager.V_frmMain.Invoke(displayMatchHandle, new object[] { ee });
                    //foreach (MatchUIObject obj in matchUICollection.Values)
                    //{

                    //    mobj_DataAgent.objControlManager.V_frmMain.Invoke(new displayMatchDelegate(obj.raiseReceiveMatch), new object[] { ee });

                    //}

                    frmMain.mobjDataAgent.objControlManager.PlayMatchReplyPlayerSound();
                    DataAgent._LM.WriteLog("TradeStringHandleReply", "match:" + BeginTime
                        + e.ReplyObject.ReplyMatchDr["investorAcno"].ToString()
                        + e.ReplyObject.ReplyMatchDr["CLORDID"].ToString()
                        + e.ReplyObject.ReplyMatchDr["EXECID"].ToString());
                }
                if ((e.ReceiveAcion == com.ddsc.BI.F.ReceivedAcion.ReceivedReply) && (e.ReplyObject.ReplyDr["RawStatus"].ToString().Contains("E") && e.ReplyObject.ReplyDr["RawStatus"].ToString().Contains("2")))
                {
                    int orderqty = int.Parse(e.ReplyObject.ReplyDr["orderQty"].ToString());  //委託數量
                    MatchUIObject.OrderQtyEventArgs ee = new MatchUIObject.OrderQtyEventArgs();


                    ee.orderNo = e.ReplyObject.ReplyDr["orderNo"].ToString();//委託書號
                    ee.tradedate = e.ReplyObject.ReplyDr["tradedate"].ToString();
                    ee.OrderQty = int.Parse(e.ReplyObject.ReplyDr["orderQty"].ToString());  //委託數量
                    ee.FCMNO = e.ReplyObject.ReplyDr["BROKERID"].ToString();//期貨商代號
                    ee.investorAcno = e.ReplyObject.ReplyDr["investorAcno"].ToString();//下單帳號
                    mobj_DataAgent.objControlManager.V_frmMain.Invoke(displayMatchOrderQtyHandle, new object[] { ee });


                    //foreach (MatchUIObject obj in matchUICollection.Values)
                    //{
                    //    mobj_DataAgent.objControlManager.V_frmMain.Invoke(new displayOrderQtyDelegate(obj.raiseReceiveOrderQty), new object[] { ee });
                    //}


                }

            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("TradeStringHandleLog", "mobj_ReplyIntegration_ReceivedReturn:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());

            }

        }
        private void showErrorMessage(string message)
        {

            VIPTradingSystem.MYcls.CommonFunction.ShowMessageBox(null, "", "委託失敗!");

        }
        //void OrderReply_RowChanging(object sender, DataRowChangeEventArgs e)
        //{

        //    if (e.Action.ToString() == "Add")
        //    {
        //        if (mdt_PriceWorkingQty.Rows.Find(new object[] { e.Row["investorAcno"].ToString(), e.Row["bs"].ToString(), e.Row["productId"].ToString().Trim(), e.Row["orderprice"].ToString() }) == null)
        //        {
        //            DataRow drPrice = mdt_PriceWorkingQty.NewRow();
        //            drPrice["investorAcno"] = e.Row["investorAcno"].ToString();
        //            drPrice["bs"] = e.Row["bs"];
        //            drPrice["productId"] = e.Row["productId"];
        //            drPrice["orderprice"] = e.Row["orderprice"];
        //            mdt_PriceWorkingQty.Rows.Add(drPrice);

        //        }

        //    }
        //}

        //void MatchDetailReply_RowChanged(object sender, System.Data.DataRowChangeEventArgs e)
        //{

        //}

        //void OrderReply_RowChanged(object sender, System.Data.DataRowChangeEventArgs e)
        //{
        //    try
        //    {
        //        foreach (ReplyUIObject obj in replyUICollection.Values)
        //        {
        //            obj.TradeDate = e.Row["TradeDate"].ToString();//委託日期
        //            obj.orderNo = e.Row["orderNo"].ToString();//委託書號
        //            obj.orderTime = e.Row["orderTime"].ToString();//委託時間
        //            obj.investorAcno = e.Row["investorAcno"].ToString();//客戶帳號
        //            obj.BS = e.Row["BS"].ToString();//買賣別
        //            obj.productId = e.Row["productId"].ToString();//商品代碼
        //            obj.orderPrice = decimal.Parse(e.Row["orderPrice"].ToString());//委託價格
        //            obj.orderQty = int.Parse(e.Row["orderQty"].ToString());  //委託數量
        //            obj.matchQty = int.Parse(e.Row["matchQty"].ToString());//成交數量
        //            obj.NoMatchQty = int.Parse(e.Row["NoMatchQty"].ToString());//未成交數量
        //            obj.DelQty = int.Parse(e.Row["DelQty"].ToString());//已刪除數量
        //            obj.OrderStatus = e.Row["OrderStatus"].ToString();//委託狀態
        //            obj.Statuscode = e.Row["Statuscode"].ToString();//委託狀態碼
        //            obj.netWorkId = e.Row["netWorkId"].ToString();//網路流水序號
        //            obj.productKind = e.Row["productKind"].ToString();//商品種類
        //            obj.OpenOffSetFlag = e.Row["OpenOffSetFlag"].ToString();//新平倉碼
        //            obj.OrderCondition = e.Row["OrderCondition"].ToString();//委託條件

        //            obj.mdate = e.Row["mdate"].ToString();//異動時間
        //            obj.seq = e.Row["seq"].ToString();

        //            obj.dtrade = e.Row["dtrade"].ToString();//當沖碼
        //            obj.multipleKind = e.Row["multipleKind"].ToString();//複式商品類型
        //            obj.multipleName = e.Row["multipleName"].ToString();//複式商品名稱
        //            obj.SourceCode = e.Row["SourceCode"].ToString();//下單別
        //            obj.FCMNO = e.Row["FCMNO"].ToString();//期貨商代號
        //            obj.ORDERTYPE = e.Row["ORDERTYPE"].ToString();//委託方式
        //            obj.AE = e.Row["AE"].ToString();//AE
        //            obj.Note = e.Row["Note"].ToString();//Note
        //            obj.ODRMEDIA = e.Row["ODRMEDIA"].ToString();//ODRMEDIA
        //            obj.raiseReceiveReply();
        //        }

        //        if (e.Action.ToString() == "Change")
        //        {
        //            string ee = "";
        //            mobj_DataAgent.objReplyIntegration.OrderReply.Rows.Remove(e.Row);

        //        }
        //        else
        //        {
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        DataAgent._LM.WriteLog("TradeStringHandleLog", "OrderReply_RowChanged:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());

        //    }
        //}
        //public void deleteAllOrder(string company, string actno)
        //{
        //    try
        //    {
        //        //if (!frmMain.UserConfigs.EnabledOrder)
        //        //{
        //        //    System.Windows.Forms.MessageBox.Show("無權限下單!");
        //        //    return;
        //        //}
        //        //int int_INVESTORACNO = 0;
        //        //if (!int.TryParse(actno, out int_INVESTORACNO))
        //        //{
        //        //    System.Windows.Forms.MessageBox.Show("客戶帳號格式不正確!");
        //        //    return;
        //        //}

        //        //if (!mobj_DataAgent.objTradeSocketClient.Socket.Connected)
        //        //{
        //        //    System.Windows.Forms.MessageBox.Show("交易連線斷線!");
        //        //    return;
        //        //}
        //        //string BeginTime = DateTime.Now.ToString("yyyyMMdd HH:mm:ss.fff");


        //        //Byte[] bb = frmMain.mobjDataAgent.objReplyIntegration.CombindDeleteAll(frmMain.UserConfigs.UserId, "", "", "", systemconfigs.ODRSRC, "0", company, actno, "", "*ALL", frmMain.UserConfigs.AENO, "G");//V1.0.0.36 Added by peter on 20140320
        //        //string seq = com.ddsc.BI.SockClientParserFunction.getDDSCRawDataNewSeq(bb);
        //        //string new_seq = seq; 

        //        //string strsenddata = Encoding.Default.GetString(bb);
        //        //DataAgent._LM.WriteLog("TradeStringHandleOrder", BeginTime + new_seq + "  " + strsenddata);

        //        //bb = com.ddsc.BI.SockClientParserFunction.EncodeData(bb);
        //        //frmMain.mobjDataAgent.objTradeSocketClient.Send(bb);
        //        string strCondition = "";
        //        if (company != "")
        //            strCondition += " BROKERID='" + company + "' and";
        //        if (actno != "")
        //            strCondition += " investorAcno='" + actno + "' and";
        //        if (strCondition != "")
        //            strCondition = strCondition.TrimEnd(new char[] { 'a', 'n', 'd' });
        //        foreach (DataRow dr in mobj_DataAgent.objReplyIntegration.OrderReply.Select(strCondition))
        //        {
        //            int NoMatchQty = int.Parse(dr["NoMatchQty"].ToString());
        //            if (NoMatchQty > 0)
        //            {
        //                sendOrder(
        //            "", "0", dr["productkind"].ToString()
        //                 , OrderType.Cancel
        //                 , dr["BROKERID"].ToString()
        //                 , dr["orderNo"].ToString()
        //                 , dr["investorAcno"].ToString()
        //                 , "", dr["productId"].ToString()
        //                 , dr["bs"].ToString()
        //                 , "L"
        //                 , decimal.Parse(decimal.Parse(dr["orderprice"].ToString()).ToString("#0.####"))
        //                 , NoMatchQty
        //                 , dr["OrderCondition"].ToString()
        //                 , ""
        //                 , dr["networkid"].ToString()
        //                 , ""
        //                   , "", dr["WEBCODE"].ToString()
        //                 );

        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        DataAgent._LM.WriteLog("TradeStringHandleLog", "deleteAllOrder:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());

        //    }
        //}
        public string sendOrder(string PRODUCTKIND, string EXECTYPE, string BROKERID
                , string ORDERNO
                , string INVESTORACNO
                , string SUBACT
                , string SECURITYEXCHANGE
                , string SECURITYTYPE1
                , string SYMBOL1
                , string MATURITYMONTHYEAR1
                , string PUTORCALL1
                , decimal STRIKEPRICE1
                , string SIDE1
                , string SECURITYTYPE2
                , string SYMBOL2
                , string MATURITYMONTHYEAR2
                , string PUTORCALL2
                , decimal STRIKEPRICE2
                , string SIDE2
                , string BS
                , string ORDERTYPE
                , decimal PRICE
                , decimal STOPPRICE
                , int ORDERQTY
                , string TIMEINFORCE
                , string OPENCLOSE
            , string DTRADE
            , string CLORDID
            , string EXPIREDATE
              , string SOURCECODE, string KEEPDATA)
        {
            string seq = "";
            try
            {
                BROKERID = "F008000";
                int int_INVESTORACNO = 0;
                //if (!int.TryParse(INVESTORACNO, out int_INVESTORACNO))
                //{

                //    VIPTradingSystem.MYcls.CommonFunction.ShowMessageBox(null, "", "客戶帳號格式不正確!");
                //    return "";
                //}

                if (!mobj_DataAgent.mobj_TradeAPClient.Socket.Connected)
                {
                    VIPTradingSystem.MYcls.CommonFunction.ShowMessageBox(null, "", "交易連線斷線!");

                    return "";
                }

                //檢查可否下市價單
                if (EXECTYPE == "0" && CommonFunction.getMK_FlagForACTNO(INVESTORACNO) != "Y" && ORDERTYPE == "M")
                {
                    VIPTradingSystem.MYcls.CommonFunction.ShowMessageBox(null, "", "交易帳號不可下市價單!");

                    return "";
                }

                string BeginTime = com.ddsc.tool.Date.NowTime().ToString("yyyyMMdd HH:mm:ss.fff");
                string data = "";

                byte[] bb = mobj_DataAgent.objReplyIntegration.Combine(
                       PRODUCTKIND
, EXECTYPE
, BROKERID
, ORDERNO
, INVESTORACNO
, SUBACT
, SECURITYEXCHANGE
, SECURITYTYPE1
, SYMBOL1
, MATURITYMONTHYEAR1
, PUTORCALL1
, STRIKEPRICE1.ToString()
, SIDE1
, SECURITYTYPE2
, SYMBOL2
, MATURITYMONTHYEAR2
, PUTORCALL2
, STRIKEPRICE2.ToString()
, SIDE2
, BS
, ORDERTYPE
, PRICE
, STOPPRICE
, ORDERQTY
, TIMEINFORCE
, OPENCLOSE
, DTRADE
, CLORDID
, EXPIREDATE
                       , "l", KEEPDATA
                       , out seq
                       , out data);

                DataAgent._LM.WriteLog("TradeStringHandleOrder", BeginTime + seq + "  " + data);


                ReplyUIObject ee = new ReplyUIObject();
                ee.TRADEDATE = DateTime.Now.ToString("yyyyMMdd");
                ee.ORDERTIME = DateTime.Now.ToString("HHmmssfff");
                ee.ORDERNO = ORDERNO;
                ee.BROKERID = BROKERID;
                ee.INVESTORACNO = INVESTORACNO;
                ee.SUBACT = SUBACT;
                ee.BS = BS;
                ee.PRODUCTKIND = PRODUCTKIND;
                ee.SECURITYEXCHANGE = SECURITYEXCHANGE;
                ee.SECURITYTYPE1 = SECURITYTYPE1;
                ee.SYMBOL1 = SYMBOL1;
                ee.MATURITYMONTHYEAR1 = MATURITYMONTHYEAR1;
                ee.PUTORCALL1 = PUTORCALL1;
                ee.STRIKEPRICE1 = STRIKEPRICE1;
                ee.SIDE1 = SIDE1;
                ee.SECURITYTYPE2 = SECURITYTYPE2;
                ee.SYMBOL2 = SYMBOL2;
                ee.MATURITYMONTHYEAR2 = MATURITYMONTHYEAR2;
                ee.PUTORCALL2 = PUTORCALL2;
                ee.STRIKEPRICE2 = STRIKEPRICE2;
                ee.SIDE2 = SIDE2;
                ee.PRICE = PRICE;
                ee.STOPPRICE = STOPPRICE;
                ee.ORDERQTY = ORDERQTY;

                ee.CLORDID = CLORDID;
                ee.OPENCLOSE = OPENCLOSE;
                ee.TIMEINFORCE = TIMEINFORCE;
                ee.ORDERTYPE = ORDERTYPE;
                ee.EXPIREDATE = EXPIREDATE;
                ee.DTRADE = DTRADE;
                ee.ORDERKIND = "1";
                ee.SOURCECODE = SOURCECODE;

                if (EXECTYPE == VIPTradingSystem.MYcls.OrderType.Order)
                {
                    ee.EXECTYPE = "0";
                    ee.STATUSCODE = com.ddsc.BI.F.FReplyIntegration.START;
                    ee.ORDERSTATUS = com.ddsc.BI.F.FReplyIntegration.ORDERING;
                    ee.SEQ = seq;
                }
                else
                {
                    if (EXECTYPE == VIPTradingSystem.MYcls.OrderType.Replace)
                    {
                        ee.EXECTYPE = "5";
                        ee.STATUSCODE = com.ddsc.BI.F.FReplyIntegration.START;
                        ee.ORDERSTATUS = com.ddsc.BI.F.FReplyIntegration.ORDERING;
                    }
                    else if (EXECTYPE == VIPTradingSystem.MYcls.OrderType.Cancel)
                    {
                        ee.EXECTYPE = "4";
                        ee.STATUSCODE = com.ddsc.BI.F.FReplyIntegration.START;
                        ee.ORDERSTATUS = com.ddsc.BI.F.FReplyIntegration.ORDERING;
                    }

                    ee.SEQ = "";
                }


                mobj_DataAgent.objControlManager.V_frmMain.Invoke(displayOrderQtyHandle, new object[] { ee });


                _OrderReplyProvider.SetOrderData(ee);

                foreach (ReplyUIObject obj in replyUICollection.Values)
                {
                    //mobj_DataAgent.objControlManager.V_frmMain.Invoke(new displayReplyDelegate(obj.raiseReceiveOrder), new object[] { ee });
                    obj.raiseReceiveOrder(ee);

                }

                bb = com.ddsc.BI.F.SockClientParserFunction.EncodeData(bb);
                mobj_DataAgent.objTradeSocketClient.Send(bb);
                // 新增記錄轉換前下單內容


            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("TradeStringHandleLog", "sendOrder:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());

            }
            return seq;
        }




        public string sendOrderStrategy(string PRODUCTKIND, string EXECTYPE, string BROKERID
              , string ORDERNO
              , string INVESTORACNO
              , string SUBACT
              , string SECURITYEXCHANGE
              , string SECURITYTYPE1
              , string SYMBOL1
              , string MATURITYMONTHYEAR1
              , string PUTORCALL1
              , decimal STRIKEPRICE1
              , string SIDE1
              , string SECURITYTYPE2
              , string SYMBOL2
              , string MATURITYMONTHYEAR2
              , string PUTORCALL2
              , decimal STRIKEPRICE2
              , string SIDE2
              , string BS
              , string ORDERTYPE
              , decimal PRICE
              , decimal STOPPRICE
              , int ORDERQTY
              , string TIMEINFORCE
              , string OPENCLOSE
          , string DTRADE
          , string CLORDID
          , string EXPIREDATE
            , string SOURCECODE, string KeepData)
        {
            string seq = "";
            try
            {
                BROKERID = "F008000";
                int int_INVESTORACNO = 0;
                //if (!int.TryParse(INVESTORACNO, out int_INVESTORACNO))
                //{

                //    VIPTradingSystem.MYcls.CommonFunction.ShowMessageBox(null, "", "客戶帳號格式不正確!");
                //    return "";
                //}

                if (!mobj_DataAgent.mobj_TradeAPClient.Socket.Connected)
                {
                    VIPTradingSystem.MYcls.CommonFunction.ShowMessageBox(null, "", "交易連線斷線!");

                    return "";
                }

                //檢查可否下市價單
                if (EXECTYPE == "0" && CommonFunction.getMK_FlagForACTNO(INVESTORACNO) != "Y" && ORDERTYPE == "M")
                {
                    VIPTradingSystem.MYcls.CommonFunction.ShowMessageBox(null, "", "交易帳號不可下市價單!");

                    return "";
                }

                string BeginTime = com.ddsc.tool.Date.NowTime().ToString("yyyyMMdd HH:mm:ss.fff");
                string data = "";

                byte[] bb = mobj_DataAgent.objReplyIntegration.Combine(
                       PRODUCTKIND
, EXECTYPE
, BROKERID
, ORDERNO
, INVESTORACNO
, SUBACT
, SECURITYEXCHANGE
, SECURITYTYPE1
, SYMBOL1
, MATURITYMONTHYEAR1
, PUTORCALL1
, STRIKEPRICE1.ToString()
, SIDE1
, SECURITYTYPE2
, SYMBOL2
, MATURITYMONTHYEAR2
, PUTORCALL2
, STRIKEPRICE2.ToString()
, SIDE2
, BS
, ORDERTYPE
, PRICE
, STOPPRICE
, ORDERQTY
, TIMEINFORCE
, OPENCLOSE
, DTRADE
, CLORDID
, EXPIREDATE
                       , "l", KeepData
                       , out seq
                       , out data);



                bb[0] = com.ddsc.BI.F.SockClientParserFunction.DDSCSocketHead.ProgramTrade;
                DataAgent._LM.WriteLog("TradeStringHandleOrder", BeginTime + seq + "  " + data + " " + KeepData);


                ReplyUIObject ee = new ReplyUIObject();
                ee.ORDERKIND = "P";
                ee.ORDERNO = ORDERNO;
                ee.BROKERID = BROKERID;
                ee.INVESTORACNO = INVESTORACNO;
                ee.SUBACT = SUBACT;
                ee.BS = BS;
                ee.PRODUCTKIND = PRODUCTKIND;
                ee.SECURITYEXCHANGE = SECURITYEXCHANGE;
                ee.SECURITYTYPE1 = SECURITYTYPE1;
                ee.SYMBOL1 = SYMBOL1;
                ee.MATURITYMONTHYEAR1 = MATURITYMONTHYEAR1;
                ee.PUTORCALL1 = PUTORCALL1;
                ee.STRIKEPRICE1 = STRIKEPRICE1;
                ee.SIDE1 = SIDE1;
                ee.SECURITYTYPE2 = SECURITYTYPE2;
                ee.SYMBOL2 = SYMBOL2;
                ee.MATURITYMONTHYEAR2 = MATURITYMONTHYEAR2;
                ee.PUTORCALL2 = PUTORCALL2;
                ee.STRIKEPRICE2 = STRIKEPRICE2;
                ee.SIDE2 = SIDE2;
                ee.PRICE = PRICE;
                ee.STOPPRICE = STOPPRICE;
                ee.ORDERQTY = ORDERQTY;

                ee.CLORDID = CLORDID;
                ee.OPENCLOSE = OPENCLOSE;
                ee.TIMEINFORCE = TIMEINFORCE;
                ee.ORDERTYPE = ORDERTYPE;
                ee.EXPIREDATE = EXPIREDATE;
                ee.DTRADE = DTRADE;

                ee.SOURCECODE = SOURCECODE;

                if (EXECTYPE == VIPTradingSystem.MYcls.OrderType.Order)
                {
                    ee.EXECTYPE = "0";
                    ee.STATUSCODE = com.ddsc.BI.F.FReplyIntegration.START;
                    ee.ORDERSTATUS = com.ddsc.BI.F.FReplyIntegration.ORDERING;
                    ee.SEQ = seq;
                }
                else
                {
                    if (EXECTYPE == VIPTradingSystem.MYcls.OrderType.Replace)
                    {
                        ee.EXECTYPE = "5";
                        ee.STATUSCODE = com.ddsc.BI.F.FReplyIntegration.START;
                        ee.ORDERSTATUS = com.ddsc.BI.F.FReplyIntegration.ORDERING;
                    }
                    else if (EXECTYPE == VIPTradingSystem.MYcls.OrderType.Cancel)
                    {
                        ee.EXECTYPE = "4";
                        ee.STATUSCODE = com.ddsc.BI.F.FReplyIntegration.START;
                        ee.ORDERSTATUS = com.ddsc.BI.F.FReplyIntegration.ORDERING;
                    }

                    ee.SEQ = "";
                }


                //  mobj_DataAgent.objControlManager.V_frmMain.Invoke(displayOrderQtyHandle, new object[] { ee });
                ee.PSEQ = ee.SEQ;


                string OrderKind = KeepData.Split('^')[0];
                string OrderTag = KeepData.Split('^')[1];
                string AE = KeepData.Split('^')[2];
                string AD = KeepData.Split('^')[3];
                //KeepData

                ////OrderKind=P^OrderTag=^AE=^AD=Time Slice|2|500|20161004172843726|20161004182843000|35000|5|0^

                AD = AD.Split('=')[1];



                _OrderReplyProvider.SetOrderStrategyData(ee, AD);

                //foreach (ReplyUIObject obj in replyUICollection.Values)
                //{
                //    //mobj_DataAgent.objControlManager.V_frmMain.Invoke(new displayReplyDelegate(obj.raiseReceiveOrder), new object[] { ee });
                //    obj.raiseReceiveOrder(ee);

                //}

                bb = com.ddsc.BI.F.SockClientParserFunction.EncodeData(bb);
                mobj_DataAgent.objTradeSocketClient.Send(bb);
                // 新增記錄轉換前下單內容


            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("TradeStringHandleLog", "sendOrder:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());

            }
            return seq;
        }


        public void ParseProgramTradeReply(byte[] buffer)
        {
            try
            {

                ReplyUIObject UIObject = StrategyProvider.Parse2ReplyUIObject(buffer);
                mobj_DataAgent.objControlManager.V_frmMain.Invoke(displayReplyHandle, new object[] { UIObject, null });
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("TradeStringHandleLog", "sendOrder:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());

            }
        }

    }


}
