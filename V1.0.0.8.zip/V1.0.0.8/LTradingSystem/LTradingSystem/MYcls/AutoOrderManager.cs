﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
namespace VIPTradingSystem.MYcls
{
    public class AutoOrderManager
    {
        public DataTable mdt_InfoCondition;
        public DataTable mdt_ReplyCondition;
        public DataTable mdt_ActiveCondition;
        public DataTable mdt_TimeCondition;
        public DataTable mdt_ConditionMaster; 
        private DataTable mdt_Type;
        private DataTable mdt_ReplyKind;
        private DataTable mdt_InfoKind;
        private DataTable mdt_ActiveKind; 
        public int mint_maxGroupCondition = 5;
        private System.Windows.Forms.Timer mtmr_TimeConditionControl;
        public Dictionary<string, AutoOrderConditionItem> _AutoOrderConditionItems = new Dictionary<string, AutoOrderConditionItem>();
        private Dictionary<string, System.Windows.Forms.Timer> mobj_timercollection = new Dictionary<string, System.Windows.Forms.Timer>();
 
        /// <summary>
        /// 成交回報處理完畢傳出值
        /// </summary>
        public struct MatchReplyParseredValue
        {
            public string seq;
            public string ProductId;
            public string orderNo;
            public string MatchQty;
            public string MatchPrice;
            public string NowMatchQtyB;
            public string NowMatchQtyS;
            public string TodayEnd;
            public string LiquidationPL;
            public string NowOTQtyB;
            public string NowOTQtyS;
            public string AvgCostB;
            public string AvgCostS;
            public string PriceDiffB;
            public string PriceDiffS;

        }
        /// <summary>
        /// 委託回報處理完畢傳出值
        /// </summary>
        public struct OrderReplyParseredValue
        {
            public string seq;
            public string ProductId;
            public string orderNo;
            public string workingQty;
            public string DeleteQty;
            public string NowOrderQtyB;
            public string NowOrderQtyS;
        }

 

        public enum InfoKind
        {
            /// <summary>
            /// 成交價
            /// </summary>
            MatchPrice = 0,
            /// <summary>
            /// 成交量
            /// </summary>
            MatchQuantity = 1,
            /// <summary>
            /// 成交總量
            /// </summary>
            MatchTotalQty = 2,
            /// <summary>
            /// 成交賣量
            /// </summary>
            MatchBuyCnt = 3,
            /// <summary>
            /// 成交買量
            /// </summary>
            MatchSellCnt = 4,
            /// <summary>
            /// 最佳買價1
            /// </summary>
            BP1 = 5,
            /// <summary>
            /// 最佳買價2
            /// </summary>
            BP2 = 6,
            /// <summary>
            /// 最佳買價3
            /// </summary>
            BP3 = 7,
            /// <summary>
            /// 最佳買價4
            /// </summary>
            BP4 = 8,
            /// <summary>
            /// 最佳買價5
            /// </summary>
            BP5 = 9,
            /// <summary>
            /// 最佳買量1
            /// </summary>
            BQ1 = 10,
            /// <summary>
            /// 最佳買量2
            /// </summary>
            BQ2 = 11,
            /// <summary>
            /// 最佳買量3
            /// </summary>
            BQ3 = 12,
            /// <summary>
            /// 最佳買量4
            /// </summary>
            BQ4 = 13,
            /// <summary>
            /// 最佳買量5
            /// </summary>
            BQ5 = 14,
            /// <summary>
            /// 最佳賣價1
            /// </summary>
            SP1 = 15,
            /// <summary>
            /// 最佳賣價2
            /// </summary>
            SP2 = 16,
            /// <summary>
            /// 最佳賣價3
            /// </summary>
            SP3 = 17,
            /// <summary>
            /// 最佳賣價4
            /// </summary>
            SP4 = 18,
            /// <summary>
            /// 最佳賣價5
            /// </summary>
            SP5 = 19,
            /// <summary>
            /// 最佳賣量1
            /// </summary>
            SQ1 = 20,
            /// <summary>
            /// 最佳賣量2
            /// </summary>
            SQ2 = 21,
            /// <summary>
            /// 最佳賣量3
            /// </summary>
            SQ3 = 22,
            /// <summary>
            /// 最佳賣量4
            /// </summary>
            SQ4 = 23,
            /// <summary>
            /// 最佳賣量5
            /// </summary>
            SQ5 = 24,
            /// <summary>
            /// 價差買
            /// </summary>
            priceDiffB = 25,
            /// <summary>
            /// 價差賣
            /// </summary>
            priceDiffS = 26,
            /// <summary>
            /// 浮動損益
            /// </summary>
            pricePL = 27,
            /// <summary>
            /// 最佳委賣總量
            /// </summary>
            totalSQ = 28,
            /// <summary>
            /// 最佳委買總量
            /// </summary>
            totalBQ = 29
        }
        public enum ReplyKind
        {
            /// <summary>
            /// 委買總量
            /// </summary>
            NowOrderQtyB = 0,
            /// <summary>
            /// 委賣總量
            /// </summary>
            NowOrderQtyS = 1,
            /// <summary>
            /// 該筆Working口數
            /// </summary>
            workingQty = 2,
            /// <summary>
            /// 該筆成交口數
            /// </summary>
            matchQty = 3,
            /// <summary>
            /// 該筆成交價格
            /// </summary>
            matchPrice = 4,
            /// <summary>
            /// 成交買進數量
            /// </summary>
            NowMatchQtyB = 5,
            /// <summary>
            /// 成交賣出數量
            /// </summary>
            NowMatchQtyS = 6,
            /// <summary>
            /// 今日數
            /// </summary>
            TodayEnd = 7,
            /// <summary>
            /// 未平倉買進
            /// </summary>
            NowOTQtyB = 8,
            /// <summary>
            /// 未平倉賣出
            /// </summary>
            NowOTQtyS = 9,
            /// <summary>
            /// 價差買
            /// </summary>
            PriceDiffB = 10,
            /// <summary>
            /// 價差賣
            /// </summary>
            PriceDiffS = 11,
            /// <summary>
            /// 買進平均成本
            /// </summary>
            AvgCostB = 12,
            /// <summary>
            /// 賣出平均成本
            /// </summary>
            AvgCostS = 13,
            /// <summary>
            /// 平倉損益
            /// </summary>
            LiquidationPL = 14,
             /// <summary>
            /// 刪除口數    from 3.0.0.8
            /// </summary>
            DeleteQty=15
        }
        public enum status
        {
            /// <summary>
            /// 未啟動
            /// </summary>
            disabled = 0,
            /// <summary>
            /// 觸發
            /// </summary>
            trigger = 1,
            /// <summary>
            /// 暫停
            /// </summary>
            pause = 2,
            /// <summary>
            /// 啟動
            /// </summary>
            enabled = 3
        }
        public enum ActiveKind
        {
            /// <summary>
            /// 移動買進停損
            /// </summary>
            StopBuyOrder = 0,
            /// <summary>
            /// 移動賣出停損
            /// </summary>
            StopSellOrder = 1
        }
        public enum codition
        {
            and = 0,
            or = 1

        }
        public enum type
        {
            /// <summary>
            /// 行情
            /// </summary>
            Info = 0,
 

        }
        private bool mbol_Enabled = false;
        public bool Enabled
        {
            get
            {
                return mbol_Enabled;
            }
            set
            {
                mbol_Enabled = value;
            }
        }
        public CommonFunction.ListBoxItem[] getEqualitys()
        {
            CommonFunction.ListBoxItem[] o = new CommonFunction.ListBoxItem[2];
            o[0] = new CommonFunction.ListBoxItem("0", ">=");
            o[1] = new CommonFunction.ListBoxItem("1", "<=");



            return o;
        }
        public CommonFunction.ListBoxItem[] getCoditions()
        {
            CommonFunction.ListBoxItem[] o = new CommonFunction.ListBoxItem[Enum.GetNames(typeof(codition)).Length];
            int i = 0;
            foreach (string s in Enum.GetNames(typeof(codition)))
            {
                o[i] = new CommonFunction.ListBoxItem(Enum.Parse(typeof(codition), s).GetHashCode().ToString(), s);
                i++;
            }


            return o;
        }
        public CommonFunction.ListBoxItem[] getTypes()
        {
            CommonFunction.ListBoxItem[] o = new CommonFunction.ListBoxItem[mdt_Type.Rows.Count];

            int i = 0;
            foreach (DataRow dr in mdt_Type.Rows)
            {
                o[i] = new CommonFunction.ListBoxItem(dr["Type"].ToString(), dr["desc"].ToString());


                i++;
            }
            return o;
        }
        public CommonFunction.ListBoxItem[] getInfoKinds()
        {
            CommonFunction.ListBoxItem[] o = new CommonFunction.ListBoxItem[mdt_InfoKind.Rows.Count];

            int i = 0;
            foreach (DataRow dr in mdt_InfoKind.Rows)
            {

                o[i] = new CommonFunction.ListBoxItem(dr["kind"].ToString(), dr["desc"].ToString());

                i++;
            }
            return o;
        }
        private void initActiveCondition()
        {

            mdt_ActiveCondition = new DataTable("ActiveCondition");
            mdt_ActiveCondition.Columns.Add("ID");//條件ID
            mdt_ActiveCondition.Columns.Add("GroupId");//順序ID
            mdt_ActiveCondition.Columns.Add("status");//狀態.0.為處理中1.已觸發2.暫停.3.未啟用
            mdt_ActiveCondition.Columns.Add("FUNID");//條件細項內容
            mdt_ActiveCondition.Columns.Add("BEGINTIME");//起始時間
            mdt_ActiveCondition.Columns.Add("ENDTIME");   //結束時間
            mdt_ActiveCondition.Columns.Add("Kind");//類型1.2

            mdt_ActiveCondition.Columns.Add("productid");//值
            mdt_ActiveCondition.Columns.Add("Condition");//0.>=.1.<=
            mdt_ActiveCondition.Columns.Add("value", typeof(decimal));//值
            mdt_ActiveCondition.Columns.Add("tick", typeof(decimal));//tick
            mdt_ActiveCondition.Columns.Add("triggervalue");//觸發值
            DataColumn[] dc = new DataColumn[] { mdt_ActiveCondition.Columns["ID"], mdt_ActiveCondition.Columns["GroupId"], mdt_ActiveCondition.Columns["FUNID"] };

            mdt_ActiveCondition.PrimaryKey = dc;
            mdt_ActiveCondition.RowChanged += new DataRowChangeEventHandler(FuntionStatus_Changed);
            mdt_ActiveCondition.RowDeleting += new DataRowChangeEventHandler(Funtion_RowDeleting);
        }

        private void initInfoCondition()
        {
            mdt_InfoCondition = new DataTable("InfoCondition");
            mdt_InfoCondition.Columns.Add("ID");//條件ID
            mdt_InfoCondition.Columns.Add("GroupId");//順序ID
            mdt_InfoCondition.Columns.Add("status");//狀態.0.為處理中1.已觸發2.暫停.3.未啟用
            mdt_InfoCondition.Columns.Add("FUNID");//條件細項內容
            mdt_InfoCondition.Columns.Add("BEGINTIME");//起始時間
            mdt_InfoCondition.Columns.Add("ENDTIME");   //結束時間
            mdt_InfoCondition.Columns.Add("Kind");//行情1-5 6
            mdt_InfoCondition.Columns.Add("productid");//值
            mdt_InfoCondition.Columns.Add("Condition");//0.>=.1.<=
            mdt_InfoCondition.Columns.Add("value", typeof(decimal));//值
            mdt_InfoCondition.Columns.Add("triggervalue");//觸發值
            DataColumn[] dc = new DataColumn[] { mdt_InfoCondition.Columns["ID"], mdt_InfoCondition.Columns["GroupId"], mdt_InfoCondition.Columns["FUNID"] };

            mdt_InfoCondition.PrimaryKey = dc;
            mdt_InfoCondition.RowChanged += new DataRowChangeEventHandler(FuntionStatus_Changed);
            mdt_InfoCondition.RowDeleting += new DataRowChangeEventHandler(Funtion_RowDeleting);
        }
        private void initReplyCondition()
        {
            mdt_ReplyCondition = new DataTable("ReplyCondition");
            mdt_ReplyCondition.Columns.Add("ID");//條件ID
            mdt_ReplyCondition.Columns.Add("GroupId");//順序ID
            mdt_ReplyCondition.Columns.Add("status");//狀態.0.為處理中1.已觸發2.暫停.3.未啟用
            mdt_ReplyCondition.Columns.Add("FUNID");//條件細項內容
            mdt_ReplyCondition.Columns.Add("BEGINTIME");//起始時間
            mdt_ReplyCondition.Columns.Add("ENDTIME");   //結束時間
            mdt_ReplyCondition.Columns.Add("Kind");//類型1.2
            mdt_ReplyCondition.Columns.Add("seq");
            mdt_ReplyCondition.Columns.Add("orderno");
            mdt_ReplyCondition.Columns.Add("productid");//值
            mdt_ReplyCondition.Columns.Add("Condition");//0.>=.1.<=
            mdt_ReplyCondition.Columns.Add("value",typeof(decimal));//值
            mdt_ReplyCondition.Columns.Add("triggervalue");//觸發值
            mdt_ReplyCondition.Columns.Add("price");//傳出值.例如:該筆成交價

            DataColumn[] dc = new DataColumn[] { mdt_ReplyCondition.Columns["ID"], mdt_ReplyCondition.Columns["GroupId"], mdt_ReplyCondition.Columns["FUNID"] };
            mdt_ReplyCondition.PrimaryKey = dc;
            mdt_ReplyCondition.RowChanged += new DataRowChangeEventHandler(FuntionStatus_Changed);
            mdt_ReplyCondition.RowDeleting += new DataRowChangeEventHandler(Funtion_RowDeleting);
        }
        private void initTimeCondition()
        {

            mdt_TimeCondition = new DataTable("TimeCondition");
            mdt_TimeCondition.Columns.Add("ID");//條件ID
            mdt_TimeCondition.Columns.Add("GroupId");//順序ID
            mdt_TimeCondition.Columns.Add("status");//狀態.0.為處理中1.已觸發2.暫停.3.未啟用
            mdt_TimeCondition.Columns.Add("FUNID");//條件細項內容
            mdt_TimeCondition.Columns.Add("BEGINTIME");//起始時間
            mdt_TimeCondition.Columns.Add("ENDTIME");   //結束時間
            mdt_TimeCondition.Columns.Add("Interval");
            mdt_TimeCondition.Columns.Add("count");//觸發次數,**設定0為連續
            mdt_TimeCondition.Columns.Add("runTimes");//已執行次數
            mdt_TimeCondition.Columns["runTimes"].DefaultValue = "0";
            DataColumn[] dc = new DataColumn[] { mdt_TimeCondition.Columns["ID"], mdt_TimeCondition.Columns["GroupId"], mdt_TimeCondition.Columns["FUNID"] };
            mdt_TimeCondition.PrimaryKey = dc;
            mdt_TimeCondition.RowChanged += new DataRowChangeEventHandler(FuntionStatus_Changed);
            mdt_TimeCondition.RowDeleting += new DataRowChangeEventHandler(Funtion_RowDeleting);
        
        }
        private void initConditionMaster()
        {
            mdt_ConditionMaster = new DataTable();
            mdt_ConditionMaster.Columns.Add("ID");//條件ID
            mdt_ConditionMaster.Columns.Add("SEQ");//條件順序
            mdt_ConditionMaster.Columns.Add("GroupId");//條件順序ID
            mdt_ConditionMaster.Columns.Add("status");//狀態.0.為處理中1.已觸發2.暫停.3.未啟用
            for (int i = 1; i <= mint_maxGroupCondition; i++)
            {
                mdt_ConditionMaster.Columns.Add("FUN" + i.ToString());
                mdt_ConditionMaster.Columns.Add("CDN" + i.ToString());
            }


            DataColumn[] dc = new DataColumn[] { mdt_ConditionMaster.Columns["ID"], mdt_ConditionMaster.Columns["GroupId"] };
            mdt_ConditionMaster.PrimaryKey = dc;

            mdt_ConditionMaster.RowChanged += new DataRowChangeEventHandler(ConditionStatus_Changed);
            mdt_ConditionMaster.RowDeleting += new DataRowChangeEventHandler(Condition_RowDeleting);
        }

 
        private void addSetType(int type, string desc)
        {
            DataRow drNewType = mdt_Type.NewRow();
            drNewType["type"] = type;
            drNewType["desc"] = desc;
            mdt_Type.Rows.Add(drNewType);
        }
        private void addSetInfoKind(int type, string desc)
        {
            DataRow drNewType = mdt_InfoKind.NewRow();
            drNewType["kind"] = type;
            drNewType["desc"] = desc;
            mdt_InfoKind.Rows.Add(drNewType);
        }
 
        public AutoOrderManager()
        {
           
            try
            {
                initInfoCondition();
                initReplyCondition();
                initActiveCondition();
                initTimeCondition();
                initConditionMaster();

                mdt_Type = new DataTable();
                mdt_Type.Columns.Add("type", typeof(int));
                mdt_Type.Columns.Add("desc");


                mdt_InfoKind = new DataTable();
                mdt_InfoKind.Columns.Add("kind");
                mdt_InfoKind.Columns.Add("desc");

                mtmr_TimeConditionControl = new System.Windows.Forms.Timer();
                mtmr_TimeConditionControl.Interval = 1000;
                mtmr_TimeConditionControl.Tick += new EventHandler(mtmr_TimeConditionControl_Tick);
                mtmr_TimeConditionControl.Start();
            
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("AutoOrderManager", ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        private void mtmr_TimeConditionControl_Tick(object sender, EventArgs e)
        {
            try
            {
                //啟動時間條件
                DataRow[] find = mdt_TimeCondition.Select(" BEGINTIME<='" + DateTime.Now.ToString("HHmmss") + "' and ENDTIME>='" + DateTime.Now.ToString("HHmmss") + "' and status='" + status.enabled.GetHashCode() + "'  and (count='0'or (count<>'0' and runtimes<count ))");

                foreach (DataRow dr in find)
                {
                    string id = dr["id"].ToString() + "@" + dr["groupid"].ToString() + "@" + dr["funid"].ToString();
                    //判斷如果開啟過timer就不啟動timer
                    if (!mobj_timercollection.ContainsKey(id))
                    {

                        System.Windows.Forms.Timer obj = new System.Windows.Forms.Timer();

                        obj.Interval = int.Parse(dr["Interval"].ToString());
                        obj.Tick += new EventHandler(obj_Tick);
                        obj.Tag = id;
                        obj.Start();
                        mobj_timercollection.Add(id, obj);
                    }
                }
                //結束時間條件
                if (mobj_timercollection.Count > 0)
                {
                    find = mdt_TimeCondition.Select(" ENDTIME<'" + DateTime.Now.ToString("HHmmss") + "' and( status='" + status.enabled.GetHashCode() + "' or status='" + status.trigger.GetHashCode() + "' )");

                    foreach (DataRow dr in find)
                    {
                        string id = dr["id"].ToString() + "@" + dr["groupid"].ToString() + "@" + dr["funid"].ToString();
                        if (mobj_timercollection.ContainsKey(id))
                        {
                            System.Windows.Forms.Timer obj = mobj_timercollection[id];

                            obj.Stop();
                            mobj_timercollection.Remove(id);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("AutoOrderManager", ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }

        }

        private void obj_Tick(object sender, EventArgs e)
        {
            try
            {
                System.Windows.Forms.Timer obj = (System.Windows.Forms.Timer)sender;
                if (mdt_TimeCondition.Rows.Find(obj.Tag.ToString().Split('@'))["count"].ToString() != "0" && (mdt_TimeCondition.Rows.Find(obj.Tag.ToString().Split('@'))["runTimes"].ToString() == mdt_TimeCondition.Rows.Find(obj.Tag.ToString().Split('@'))["count"].ToString()))
                {
                    obj.Stop();

                }
                else
                {
                    mdt_TimeCondition.Rows.Find(obj.Tag.ToString().Split('@')).BeginEdit();
                    mdt_TimeCondition.Rows.Find(obj.Tag.ToString().Split('@'))["runTimes"] = (int.Parse(mdt_TimeCondition.Rows.Find(obj.Tag.ToString().Split('@'))["runTimes"].ToString()) + 1).ToString();
                    mdt_TimeCondition.Rows.Find(obj.Tag.ToString().Split('@'))["status"] = status.trigger.GetHashCode(); ;
                    mdt_TimeCondition.Rows.Find(obj.Tag.ToString().Split('@')).EndEdit();
                }
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("AutoOrderManager", ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }


        public void raiseInfoCondition(string strData)
        {
            try
            {
                //判斷是否啟動
                if (mbol_Enabled)
                {
                    if (strData.Substring(0, 1) == "2" || strData.Substring(0, 1) == "5")
                    {
                        //add by  samantha 20090721 用@轉成欄位陣列做使用
                        string[] arrData = strData.Substring(2, strData.Length - 2).Split('@');
                        string COMMODITYID = arrData[0].TrimEnd();

                        string strMatchTime = "";
                        string strMatchPrice = "";
                        string strMatchBuyCnt = "";
                        string strMatchSellCnt = "";
                        string strMatchQuantity = "";
                        string strMatchTotalQty = "";

                        string BP1 = "";
                        string BP2 = "";
                        string BP3 = "";
                        string BP4 = "";
                        string BP5 = "";
                        string BQ1 = "";
                        string BQ2 = "";
                        string BQ3 = "";
                        string BQ4 = "";
                        string BQ5 = "";
                        string SP1 = "";
                        string SP2 = "";
                        string SP3 = "";
                        string SP4 = "";
                        string SP5 = "";
                        string SQ1 = "";
                        string SQ2 = "";
                        string SQ3 = "";
                        string SQ4 = "";
                        string SQ5 = "";



                        if (strData.Substring(1, 1).Trim() == "1")
                        {

                            //add by  samantha 20090721 簡化行情資料修改,使用陣列方式取欄位
                            strMatchTime = arrData[1];
                            strMatchPrice = arrData[2];
                            strMatchQuantity = arrData[3];
                            strMatchTotalQty = arrData[4];
                            strMatchBuyCnt = arrData[5];
                            strMatchSellCnt = arrData[6];

                            //判斷成交價是否有條件設定符合                    
                            updateInfoConditionStatus(COMMODITYID, InfoKind.MatchPrice, strMatchPrice);
                            //判斷成交數量是否有條件設定符合
                            updateInfoConditionStatus(COMMODITYID, InfoKind.MatchQuantity, strMatchQuantity);
                            //判斷成交總量是否有條件設定符合
                            updateInfoConditionStatus(COMMODITYID, InfoKind.MatchTotalQty, strMatchTotalQty);
                            //判斷成交買量是否有條件設定符合
                            updateInfoConditionStatus(COMMODITYID, InfoKind.MatchBuyCnt, strMatchBuyCnt);
                            //判斷成交賣量是否有條件設定符合
                            updateInfoConditionStatus(COMMODITYID, InfoKind.MatchSellCnt, strMatchSellCnt);


                            if (strMatchPrice != "")
                            {
                                strMatchPrice = strMatchPrice.Replace(",", "");
                                //賣出移動停損,用買進時進場價為基準點.抓最高價:目前行情>Value則更新value值
                                DataRow[] find = mdt_ActiveCondition.Select("productid='" + COMMODITYID + "' and BEGINTIME<='" + DateTime.Now.ToString("HHmmss") + "' and ENDTIME>='" + DateTime.Now.ToString("HHmmss") + "' and status='" + status.enabled.GetHashCode() + "'  and kind='" + ActiveKind.StopSellOrder.GetHashCode() + "'  and value<" + strMatchPrice);
                                foreach (DataRow dr in find)
                                {
                                    dr["value"] = strMatchPrice;

                                }
                                //買進移動停損,用賣出時進場價為基準點.抓最低價:目前行情>Value則更新value值
                                find = mdt_ActiveCondition.Select("productid='" + COMMODITYID + "' and BEGINTIME<='" + DateTime.Now.ToString("HHmmss") + "' and ENDTIME>='" + DateTime.Now.ToString("HHmmss") + "' and status='" + status.enabled.GetHashCode() + "'  and kind='" + ActiveKind.StopBuyOrder.GetHashCode() + "'  and value>" + strMatchPrice);
                                foreach (DataRow dr in find)
                                {
                                    dr["value"] = strMatchPrice;

                                }


                                //判斷目前成交價使否符合賣出移動停損設定
                                find = mdt_ActiveCondition.Select("productid='" + COMMODITYID + "' and BEGINTIME<='" + DateTime.Now.ToString("HHmmss") + "' and ENDTIME>='" + DateTime.Now.ToString("HHmmss") + "' and status='" + status.enabled.GetHashCode() + "'  and kind='" + ActiveKind.StopSellOrder.GetHashCode() + "'  and value-tick>=" + strMatchPrice);
                                foreach (DataRow dr in find)
                                {
                                    dr.BeginEdit();
                                    dr["status"] = status.trigger.GetHashCode();
                                    dr["triggervalue"] = strMatchPrice;
                                    dr.EndEdit();

                                }
                                //判斷目前成交價使否符合買進移動停損設定
                                find = mdt_ActiveCondition.Select("productid='" + COMMODITYID + "' and BEGINTIME<= '" + DateTime.Now.ToString("HHmmss") + "'  and ENDTIME>= '" + DateTime.Now.ToString("HHmmss") + "' and status='" + status.enabled.GetHashCode() + "'  and kind='" + ActiveKind.StopBuyOrder.GetHashCode() + "'  and value+tick<=" + strMatchPrice);
                                foreach (DataRow dr in find)
                                {
                                    dr.BeginEdit();
                                    dr["status"] = status.trigger.GetHashCode();
                                    dr["triggervalue"] = strMatchPrice;
                                    dr.EndEdit();
                                }
                            }
                        }
                        else if (strData.Substring(1, 1).Trim() == "2")
                        {

                            //add by  samantha 20090721 簡化行情資料修改,使用陣列方式取欄位
                            BP1 = arrData[1];
                            BP2 = arrData[3];
                            BP3 = arrData[5];
                            BP4 = arrData[7];
                            BP5 = arrData[9];
                            BQ1 = arrData[2];
                            BQ2 = arrData[4];
                            BQ3 = arrData[6];
                            BQ4 = arrData[8];
                            BQ5 = arrData[10];
                            SP1 = arrData[11];
                            SP2 = arrData[13];
                            SP3 = arrData[15];
                            SP4 = arrData[17];
                            SP5 = arrData[19];
                            SQ1 = arrData[12];
                            SQ2 = arrData[14];
                            SQ3 = arrData[16];
                            SQ4 = arrData[18];
                            SQ5 = arrData[20];

                            //判斷最佳買價1是否有條件設定符合                    
                            updateInfoConditionStatus(COMMODITYID, InfoKind.BP1, BP1);
                            //判斷最佳買價2是否有條件設定符合                    
                            updateInfoConditionStatus(COMMODITYID, InfoKind.BP2, BP2);
                            //判斷最佳買價3是否有條件設定符合                    
                            updateInfoConditionStatus(COMMODITYID, InfoKind.BP3, BP3);
                            //判斷最佳買價4是否有條件設定符合                    
                            updateInfoConditionStatus(COMMODITYID, InfoKind.BP4, BP4);
                            //判斷最佳買價5是否有條件設定符合                    
                            updateInfoConditionStatus(COMMODITYID, InfoKind.BP5, BP5);

                            //判斷最佳買量1是否有條件設定符合                    
                            updateInfoConditionStatus(COMMODITYID, InfoKind.BQ1, BQ1);
                            //判斷最佳買量2是否有條件設定符合                    
                            updateInfoConditionStatus(COMMODITYID, InfoKind.BQ2, BQ2);
                            //判斷最佳買量3是否有條件設定符合                    
                            updateInfoConditionStatus(COMMODITYID, InfoKind.BQ3, BQ3);
                            //判斷最佳買量4是否有條件設定符合                    
                            updateInfoConditionStatus(COMMODITYID, InfoKind.BQ4, BQ4);
                            //判斷最佳買量5是否有條件設定符合                    
                            updateInfoConditionStatus(COMMODITYID, InfoKind.BQ5, BQ5);


                            //判斷最佳賣價1是否有條件設定符合                    
                            updateInfoConditionStatus(COMMODITYID, InfoKind.SP1, SP1);
                            //判斷最佳賣價2是否有條件設定符合                    
                            updateInfoConditionStatus(COMMODITYID, InfoKind.SP2, SP2);
                            //判斷最佳賣價3是否有條件設定符合                    
                            updateInfoConditionStatus(COMMODITYID, InfoKind.SP3, SP3);
                            //判斷最佳賣價4是否有條件設定符合                    
                            updateInfoConditionStatus(COMMODITYID, InfoKind.SP4, SP4);
                            //判斷最佳賣價5是否有條件設定符合                    
                            updateInfoConditionStatus(COMMODITYID, InfoKind.SP5, SP5);

                            //判斷最佳賣量1是否有條件設定符合                    
                            updateInfoConditionStatus(COMMODITYID, InfoKind.SQ1, SQ1);
                            //判斷最佳賣量2是否有條件設定符合                    
                            updateInfoConditionStatus(COMMODITYID, InfoKind.SQ2, SQ2);
                            //判斷最佳賣量3是否有條件設定符合                    
                            updateInfoConditionStatus(COMMODITYID, InfoKind.SQ3, SQ3);
                            //判斷最佳賣量4是否有條件設定符合                    
                            updateInfoConditionStatus(COMMODITYID, InfoKind.SQ4, SQ4);
                            //判斷最佳賣量5是否有條件設定符合                    
                            updateInfoConditionStatus(COMMODITYID, InfoKind.SQ5, SQ5);

                            //判斷市場最佳買量總和
                            updateInfoConditionStatus(COMMODITYID, InfoKind.totalBQ, (int.Parse(BQ1) + int.Parse(BQ2) + int.Parse(BQ3) + int.Parse(BQ4) + int.Parse(BQ5)).ToString());
                            //判斷市場最佳賣量總和
                            updateInfoConditionStatus(COMMODITYID, InfoKind.totalSQ, (int.Parse(SQ1) + int.Parse(SQ2) + int.Parse(SQ3) + int.Parse(SQ4) + int.Parse(SQ5)).ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("AutoOrderManager", ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        public void raiseAccoutInfoCondition(string strData)
        {
            try
            {
                //判斷是否啟動
                if (mbol_Enabled)
                {
                    string productid = strData.Split('@')[0];
                    string priceDiffB = strData.Split('@')[1];
                    string priceDiffS = strData.Split('@')[2];
                    string pricePL = strData.Split('@')[3];

                    //判斷價差買是否有條件設定符合
                    updateInfoConditionStatus(productid, InfoKind.priceDiffB, priceDiffB);
                    //判斷價差賣是否有條件設定符合
                    updateInfoConditionStatus(productid, InfoKind.priceDiffS, priceDiffS);
                    //判斷浮動損益是否有條件設定符合
                    updateInfoConditionStatus(productid, InfoKind.pricePL, pricePL);
                }
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("AutoOrderManager", ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        private void updateInfoConditionStatus(string productid, InfoKind kind, string value)
        {
            try
            {
                if (value != "")
                {
                    value = value.Replace(",", "");
                    //>=
                    DataRow[] find = mdt_InfoCondition.Select("productid='" + productid + "' and  BEGINTIME<= '" + DateTime.Now.ToString("HHmmss") + "'  and ENDTIME>= '" + DateTime.Now.ToString("HHmmss") + "' and kind='" + kind.GetHashCode() + "' and status='" + status.enabled.GetHashCode() + "' and Condition='0' and value>=" + value);
                    foreach (DataRow dr in find)
                    {
                        dr.BeginEdit();
                        dr["status"] = status.trigger.GetHashCode();
                        dr["triggervalue"] = value;
                        dr.EndEdit();
                    }
                    //<=
                    find = mdt_InfoCondition.Select("productid='" + productid + "' and  BEGINTIME<= '" + DateTime.Now.ToString("HHmmss") + "'  and ENDTIME>= '" + DateTime.Now.ToString("HHmmss") + "' and kind='" + kind.GetHashCode() + "'and status='" + status.enabled.GetHashCode() + "' and Condition='1' and value<=" + value);
                    foreach (DataRow dr in find)
                    {
                        dr.BeginEdit();
                        dr["status"] = status.trigger.GetHashCode();
                        dr["triggervalue"] = value;
                        dr.EndEdit();
                    }
                }
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("AutoOrderManager", ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        public void raiseOrderReplyCondition(OrderReplyParseredValue objvalue)
        {
            try
            {

                //判斷是否啟動
                if (mbol_Enabled)
                {
                    //判斷委買總量是否有條件設定符合
                    updateReplyConditionStatus(objvalue.ProductId, ReplyKind.NowOrderQtyB, objvalue.NowOrderQtyB);
                    //判斷委賣總量是否有條件設定符合
                    updateReplyConditionStatus(objvalue.ProductId, ReplyKind.NowOrderQtyS, objvalue.NowOrderQtyS);
                    //判斷woking口數是否有條件設定符合
                    updateReplyConditionStatus(objvalue.orderNo, objvalue.ProductId, ReplyKind.workingQty, objvalue.workingQty);
                    //判斷woking口數是否有條件設定符合
                    updateReplyConditionStatusBySeq(objvalue.seq, objvalue.ProductId, ReplyKind.workingQty, objvalue.workingQty);

                    //判刪除口數是否有條件設定符合
                    updateReplyConditionStatusBySeq(objvalue.seq, objvalue.ProductId, ReplyKind.DeleteQty, objvalue.DeleteQty);

                }
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("AutoOrderManager", ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        public void raiseMatchReplyCondition(MatchReplyParseredValue objvalue)
        {
            try
            {
                //判斷是否啟動
                if (mbol_Enabled)
                {

                    //判斷該筆成交量是否有條件設定符合
                    updateReplyConditionStatus(objvalue.orderNo, objvalue.ProductId, ReplyKind.matchQty, objvalue.MatchQty, objvalue.MatchPrice);
                    //判斷該筆成交價是否有條件設定符合
                    updateReplyConditionStatus(objvalue.orderNo, objvalue.ProductId, ReplyKind.matchPrice, objvalue.MatchPrice, objvalue.MatchQty);
                    //判斷該筆成交量是否有條件設定符合
                    updateReplyConditionStatusBySeq(objvalue.seq, objvalue.ProductId, ReplyKind.matchQty, objvalue.MatchQty, objvalue.MatchPrice);
                    //判斷該筆成交價是否有條件設定符合
                    updateReplyConditionStatusBySeq(objvalue.seq, objvalue.ProductId, ReplyKind.matchPrice, objvalue.MatchPrice, objvalue.MatchQty);


                    //判斷成交買進數量是否有條件設定符合
                    updateReplyConditionStatus(objvalue.ProductId, ReplyKind.NowMatchQtyB, objvalue.NowMatchQtyB);
                    //判斷成交賣出數量是否有條件設定符合
                    updateReplyConditionStatus(objvalue.ProductId, ReplyKind.NowMatchQtyS, objvalue.NowMatchQtyS);
                    //判斷今日數是否有條件設定符合
                    updateReplyConditionStatus(objvalue.ProductId, ReplyKind.TodayEnd, objvalue.TodayEnd);
                    //判斷未平倉買進數量是否有條件設定符合
                    updateReplyConditionStatus(objvalue.ProductId, ReplyKind.NowOTQtyB, objvalue.NowOTQtyB);
                    //判斷未平倉賣出數量是否有條件設定符合
                    updateReplyConditionStatus(objvalue.ProductId, ReplyKind.NowOTQtyS, objvalue.NowOTQtyS);
                    //判斷價差買是否有條件設定符合
                    updateReplyConditionStatus(objvalue.ProductId, ReplyKind.PriceDiffB, objvalue.PriceDiffB);
                    //判斷價差賣是否有條件設定符合
                    updateReplyConditionStatus(objvalue.ProductId, ReplyKind.PriceDiffS, objvalue.PriceDiffS);
                    //判斷買進平均成本是否有條件設定符合
                    updateReplyConditionStatus(objvalue.ProductId, ReplyKind.AvgCostB, objvalue.AvgCostB);
                    //判斷買出平均成本是否有條件設定符合
                    updateReplyConditionStatus(objvalue.ProductId, ReplyKind.AvgCostS, objvalue.AvgCostS);
                    //判斷平倉損益是否有條件設定符合
                    updateReplyConditionStatus(objvalue.ProductId, ReplyKind.LiquidationPL, objvalue.LiquidationPL);
                }
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("AutoOrderManager", ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }

        }
        private void updateReplyConditionStatus(string productid, ReplyKind kind, string value)
        {
            try
            {
                if (value != "")
                {
                    //>=
                    DataRow[] find = mdt_ReplyCondition.Select("productid='" + productid + "' and  BEGINTIME<='" + DateTime.Now.ToString("HHmmss") + "' and ENDTIME>='" + DateTime.Now.ToString("HHmmss") + "'and kind='" + kind.GetHashCode() + "'and status='" + status.enabled.GetHashCode() + "' and Condition='0' and value>=" + value);
                    foreach (DataRow dr in find)
                    {
                        dr.BeginEdit();
                        dr["status"] = status.trigger.GetHashCode();
                        dr["triggervalue"] = value;
                        dr.EndEdit();
                    }
                    //<=
                    find = mdt_ReplyCondition.Select("productid='" + productid + "' and  BEGINTIME<='" + DateTime.Now.ToString("HHmmss") + "' and ENDTIME>='" + DateTime.Now.ToString("HHmmss") + "'and kind='" + kind.GetHashCode() + "'and status='" + status.enabled.GetHashCode() + "' and Condition='1' and value<=" + value);
                    foreach (DataRow dr in find)
                    {
                        dr.BeginEdit();
                        dr["status"] = status.trigger.GetHashCode();
                        dr["triggervalue"] = value;
                        dr.EndEdit();
                    }
                }
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("AutoOrderManager", ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        private void updateReplyConditionStatus(string orderno, string productid, ReplyKind kind, string value)
        {
            try
            {
                if (value != "")
                {
                    //>=
                    DataRow[] find = mdt_ReplyCondition.Select("orderno='" + orderno + "' and productid='" + productid + "' and  BEGINTIME<='" + DateTime.Now.ToString("HHmmss") + "' and ENDTIME>='" + DateTime.Now.ToString("HHmmss") + "'and kind='" + kind.GetHashCode() + "'and status='" + status.enabled.GetHashCode() + "' and Condition='0' and value>=" + value);
                    foreach (DataRow dr in find)
                    {
                        dr.BeginEdit();
                        dr["status"] = status.trigger.GetHashCode();
                        dr["triggervalue"] = value;
                        dr.EndEdit();
                    }
                    //<=
                    find = mdt_ReplyCondition.Select("orderno='" + orderno + "' and productid='" + productid + "' and  BEGINTIME<='" + DateTime.Now.ToString("HHmmss") + "' and ENDTIME>='" + DateTime.Now.ToString("HHmmss") + "'and kind='" + kind.GetHashCode() + "'and status='" + status.enabled.GetHashCode() + "' and Condition='1' and value<=" + value);
                    foreach (DataRow dr in find)
                    {
                        dr.BeginEdit();
                        dr["status"] = status.trigger.GetHashCode();
                        dr["triggervalue"] = value;
                        dr.EndEdit();
                    }
                }
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("AutoOrderManager", ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        private void updateReplyConditionStatus(string orderno, string productid, ReplyKind kind, string value, string price)
        {
            try
            {
                if (value != "")
                {
                    //>=
                    DataRow[] find = mdt_ReplyCondition.Select("orderno='" + orderno + "' and productid='" + productid + "' and  BEGINTIME<='" + DateTime.Now.ToString("HHmmss") + "' and ENDTIME>='" + DateTime.Now.ToString("HHmmss") + "'and kind='" + kind.GetHashCode() + "'and status='" + status.enabled.GetHashCode() + "' and Condition='0' and value>=" + value);
                    foreach (DataRow dr in find)
                    {
                        dr.BeginEdit();
                        dr["status"] = status.trigger.GetHashCode();
                        dr["triggervalue"] = value;
                        dr["price"] = price;
                        dr.EndEdit();
                    }
                    //<=
                    find = mdt_ReplyCondition.Select("orderno='" + orderno + "' and productid='" + productid + "' and  BEGINTIME<='" + DateTime.Now.ToString("HHmmss") + "' and ENDTIME>='" + DateTime.Now.ToString("HHmmss") + "'and kind='" + kind.GetHashCode() + "'and status='" + status.enabled.GetHashCode() + "' and Condition='1' and value<=" + value);
                    foreach (DataRow dr in find)
                    {
                        dr.BeginEdit();
                        dr["status"] = status.trigger.GetHashCode();
                        dr["triggervalue"] = value;
                        dr["price"] = price;
                        dr.EndEdit();
                    }
                }
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("AutoOrderManager", ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        private void updateReplyConditionStatusBySeq(string seq, string productid, ReplyKind kind, string value)
        {
            try
            {
                if (value != "")
                {
                    //>=
                    DataRow[] find = mdt_ReplyCondition.Select("seq='" + seq + "' and productid='" + productid + "' and  BEGINTIME<='" + DateTime.Now.ToString("HHmmss") + "' and ENDTIME>='" + DateTime.Now.ToString("HHmmss") + "'and kind='" + kind.GetHashCode() + "'and status='" + status.enabled.GetHashCode() + "' and Condition='0' and value>=" + value);
                    foreach (DataRow dr in find)
                    {
                        dr.BeginEdit();
                        dr["status"] = status.trigger.GetHashCode();
                        dr["triggervalue"] = value;
                        dr.EndEdit();
                    }
                    //<=
                    find = mdt_ReplyCondition.Select("seq='" + seq + "' and productid='" + productid + "' and  BEGINTIME<='" + DateTime.Now.ToString("HHmmss") + "' and ENDTIME>='" + DateTime.Now.ToString("HHmmss") + "'and kind='" + kind.GetHashCode() + "'and status='" + status.enabled.GetHashCode() + "' and Condition='1' and value<=" + value);
                    foreach (DataRow dr in find)
                    {
                        dr.BeginEdit();
                        dr["status"] = status.trigger.GetHashCode();
                        dr["triggervalue"] = value;
                        dr.EndEdit();
                    }
                }
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("AutoOrderManager", ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        private void updateReplyConditionStatusBySeq(string seq, string productid, ReplyKind kind, string value, string price)
        {
            try
            {
                if (value != "")
                {
                    //>=
                    DataRow[] find = mdt_ReplyCondition.Select("seq='" + seq + "' and productid='" + productid + "' and  BEGINTIME<='" + DateTime.Now.ToString("HHmmss") + "' and ENDTIME>='" + DateTime.Now.ToString("HHmmss") + "'and kind='" + kind.GetHashCode() + "'and status='" + status.enabled.GetHashCode() + "' and Condition='0' and value>=" + value);
                    foreach (DataRow dr in find)
                    {
                        dr.BeginEdit();
                        dr["status"] = status.trigger.GetHashCode();
                        dr["triggervalue"] = value;
                        dr["price"] = price;
                        dr.EndEdit();
                    }
                    //<=
                    find = mdt_ReplyCondition.Select("seq='" + seq + "' and productid='" + productid + "' and  BEGINTIME<='" + DateTime.Now.ToString("HHmmss") + "' and ENDTIME>='" + DateTime.Now.ToString("HHmmss") + "'and kind='" + kind.GetHashCode() + "'and status='" + status.enabled.GetHashCode() + "' and Condition='1' and value<=" + value);
                    foreach (DataRow dr in find)
                    {
                        dr.BeginEdit();
                        dr["status"] = status.trigger.GetHashCode();
                        dr["triggervalue"] = value;
                        dr["price"] = price;
                        dr.EndEdit();
                    }
                }
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("AutoOrderManager", ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }

        private void FuntionStatus_Changed(object sender, DataRowChangeEventArgs e)
        {
            try
            {
                DataAgent._LM.WriteLog("AutoOrderManager", "Funtion ChangeLog:Action=" + e.Action.ToString() + ";Row=" + String.Concat(e.Row.ItemArray));
                if (e.Action.ToString() == "Change")
                {

                    string[] obj = new string[2];
                    obj[0] = e.Row["ID"].ToString();
                    obj[1] = e.Row["GroupId"].ToString();
                    if (e.Row["status"].ToString() == status.trigger.GetHashCode().ToString())
                    {
                        if (_AutoOrderConditionItems.ContainsKey(e.Row["ID"].ToString() + e.Row["GroupId"].ToString()))
                        {
                            _AutoOrderConditionItems[e.Row["ID"].ToString() + e.Row["GroupId"].ToString()].raiseFunctionConfirm(e.Row["FUNID"].ToString(), e.Row  );
                        }


                    }
                    DataRow find = mdt_ConditionMaster.Rows.Find(obj);
                    if (find != null)
                    {
                       
                        find[e.Row["FUNID"].ToString()] = e.Row["status"].ToString();

                    }

                }
                else if (e.Action.ToString() == "Add")
                {
                    if (((DataTable)sender).TableName == "TimeCondition" && e.Row["BEGINTIME"].ToString().Trim()=="")
                    {
                        string id = e.Row["id"].ToString() + "@" + e.Row["groupid"].ToString() + "@" + e.Row["funid"].ToString();
                        //判斷如果開啟過timer就不啟動timer
                        if (!mobj_timercollection.ContainsKey(id))
                        {

                            System.Windows.Forms.Timer obj = new System.Windows.Forms.Timer();

                            obj.Interval = int.Parse(e.Row["Interval"].ToString());
                            obj.Tick += new EventHandler(obj_Tick);
                            obj.Tag = id;
                            obj.Start();
                            mobj_timercollection.Add(id, obj);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("AutoOrderManager", ("Funtion ChangeError:Action=" + e.Action.ToString() + ";Row=" + String.Concat(e.Row.ItemArray)) + ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
            }
        }
        private void ConditionStatus_Changed(object sender, DataRowChangeEventArgs e)
        {
            try
            {
                DataAgent._LM.WriteLog("AutoOrderManager", "Condition ChangeLog:Action=" + e.Action.ToString() + ";Row=" + String.Concat(e.Row.ItemArray));

                if (e.Action.ToString() == "Change")
                {
                    if (e.Row["status"].ToString() == status.enabled.GetHashCode().ToString())
                    {

                        bool bolCheck = true;

                        for (int i = 1; i < mint_maxGroupCondition; i++)
                        {

                            bool bolChk1 = true;
                            bool bolChk2 = true;

                            if (e.Row["FUN" + i.ToString()].ToString() != "" && e.Row["FUN" + i.ToString()].ToString() != status.trigger.GetHashCode().ToString() && (!(i > 1 && (e.Row["CDN" + (i - 1).ToString()].ToString() == codition.or.GetHashCode().ToString()))))
                            {
                                bolChk1 = false;
                            }
                            if (e.Row["FUN" + (i + 1).ToString()].ToString() != "" && e.Row["FUN" + (i + 1).ToString()].ToString() != status.trigger.GetHashCode().ToString())
                            {
                                bolChk2 = false;
                            }

                            if (e.Row["CDN" + i.ToString()].ToString() == "" || e.Row["FUN" + (i + 1).ToString()].ToString() == "")
                            {
                                if (!bolChk1)
                                {

                                    bolCheck = false;
                                }


                            }
                            else if (e.Row["CDN" + i.ToString()].ToString() != "" && e.Row["CDN" + i.ToString()].ToString() == codition.and.GetHashCode().ToString())
                            {
                                if (!(bolChk1 && bolChk2))
                                {
                                    bolCheck = false;
                                }
                            }
                            else if (e.Row["CDN" + i.ToString()].ToString() != "" && e.Row["CDN" + i.ToString()].ToString() == codition.or.GetHashCode().ToString())
                            {
                                if (!(bolChk1 || bolChk2))
                                {
                                    bolCheck = false;
                                }
                            }
                        }



                        if (bolCheck)
                        {

                            e.Row["status"] = status.trigger.GetHashCode();
                            //string[] obj = new string[2];
                            //obj[0] = e.Row["ID"].ToString();
                            //obj[2] = e.Row["GroupId"].ToString();
                            if (_AutoOrderConditionItems.ContainsKey(e.Row["ID"].ToString() + e.Row["GroupId"].ToString()))
                            {
                                _AutoOrderConditionItems[e.Row["ID"].ToString() + e.Row["GroupId"].ToString()].raiseConditionConfirm( );
                            }


                        }

                    }
                }
            }
            catch (Exception ex)
            {
                  DataAgent._LM.WriteLog("AutoOrderManager",("Condition ChangeError:Action=" + e.Action.ToString() + ";Row=" + String.Concat(e.Row.ItemArray)) + ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
            }
        }

        void Funtion_RowDeleting(object sender, DataRowChangeEventArgs e)
        {
            DataAgent._LM.WriteLog("AutoOrderManager", "Funtion DeleteLog:Action=" + e.Action.ToString() + ";Row=" + String.Concat(e.Row.ItemArray));

        }
        void Condition_RowDeleting(object sender, DataRowChangeEventArgs e)
        {
            DataAgent._LM.WriteLog("AutoOrderManager", "Condition DeleteLog:Action=" + e.Action.ToString() + ";Row=" + String.Concat(e.Row.ItemArray));
        }
        public class AutoOrderConditionItem
        {
            private string _id;
            private string _seq;
            private string _groupid;


            public string id
            {
                set { this._id = value; }
                get { return this._id; }
            }
            public string seq
            {
                set { this._seq = value; }
                get { return this._seq; }
            }
            public string groupid
            {
                set { this._groupid = value; }
                get { return this._groupid; }
            }


            public struct ConditionConfirmEventArgs
            {
                public string _id;
                public string _seq;
                public string _groupid;
   
            }
            public struct FunctionConfirmEventArgs
            {
                public string _id;
                public string _seq;
                public string _groupid;
                public string _confirmFunctionId;
                public DataRow _DataRow;
            }

            public delegate
             void ConditionConfirmCallback(ConditionConfirmEventArgs e);
            public event ConditionConfirmCallback _ConditionConfirm;
            public delegate
                void FunctionConfirmCallback(FunctionConfirmEventArgs e);
            public event FunctionConfirmCallback _FunctionConfirm;

            public AutoOrderConditionItem()
            {
            }
            public void raiseConditionConfirm( )
            {
                ConditionConfirmEventArgs ee = new ConditionConfirmEventArgs();
                ee._id = _id;
                ee._seq = _seq;
                ee._groupid = _groupid;
         
                if (_ConditionConfirm != null)
                {
                    DataAgent._LM.WriteLog("AutoOrderManager", "Condition EventLog:_id=" + ee._id + ";_seq=" + ee._seq + ";_groupid=" + ee._groupid);

                    _ConditionConfirm(ee);
                }
            }
            public void raiseFunctionConfirm(string confirmFunctionId, DataRow raiseRow)
            {
                FunctionConfirmEventArgs ee = new FunctionConfirmEventArgs();
                ee._id = _id;
                ee._seq = _seq;
                ee._groupid = _groupid;
                ee._confirmFunctionId = confirmFunctionId;
                ee._DataRow = raiseRow;
                if (_FunctionConfirm != null)
                {
                    DataAgent._LM.WriteLog("AutoOrderManager", "Function EventLog:_id=" + ee._id + ";_seq=" + ee._seq + ";_groupid=" + ee._groupid + ";_confirmFunctionId=" + ee._confirmFunctionId);

                    _FunctionConfirm(ee);
                }
            }
        }
    }
}
