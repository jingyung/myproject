﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Windows.Forms;
using System.Drawing;
using System.ComponentModel;
using System.IO;
using System.Collections;
using VIPTradingSystem;
namespace VIPTradingSystem.MYcls
{
    public class ControlManager
    {
        private System.DateTime dtReplyPlayerlast;
        private System.TimeSpan tsReplyPlayerSpan;
        private System.DateTime dtMatchReplyPlayerlast;
        private System.TimeSpan tsMatchReplyPlayerSpan;
        private System.Media.SoundPlayer _sndReplyPlayer;
        private System.Media.SoundPlayer _sndMatchReplyPlayer;
        /// <summary>
        /// 主畫面
        /// </summary>
        private frmMain mfrmMain;


        private ProgramProvider _ProgramProvider;
        public ArrayList _FocusArray = new ArrayList();
        DataTable mdt_GridSet;
        public ControlManager()
        {
            _sndReplyPlayer = new System.Media.SoundPlayer();
            _sndMatchReplyPlayer = new System.Media.SoundPlayer();



        }


        public void SetSoundLocation()
        {
            try
            {
                //_sndReplyPlayer.SoundLocation = frmMain.UserConfigs.R_SOUND_FILENAME;
                //_sndMatchReplyPlayer.SoundLocation = frmMain.UserConfigs.M_SOUND_FILENAME;
                if (frmMain.UserConfigs.R_SOUND)
                {
                    if (frmMain.UserConfigs.R_SOUND_FILE.Length == 0)
                        _sndReplyPlayer.Stream = Properties.Resources.R_SOUND;
                    else
                        _sndReplyPlayer.Stream = new MemoryStream(frmMain.UserConfigs.R_SOUND_FILE);
                    _sndReplyPlayer.Load();
                }
                if (frmMain.UserConfigs.M_SOUND)
                {
                    if (frmMain.UserConfigs.M_SOUND_FILE.Length == 0)
                        _sndMatchReplyPlayer.Stream = Properties.Resources.M_SOUND;
                    else
                        _sndMatchReplyPlayer.Stream = new MemoryStream(frmMain.UserConfigs.M_SOUND_FILE);
                    _sndMatchReplyPlayer.Load();
                }
            }
            catch (Exception ex)
            {
                CommonFunction.ShowMessageBox(null, "Error loading sound", ex.Message);
            }
        }

        public void PlayReplyPlayerSound()
        {
            try
            {
                if (_sndReplyPlayer != null)
                {
                    if (frmMain.UserConfigs.R_SOUND)
                        _sndReplyPlayer.Play();


                }
            }
            catch (Exception ex)
            {
                CommonFunction.ShowMessageBox(null, "Error loading sound", ex.Message);

            }
        }


        public void PlayMatchReplyPlayerSound()
        {
            try
            {
                if (_sndMatchReplyPlayer != null)
                {
                    if (frmMain.UserConfigs.M_SOUND)
                        _sndMatchReplyPlayer.Play();


                }
            }
            catch (Exception ex)
            {
                CommonFunction.ShowMessageBox(null, "Error loading sound", ex.Message);
            }
        }




        void _sndReplyPlayer_LoadCompleted(object sender, AsyncCompletedEventArgs e)
        {
            try
            {
                _sndReplyPlayer.Play();
            }
            catch
            {
            }
        }

        void _sndMatchReplyPlayer_LoadCompleted(object sender, AsyncCompletedEventArgs e)
        {
            try
            {
                _sndMatchReplyPlayer.Play();
            }
            catch
            {
            }

        }




        /// <summary>
        /// 主畫面
        /// </summary>
        public frmMain V_frmMain
        {
            get
            {
                return mfrmMain;
            }
            set
            {
                mfrmMain = value;
            }
        }


        /// <summary>
        /// Grid預設樣式集合
        /// </summary>
        public DataTable GridSet
        {
            get
            {
                return mdt_GridSet;
            }
            set
            {
                mdt_GridSet = value;
            }
        }


        /// <summary>
        /// 主畫面設定
        /// </summary>
        public void ini_Main()
        {
            try
            {
                //  mdic_Programs = new Dictionary<string, object>();

                _ProgramProvider = new ProgramProvider();
                display_Menu();
               

            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("ControlManagerLog", "ini_Main:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }

        }

        public void initOpenform()
        {
            ProgramInfo Item = new ProgramInfo();
            Item.classid = "2";
            Item.collectId = "";
            Item.mod_id = "Reply";
            Item.MutiFlag = false;
            Item.prog_desc = "改單介面";
            Item.prog_name = "frmReply";
            open_Form(Item);

            Item = new ProgramInfo();
            Item.classid = "1";
            Item.collectId = "";
            Item.mod_id = "Order";
            Item.MutiFlag = true;
            Item.prog_desc = "下單介面";
            Item.prog_name = "frmTrade";
            open_Form(Item);
        }
        public void saveCollect(string collectid, string ISDEFUALT)
        {
            try
            {
                foreach (DataRow dr in mdt_GridSet.Select("   COLLECT_ID ='" + collectid + "'  "))
                {
                    mdt_GridSet.Rows.Remove(dr);
                }
                foreach (DataRow dr in frmMain.UserConfigs.FORM_SET.Select("   COLLECT_ID ='" + collectid + "' "))
                {
                    frmMain.UserConfigs.FORM_SET.Rows.Remove(dr);
                }
                foreach (string prog_name in _ProgramProvider.GetKey())
                {
                    Dictionary<string, BaseForm> dicSaveForm = new Dictionary<string, BaseForm>();
                    if (_ProgramProvider.GetData(prog_name) != null)
                    {
                        ProgramSet set = _ProgramProvider.GetData(prog_name);


                        if (set.ProgramInfo.MutiFlag)
                        {
                            dicSaveForm = set.Programs;
                        }
                        else
                        {
                            dicSaveForm.Add(prog_name, (BaseForm)_ProgramProvider.GetData(prog_name).Form);
                        }

                        foreach (Form form in dicSaveForm.Values)
                        {
                            BaseForm oForm = (BaseForm)form;
                            DataView dvGrid = new DataView(mdt_GridSet);
                            dvGrid.RowFilter = "PROG_NAME='" + prog_name + "' and COLLECT_ID =''";
                            foreach (DataRow dr in dvGrid.ToTable(true, new string[] { "GRID_NAME" }).Rows)
                            {
                                string grid_name = dr["GRID_NAME"].ToString();
                                if (oForm.dicControls.ContainsKey(grid_name))
                                {
                                    DataGridView dvdata = (DataGridView)oForm.dicControls[grid_name];
                                    foreach (DataGridViewColumn dvc in dvdata.Columns)
                                    {
                                        mdt_GridSet.Rows.Add(new object[] { collectid, oForm.Name, grid_name, dvc.Name, dvc.HeaderText, dvc.Width.ToString(), dvc.DisplayIndex.ToString(), (dvc.Visible ? "Y" : "N"), "N", (dvc.SortMode == DataGridViewColumnSortMode.NotSortable ? "N" : "Y"), dvc.GetType().ToString() == "System.Windows.Forms.DataGridViewButtonColumn" ? "BUTTON" : "TEXT" });
                                    }
                                }
                            }
                            foreach (DataRow dr in frmMain.UserConfigs.FORM_SET.Select("PROG_NAME='" + prog_name + "' and COLLECT_ID =''"))
                            {

                                string set_name = dr["SET_NAME"].ToString();
                                string value = "";
                                string type = dr["TYPE"].ToString();
                                PropertyDescriptor prop = null;
                                string property = "";
                                if (set_name == "this.Height")
                                {
                                    frmMain.UserConfigs.FORM_SET.Rows.Add(new object[] { collectid, oForm.Name, set_name, oForm.BeforeSize.Height.ToString(), type });
                                }
                                else if (set_name == "this.Width")
                                {
                                    frmMain.UserConfigs.FORM_SET.Rows.Add(new object[] { collectid, oForm.Name, set_name, oForm.BeforeSize.Width.ToString(), type });
                                }
                                else
                                {
                                    string name = set_name.Split('.')[0];
                                    property = set_name.Split('.')[1];
                                    prop = TypeDescriptor.GetProperties(oForm.dicControls[name])[property];
                                    if (prop != null)
                                    {
                                        if (type == "Font")
                                        {
                                            value = ((System.Drawing.Font)prop.GetValue(oForm.dicControls[name])).FontFamily.Name.ToString() + "," + ((System.Drawing.Font)prop.GetValue(oForm.dicControls[name])).Size.ToString() + "," + ((System.Drawing.Font)prop.GetValue(oForm.dicControls[name])).Style.GetHashCode().ToString();
                                        }
                                        else
                                        {
                                            value = prop.GetValue(oForm.dicControls[name]).ToString();
                                        }
                                        if (type == "FormWindowState")
                                        {
                                            value = value.Split('.')[value.Split('.').Length - 1];
                                        }
                                        if (set_name == "this.Location" && (oForm.WindowState == System.Windows.Forms.FormWindowState.Maximized || oForm.WindowState == System.Windows.Forms.FormWindowState.Minimized))
                                        {
                                            value = "{X=0,Y=0}";
                                        }
                                        frmMain.UserConfigs.FORM_SET.Rows.Add(new object[] { collectid, oForm.Name, set_name, value, type });
                                    }
                                }
                            }
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("ControlManagerLog", "saveCollect:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        public void openCollection(string collectid, string isdefuat)
        {
            try
            {
                closeForms();
                DataView dvDisplaySet = new DataView(frmMain.UserConfigs.FORM_SET);
                dvDisplaySet.RowFilter = "COLLECT_ID ='" + collectid + "' ";
                DataTable dtPROG_NAME = dvDisplaySet.ToTable(true, new string[] { "PROG_NAME" });
                foreach (DataRow dr in dtPROG_NAME.Rows)
                {
                    string prog_name = dr["PROG_NAME"].ToString().Split(':')[0];
                    ProgramInfo p = frmMain.UserConfigs.ProgramSet.GetData(prog_name);
                    ProgramInfo Item = new ProgramInfo();
                    Item.mod_id = p.mod_id;
                    Item.prog_name = p.prog_name;
                    Item.prog_desc = p.prog_desc;
                    Item.collectId = collectid;
                    Item.classid = p.classid;
                    Item.remark = p.remark;
                    Item.MutiFlag = p.MutiFlag;


                    if (prog_name == "frmInfoTrade")
                    {
                        Item.productid = dr["PROG_NAME"].ToString().Split(':')[1].Split('_')[0];
                        Item.MutiFlag = false;
                        open_Form(Item);

                    }
                    else if (prog_name == "frmLinkOrder")
                    {
                        Item.productid = dr["PROG_NAME"].ToString().Split(':')[1].Split('_')[0];
                        Item.MutiFlag = false;
                        open_Form(Item);
                    }
                    else
                    {

                        open_Form(Item);
                    }
                }
                setFocusSeq(collectid);
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("ControlManagerLog", "openCollection:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        private void setFocusSeq(string collectid)
        {
            DataTable dtSeq = new DataTable();
            dtSeq.Columns.Add("form");
            dtSeq.Columns.Add("seq", typeof(int));
            foreach (DataRow dr in frmMain.UserConfigs.FORM_SET.Select("COLLECT_ID ='" + collectid + "' and   SET_NAME='this.focusSeq'"))
            {
                dtSeq.Rows.Add(new object[] { dr["PROG_NAME"].ToString(), dr["SET_VALUE"].ToString() });
            }
            //foreach (DataRow dr in dtSeq.Select("", "seq"))
            //{
            //    string form = dr["form"].ToString();

            //    {
            //        if (mdic_Programs[form.Split(':')[0]] != null)
            //        {
            //            if (form.Split(':').Length == 2)
            //            {
            //                ((Dictionary<string, Form>)mdic_Programs[form.Split(':')[0]])[form].Focus();
            //            }
            //            else
            //            {
            //                ((Form)mdic_Programs[form]).Focus();
            //            }
            //        }
            //    }
            //}
        }
        /// <summary>
        /// 顯設設定程式menu
        /// </summary>
        private void display_Menu()
        {

            try
            {
                DataSet dsData = new DataSet();
                DataSet dsConn = new DataSet();
                DataTable dtMenuList = frmMain.UserConfigs.ProgramSet.GetDt();
                if (dtMenuList.Rows.Count > 0)
                {
                    ToolStripMenuItem itemMod = new ToolStripMenuItem(); ;
                    ToolStripMenuItem itemProgram;

                    //前一項模組

                    string strPreMOD_SEQ = "";
                    string strPreMOD_ID = "";
                    string strPreMOD_Name = "";

                    int modCount = 0;
                    DataRow drData = null;
                    foreach (DataRow drw in dtMenuList.Rows)
                    {
                        drData = drw;
                        frmMain.mobjDataAgent.objControlManager._ProgramProvider.AddProgram(drw["prog_name"].ToString().Trim(), null);

                        if (strPreMOD_SEQ != "" && drw["MOD_SEQ"].ToString() != strPreMOD_SEQ)
                        {
                            //新增模組

                            itemMod.Name = "mnu" + strPreMOD_ID;
                            itemMod.Text = strPreMOD_Name;
                            itemMod.Tag = modCount;
                            mfrmMain.mnuMain.Items.Insert(modCount + 1, itemMod);

                            modCount++;
                            itemMod = new ToolStripMenuItem();
                            strPreMOD_SEQ = "";

                        }
                        //新增程式
                        itemProgram = new ToolStripMenuItem();
                        itemProgram.Name = "mnu" + drw["prog_name"].ToString().Trim();
                        itemProgram.Tag = drw["class"].ToString().Trim() + "@" + drw["remark"].ToString().Trim() + "@" + drw["MULTIFORM"].ToString().Trim();

                        itemProgram.Text = "[" + drw["class"].ToString().Trim() + "]" + drw["PROG_DESC"].ToString().Trim();
                        itemProgram.Click += new System.EventHandler(V_frmMain.mnuProgram_Click);
                        itemMod.DropDownItems.Add(itemProgram);

                        if (drw["prog_name"].ToString().Trim() == "frmMarketConnection")
                        {

                            foreach (DataRow dr in frmMain.UserConfigs.ServerSet.Select("type='M'", "IsDefault desc,sortno"))
                            {
                                DataRow[] dtRegisterConnRows = frmMain.UserConfigs.ServerSet.Select(" type='S' and seq='" + dr["seq"].ToString().Trim() + "'");
                                ToolStripMenuItem itemConn = new ToolStripMenuItem();
                                if (dtRegisterConnRows.Length > 0)
                                {
                                    itemConn.Name = dr["ServerIp"].ToString().Trim() + ":" + dr["ServerPort"].ToString().Trim() + "," + dtRegisterConnRows[0]["ServerIp"].ToString().Trim() + ":" + dtRegisterConnRows[0]["ServerPort"].ToString().Trim();
                                }
                                else
                                {
                                    itemConn.Name = dr["ServerIp"].ToString().Trim() + ":" + dr["ServerPort"].ToString().Trim();

                                }
                                if (dr["IsDefault"].ToString().Trim() == "Y")
                                {
                                    itemConn.Checked = true;
                                }
                                itemConn.Text = dr["serverdsc"].ToString().Trim() + dr["seq"].ToString().Trim();
                                itemConn.Tag = dr["seq"].ToString().Trim();
                                itemConn.Click += new EventHandler(itemConn_Click);
                                itemProgram.DropDownItems.Add(itemConn);
                            }

                        }
                        else if (drw["prog_name"].ToString().Trim() == "frmTradeConnection" || drw["prog_name"].ToString().Trim() == "frmAccountConnection")
                        {
                            string type = "";
                            if (drw["prog_name"].ToString().Trim() == "frmTradeConnection")
                            {
                                type = "T";
                            }
                            else
                            {
                                type = "A";
                            }
                            foreach (DataRow dr in frmMain.UserConfigs.ServerSet.Select("type='" + type + "'", "IsDefault desc,sortno"))
                            {
                                ToolStripMenuItem itemConn = new ToolStripMenuItem();

                                itemConn.Name = dr["ServerIp"].ToString().Trim() + ":" + dr["ServerPort"].ToString().Trim();

                                itemConn.Text = dr["serverdsc"].ToString().Trim() + dr["seq"].ToString().Trim();
                                itemConn.Tag = dr["seq"].ToString().Trim();
                                if (dr["IsDefault"].ToString().Trim() == "Y")
                                {
                                    itemConn.Checked = true;
                                }
                                itemConn.Click += new EventHandler(itemConn_Click);

                                itemProgram.DropDownItems.Add(itemConn);
                            }

                        }

                        strPreMOD_SEQ = drw["MOD_SEQ"].ToString().Trim();
                        strPreMOD_ID = drw["MODID"].ToString().Trim();
                        strPreMOD_Name = drw["mod_desc"].ToString().Trim();


                    }
                    //將最後一項模組加進去
                    if (strPreMOD_SEQ != "")
                    {

                        itemMod.Name = "mnu" + strPreMOD_ID;
                        itemMod.Text = strPreMOD_Name;
                        itemMod.Tag = modCount;
                        mfrmMain.mnuMain.Items.Insert(modCount + 1, itemMod);
                    }
                }

                ////清除使用者基本設定




                //mfrmMain.mnuCollectSet.Visible = true;
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("ControlManagerLog", "display_Menu:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }

        }
        /// <summary>
        /// 通訊連線
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void itemConn_Click(object sender, EventArgs e)
        {
            try
            {
                for (int i = 0; i < ((ToolStripMenuItem)(((ToolStripMenuItem)(sender)).OwnerItem)).DropDownItems.Count; i++)
                {
                    if (((ToolStripMenuItem)(((ToolStripMenuItem)(sender)).OwnerItem)).DropDownItems[i] is ToolStripMenuItem)
                    {
                        ((ToolStripMenuItem)((ToolStripMenuItem)(((ToolStripMenuItem)(sender)).OwnerItem)).DropDownItems[i]).Checked = false;

                    }
                }
                if (((ToolStripMenuItem)(sender)).OwnerItem.Name == "mnufrmMarketConnection")
                {


                    ((System.Windows.Forms.ToolStripMenuItem)(sender)).Checked = true;
                    //取得itemName
                    string strItemName = ((System.Windows.Forms.ToolStripMenuItem)(sender)).Name;
                    MYcls.DataAgent._LM.WriteLog("UIEventLog", "行情連線切換" + strItemName);
                    string strMarketConnName = "";
                    string strRegisterConnName = "";
                    //判斷設定是舊的還是新的.新的會包含註冊連線資訊
                    if (strItemName.Split(',').Length > 1)
                    {
                        strMarketConnName = strItemName.Split(',')[0];
                        strRegisterConnName = strItemName.Split(',')[1];
                        frmMain.mobjDataAgent.mstr_MarketInfoServerIp = strMarketConnName.Split(':')[0];
                        frmMain.mobjDataAgent.mstr_MarketInfoServerPort = int.Parse(strMarketConnName.Split(':')[1]);
                        V_frmMain.toolbar_InfoSocketClientStatus.Text = "";
                        V_frmMain.toolbar_InfoSocketClientStatus.Image = null;
                        frmMain.mobjDataAgent.enabledMarketSocket(false);
                        frmMain.mobjDataAgent.enabledMarketSocket(true);




                    }
                    else
                    {
                        strMarketConnName = strItemName;
                        frmMain.mobjDataAgent.mstr_MarketInfoServerIp = strMarketConnName.Split(':')[0];
                        frmMain.mobjDataAgent.mstr_MarketInfoServerPort = int.Parse(strMarketConnName.Split(':')[1]);
                        frmMain.mobjDataAgent.enabledMarketSocket(false);
                        V_frmMain.toolbar_InfoSocketClientStatus.Text = "";
                        V_frmMain.toolbar_InfoSocketClientStatus.Image = null;
                        frmMain.mobjDataAgent.enabledMarketSocket(true);
                        V_frmMain.toolbar_RegisterClientStatus.Text = "";
                        V_frmMain.toolbar_RegisterClientStatus.Image = null;

                    }

                }
                else if (((ToolStripMenuItem)(sender)).OwnerItem.Name == "mnufrmTradeConnection")
                {


                    ((System.Windows.Forms.ToolStripMenuItem)(sender)).Checked = true;

                    string strTradeConnName = ((System.Windows.Forms.ToolStripMenuItem)(sender)).Name.Split(',')[0];
                    MYcls.DataAgent._LM.WriteLog("UIEventLog", "交易連線切換" + strTradeConnName);
                    string seq = ((System.Windows.Forms.ToolStripMenuItem)(sender)).Tag.ToString();


                    DataRow[] drFind = frmMain.UserConfigs.ServerSet.Select("type='W' and seq='" + seq + "'");

                    if (drFind.Length > 0)
                    {
                        MYcls.DataAgent._LM.WriteLog("UIEventLog", "WS連線切換" + drFind[0]["serverip"].ToString());
                        //        frmMain.mobjDataAgent.WS_VIPService.Url = "http://" + drFind[0]["serverip"].ToString() + "/WS_VIPService/VIPService.asmx";
                        //        frmMain.mobjDataAgent.WS_VIPService.Discover();
                        frmMain.mobjDataAgent.GetReply();
                    }

                    frmMain.mobjDataAgent.mstr_TradeServerIp = strTradeConnName.Split(':')[0];
                    frmMain.mobjDataAgent.mstr_TradePort = int.Parse(strTradeConnName.Split(':')[1]);
                    frmMain.mobjDataAgent.enabledTradeAPClient(false);
                    frmMain.mobjDataAgent.enabledTradeAPClient(true);

                }


            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("ControlManagerLog", "display_Menu:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }




        /// <summary>
        /// 開啟程式
        /// </summary>
        public void open_Form(ProgramInfo item)
        {
            try
            {
                string mod_id = item.mod_id; //程式模組
                string prog_name = item.prog_name; //程式名稱
                string prog_desc = item.prog_desc; //程式描述
                string productid = item.productid;  //商品ID
                string collectId = item.collectId; //版面ID 
                string remark = item.remark;
                string classid = item.classid;      //功能代號
                bool MULTIFORM = item.MutiFlag;    //多視窗FLAG
                {
                    if (_ProgramProvider.GetData(prog_name) != null && !MULTIFORM)
                    {
                        focusForm(prog_name);
                    }
                    else
                    {
                        object instance = createActiveObject("VIPTradingSystem.ui." + mod_id + "." + prog_name);
                        if (instance != null)
                        {
                            BaseForm oForm = ((BaseForm)instance);
                            if (remark != "")
                            {
                                oForm.Text = remark + "." + prog_desc;
                            }
                            else
                            {
                                oForm.Text = prog_desc;
                            }
                            oForm.Text = "[" + classid + "]" + oForm.Text;
                            oForm.Tag = collectId;
                            string formName = prog_name;
                            if (MULTIFORM)
                            {
                                formName = _ProgramProvider.Add(true, prog_name, oForm);
                            }
                            else
                            {
                                formName = _ProgramProvider.Add(prog_name, oForm);
                            }
                            mfrmMain.new_tbButton(formName, prog_desc, oForm);
                            createForm(formName, oForm);
                            ((BaseForm)instance).parentForm = V_frmMain;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("ControlManagerLog", "open_Form:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        /// <summary>
        /// 依變數建立物件
        /// </summary>
        private object createActiveObject(string name)
        {
            object instance = null;
            try
            {
                System.Reflection.Assembly asm = System.Reflection.Assembly.GetExecutingAssembly();
                object[] objContructArgs = new object[1];
                Type t = asm.GetType(name);
                if (t != null)
                {
                    System.Reflection.ConstructorInfo[] c = t.GetConstructors();

                    instance = c[0].Invoke(null);
                }
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("ControlManagerLog", "createActiveObject:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
            return instance;
        }
        /// <summary>
        /// 開啟視窗
        /// </summary>
        private void createForm(string prog_name, Form form)
        {
            try
            {
                form.Name = prog_name;
                form.MdiParent = mfrmMain;
                form.FormClosed += new FormClosedEventHandler(program_FormClosed);
                form.Show();
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("ControlManagerLog", "createForm:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }

        /// <summary>
        /// 移除程式
        /// </summary>
        private void removeProgram(string prog_name)
        {
            try
            {
                int idx = _FocusArray.IndexOf(prog_name);
                if (idx > -1)
                {
                    _FocusArray.Remove(prog_name);
                }
                mfrmMain.toolBar.Items.RemoveByKey(prog_name);

                {
                    if (prog_name.Split(':').Length == 2)
                    {
                        //     ((Dictionary<string, Form>)mdic_Programs[prog_name.Split(':')[0]]).Remove(prog_name);

                        _ProgramProvider.Remove(prog_name);
                    }
                    else
                    {
                        _ProgramProvider.Remove(prog_name);
                    }
                }
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("ControlManagerLog", "removeProgram:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        /// <summary>
        /// focus 視窗
        /// </summary>
        public void focusForm(string prog_name)
        {
            try
            {
                BaseForm oForm;
                ProgramSet set = _ProgramProvider.GetData(prog_name.Split(':')[0]);
                if (set == null) return;

                if (set.ProgramInfo.MutiFlag)
                    oForm = set.GetData(prog_name);
                else
                    oForm = _ProgramProvider.GetData(prog_name).Form;

                if (oForm.WindowState == System.Windows.Forms.FormWindowState.Minimized)
                {
                    oForm.WindowState = System.Windows.Forms.FormWindowState.Normal;

                }
                oForm.Focus();


            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("ControlManagerLog", "focusForm:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }

        void program_FormClosed(object sender, FormClosedEventArgs e)
        {
            try
            {
                string prog_name = ((Form)sender).Name;
                removeProgram(prog_name);
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("ControlManagerLog", "program_FormClosed:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        private void closeForms()
        {
            try
            {

                _ProgramProvider.Dispose();

            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("ControlManagerLog", "closeForms:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        private void closeMenu()
        {
            try
            {
                //清除程式功能menu
                int count = mfrmMain.mnuMain.Items.Count;
                for (int i = 0; i < count; i++)
                {
                    if (mfrmMain.mnuMain.Items[i].Tag != null)
                    {
                        mfrmMain.mnuMain.Items.Remove(mfrmMain.mnuMain.Items[i]);
                        count = mfrmMain.mnuMain.Items.Count;
                        i--;
                    }
                }
                mfrmMain.mnuCollectSet.Visible = false;
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("ControlManagerLog", "closeMenu:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        public void close()
        {
            try
            {
                closeForms();
                closeMenu();
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("ControlManagerLog", "close:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }


        private delegate void changeStatusBar(string type, bool isError, string strText);

        /// <summary>
        /// 給外層呼叫呈現狀態列
        /// </summary>
        public void refreshStatusBar(string strType, bool isError, string strText)
        {
            try
            {
                mfrmMain.Invoke(new changeStatusBar(this.displayStatusBar), new object[] { strType, isError, strText });
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("ControlManagerLog", "refreshStatusBar:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }

        /// <summary>
        /// clear狀態列
        /// </summary>
        public void clearStatusBar()
        {
            mfrmMain.toolbar_InfoSocketClientStatus.Text = "";
            mfrmMain.toolbar_InfoSocketClientStatus.Image = null;

            mfrmMain.toolbar_RegisterClientStatus.Text = "";
            mfrmMain.toolbar_RegisterClientStatus.Image = null;

            mfrmMain.toolbar_OrderClientStatus.Text = "";
            mfrmMain.toolbar_OrderClientStatus.Image = null;

        }
        /// <summary>
        /// 呈現狀態列
        /// </summary>
        private void displayStatusBar(string strType, bool isError, string strText)
        {
            try
            {
                if (strType == "Market")
                {
                    //mfrmMain.toolbar_InfoSocketClientStatus.Text = strText;
                    //if (isError)
                    //{
                    //    mfrmMain.toolbar_InfoSocketClientStatus.Image = VIPTradingSystem.Properties.Resources.ERROR;
                    //}
                    //else
                    //{
                    //    mfrmMain.toolbar_InfoSocketClientStatus.Image = VIPTradingSystem.Properties.Resources.on;
                    //}
                }
                else if (strType == "Register")
                {
                    mfrmMain.toolbar_RegisterClientStatus.Text = strText;
                    if (isError)
                    {
                        mfrmMain.toolbar_RegisterClientStatus.Image = VIPTradingSystem.Properties.Resources.ERROR;
                    }
                    else
                    {
                        mfrmMain.toolbar_RegisterClientStatus.Image = VIPTradingSystem.Properties.Resources.on;
                    }
                }
                else if (strType == "Trade")
                {
                    mfrmMain.toolbar_OrderClientStatus.Text = strText;
                    if (isError)
                    {
                        mfrmMain.toolbar_OrderClientStatus.Image = VIPTradingSystem.Properties.Resources.ERROR;
                    }
                    else
                    {
                        mfrmMain.toolbar_OrderClientStatus.Image = VIPTradingSystem.Properties.Resources.on;
                    }
                }
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("ControlManagerLog", "refreshStatusBar:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }

    }
}
