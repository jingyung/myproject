using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using System.Windows.Forms;
using System.Collections;


namespace VIPTradingSystem.MYcls
{
    public class HotKeyManager : IDisposable
    {
        private Dictionary<int, HotKeyItem> _hotkey = new Dictionary<int, HotKeyItem>();
        private Dictionary<string, HotKeyItem> _hotkeyItems = new Dictionary<string, HotKeyItem>();
        private com.ddsc.tool.window.UserActivityHook _actHook;

        private MouseEventHandler _MouseEventHandler;
        public event MouseEventHandler MouseEvent
        {
            add
            {
                _MouseEventHandler = value;
            }
            remove
            {
                _MouseEventHandler = value;
            }
        }
        private DataTable _dt = null;

        public HotKeyManager()
        {
            try
            {

                this._actHook = new com.ddsc.tool.window.UserActivityHook();
                this._actHook.OnMouseActivity += new MouseEventHandler(_actHook_OnMouseActivity);
                this._actHook.KeyDown += new KeyEventHandler(m_actHook_KeyDown);
                this._actHook.KeyUp += new KeyEventHandler(m_actHook_KeyUp);
            this._actHook.Start(true, true);
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("HotKeyManagerLog", "HotKeyManager:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }

        void _actHook_OnMouseActivity(object sender, MouseEventArgs e)
        {
            if (_MouseEventHandler!=null)
            {
                _MouseEventHandler(sender, e);
            }

            //throw new NotImplementedException();
        }

        public void start()
        {
            try
            {
                this._actHook.Start(false, true);
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("HotKeyManagerLog", "start:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        public void stop()
        {
            try
            {
                this._actHook.Stop();
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("HotKeyManagerLog", "stop:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }

        public void Dispose()
        {
            try
            {
                this._actHook.Stop();
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("HotKeyManagerLog", "Dispose:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
            GC.SuppressFinalize(this);
        }
        public DataTable DataTable
        {
            set
            {
                this._dt = value;

            }
            get { return this._dt; }
        }
        public void addRegItems()
        {
            _hotkeyItems.Clear();
            foreach (DataRow dr in _dt.Rows)
            {
                HotKeyItem item = new HotKeyItem();
                item.functionId = dr["function"].ToString();
                _hotkeyItems.Add(dr["function"].ToString(), item);
            }
        }
        public bool excuteData()
        {
            if (this._dt == null) return false;
            this._hotkey.Clear();
            //_hotkeyItems.Clear();

            foreach (DataRow dr in this._dt.Rows)
            {
                //index function hotkey hotkeyIndex hotkeykey hotkeycontrol hotkeyshfit hotkeyalt
                if (dr["hotkeyIndex"].ToString() != "")
                {

                    HotKeyItem obj = _hotkeyItems[dr["function"].ToString()];
                    obj.functionId = dr["function"].ToString();
                    obj.value = dr["value"].ToString();
                    obj.hotkeyText = dr["hotkey"].ToString();
                    obj.hotkeykey = int.Parse(dr["hotkeykey"].ToString());
                    if (dr["hotkeycontrol"].ToString() == "")
                    {
                        obj.hotkeycontrol = false;
                    }
                    else
                    {
                        obj.hotkeycontrol = true;
                    }
                    if (dr["hotkeyshfit"].ToString() == "")
                    {
                        obj.hotkeyshfit = false;
                    }
                    else
                    {
                        obj.hotkeyshfit = true;
                    }
                    if (dr["hotkeyalt"].ToString() == "")
                    {
                        obj.hotkeyalt = false;
                    }
                    else
                    {
                        obj.hotkeyalt = true;
                    }

                    this._hotkey.Add(int.Parse(dr["hotkeyIndex"].ToString()), obj);
                    //_hotkeyItems.Add(dr["function"].ToString(), obj);
                }
            }
            return true;
        }

        //private bool chkFocus()
        //{

        //    if (AEFutureMaster.frmMain.mobj_DataAgent.V_frmFuture != null)
        //    {
        //        UI.MarketInfo.frmFuture frm = (UI.MarketInfo.frmFuture)AEFutureMaster.frmMain.mobj_DataAgent.V_frmFuture;
        //        if (frm.ContainsFocus == true) return true;
        //    }
        //    if (AEFutureMaster.frmMain.mobj_DataAgent.V_frmOption != null)
        //    {
        //        UI.MarketInfo.frmOption frm = (UI.MarketInfo.frmOption)AEFutureMaster.frmMain.mobj_DataAgent.V_frmOption;
        //        if (frm.ContainsFocus == true) return true;

        //    }
        //    if (AEFutureMaster.frmMain.mobj_DataAgent.V_frmInfoDetail != null)
        //    {
        //        UI.MarketInfo.frmInfoDetail frm = (UI.MarketInfo.frmInfoDetail)AEFutureMaster.frmMain.mobj_DataAgent.V_frmInfoDetail;

        //        if (frm.ContainsFocus == true) return true;
        //    }
        //    if (AEFutureMaster.frmMain.mobj_DataAgent.V_frmOrderReply != null)
        //    {
        //        UI.Reply.frmOrderReply frm = (UI.Reply.frmOrderReply)AEFutureMaster.frmMain.mobj_DataAgent.V_frmOrderReply;
        //        if (frm.ContainsFocus == true) return true;
        //    }
        //    if (AEFutureMaster.frmMain.mobj_DataAgent.V_frmMatchReply != null)
        //    {
        //        UI.Reply.frmMatchReply frm = (UI.Reply.frmMatchReply)AEFutureMaster.frmMain.mobj_DataAgent.V_frmMatchReply;
        //        if (frm.ContainsFocus == true) return true;
        //    }
        //    if (AEFutureMaster.frmMain.mobj_DataAgent.V_frmMultipleFuture != null)
        //    {
        //        UI.MarketInfo.frmMultipleFuture frm = (UI.MarketInfo.frmMultipleFuture)AEFutureMaster.frmMain.mobj_DataAgent.V_frmMultipleFuture;
        //        if (frm.ContainsFocus == true) return true;
        //    }
        //    if (AEFutureMaster.frmMain.mobj_DataAgent.V_InfoTradeCollection != null)
        //    {
        //        if (AEFutureMaster.frmMain.mobj_DataAgent.V_InfoTradeCollection.Count != 0)
        //        {
        //            foreach (string key in AEFutureMaster.frmMain.mobj_DataAgent.V_InfoTradeCollection.Keys)
        //            {
        //                //20090424�令��lcollection
        //                Hashtable obj = (Hashtable)frmMain.mobj_DataAgent.V_InfoTradeCollection[key];
        //                foreach (string objkey in obj.Keys)
        //                {

        //                    UI.Order.frmInfoTrade frm = (UI.Order.frmInfoTrade)obj[objkey];
        //                    if (frm.ContainsFocus == true) return true;
        //                }
        //            }
        //        }
        //    }
        //    if (AEFutureMaster.frmMain.mobj_DataAgent.V_frmUrldeposit != null)
        //    {
        //        UI.Risk.frmUrldeposit frm = (UI.Risk.frmUrldeposit)AEFutureMaster.frmMain.mobj_DataAgent.V_frmUrldeposit;
        //        if (frm.ContainsFocus == true) return true;
        //    }
        //    if (AEFutureMaster.frmMain.mobj_DataAgent.V_frmUrldepositQuery != null)
        //    {
        //        UI.Risk.frmUrldepositQuery frm = (UI.Risk.frmUrldepositQuery)AEFutureMaster.frmMain.mobj_DataAgent.V_frmUrldepositQuery;
        //        if (frm.ContainsFocus == true) return true;
        //    }
        //    if (AEFutureMaster.frmMain.mobj_DataAgent.V_frmUrlMessage != null)
        //    {
        //        UI.Risk.frmUrlMessage frm = (UI.Risk.frmUrlMessage)AEFutureMaster.frmMain.mobj_DataAgent.V_frmUrlMessage;
        //        if (frm.ContainsFocus == true) return true;
        //    }
        //    if (AEFutureMaster.frmMain.mobj_DataAgent.V_frmUrlposition != null)
        //    {
        //        UI.Risk.frmUrlposition frm = (UI.Risk.frmUrlposition)AEFutureMaster.frmMain.mobj_DataAgent.V_frmUrlposition;
        //        if (frm.ContainsFocus == true) return true;
        //    }
        //    if (AEFutureMaster.frmMain.mobj_DataAgent.V_frmUrlpositionQuery != null)
        //    {
        //        UI.Risk.frmUrlpositionQuery frm = (UI.Risk.frmUrlpositionQuery)AEFutureMaster.frmMain.mobj_DataAgent.V_frmUrlpositionQuery;
        //        if (frm.ContainsFocus == true) return true;
        //    }
        //    if (AEFutureMaster.frmMain.mobj_DataAgent.V_frmUrlremit != null)
        //    {
        //        UI.Risk.frmUrlremit frm = (UI.Risk.frmUrlremit)AEFutureMaster.frmMain.mobj_DataAgent.V_frmUrlremit;
        //        if (frm.ContainsFocus == true) return true;
        //    }
        //    if (AEFutureMaster.frmMain.mobj_DataAgent.V_frmUrlremitQuery != null)
        //    {
        //        UI.Risk.frmUrlremitQuery frm = (UI.Risk.frmUrlremitQuery)AEFutureMaster.frmMain.mobj_DataAgent.V_frmUrlremitQuery;
        //        if (frm.ContainsFocus == true) return true;
        //    }
        //    if (AEFutureMaster.frmMain.mobj_DataAgent.V_frmUrlreport != null)
        //    {
        //        UI.Risk.frmUrlreport frm = (UI.Risk.frmUrlreport)AEFutureMaster.frmMain.mobj_DataAgent.V_frmUrlreport;
        //        if (frm.ContainsFocus == true) return true;
        //    }

        //    if (AEFutureMaster.frmMain.mobj_DataAgent.V_frmAccountBook != null)
        //    {
        //        AEFutureMaster.Base.frmAccountBook frm = (AEFutureMaster.Base.frmAccountBook)AEFutureMaster.frmMain.mobj_DataAgent.V_frmAccountBook;
        //        if (frm.ContainsFocus == true) return true;

        //    }
        //    //20090603 add by Irving
        //    if (AEFutureMaster.frmMain.mobj_DataAgent.V_frmChoseInfo != null)
        //    {
        //        AEFutureMaster.UI.MarketInfo.frmChoseInfo frm = (AEFutureMaster.UI.MarketInfo.frmChoseInfo)AEFutureMaster.frmMain.mobj_DataAgent.V_frmChoseInfo;
        //        if (frm.ContainsFocus == true) return true;
        //    }
        //    return false;
        //}

        public void m_actHook_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                int KeyValue = e.KeyValue + (e.Control == true ? (int)Keys.Control : 0)
                                  + (e.Shift == true ? (int)Keys.Shift : 0)
                                  + (e.Alt == true ? (int)Keys.Alt : 0);

                if (e.KeyCode == Keys.ControlKey)
                    KeyValue = (int)Keys.Control;

                if (e.KeyCode == Keys.ShiftKey)
                    KeyValue = (int)Keys.Shift;

                if (e.KeyCode == Keys.Alt)
                    KeyValue = (int)Keys.Alt;

                if (this._hotkey.ContainsKey(KeyValue))
                {

                    this._hotkey[KeyValue].raiseKeyUp();
                }
            }

            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("HotKeyManagerLog", "m_actHook_KeyUp:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        private void m_actHook_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {

                int KeyValue = e.KeyValue + (e.Control == true ? (int)Keys.Control : 0)
                    + (e.Shift == true ? (int)Keys.Shift : 0)
                    + (e.Alt == true ? (int)Keys.Alt : 0);

                if (e.KeyCode == Keys.ControlKey)
                    KeyValue = (int)Keys.Control;

                if (e.KeyCode == Keys.ShiftKey)
                    KeyValue = (int)Keys.Shift;

                if (e.KeyCode == Keys.Alt)
                    KeyValue = (int)Keys.Alt;
                if (this._hotkey.ContainsKey(KeyValue))
                {

                    this._hotkey[KeyValue].raiseKeyDown();
                }
            }

            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("HotKeyManagerLog", "m_actHook_KeyDown:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }


        public void setItemKeyValue(string functionId, int hotkeykey, bool hotkeycontrol, bool hotkeyshfit, bool hotkeyalt, string hotKeyValue)
        {
            try
            {
                string hotkeyText = ((Keys)hotkeykey).ToString();
                DataRow[] dr = _dt.Select("function ='" + functionId + "'");
                if (dr.Length > 0)
                {


                    dr[0].BeginEdit();
                    dr[0]["hotkeykey"] = hotkeykey;
                    string value = hotkeyText;
                    int tmpKey = hotkeykey;


                    if (hotkeycontrol)
                    {
                        dr[0]["hotkeycontrol"] = "+ Ctrl";
                        value += "+ Ctrl";
                        tmpKey = tmpKey + (int)Keys.Control;
                    }
                    else
                    {
                        dr[0]["hotkeycontrol"] = "";
                    }
                    if (hotkeyshfit)
                    {
                        value += "+ Shift";
                        tmpKey = tmpKey + (int)Keys.Shift;
                        dr[0]["hotkeyshfit"] = "+ Shfit";
                    }
                    else
                    {
                        dr[0]["hotkeyshfit"] = "";
                    }
                    if (hotkeyalt)
                    {
                        value += "+ Alt";
                        tmpKey = tmpKey + (int)Keys.Alt;
                        dr[0]["hotkeyalt"] = "+ Alt";
                    }
                    else
                    {
                        dr[0]["hotkeyalt"] = "";
                    }
                    dr[0]["hotkey"] = value;
                    dr[0]["hotkeyIndex"] = tmpKey;
                    dr[0]["value"] = hotKeyValue;
                    DataRow[] drFinds = _dt.Select("function<>'" + functionId + "'and hotkeyIndex='" + tmpKey.ToString() + "' ");
                    if (drFinds.Length == 0)
                    {

                        dr[0].EndEdit();

                        excuteData();
                    }
                    else
                    {
                        dr[0].CancelEdit();

                        VIPTradingSystem.MYcls.CommonFunction.ShowMessageBox(null,"", "�ֳt�䭫��!");  
                  
                    }
                }
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("HotKeyManagerLog", "setItemKeyValue:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        public void addItem(string functionId, int hotkeykey, bool hotkeycontrol, bool hotkeyshfit, bool hotkeyalt, string hotKeyValue)
        {
            try
            {
                string hotkeyText = ((Keys)hotkeykey).ToString();
                DataRow[] dr = _dt.Select("function ='" + functionId + "'");
                if (dr.Length == 0)
                {
                    DataRow drNew = _dt.NewRow();
                    drNew["userid"] = frmMain.UserConfigs.LoginID;
                    drNew["function"] = functionId;
                    drNew["hotkeykey"] = hotkeykey;
                    string value = hotkeyText;
                    int tmpKey = hotkeykey;


                    if (hotkeycontrol)
                    {
                        drNew["hotkeycontrol"] = "+ Ctrl";
                        value += "+ Ctrl";
                        tmpKey = tmpKey + (int)Keys.Control;
                    }
                    else
                    {
                        drNew["hotkeycontrol"] = "";
                    }
                    if (hotkeyshfit)
                    {
                        value += "+ Shift";
                        tmpKey = tmpKey + (int)Keys.Shift;
                        drNew["hotkeyshfit"] = "+ Shfit";
                    }
                    else
                    {
                        drNew["hotkeyshfit"] = "";
                    }
                    if (hotkeyalt)
                    {
                        value += "+ Alt";
                        tmpKey = tmpKey + (int)Keys.Alt;
                        drNew["hotkeyalt"] = "+ Alt";
                    }
                    else
                    {
                        drNew["hotkeyalt"] = "";
                    }
                    drNew["hotkey"] = value;
                    drNew["hotkeyIndex"] = tmpKey;
                    drNew["value"] = hotKeyValue;
                    drNew["index"] = _dt.Rows.Count;
                    DataRow[] drFinds = _dt.Select("function<>'" + functionId + "'and hotkeyIndex='" + tmpKey.ToString() + "' ");
                    if (drFinds.Length == 0)
                    {

                        _dt.Rows.Add(drNew);
                        HotKeyItem item = new HotKeyItem();
                        item.functionId = functionId;
                        _hotkeyItems.Add(functionId, item);

                        excuteData();
                    }
                    else
                    {
                        VIPTradingSystem.MYcls.CommonFunction.ShowMessageBox(null, "", "�ֳt�䭫��!");  
                     
                    }

                }
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("HotKeyManagerLog", "addItem:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        public void removeItem(string functionId)
        {
            try
            {
                DataRow[] dr = _dt.Select("function ='" + functionId + "'");
                if (dr.Length > 0)
                {
                    //dr[0].Delete();
                    _dt.Rows.Remove(dr[0]);
                    _hotkeyItems.Remove(functionId);

                    excuteData();
                }
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("HotKeyManagerLog", "removeItem:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        public HotKeyItem getItem(string functionId)
        {
            HotKeyItem obj = _hotkeyItems[functionId];
            return obj;
        }

    }
    public class HotKeyItem
    {
        private string _functionId;
        private int _hotkeykey;
        private string _hotkeyText;
        private string _value;
        private bool _hotkeycontrol;
        private bool _hotkeyshfit;
        private bool _hotkeyalt;

        public string functionId
        {
            set { this._functionId = value; }
            get { return this._functionId; }
        }
        public string hotkeyText
        {
            set { this._hotkeyText = value; }
            get { return this._hotkeyText; }
        }
        public string value
        {
            set { this._value = value; }
            get { return this._value; }
        }
        public int hotkeykey
        {
            set { this._hotkeykey = value; }
            get { return this._hotkeykey; }
        }
        public bool hotkeycontrol
        {
            set { this._hotkeycontrol = value; }
            get { return this._hotkeycontrol; }
        }
        public bool hotkeyshfit
        {
            set { this._hotkeyshfit = value; }
            get { return this._hotkeyshfit; }
        }
        public bool hotkeyalt
        {
            set { this._hotkeyalt = value; }
            get { return this._hotkeyalt; }
        }
        public struct HotKeyEventArgs
        {
            public string _functionId;
            public int _hotkeykey;
            public string _hotkeyText;
            public string _value;
            public bool _hotkeycontrol;
            public bool _hotkeyshfit;
            public bool _hotkeyalt;

        }
        public delegate
  void KeyDownCallback(HotKeyEventArgs e);
        public event KeyDownCallback _KeyDown;

        public delegate
void KeyUpCallback(HotKeyEventArgs e);
        public event KeyUpCallback _KeyUp;
        public HotKeyItem()
        {
        }
        public void raiseKeyDown()
        {
            HotKeyEventArgs ee = new HotKeyEventArgs();
            ee._functionId = _functionId;
            ee._hotkeyalt = _hotkeyalt;
            ee._hotkeycontrol = _hotkeycontrol;
            ee._hotkeykey = _hotkeykey;
            ee._hotkeyshfit = _hotkeyshfit;
            ee._hotkeyText = _hotkeyText;
            ee._value = _value;
            if (_KeyDown != null)
            {
                _KeyDown(ee);
            }
        }
        public void raiseKeyUp()
        {
            HotKeyEventArgs ee = new HotKeyEventArgs();
            ee._functionId = _functionId;
            ee._hotkeyalt = _hotkeyalt;
            ee._hotkeycontrol = _hotkeycontrol;
            ee._hotkeykey = _hotkeykey;
            ee._hotkeyshfit = _hotkeyshfit;
            ee._hotkeyText = _hotkeyText;
            ee._value = _value;
            if (_KeyUp != null)
            {
                _KeyUp(ee);
            }
        }
    }
}
