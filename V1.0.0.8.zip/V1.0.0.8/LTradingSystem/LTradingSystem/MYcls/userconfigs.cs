﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.IO;
namespace VIPTradingSystem.MYcls
{
    [Serializable]
    public class userconfigs
    {
        public string ServerDateTime = "";
        public string ClearDataDate = "";
        public string ClearDataTime = "";




        /// <summary>
        /// 正式機旗標
        /// </summary>
        public bool MASTER = true;
        /// <summary>
        /// 回報分頁筆數
        /// </summary>
        public const int PAGECOUNT = 50;
        /// <summary>
        /// 手續費設定檔
        /// </summary>
        private DataTable mdtFBMNFE;
        /// <summary>
        /// 連線設定檔
        /// </summary>
        private DataTable mdtServerSet;
        /// <summary>
        /// 組合設定檔
        /// </summary>
        private DataTable mdtCollectionSet;
        /// <summary>
        /// 版面設定檔
        /// </summary>
        private DataTable mdtFORM_SET;
        /// <summary>
        /// 下單帳號檔
        /// </summary>
        private DataTable mdtAccountData;

        /// <summary>
        /// 群組設定檔
        /// </summary>
        private DataTable mdtGroupAccountSet;
        /// <summary>
        /// 登入主機設定檔
        /// </summary>
        private System.Data.DataTable mdtLoginServerSet;
        /// <summary>
        /// 批次群組設定
        /// </summary>
        private System.Data.DataTable mdtBatchGroup;
        /// <summary>
        /// 批次下單設定
        /// </summary>
        private System.Data.DataTable mdtBatchOrderSet;

        /// <summary>
        /// 登入身份證字號
        /// </summary>
        private string mstr_loginid;
        /// <summary>
        /// 登入交易帳號
        /// </summary>
        private string mstr_loginacno;
        /// <summary>
        /// 使用者分公司
        /// </summary>
        private string mstr_company = "";
        /// <summary>
        /// 營業員帳號
        /// </summary>
        private string mstr_AENO;
        /// <summary>
        /// 是否可交易
        /// </summary>
        private bool mbol_EnabledOrder;
        /// <summary>
        /// 是否簽章
        /// </summary>
        private bool mbol_EnabledCA;

        /// <summary>
        /// 使用者快速鍵
        /// </summary>
        private DataTable mdtUser_HotKeySet;
        /// <summary>
        /// 使用者密碼
        /// </summary>
        private string mstr_PW;
        /// <summary>
        /// 部門別
        /// </summary>
        private string mstr_GROUPID;
        /// <summary>
        /// 使用者類型
        /// </summary>
        private string mstr_USERKIND;
        /// <summary>
        /// 群組最多帳號
        /// </summary>
        private int mint_MaxGroupAccountsCount;
        /// <summary>
        /// 允許使用者修改show下單提示
        /// </summary>
        private bool mbol_EnabledChangeShowMsg;
        /// <summary>
        /// 預設下單群組
        /// </summary>
        /// <value>群組GroupSelect帳號AccountEnter</value>
        private string mstr_DefualtGroupSelect = "GroupSelect";
        /// <summary>
        /// 預設買進顏色
        /// </summary>
        /// <value>ARGB 值</value>
        private int mint_DefualtBuyBackColor = System.Drawing.Color.FromArgb(255, 166, 166).ToArgb();

        /// <summary>
        /// 預設賣出顏色
        /// </summary>
        /// <value>ARGB 值</value>
        private int mint_DefualtSellBackColor = System.Drawing.Color.FromArgb(80, 230, 80).ToArgb();

        /// <summary>
        /// 預設複式單顏色
        /// </summary>
        /// <value>ARGB 值</value>
        private int mint_DefualtMultiBackColor = System.Drawing.Color.Purple.ToArgb();
        /// <summary>
        /// 預設焦點位置
        /// </summary>
        /// <value>數量Q價格P</value>
        private string mstr_DefualtHOFocus = "P";
        /// <summary>
        /// 記憶下單單價
        /// </summary>
        /// <value>記憶True不記憶False</value>
        private bool mbol_MemoryPrice = false;
        /// <summary>
        /// 記憶下單數量
        /// </summary>
        /// <value>記憶True不記憶False</value>
        private bool mbol_MemoryQty = false;
        /// <summary>
        /// 記憶下單商品
        /// </summary>
        /// <value>記憶True不記憶False</value>
        private bool mbol_MemoryProduct = true;
        /// <summary>
        /// 記憶下單委託條件
        /// </summary>
        /// <value>記憶True不記憶False</value>
        private bool mbol_MemoryCondition = true;
        /// <summary>
        /// 記憶下單新平倉碼
        /// </summary>
        /// <value>記憶True不記憶False</value>
        private bool mbol_MemoryOSFlag = true;
        /// <summary>
        /// 記憶下單BS
        /// </summary>
        /// <value>記憶True不記憶False</value>
        private bool mbol_MemoryBS = true;
        /// <summary>
        /// 記憶下單來源別
        /// </summary>
        /// <value>記憶True不記憶False</value>
        private bool mbol_MemorySourceType = true;
        /// <summary>
        /// 記憶當沖
        /// </summary>
        /// <value>記憶True不記憶False</value>
        private bool mbol_MemoryDTrade = true;
        /// <summary>
        /// 顯示下單確認
        /// </summary>
        /// <value>顯示True不顯示False</value>
        private bool mbol_ShowOrderMsg = true;
        /// <summary>
        /// 下單帳號是否與快速帳務查詢的帳號同步
        /// </summary>
        /// <value>同步True不同步False</value>
        private bool mbol_SyncAccount = true;

        /// <summary>
        /// 下單帳號是否與委回和成回查詢的帳號同步
        /// </summary>
        /// <value>同步True不同步False</value>
        private bool mbol_SyncReply = true;

        /// <summary>
        /// 點報價下單依賣賣價帶預設買賣別
        /// </summary>
        /// <value>B:點選買進價格帶買進,賣出價格帶賣出;S:點選買進價格帶賣出,賣出價格帶買進</value>
        private string mstr_QuickOrderBS = "B";
        /// <summary>
        /// 自設匯出Excel存檔路徑
        /// </summary>
        /// <value>路徑位置</value>
        private string mstr_ExcelPath = "桌面";
        /// <summary>
        /// 自選商品設定資料
        /// </summary>
        private DataTable mdtChoseInfoProductSet;
        /// <summary>
        /// 自選商品群組設定資料
        /// </summary>
        private System.Data.DataTable mdtChoseInfoGroupSet;
        /// <summary>
        /// 營業員帳號
        /// </summary>
        private System.Data.DataTable mdtAE;
        /// <summary>
        /// 部門資料
        /// </summary>
        private System.Data.DataTable mdtGroup;
        /// <summary>
        /// 分公司資料
        /// </summary>
        private System.Data.DataTable mdtCompany;

        private string mstr_Quantity;
        private string mstr_LogDate;
        private string mstr_LogTime;

        private bool mbol_ORDERMSG;//	委託確認訊息
        private bool mbol_CANCELORDERMSG;//	刪單確認訊息
        private bool mbol_ORDERERRORMSG;//	委託失敗訊息
        private bool mbol_CANCELERRORMSG;//	刪單失敗訊息
        private bool mbol_R_SOUND;//	播放委託回報音效
        private byte[] mstr_R_SOUND_FILE = new byte[0];//	委託回報音效
        private bool mbol_M_SOUND;//	播放成交回報音效
        private byte[] mstr_M_SOUND_FILE = new byte[0];//	成交回報音效
        private bool mbol_MOVEBACKCOLOR;//	滑鼠移動呈現底色
        private string mstr_LEFTCLICKORDER;//	滑鼠左鍵下單
        private bool mbol_A_TIME;//	啟用報時
        private int mint_A_TIME_MINUTES;//	報時間隔分鐘
        private int mint_A_TIME_SECONDS;//	報時提醒秒鐘
        private bool mbol_PROFIT;//	啟動均價及損益
        private string mstr_PROFI_BASE;//	損益計算基準
        private bool mbol_MAX_MIN;//	啟用最高最低價
        private bool mbol_MARKETQTY;//	啟用市場成交量
        private bool mbol_COMMNO_CLICK;//	啟用快速商品切換
        private bool mbol_CANCEL_SYNC;//	同步刪除條件單
        private int mint_FONT_SIZE;//	字型大小
        private int mint_ROW_HEIGHT;//	欄位高度
        private int mint_PRICE_WIDTH;//	價格寬度
        private int mint_MKQ_WIDTH;//	市場數量寬度
        private int mint_WQ_WIDTH;//	Working數量寬度
        private int mint_MHQ_WIDTH;//	成交數量寬度
        private int mint_MITQ_WIDTH;//	MIT數量寬度
        private string mstr_MPRICE_FONTCOLOR;//	成交價字型
        private string mstr_MPRICE_BACKCOLOR;//	成交價背景
        private string mstr_PRICE_FONTCOLOR;//	價格字型
        private string mstr_PRICE_BACKCOLOR;//	價格背景
        private string mstr_WB_FONTCOLOR;//	Working買量字型
        private string mstr_WB_BACKCOLOR;//	Working買量背景
        private string mstr_WS_FONTCOLOR;//	Working賣量字型
        private string mstr_WS_BACKCOLOR;//	Working賣量背景
        private string mstr_MB_FONTCOLOR;//	市場買量字型
        private string mstr_MB_BACKCOLOR;//	市場買量背景
        private string mstr_MS_FONTCOLOR;//	市場賣量字型
        private string mstr_MS_BACKCOLOR;//	市場賣量背景
        private string mstr_BM_FONTCOLOR;//	買進成交字型
        private string mstr_BM_BACKCOLOR;//	買進成交背景
        private string mstr_SM_FONTCOLOR;//	賣出成交字型
        private string mstr_SM_BACKCOLOR;//	賣出成交背景
        private string mstr_TMB_FONTCOLOR;//	市場總買量字型
        private string mstr_TMB_BACKCOLOR;//	市場總買量背景
        private string mstr_TMS_FONTCOLOR;//	市場總賣量字型
        private string mstr_TMS_BACKCOLOR;//	市場總賣量背景
        private string mstr_TBM_FONTCOLOR;//	買進成交總量字型
        private string mstr_TBM_BACKCOLOR;//	買進成交總量背景
        private string mstr_TSM_FONTCOLOR;//	賣出成交總量字型
        private string mstr_TSM_BACKCOLOR;//	賣出成交總量背景
        private string mstr_TWB_FONTCOLOR;//	Working總買量字型
        private string mstr_TWB_BACKCOLOR;//	Working總買量背景
        private string mstr_TWS_FONTCOLOR;//	Working總賣量字型
        private string mstr_TWS_BACKCOLOR;//	Working總賣量背景
        private string mstr_M5B_FONTCOLOR;//	五檔買量字型
        private string mstr_M5B_BACKCOLOR;//	五檔買量背景
        private string mstr_M5S_FONTCOLOR;//	五檔賣量字型
        private string mstr_M5S_BACKCOLOR;//	五檔賣量背景
        private string mstr_MIT_BACKCOLOR;//	條件式下單選項背景
        private string mstr_BT_FONTCOLOR;//	報時字型
        private string mstr_BT_BACKCOLOR;//	報時背景
        private string mstr_AT_FONTCOLOR;//	報時提醒字型
        private string mstr_AT_BACKCOLOR;//	報時提醒背景
        private string mstr_MAX_BACKCOLOR;//	最高價背景
        private string mstr_MIN_BACKCOLOR;//	最低價背景
        private bool mbol_QTY_HOTKEY1;//	啟用口數快速鍵1
        private string mstr_QTY_HOTKEY_KEY1;//	口數快速鍵值1
        private int mint_QTY_HOTKEY_VALUE1;//	口數快速鍵口數1
        private bool mbol_QTY_HOTKEY2;//	啟用口數快速鍵2
        private string mstr_QTY_HOTKEY_KEY2;//	口數快速鍵值2
        private int mint_QTY_HOTKEY_VALUE2;//	口數快速鍵口數2
        private bool mbol_QTY_HOTKEY3;//	啟用口數快速鍵3
        private string mstr_QTY_HOTKEY_KEY3;//	口數快速鍵值3
        private int mint_QTY_HOTKEY_VALUE3;//	口數快速鍵口數3
        private bool mbol_QTY_HOTKEY4;//	啟用口數快速鍵4
        private string mstr_QTY_HOTKEY_KEY4;//	口數快速鍵值4
        private int mint_QTY_HOTKEY_VALUE4;//	口數快速鍵口數4
        private bool mbol_QTY_HOTKEY5;//	啟用口數快速鍵5
        private string mstr_QTY_HOTKEY_KEY5;//	口數快速鍵值5
        private int mint_QTY_HOTKEY_VALUE5;//	口數快速鍵口數5
        private bool mbol_MP_HOTKEY;//	啟用市價快速鍵
        private string mstr_MP_HOTKEY_BKEY;//	市價買進快速鍵值
        private string mstr_MP_HOTKEY_SKEY;//	市價賣出快速鍵值
        private bool mbol_CA_HOTKEY;//	啟用全部刪單快速鍵
        private string mstr_CA_HOTKEY_KEY;//	全部刪單快速鍵值
        private bool mbol_MIT_HOTKEY;//	啟用MIT刪單快速鍵
        private string mstr_MIT_HOTKEY_KEY;//	MIT刪單快速鍵值
        private bool mbol_BM_HOTKEY;//	啟用市價反向平倉快速鍵
        private string mstr_BM_HOTKEY_KEY;//	市價反向平倉快速鍵值
        private string mstr_BM_HOTKEY_VALUE;//	反向平倉預設價格
        private int mint_BM_HOTKEY_BTICK;//	反向平倉限價Tick BUY
        private int mint_BM_HOTKEY_STICK;//	反向平倉限價Tick SELL
        private bool mbol_NUMER_KEYBOARD;//	啟動數字鍵盤特殊功能

        private bool mbol_ENABLED_QTY;//	啟動口數bar
        private string mstr_DIPLAYACCOLUMNS;
        private bool mbol_SHOWACHEADER;
        private string mstr_FONT_NAME;
        private string mstr_FONT_STYLE;

        public bool DEFAULT_ORDERMSG = true;//	委託確認訊息
        public bool DEFAULT_CANCELORDERMSG = true;//	刪單確認訊息
        public bool DEFAULT_ORDERERRORMSG = true;//	委託失敗訊息
        public bool DEFAULT_CANCELERRORMSG = true;//	刪單失敗訊息
        public bool DEFAULT_R_SOUND = true;//	播放委託回報音效
        public string DEFAULT_R_SOUND_FILENAME = AppDomain.CurrentDomain.BaseDirectory.ToString().TrimEnd() + @"\sound\Windows XP 叮咚.wav";//	委託回報音效檔名 
        public bool DEFAULT_M_SOUND = true;//	播放成交回報音效
        public string DEFAULT_M_SOUND_FILENAME = AppDomain.CurrentDomain.BaseDirectory.ToString().TrimEnd() + @"\sound\Windows XP 列印完成.wav";//	成交回報音效檔名
        public bool DEFAULT_MOVEBACKCOLOR = false;//	滑鼠移動呈現底色
        public string DEFAULT_LEFTCLICKORDER = "1";//	滑鼠左鍵下單
        public bool DEFAULT_A_TIME = true;//	啟用報時
        public int DEFAULT_A_TIME_MINUTES = 1;//	報時間隔分鐘
        public int DEFAULT_A_TIME_SECONDS = 3;//	報時提醒秒鐘
        public bool DEFAULT_PROFIT = true;//	啟動均價及損益
        public string DEFAULT_PROFI_BASE = "M";//	損益計算基準
        public bool DEFAULT_MAX_MIN = true;//	啟用最高最低價
        public bool DEFAULT_MARKETQTY = true;//	啟用市場成交量
        public bool DEFAULT_COMMNO_CLICK = false;//	啟用快速商品切換
        public bool DEFAULT_CANCEL_SYNC = false;//	同步刪除條件單
        public int DEFAULT_FONT_SIZE = 11;//	字型大小
        public int DEFAULT_ROW_HEIGHT = 20;//	欄位高度
        public int DEFAULT_PRICE_WIDTH = 63;//	價格寬度
        public int DEFAULT_MKQ_WIDTH = 35;//	市場數量寬度
        public int DEFAULT_WQ_WIDTH = 35;//	Working數量寬度
        public int DEFAULT_MHQ_WIDTH = 35;//	成交數量寬度
        public int DEFAULT_MITQ_WIDTH = 35;//	MIT數量寬度
        public string DEFAULT_MPRICE_FONTCOLOR = MYcls.CommonFunction.getARGBString(System.Drawing.Color.Red);//	成交價字型
        public string DEFAULT_MPRICE_BACKCOLOR = MYcls.CommonFunction.getARGBString(System.Drawing.Color.Yellow);//	成交價背景
        public string DEFAULT_PRICE_FONTCOLOR = MYcls.CommonFunction.getARGBString(System.Drawing.Color.Black);//	價格字型
        public string DEFAULT_PRICE_BACKCOLOR = MYcls.CommonFunction.getARGBString(System.Drawing.Color.LightYellow);//	價格背景
        public string DEFAULT_WB_FONTCOLOR = MYcls.CommonFunction.getARGBString(System.Drawing.Color.Black);//	Working買量字型
        public string DEFAULT_WB_BACKCOLOR = MYcls.CommonFunction.getARGBString(System.Drawing.Color.White);//	Working買量背景
        public string DEFAULT_WS_FONTCOLOR = MYcls.CommonFunction.getARGBString(System.Drawing.Color.Black);//	Working賣量字型
        public string DEFAULT_WS_BACKCOLOR = MYcls.CommonFunction.getARGBString(System.Drawing.Color.White);//	Working賣量背景
        public string DEFAULT_MB_FONTCOLOR = MYcls.CommonFunction.getARGBString(System.Drawing.Color.Red);//	市場買量字型
        public string DEFAULT_MB_BACKCOLOR = MYcls.CommonFunction.getARGBString(System.Drawing.Color.White);//	市場買量背景
        public string DEFAULT_MS_FONTCOLOR = MYcls.CommonFunction.getARGBString(System.Drawing.Color.Green);//	市場賣量字型
        public string DEFAULT_MS_BACKCOLOR = MYcls.CommonFunction.getARGBString(System.Drawing.Color.White);//	市場賣量背景
        public string DEFAULT_BM_FONTCOLOR = MYcls.CommonFunction.getARGBString(System.Drawing.Color.Black);//	買進成交字型
        public string DEFAULT_BM_BACKCOLOR = MYcls.CommonFunction.getARGBString(System.Drawing.Color.White);//	買進成交背景
        public string DEFAULT_SM_FONTCOLOR = MYcls.CommonFunction.getARGBString(System.Drawing.Color.Black);//	賣出成交字型
        public string DEFAULT_SM_BACKCOLOR = MYcls.CommonFunction.getARGBString(System.Drawing.Color.White);//	賣出成交背景
        public string DEFAULT_TMB_FONTCOLOR = MYcls.CommonFunction.getARGBString(System.Drawing.Color.Black);//	市場總買量字型
        public string DEFAULT_TMB_BACKCOLOR = MYcls.CommonFunction.getARGBString(System.Drawing.Color.White);//	市場總買量背景
        public string DEFAULT_TMS_FONTCOLOR = MYcls.CommonFunction.getARGBString(System.Drawing.Color.Black);//	市場總賣量字型
        public string DEFAULT_TMS_BACKCOLOR = MYcls.CommonFunction.getARGBString(System.Drawing.Color.White);//	市場總賣量背景
        public string DEFAULT_TBM_FONTCOLOR = MYcls.CommonFunction.getARGBString(System.Drawing.Color.Black);//	買進成交總量字型
        public string DEFAULT_TBM_BACKCOLOR = MYcls.CommonFunction.getARGBString(System.Drawing.Color.White);//	買進成交總量背景
        public string DEFAULT_TSM_FONTCOLOR = MYcls.CommonFunction.getARGBString(System.Drawing.Color.Black);//	賣出成交總量字型
        public string DEFAULT_TSM_BACKCOLOR = MYcls.CommonFunction.getARGBString(System.Drawing.Color.White);//	賣出成交總量背景
        public string DEFAULT_TWB_FONTCOLOR = MYcls.CommonFunction.getARGBString(System.Drawing.Color.Black);//	Working總買量字型
        public string DEFAULT_TWB_BACKCOLOR = MYcls.CommonFunction.getARGBString(System.Drawing.Color.White);//	Working總買量背景
        public string DEFAULT_TWS_FONTCOLOR = MYcls.CommonFunction.getARGBString(System.Drawing.Color.Black);//	Working總賣量字型
        public string DEFAULT_TWS_BACKCOLOR = MYcls.CommonFunction.getARGBString(System.Drawing.Color.White);//	Working總賣量背景
        public string DEFAULT_M5B_FONTCOLOR = MYcls.CommonFunction.getARGBString(System.Drawing.Color.Red);//	五檔買量字型
        public string DEFAULT_M5B_BACKCOLOR = MYcls.CommonFunction.getARGBString(System.Drawing.Color.Wheat);//	五檔買量背景
        public string DEFAULT_M5S_FONTCOLOR = MYcls.CommonFunction.getARGBString(System.Drawing.Color.Green);//	五檔賣量字型
        public string DEFAULT_M5S_BACKCOLOR = MYcls.CommonFunction.getARGBString(System.Drawing.Color.Wheat);//	五檔賣量背景
        public string DEFAULT_MIT_BACKCOLOR = MYcls.CommonFunction.getARGBString(System.Drawing.Color.Yellow);//	條件式下單選項背景
        public string DEFAULT_BT_FONTCOLOR = MYcls.CommonFunction.getARGBString(System.Drawing.Color.Black);//	報時字型
        public string DEFAULT_BT_BACKCOLOR = MYcls.CommonFunction.getARGBString(System.Drawing.Color.Gray);//	報時背景
        public string DEFAULT_AT_FONTCOLOR = MYcls.CommonFunction.getARGBString(System.Drawing.Color.Black);//	報時提醒字型
        public string DEFAULT_AT_BACKCOLOR = MYcls.CommonFunction.getARGBString(System.Drawing.Color.Red);//	報時提醒背景
        public string DEFAULT_MAX_BACKCOLOR = MYcls.CommonFunction.getARGBString(System.Drawing.Color.Red);//	最高價背景
        public string DEFAULT_MIN_BACKCOLOR = MYcls.CommonFunction.getARGBString(System.Drawing.Color.Green);//	最低價背景
        public bool DEFAULT_QTY_HOTKEY1 = false;//	啟用口數快速鍵1
        public string DEFAULT_QTY_HOTKEY_KEY1;//	口數快速鍵值1
        public int DEFAULT_QTY_HOTKEY_VALUE1;//	口數快速鍵口數1
        public bool DEFAULT_QTY_HOTKEY2 = false;//	啟用口數快速鍵2
        public string DEFAULT_QTY_HOTKEY_KEY2;//	口數快速鍵值2
        public int DEFAULT_QTY_HOTKEY_VALUE2;//	口數快速鍵口數2
        public bool DEFAULT_QTY_HOTKEY3 = false;//	啟用口數快速鍵3
        public string DEFAULT_QTY_HOTKEY_KEY3;//	口數快速鍵值3
        public int DEFAULT_QTY_HOTKEY_VALUE3;//	口數快速鍵口數3
        public bool DEFAULT_QTY_HOTKEY4 = false;//	啟用口數快速鍵4
        public string DEFAULT_QTY_HOTKEY_KEY4;//	口數快速鍵值4
        public int DEFAULT_QTY_HOTKEY_VALUE4;//	口數快速鍵口數4
        public bool DEFAULT_QTY_HOTKEY5 = false;//	啟用口數快速鍵5
        public string DEFAULT_QTY_HOTKEY_KEY5;//	口數快速鍵值5
        public int DEFAULT_QTY_HOTKEY_VALUE5;//	口數快速鍵口數5
        public bool DEFAULT_MP_HOTKEY = false;//	啟用市價快速鍵
        public string DEFAULT_MP_HOTKEY_BKEY;//	市價買進快速鍵值
        public string DEFAULT_MP_HOTKEY_SKEY;//	市價賣出快速鍵值
        public bool DEFAULT_CA_HOTKEY = false;//	啟用全部刪單快速鍵
        public string DEFAULT_CA_HOTKEY_KEY;//	全部刪單快速鍵值
        public bool DEFAULT_MIT_HOTKEY = false;//	啟用MIT刪單快速鍵
        public string DEFAULT_MIT_HOTKEY_KEY;//	MIT刪單快速鍵值
        public bool DEFAULT_BM_HOTKEY = false;//	啟用市價反向平倉快速鍵
        public string DEFAULT_BM_HOTKEY_KEY;//	市價反向平倉快速鍵值
        public string DEFAULT_BM_HOTKEY_VALUE;//	反向平倉預設價格
        public int DEFAULT_BM_HOTKEY_BTICK;//	反向平倉限價Tick BUY
        public int DEFAULT_BM_HOTKEY_STICK;//	反向平倉限價Tick SELL
        public bool DEFAULT_NUMER_KEYBOARD = false;//	啟動數字鍵盤特殊功能
        public bool DEFAULT_ENABLED_QTY = true;//	啟動口數bar

        public string DefalutQuantity = "1,2,3,5,10,20,100";
        public string DEFAULT_DIPLAYACCOLUMNS = "POSITION_PRICE,POSITION_QTY,FLOAT_PROFIT";
        public bool DEFAULT_SHOWACHEADER = false;
        public string DEFAULT_FONT_NAME = "Arial";
        public string DEFAULT_FONT_STYLE = "Bold";


        private DataTable mdt_Quantity;
        private bool mbol_EnabledSave;
        private bool mbol_EnabledSavePW;
        private bool mbol_IDlogin = true;
        private string m_strAccountServerIP = "";

        private string m_strAccountServerPort;
        private string m_strAs400ServerIP = "";

        private string m_strAs400ServerPort;




        private bool m_bolOpenNewOrder = false;
        /// <summary>
        /// 手續費設定檔
        /// </summary>
        public DataTable FBMNFE
        {
            get
            {
                return mdtFBMNFE;
            }
            set
            {
                mdtFBMNFE = value;
            }
        }


        /// <summary>
        /// 連線設定檔
        /// </summary>
        public DataTable ServerSet
        {
            get
            {
                return mdtServerSet;
            }
            set
            {
                mdtServerSet = value;
            }
        }

        /// <summary>
        /// 組合設定檔
        /// </summary>
        public DataTable CollectionSet
        {
            get
            {
                return mdtCollectionSet;
            }
            set
            {
                mdtCollectionSet = value;
            }
        }

        /// <summary>
        /// 版面設定檔
        /// </summary>
        public DataTable FORM_SET
        {
            get
            {
                return mdtFORM_SET;
            }
            set
            {
                mdtFORM_SET = value;
            }
        }

        /// <summary>
        /// 下單帳號檔
        /// </summary>
        public DataTable AccountData
        {
            get
            {
                return mdtAccountData;
            }
            set
            {
                mdtAccountData = value;
            }
        }
        /// <summary>
        /// 使用者快速鍵
        /// </summary>
        public DataTable User_HotKeySet
        {
            get
            {
                return mdtUser_HotKeySet;
            }
            set
            {
                mdtUser_HotKeySet = value;
            }
        }


        /// <summary>
        /// 登入主機設定檔
        /// </summary>
        public System.Data.DataTable LoginServerSet
        {
            get
            {
                return mdtLoginServerSet;
            }
            set
            {
                mdtLoginServerSet = value;
            }
        }

        /// <summary>
        /// 登入身份證字號
        /// </summary>
        public string LoginID
        {
            get
            {
                return mstr_loginid;
            }
            set
            {
                mstr_loginid = value;
            }
        }
        /// <summary>
        /// 登入交易帳號
        /// </summary>
        public string LoginACNO
        {
            get
            {
                return mstr_loginacno;
            }
            set
            {
                mstr_loginacno = value;
            }
        }
        /// <summary>
        /// 使用者分公司
        /// </summary>
        public string Company
        {
            get
            {
                return mstr_company;
            }
            set
            {
                mstr_company = value;
            }
        }

        public class Program
        {
            Dictionary<string, ProgramInfo> _Data;
            private DataTable _dtProgramSet;
            public Program(DataTable dt)
            {
                if (dt == null) return;
                _Data = new Dictionary<string, ProgramInfo>();
                _dtProgramSet = dt;
                foreach (DataRow dr in _dtProgramSet.Rows)
                {
                    ProgramInfo info = new ProgramInfo();
                    info.mod_id = dr["MODID"].ToString().Trim();
                    info.prog_name = dr["PROG_NAME"].ToString().Trim();
                    info.prog_desc = dr["PROG_DESC"].ToString().Trim();
                    info.remark = dr["REMARK"].ToString().Trim();
                    info.MutiFlag = dr["MULTIFORM"].ToString().Trim() == "Y" ? true : false;
                    _Data[info.prog_name] = info;
                }
            }

            public DataTable GetDt()
            {
                return _dtProgramSet;
            }
             public DataRow[] Select(string expr)
             {
                 return _dtProgramSet.Select(expr );
             }
             public ProgramInfo GetData(string key)
             {
                ProgramInfo info;
                if ( _Data.TryGetValue(key,out info))
                {
                    return info;
                }
                return null;
             }
        }


        Program _ProgramSet;

        /// <summary>
        /// 程式設定
        /// </summary>
        public Program ProgramSet {get;set;}
    

        /// <summary>
        /// 使用者密碼
        /// </summary>
        public string PW
        {
            get
            {
                return mstr_PW;
            }
            set
            {
                mstr_PW = value;
            }
        }



        /// <summary>
        /// 預設下單群組
        /// </summary>
        /// <value>群組GroupSelect帳號AccountEnter</value>
        public string strDefualtGroupSelect
        {
            get
            {
                return mstr_DefualtGroupSelect;
            }
            set
            {
                mstr_DefualtGroupSelect = value;
            }
        }

        /// <summary>
        /// 預設買進顏色
        /// </summary>
        /// <value>ARGB 值</value>
        public int intDefualtBuyBackColor
        {
            get
            {
                return mint_DefualtBuyBackColor;
            }
            set
            {
                mint_DefualtBuyBackColor = value;
            }
        }

        /// <summary>
        /// 預設賣出顏色
        /// </summary>
        /// <value>ARGB 值</value>
        public int intDefualtSellBackColor
        {
            get
            {
                return mint_DefualtSellBackColor;
            }
            set
            {
                mint_DefualtSellBackColor = value;
            }
        }

        /// <summary>
        /// 預設複式單顏色
        /// </summary>
        /// <value>ARGB 值</value>
        public int intDefualtMultiBackColor
        {
            get
            {
                return mint_DefualtMultiBackColor;
            }
            set
            {
                mint_DefualtMultiBackColor = value;
            }
        }

        /// <summary>
        /// 預設焦點位置
        /// </summary>
        /// <value>數量Q價格P</value>
        public string strDefualtHOFocus
        {
            get
            {
                return mstr_DefualtHOFocus;
            }
            set
            {
                mstr_DefualtHOFocus = value;
            }
        }

        /// <summary>
        /// 記憶下單單價
        /// </summary>
        /// <value>記憶True不記憶False</value>
        public bool bolMemoryPrice
        {
            get
            {
                return mbol_MemoryPrice;
            }
            set
            {
                mbol_MemoryPrice = value;
            }
        }

        /// <summary>
        /// 記憶下單數量
        /// </summary>
        /// <value>記憶True不記憶False</value>
        public bool bolMemoryQty
        {
            get
            {
                return mbol_MemoryQty;
            }
            set
            {
                mbol_MemoryQty = value;
            }
        }

        /// <summary>
        /// 記憶下單商品
        /// </summary>
        /// <value>記憶True不記憶False</value>
        public bool bolMemoryProduct
        {
            get
            {
                return mbol_MemoryProduct;
            }
            set
            {
                mbol_MemoryProduct = value;
            }
        }

        /// <summary>
        /// 記憶下單委託條件
        /// </summary>
        /// <value>記憶True不記憶False</value>
        public bool bolMemoryCondition
        {
            get
            {
                return mbol_MemoryCondition;
            }
            set
            {
                mbol_MemoryCondition = value;
            }
        }

        /// <summary>
        /// 記憶下單新平倉碼
        /// </summary>
        /// <value>記憶True不記憶False</value>
        public bool bolMemoryOSFlag
        {
            get
            {
                return mbol_MemoryOSFlag;
            }
            set
            {
                mbol_MemoryOSFlag = value;
            }
        }

        /// <summary>
        /// 記憶下單BS
        /// </summary>
        /// <value>記憶True不記憶False</value>
        public bool bolMemoryBS
        {
            get
            {
                return mbol_MemoryBS;
            }
            set
            {
                mbol_MemoryBS = value;
            }
        }

        /// <summary>
        /// 記憶下單來源別
        /// </summary>
        /// <value>記憶True不記憶False</value>
        public bool bolMemorySourceType
        {
            get
            {
                return mbol_MemorySourceType;
            }
            set
            {
                mbol_MemorySourceType = value;
            }
        }
        /// <summary>
        /// 記憶當沖
        /// </summary>
        /// <value>記憶True不記憶False</value>
        public bool bolMemoryDTrade
        {
            get
            {
                return mbol_MemoryDTrade;
            }
            set
            {
                mbol_MemoryDTrade = value;
            }
        }


        /// <summary>
        /// 下單帳號是否與快速帳務查詢的帳號同步
        /// </summary>
        /// <value>同步True不同步False</value>
        public bool bolSyncAccount
        {
            get
            {
                return mbol_SyncAccount;
            }
            set
            {
                mbol_SyncAccount = value;
            }
        }
        /// <summary>
        /// 下單帳號是否與委回和成回查詢的帳號同步
        /// </summary>
        /// <value>同步True不同步False</value>
        public bool bolSyncReply
        {
            get
            {
                return mbol_SyncReply;
            }
            set
            {
                mbol_SyncReply = value;
            }
        }
        /// <summary>
        /// 自設匯出Excel存檔路徑
        /// </summary>
        /// <value>路徑位置</value>
        public string strExcelPath
        {
            get
            {
                return mstr_ExcelPath;
            }
            set
            {
                mstr_ExcelPath = value;
            }
        }
        /// <summary>
        /// 點報價下單依賣賣價帶預設買賣別
        /// </summary>
        /// <value>B:點選買進價格帶買進,賣出價格帶賣出;S:點選買進價格帶賣出,賣出價格帶買進</value>
        public string strQuickOrderBS
        {
            get
            {
                return mstr_QuickOrderBS;
            }
            set
            {
                mstr_QuickOrderBS = value;
            }
        }


        public bool ORDERMSG { get { return mbol_ORDERMSG; } set { mbol_ORDERMSG = value; } }//	委託確認訊息
        public bool CANCELORDERMSG { get { return mbol_CANCELORDERMSG; } set { mbol_CANCELORDERMSG = value; } }//	刪單確認訊息
        public bool ORDERERRORMSG { get { return mbol_ORDERERRORMSG; } set { mbol_ORDERERRORMSG = value; } }//	委託失敗訊息
        public bool CANCELERRORMSG { get { return mbol_CANCELERRORMSG; } set { mbol_CANCELERRORMSG = value; } }//	刪單失敗訊息
        public bool R_SOUND { get { return mbol_R_SOUND; } set { mbol_R_SOUND = value; } }//	播放委託回報音效
        public byte[] R_SOUND_FILE { get { return mstr_R_SOUND_FILE; } set { mstr_R_SOUND_FILE = value; } }//	委託回報音效檔名
        public bool M_SOUND { get { return mbol_M_SOUND; } set { mbol_M_SOUND = value; } }//	播放成交回報音效
        public byte[] M_SOUND_FILE { get { return mstr_M_SOUND_FILE; } set { mstr_M_SOUND_FILE = value; } }//	成交回報音效檔名
        public bool MOVEBACKCOLOR { get { return mbol_MOVEBACKCOLOR; } set { mbol_MOVEBACKCOLOR = value; } }//	滑鼠移動呈現底色
        public string LEFTCLICKORDER { get { return mstr_LEFTCLICKORDER; } set { mstr_LEFTCLICKORDER = value; } }//	滑鼠左鍵下單
        public bool A_TIME { get { return mbol_A_TIME; } set { mbol_A_TIME = value; } }//	啟用報時
        public int A_TIME_MINUTES { get { return mint_A_TIME_MINUTES; } set { mint_A_TIME_MINUTES = value; } }//	報時間隔分鐘
        public int A_TIME_SECONDS { get { return mint_A_TIME_SECONDS; } set { mint_A_TIME_SECONDS = value; } }//	報時提醒秒鐘
        public bool PROFIT { get { return mbol_PROFIT; } set { mbol_PROFIT = value; } }//	啟動均價及損益
        public string PROFI_BASE { get { return mstr_PROFI_BASE; } set { mstr_PROFI_BASE = value; } }//	損益計算基準
        public bool MAX_MIN { get { return mbol_MAX_MIN; } set { mbol_MAX_MIN = value; } }//	啟用最高最低價
        public bool MARKETQTY { get { return mbol_MARKETQTY; } set { mbol_MARKETQTY = value; } }//	啟用市場成交量
        public bool COMMNO_CLICK { get { return mbol_COMMNO_CLICK; } set { mbol_COMMNO_CLICK = value; } }//	啟用快速商品切換
        public bool CANCEL_SYNC { get { return mbol_CANCEL_SYNC; } set { mbol_CANCEL_SYNC = value; } }//	同步刪除條件單
        public int FONT_SIZE { get { return mint_FONT_SIZE; } set { mint_FONT_SIZE = value; } }//	字型大小
        public int ROW_HEIGHT { get { return mint_ROW_HEIGHT; } set { mint_ROW_HEIGHT = value; } }//	欄位高度
        public int PRICE_WIDTH { get { return mint_PRICE_WIDTH; } set { mint_PRICE_WIDTH = value; } }//	價格寬度
        public int MKQ_WIDTH { get { return mint_MKQ_WIDTH; } set { mint_MKQ_WIDTH = value; } }//	市場數量寬度
        public int WQ_WIDTH { get { return mint_WQ_WIDTH; } set { mint_WQ_WIDTH = value; } }//	Working數量寬度
        public int MHQ_WIDTH { get { return mint_MHQ_WIDTH; } set { mint_MHQ_WIDTH = value; } }//	成交數量寬度
        public int MITQ_WIDTH { get { return mint_MITQ_WIDTH; } set { mint_MITQ_WIDTH = value; } }//	MIT數量寬度
        public string MPRICE_FONTCOLOR { get { return mstr_MPRICE_FONTCOLOR; } set { mstr_MPRICE_FONTCOLOR = value; } }//	成交價字型
        public string MPRICE_BACKCOLOR { get { return mstr_MPRICE_BACKCOLOR; } set { mstr_MPRICE_BACKCOLOR = value; } }//	成交價背景
        public string PRICE_FONTCOLOR { get { return mstr_PRICE_FONTCOLOR; } set { mstr_PRICE_FONTCOLOR = value; } }//	價格字型
        public string PRICE_BACKCOLOR { get { return mstr_PRICE_BACKCOLOR; } set { mstr_PRICE_BACKCOLOR = value; } }//	價格背景
        public string WB_FONTCOLOR { get { return mstr_WB_FONTCOLOR; } set { mstr_WB_FONTCOLOR = value; } }//	Working買量字型
        public string WB_BACKCOLOR { get { return mstr_WB_BACKCOLOR; } set { mstr_WB_BACKCOLOR = value; } }//	Working買量背景
        public string WS_FONTCOLOR { get { return mstr_WS_FONTCOLOR; } set { mstr_WS_FONTCOLOR = value; } }//	Working賣量字型
        public string WS_BACKCOLOR { get { return mstr_WS_BACKCOLOR; } set { mstr_WS_BACKCOLOR = value; } }//	Working賣量背景
        public string MB_FONTCOLOR { get { return mstr_MB_FONTCOLOR; } set { mstr_MB_FONTCOLOR = value; } }//	市場買量字型
        public string MB_BACKCOLOR { get { return mstr_MB_BACKCOLOR; } set { mstr_MB_BACKCOLOR = value; } }//	市場買量背景
        public string MS_FONTCOLOR { get { return mstr_MS_FONTCOLOR; } set { mstr_MS_FONTCOLOR = value; } }//	市場賣量字型
        public string MS_BACKCOLOR { get { return mstr_MS_BACKCOLOR; } set { mstr_MS_BACKCOLOR = value; } }//	市場賣量背景
        public string BM_FONTCOLOR { get { return mstr_BM_FONTCOLOR; } set { mstr_BM_FONTCOLOR = value; } }//	買進成交字型
        public string BM_BACKCOLOR { get { return mstr_BM_BACKCOLOR; } set { mstr_BM_BACKCOLOR = value; } }//	買進成交背景
        public string SM_FONTCOLOR { get { return mstr_SM_FONTCOLOR; } set { mstr_SM_FONTCOLOR = value; } }//	賣出成交字型
        public string SM_BACKCOLOR { get { return mstr_SM_BACKCOLOR; } set { mstr_SM_BACKCOLOR = value; } }//	賣出成交背景
        public string TMB_FONTCOLOR { get { return mstr_TMB_FONTCOLOR; } set { mstr_TMB_FONTCOLOR = value; } }//	市場總買量字型
        public string TMB_BACKCOLOR { get { return mstr_TMB_BACKCOLOR; } set { mstr_TMB_BACKCOLOR = value; } }//	市場總買量背景
        public string TMS_FONTCOLOR { get { return mstr_TMS_FONTCOLOR; } set { mstr_TMS_FONTCOLOR = value; } }//	市場總賣量字型
        public string TMS_BACKCOLOR { get { return mstr_TMS_BACKCOLOR; } set { mstr_TMS_BACKCOLOR = value; } }//	市場總賣量背景
        public string TBM_FONTCOLOR { get { return mstr_TBM_FONTCOLOR; } set { mstr_TBM_FONTCOLOR = value; } }//	買進成交總量字型
        public string TBM_BACKCOLOR { get { return mstr_TBM_BACKCOLOR; } set { mstr_TBM_BACKCOLOR = value; } }//	買進成交總量背景
        public string TSM_FONTCOLOR { get { return mstr_TSM_FONTCOLOR; } set { mstr_TSM_FONTCOLOR = value; } }//	賣出成交總量字型
        public string TSM_BACKCOLOR { get { return mstr_TSM_BACKCOLOR; } set { mstr_TSM_BACKCOLOR = value; } }//	賣出成交總量背景
        public string TWB_FONTCOLOR { get { return mstr_TWB_FONTCOLOR; } set { mstr_TWB_FONTCOLOR = value; } }//	Working總買量字型
        public string TWB_BACKCOLOR { get { return mstr_TWB_BACKCOLOR; } set { mstr_TWB_BACKCOLOR = value; } }//	Working總買量背景
        public string TWS_FONTCOLOR { get { return mstr_TWS_FONTCOLOR; } set { mstr_TWS_FONTCOLOR = value; } }//	Working總賣量字型
        public string TWS_BACKCOLOR { get { return mstr_TWS_BACKCOLOR; } set { mstr_TWS_BACKCOLOR = value; } }//	Working總賣量背景
        public string M5B_FONTCOLOR { get { return mstr_M5B_FONTCOLOR; } set { mstr_M5B_FONTCOLOR = value; } }//	五檔買量字型
        public string M5B_BACKCOLOR { get { return mstr_M5B_BACKCOLOR; } set { mstr_M5B_BACKCOLOR = value; } }//	五檔買量背景
        public string M5S_FONTCOLOR { get { return mstr_M5S_FONTCOLOR; } set { mstr_M5S_FONTCOLOR = value; } }//	五檔賣量字型
        public string M5S_BACKCOLOR { get { return mstr_M5S_BACKCOLOR; } set { mstr_M5S_BACKCOLOR = value; } }//	五檔賣量背景
        public string MIT_BACKCOLOR { get { return mstr_MIT_BACKCOLOR; } set { mstr_MIT_BACKCOLOR = value; } }//	條件式下單選項背景
        public string BT_FONTCOLOR { get { return mstr_BT_FONTCOLOR; } set { mstr_BT_FONTCOLOR = value; } }//	報時字型
        public string BT_BACKCOLOR { get { return mstr_BT_BACKCOLOR; } set { mstr_BT_BACKCOLOR = value; } }//	報時背景
        public string AT_FONTCOLOR { get { return mstr_AT_FONTCOLOR; } set { mstr_AT_FONTCOLOR = value; } }//	報時提醒字型
        public string AT_BACKCOLOR { get { return mstr_AT_BACKCOLOR; } set { mstr_AT_BACKCOLOR = value; } }//	報時提醒背景
        public string MAX_BACKCOLOR { get { return mstr_MAX_BACKCOLOR; } set { mstr_MAX_BACKCOLOR = value; } }//	最高價背景
        public string MIN_BACKCOLOR { get { return mstr_MIN_BACKCOLOR; } set { mstr_MIN_BACKCOLOR = value; } }//	最低價背景
        public bool QTY_HOTKEY1 { get { return mbol_QTY_HOTKEY1; } set { mbol_QTY_HOTKEY1 = value; } }//	啟用口數快速鍵1
        public string QTY_HOTKEY_KEY1 { get { return mstr_QTY_HOTKEY_KEY1; } set { mstr_QTY_HOTKEY_KEY1 = value; } }//	口數快速鍵值1
        public int QTY_HOTKEY_VALUE1 { get { return mint_QTY_HOTKEY_VALUE1; } set { mint_QTY_HOTKEY_VALUE1 = value; } }//	口數快速鍵口數1
        public bool QTY_HOTKEY2 { get { return mbol_QTY_HOTKEY2; } set { mbol_QTY_HOTKEY2 = value; } }//	啟用口數快速鍵2
        public string QTY_HOTKEY_KEY2 { get { return mstr_QTY_HOTKEY_KEY2; } set { mstr_QTY_HOTKEY_KEY2 = value; } }//	口數快速鍵值2
        public int QTY_HOTKEY_VALUE2 { get { return mint_QTY_HOTKEY_VALUE2; } set { mint_QTY_HOTKEY_VALUE2 = value; } }//	口數快速鍵口數2
        public bool QTY_HOTKEY3 { get { return mbol_QTY_HOTKEY3; } set { mbol_QTY_HOTKEY3 = value; } }//	啟用口數快速鍵3
        public string QTY_HOTKEY_KEY3 { get { return mstr_QTY_HOTKEY_KEY3; } set { mstr_QTY_HOTKEY_KEY3 = value; } }//	口數快速鍵值3
        public int QTY_HOTKEY_VALUE3 { get { return mint_QTY_HOTKEY_VALUE3; } set { mint_QTY_HOTKEY_VALUE3 = value; } }//	口數快速鍵口數3
        public bool QTY_HOTKEY4 { get { return mbol_QTY_HOTKEY4; } set { mbol_QTY_HOTKEY4 = value; } }//	啟用口數快速鍵4
        public string QTY_HOTKEY_KEY4 { get { return mstr_QTY_HOTKEY_KEY4; } set { mstr_QTY_HOTKEY_KEY4 = value; } }//	口數快速鍵值4
        public int QTY_HOTKEY_VALUE4 { get { return mint_QTY_HOTKEY_VALUE4; } set { mint_QTY_HOTKEY_VALUE4 = value; } }//	口數快速鍵口數4
        public bool QTY_HOTKEY5 { get { return mbol_QTY_HOTKEY5; } set { mbol_QTY_HOTKEY5 = value; } }//	啟用口數快速鍵5
        public string QTY_HOTKEY_KEY5 { get { return mstr_QTY_HOTKEY_KEY5; } set { mstr_QTY_HOTKEY_KEY5 = value; } }//	口數快速鍵值5
        public int QTY_HOTKEY_VALUE5 { get { return mint_QTY_HOTKEY_VALUE5; } set { mint_QTY_HOTKEY_VALUE5 = value; } }//	口數快速鍵口數5
        public bool MP_HOTKEY { get { return mbol_MP_HOTKEY; } set { mbol_MP_HOTKEY = value; } }//	啟用市價快速鍵
        public string MP_HOTKEY_BKEY { get { return mstr_MP_HOTKEY_BKEY; } set { mstr_MP_HOTKEY_BKEY = value; } }//	市價買進快速鍵值
        public string MP_HOTKEY_SKEY { get { return mstr_MP_HOTKEY_SKEY; } set { mstr_MP_HOTKEY_SKEY = value; } }//	市價賣出快速鍵值
        public bool CA_HOTKEY { get { return mbol_CA_HOTKEY; } set { mbol_CA_HOTKEY = value; } }//	啟用全部刪單快速鍵
        public string CA_HOTKEY_KEY { get { return mstr_CA_HOTKEY_KEY; } set { mstr_CA_HOTKEY_KEY = value; } }//	全部刪單快速鍵值
        public bool MIT_HOTKEY { get { return mbol_MIT_HOTKEY; } set { mbol_MIT_HOTKEY = value; } }//	啟用MIT刪單快速鍵
        public string MIT_HOTKEY_KEY { get { return mstr_MIT_HOTKEY_KEY; } set { mstr_MIT_HOTKEY_KEY = value; } }//	MIT刪單快速鍵值
        public bool BM_HOTKEY { get { return mbol_BM_HOTKEY; } set { mbol_BM_HOTKEY = value; } }//	啟用市價反向平倉快速鍵
        public string BM_HOTKEY_KEY { get { return mstr_BM_HOTKEY_KEY; } set { mstr_BM_HOTKEY_KEY = value; } }//	市價反向平倉快速鍵值
        public string BM_HOTKEY_VALUE { get { return mstr_BM_HOTKEY_VALUE; } set { mstr_BM_HOTKEY_VALUE = value; } }//	反向平倉預設價格
        public int BM_HOTKEY_BTICK { get { return mint_BM_HOTKEY_BTICK; } set { mint_BM_HOTKEY_BTICK = value; } }//	反向平倉限價Tick BUY
        public int BM_HOTKEY_STICK { get { return mint_BM_HOTKEY_STICK; } set { mint_BM_HOTKEY_STICK = value; } }//	反向平倉限價Tick SELL
        public bool NUMER_KEYBOARD { get { return mbol_NUMER_KEYBOARD; } set { mbol_NUMER_KEYBOARD = value; } }//	啟動數字鍵盤特殊功能
        public bool ENABLED_QTY { get { return mbol_ENABLED_QTY; } set { mbol_ENABLED_QTY = value; } }//	啟動口數bar

        public string DIPLAYACCOLUMNS { get { return mstr_DIPLAYACCOLUMNS; } set { mstr_DIPLAYACCOLUMNS = value; } }

        public bool SHOWACHEADER { get { return mbol_SHOWACHEADER; } set { mbol_SHOWACHEADER = value; } }

        public string FONT_NAME { get { return mstr_FONT_NAME; } set { mstr_FONT_NAME = value; } }
        public string FONT_STYLE { get { return mstr_FONT_STYLE; } set { mstr_FONT_STYLE = value; } }



        /// <summary>
        /// 營業員帳號
        /// </summary>
        public System.Data.DataTable dtAE
        {
            get
            {
                return mdtAE;
            }
            set
            {
                mdtAE = value;
            }
        }

        /// <summary>
        /// 部門資料
        /// </summary>
        public System.Data.DataTable dtGroup
        {
            get
            {
                return mdtGroup;
            }
            set
            {
                mdtGroup = value;
            }
        }
        /// <summary>
        /// 分公司資料
        /// </summary>
        public System.Data.DataTable dtCompany
        {
            get
            {
                return mdtCompany;
            }
            set
            {
                mdtCompany = value;
            }
        }

        /// <summary>
        /// 記憶ID
        /// </summary>
        public bool bolEnabledSave
        {
            get
            {
                return mbol_EnabledSave;
            }
            set
            {
                mbol_EnabledSave = value;
            }
        }
        /// <summary>
        /// 記憶密碼
        /// </summary>
        public bool bolEnabledSavePW
        {
            get
            {
                return mbol_EnabledSavePW;
            }
            set
            {
                mbol_EnabledSavePW = value;
            }
        }
        /// 身份證登入
        /// </summary>
        public bool bolIDlogin
        {
            get
            {
                return mbol_IDlogin;
            }
            set
            {
                mbol_IDlogin = value;
            }
        }

        public bool bolOpenNewOrder
        {
            get
            {
                return m_bolOpenNewOrder;
            }
            set
            {
                m_bolOpenNewOrder = value;
            }
        }

        public string logDate
        {
            get
            {
                return mstr_LogDate;
            }
            set
            {
                mstr_LogDate = value;
            }
        }
        public string logTime
        {
            get
            {
                return mstr_LogTime;
            }
            set
            {
                mstr_LogTime = value;
            }
        }
        public bool bolCtrlKeyDown
        {
            get
            {
                return m_bolCtrlKeyDown;
            }
            set
            {
                m_bolCtrlKeyDown = value;
            }
        }
        public bool m_bolCtrlKeyDown = false;

        /// <summary>
        /// 下單帳號集合
        /// </summary>
        public Dictionary<string, DataRow> _AccountIdData = new Dictionary<string, DataRow>();
    }
}
