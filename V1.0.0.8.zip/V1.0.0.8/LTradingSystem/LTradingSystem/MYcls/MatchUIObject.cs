﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VIPTradingSystem.MYcls
{
    public class MatchUIObject
    {
        public struct OrderQtyEventArgs
        {
            public string orderNo;//委託書號
            public string tradedate;
            public string investorAcno;//下單帳號
            public string FCMNO;//期貨商代號
            public int OrderQty;//委託數量
        }

        public string TRADEDATE { get; set; }
        public string MATCHTIME { get; set; }
        public string BROKERID { get; set; }
        public string INVESTORACNO { get; set; }
        public string SUBACT { get; set; }
        public string ORDERNO { get; set; }
        public string PRODUCTKIND { get; set; }
        public string BS { get; set; }
        public string SECURITYEXCHANGE { get; set; }
        public string SECURITYTYPE1 { get; set; }
        public string SYMBOL1 { get; set; }
        public string MATURITYMONTHYEAR1 { get; set; }
        public string PUTORCALL1 { get; set; }
        public decimal STRIKEPRICE1 { get; set; }
        public string SIDE1 { get; set; }
        public decimal PRICE1 { get; set; }
        public string SECURITYTYPE2 { get; set; }
        public string SYMBOL2 { get; set; }
        public string MATURITYMONTHYEAR2 { get; set; }
        public string PUTORCALL2 { get; set; }
        public decimal STRIKEPRICE2 { get; set; }
        public string SIDE2 { get; set; }
        public decimal PRICE2 { get; set; }
        public decimal MATCHPRICE { get; set; }
        public int MATCHQTY { get; set; }
        public string CLORDID { get; set; }
        public string OPENCLOSE { get; set; }
        public string EXECID { get; set; }
        public string MDATE { get; set; }
        public string ORDERID { get; set; }
        public string TARGETID { get; set; }
        public string ACCOUNT { get; set; }
        public string KEEPDATA { get; set; }

        public string STATE { get; set; }
        public string AE { set; get; }
        public string ORDERTAG { set; get; }
        public string EXECTRANSTYPE { set; get; }
        public string EXECREFID { set; get; }
        public string PSEQ { set; get; }
        public delegate
  void ReceiveMatchCallback(MatchUIObject e);
        public event ReceiveMatchCallback _ReceiveMatch;


        public delegate
void ReceiveOrderQtyCallback(OrderQtyEventArgs e);
        public event ReceiveOrderQtyCallback _ReceiveOrderQty;


        public MatchUIObject()
        {
            TRADEDATE = "";
            MATCHTIME = "";
            BROKERID = "";
            INVESTORACNO = "";
            SUBACT = "";
            ORDERNO = "";
            PRODUCTKIND = "";
            BS = "";
            SECURITYEXCHANGE = "";
            SECURITYTYPE1 = "";
            SYMBOL1 = "";
            MATURITYMONTHYEAR1 = "";
            PUTORCALL1 = "";
            STRIKEPRICE1 = 0;
            SIDE1 = "";
            PRICE1 = 0;
            SECURITYTYPE2 = "";
            SYMBOL2 = "";
            MATURITYMONTHYEAR2 = "";
            PUTORCALL2 = "";
            STRIKEPRICE2 = 0;
            SIDE2 = "";
            PRICE2 = 0;
            MATCHPRICE = 0;
            MATCHQTY = 0;
            CLORDID = "";
            OPENCLOSE = "";
            EXECID = "";
            MDATE = "";
            ORDERID = "";
            TARGETID = "";
            ACCOUNT = "";
        }
        public void raiseReceiveMatch(MatchUIObject e)
        {

            if (_ReceiveMatch != null)
            {
                _ReceiveMatch(e);
            }
        }

        public void raiseReceiveOrderQty(OrderQtyEventArgs ee)
        {

            if (_ReceiveOrderQty != null)
            {
                _ReceiveOrderQty(ee);
            }
        }
    }
}
