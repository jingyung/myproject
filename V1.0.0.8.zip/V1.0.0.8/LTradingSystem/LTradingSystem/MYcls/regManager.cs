using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using Microsoft.Win32;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace VIPTradingSystem.MYcls
{

    public class regManager
    {

        private const string USERROOT = "HKEY_CURRENT_USER";
        private const string MAINKEY = "AETrade(�Τ@��)";
        private const string USERROOT_MAINKEY_LOGIN = USERROOT + "\\" + MAINKEY;
        private const string MAINKEYNAME = USERROOT + "\\" + MAINKEY;

        REGLOGIN _reglogin;
        REGSYSTEMHKEY _REGSYSTEMHKEY;
        REGTEMPORDER _REGTEMPORDER;
        public regManager()
        {
            this._reglogin = new REGLOGIN();
            this._REGSYSTEMHKEY = new REGSYSTEMHKEY();
            _REGTEMPORDER = new REGTEMPORDER();
        }
        public REGLOGIN reglogin
        {
            get { return this._reglogin; }
        }
        public REGSYSTEMHKEY RegSystemHotKey
        {
            get { return this._REGSYSTEMHKEY; }
        }
        public REGTEMPORDER RegTempOrder
        {
            get { return this._REGTEMPORDER; }
        }

        public class REGLOGIN
        {
            bool m_ENABLEDSAVE;
            string m_USERID;
            string m_PASSWORD;
            public bool ENABLEDSAVE
            {
                get { return this.m_ENABLEDSAVE; }
            }
            public string USERID
            {
                get { return this.m_USERID; }
            }
            public string PASSWORD
            {
                get { return this.m_PASSWORD; }
            }
            public REGLOGIN()
            {
                this.m_ENABLEDSAVE = false;
                this.m_USERID = "";
                this.m_PASSWORD = "";
                this.getRegLogin();
            }
            private void getRegLogin()
            {
                try
                {

                    if (Registry.CurrentUser.OpenSubKey(MAINKEY) != null)
                    {
                        this.m_ENABLEDSAVE = bool.Parse(Registry.GetValue(USERROOT_MAINKEY_LOGIN, "ENABLEDSAVE", false).ToString());
                        this.m_USERID = Registry.GetValue(USERROOT_MAINKEY_LOGIN, "USERID", "").ToString();
                        this.m_PASSWORD = Registry.GetValue(USERROOT_MAINKEY_LOGIN, "PASSWORD", "").ToString();
                    }
                }
                catch (Exception ex)
                {
                    DataAgent._LM.WriteLog("regManagerLog", "getRegLogin:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
                }
            }
            public void Refresh()
            {
                try
                {
                    if (Registry.CurrentUser.OpenSubKey(MAINKEY) != null)
                    {
                        this.m_ENABLEDSAVE = bool.Parse(Registry.GetValue(USERROOT_MAINKEY_LOGIN, "ENABLEDSAVE", false).ToString());
                        this.m_USERID = Registry.GetValue(USERROOT_MAINKEY_LOGIN, "USERID", "").ToString();
                        this.m_PASSWORD = Registry.GetValue(USERROOT_MAINKEY_LOGIN, "PASSWORD", "").ToString();
                    }
                }
                catch (Exception ex)
                {
                    DataAgent._LM.WriteLog("regManagerLog", "Refresh:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
                }
            }
            public void removeRegLogin()
            {
                try
                {
                    Registry.CurrentUser.DeleteSubKey(MAINKEY, false);
                }
                catch (Exception ex)
                {
                    DataAgent._LM.WriteLog("regManagerLog", "removeRegLogin:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
                }
            }

            public void setRegLogin(string USERID, string PASSWORD, bool ENABLEDSAVE)
            {
                try
                {
                    if (!ENABLEDSAVE)
                    {
                        USERID = "";
                        PASSWORD = "";
                    }

                    Registry.SetValue(USERROOT_MAINKEY_LOGIN, "USERID", USERID, RegistryValueKind.String);
                    Registry.SetValue(USERROOT_MAINKEY_LOGIN, "PASSWORD", PASSWORD, RegistryValueKind.String);
                    Registry.SetValue(USERROOT_MAINKEY_LOGIN, "ENABLEDSAVE", ENABLEDSAVE, RegistryValueKind.String);
                }
                catch (Exception ex)
                {
                    DataAgent._LM.WriteLog("regManagerLog", "setRegLogin:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
                }
            }
        }

        public class REGSYSTEMHKEY
        {

            private DataTable m_defaultdtHotKeyData;
            public REGSYSTEMHKEY()
            {
                this.init();
            }
            private void init()
            {
                try
                {
                    this.m_defaultdtHotKeyData = new DataTable();
                    this.m_defaultdtHotKeyData.Columns.Add("function");
                    this.m_defaultdtHotKeyData.Columns.Add("hotkey");
                    this.m_defaultdtHotKeyData.Columns.Add("hotkeyIndex");
                    this.m_defaultdtHotKeyData.Columns.Add("hotkeykey");
                    this.m_defaultdtHotKeyData.Columns.Add("hotkeycontrol");
                    this.m_defaultdtHotKeyData.Columns.Add("hotkeyshfit");
                    this.m_defaultdtHotKeyData.Columns.Add("hotkeyalt");
                    this.m_defaultdtHotKeyData.Columns.Add("value");
                    this.m_defaultdtHotKeyData.Columns.Add("index");

                    //DataRow dr = this.m_defaultdtHotKeyData.NewRow();
                    //dr["index"] = "0";
                    //dr["function"] = "�����R��";
                    //this.m_defaultdtHotKeyData.Rows.Add(dr);
                    //DataRow dr4 = this.m_defaultdtHotKeyData.NewRow();
                    //dr4["index"] = "1";
                    //dr4["function"] = "����1";
                    //this.m_defaultdtHotKeyData.Rows.Add(dr4);
                    //DataRow dr5 = this.m_defaultdtHotKeyData.NewRow();
                    //dr5["index"] = "2";
                    //dr5["function"] = "����2";
                    //this.m_defaultdtHotKeyData.Rows.Add(dr5);

                }
                catch (Exception ex)
                {
                    DataAgent._LM.WriteLog("regManagerLog", "init:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
                }
            }
            public void addItem(string functionId)
            {
                try
                {
                    DataRow[] dr = m_defaultdtHotKeyData.Select("function ='" + functionId + "'");
                    if (dr.Length == 0)
                    {

                        DataRow drNew = m_defaultdtHotKeyData.NewRow();
                        drNew["function"] = functionId;
                        drNew["index"] = m_defaultdtHotKeyData.Rows.Count;
                        m_defaultdtHotKeyData.Rows.Add(drNew);

                    }
                }
                catch (Exception ex)
                {
                    DataAgent._LM.WriteLog("regManagerLog", "addItem:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
                }
            }
            public DataTable getRegSystemHKEY(string userid)
            {
                try
                {
                    byte[] buff = (byte[])Registry.GetValue(USERROOT_MAINKEY_LOGIN + "\\" + userid, "SystemHkey", null);
                    if (buff == null) return this.m_defaultdtHotKeyData;
                    BinaryFormatter b = new BinaryFormatter();
                    DataTable dtHotKeyData = (DataTable)b.Deserialize(new MemoryStream(buff));
                    if (dtHotKeyData != null)
                    {
                        //�ư��H�x�s.�����ݩ�{���\�઺���
                        foreach (DataRow dr in m_defaultdtHotKeyData.Rows)
                        {
                            DataRow[] drFind = dtHotKeyData.Select("function='" + dr["function"].ToString() + "'");
                            if (drFind.Length > 0)
                            {
                                dr["hotkey"] = drFind[0]["hotkey"];
                                dr["hotkeyIndex"] = drFind[0]["hotkeyIndex"];
                                dr["hotkeykey"] = drFind[0]["hotkeykey"];
                                dr["hotkeycontrol"] = drFind[0]["hotkeycontrol"];
                                dr["hotkeyshfit"] = drFind[0]["hotkeyshfit"];
                                dr["hotkeyalt"] = drFind[0]["hotkeyalt"];
                                dr["value"] = drFind[0]["value"];
                            }
                        }
                    }

                }
                catch (Exception ex)
                {
                    DataAgent._LM.WriteLog("regManagerLog", "getRegSystemHKEY:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());

                }
                return m_defaultdtHotKeyData;
            }
            public void setRegSystemHKEY(string userid, DataTable dt)
            {
                try
                {
                    System.IO.MemoryStream memory = new MemoryStream();
                    BinaryFormatter b = new BinaryFormatter();
                    b.Serialize(memory, dt);
                    byte[] buff = memory.GetBuffer();
                    memory.Close();
                    Registry.SetValue(USERROOT_MAINKEY_LOGIN + "\\" + userid, "SystemHkey", buff, RegistryValueKind.Binary);
                }
                catch (Exception ex)
                {
                    DataAgent._LM.WriteLog("regManagerLog", "setRegSystemHKEY:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());

                }
            }

        }
        public class REGTEMPORDER
        { 
            public REGTEMPORDER()
            {
               
            }
            public void setRegTempFolder(string userid, string[] foldernames)
            {
                try
                {
                    System.IO.MemoryStream memory = new MemoryStream();
                    BinaryFormatter b = new BinaryFormatter();
                    b.Serialize(memory, foldernames);
                    byte[] buff = memory.GetBuffer();
                    memory.Close();
                    Registry.SetValue(USERROOT_MAINKEY_LOGIN + "\\" + userid, "TempFolder", buff, RegistryValueKind.Binary);
                }
                catch (Exception ex)
                {
                    DataAgent._LM.WriteLog("regManagerLog", "setRegTempFolder:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());

                }
            }

            public string[] getRegTempFolder(string userid)
            {
                string[] foldernames = null;
                try
                {
                    byte[] buff = (byte[])Registry.GetValue(USERROOT_MAINKEY_LOGIN + "\\" + userid, "TempFolder", null);
                    if (buff == null) return null;
                    BinaryFormatter b = new BinaryFormatter();
                    foldernames = (string[])b.Deserialize(new MemoryStream(buff));

                }
                catch (Exception ex)
                {
                    DataAgent._LM.WriteLog("regManagerLog", "getRegTempFolder:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());

                }
                return foldernames;
            }
            public DataTable getRegTempOrder(string userid,string foldername)
            {
                DataTable dtTempData = null;
                try
                {
                    byte[] buff = (byte[])Registry.GetValue(USERROOT_MAINKEY_LOGIN + "\\" + userid, foldername, null);
                    if (buff == null) return null ;
                    BinaryFormatter b = new BinaryFormatter();
                    dtTempData = (DataTable)b.Deserialize(new MemoryStream(buff));
                    
                }
                catch (Exception ex)
                {
                    DataAgent._LM.WriteLog("regManagerLog", "getRegTempOrder:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());

                }
                return dtTempData;
            }
            public void setRegTempOrder(string userid,string foldername, DataTable dt)
            {
                try
                {
                    System.IO.MemoryStream memory = new MemoryStream();
                    BinaryFormatter b = new BinaryFormatter();
                    b.Serialize(memory, dt);
                    byte[] buff = memory.GetBuffer();
                    memory.Close();
                    Registry.SetValue(USERROOT_MAINKEY_LOGIN + "\\" + userid, foldername, buff, RegistryValueKind.Binary);
                }
                catch (Exception ex)
                {
                    DataAgent._LM.WriteLog("regManagerLog", "setRegTempOrder:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());

                }
            }

        }

    }

}
