﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.IO;
using System.IO.Compression;
using System.Runtime.Serialization.Formatters.Binary;
using System.ComponentModel;
using System.Windows.Forms;
using System.Drawing;
using System.Security.Cryptography;

using com.ddsc.tool.window;
namespace VIPTradingSystem.MYcls
{
    public class QueryActionObject
    {
        bool _cleardata;

        public bool Cleardata
        {
            get { return _cleardata; }
            set { _cleardata = value; }
        }
        QueryAction _QueryAction;

        public QueryAction QueryAction
        {
            get { return _QueryAction; }
            set { _QueryAction = value; }
        }


    }
    public enum TradeStyle : int
    {
        /// <summary>
        /// 一般
        /// </summary>
        normal = 0,
        /// <summary>
        /// 買上賣下(順勢鋪價)
        /// </summary>
        following = 1,
        /// <summary>
        /// 買下賣上(逆勢鋪價)
        /// </summary>
        opposite = 2,
        /// <summary>
        /// 上下皆鋪
        /// </summary>
        all = 3
    }
    public class CommonFunction
    {
      
        public const string ProductExpression = "TRIM(SYMBOL1)";
        public const string ContractExpression = @" TRIM(IIF(SIDE1='B','+1*',IIF(SIDE1='S','-1*','')))
                                                                            +TRIM(MATURITYMONTHYEAR1)+TRIM(PUTORCALL1)
                                                                            +IIF(SECURITYTYPE1='FUT','',STRIKEPRICE1) 
                                                          +' '+TRIM(IIF(SIDE2='B','+1*',IIF(SIDE2='S','-1*','')))
                                        +TRIM(MATURITYMONTHYEAR2)+TRIM(PUTORCALL2)
                                              +IIF(PRODUCTKIND='1' or PRODUCTKIND='4','' , STRIKEPRICE2) ";


        public const string BSVIEWExpression = @"IIF(IsNull(multipleKind, '0')  ='0',BS
, IIF( multipleKind ='/', IIF( BS ='B','S/B','B/S' )
,  IIF( multipleKind =':', IIF( BS ='B','B/B','S/S' )
, IIF( multipleKind ='-', IIF( BS ='B','S/B','B/S' ),BS  )  ) ))";


        public const string MutipleItemTypeNameExpression = "IIF(IsNull(multipleKind, '0')  ='0','單式', IIF( multipleKind ='/', IIF(productkind='4','期貨價差組合', IIF(len(productId)=13,'時間價差組合',IIF(substring(productId,9,1)='/','價格價差組合','時間價差組合'))),IIF( multipleKind =':',  IIF(len(productId)>14,'勒式組合','跨式組合'),IIF( multipleKind ='-','轉換/逆轉換組合','單式'))))";

        public enum ProductKind : int
        {
            /// <summary>
            /// 期貨
            /// </summary>
            future = 1,
            /// <summary>
            /// 選擇權
            /// </summary>
            option = 2,

        }
        public enum TradeStyle : int
        {
            /// <summary>
            /// 一般
            /// </summary>
            normal = 0,
            /// <summary>
            /// 順勢鋪價
            /// </summary>
            following = 1,
            /// <summary>
            /// 逆勢鋪價
            /// </summary>
            opposite = 2,
            /// <summary>
            /// 上下皆鋪
            /// </summary>
            all = 3
        }
        public enum TradeMode : int
        {
            /// <summary>
            /// 直接送出
            /// </summary>
            unconfirm = 0,
            /// <summary>
            /// 確認模式
            /// </summary>
            confirm = 1,

        }

        public class ListBoxItem
        {
            private string m_Text;
            private string m_Value;

            public ListBoxItem(string Value, string Text)
            {
                this.m_Value = Value;
                this.m_Text = Text;
            }

            public string Text
            {
                get
                {
                    return m_Text;
                }
                set
                {
                    this.m_Text = value;
                }
            }

            public string Value
            {
                get
                {
                    return m_Value;
                }
                set
                {
                    this.m_Value = value;
                }
            }

            public override string ToString()
            {
                return this.m_Text;
            }
        }
        public class ProductInfo
        {
            private string m_Comtype = "";
            private string m_ProductClass = "";
            private string m_ProductShortDsc = "";
            private string m_ProductId = "";
            private string m_Period = "";
            private string m_Cp = "";
            private string m_Strike = "";
            private string m_ProductClass2 = "";
            private string m_ProductShortDsc2 = "";
            private string m_ProductId2 = "";
            private string m_Period2 = "";
            private string m_Cp2 = "";
            private string m_Strike2 = "";
            private string m_ProductName = "";
            private string m_ProductKind;
            private int m_MultipleKind;
            private string m_Commodiy1 = "";
            private string m_Commodiy2 = "";
            /// <summary>
            /// 0:期貨/1:選擇權
            /// </summary>
            public string ComType
            {
                get { return m_Comtype; }
                set { m_Comtype = value; }
            }
            /// <summary>
            /// 商品類別碼
            /// </summary>
            public string ProductClass
            {
                get { return m_ProductClass; }
                set { m_ProductClass = value; }
            }
            /// <summary>
            /// 商品類別名稱
            /// </summary>
            public string ProductShortDsc
            {
                get { return m_ProductShortDsc; }
                set { m_ProductShortDsc = value; }
            }
            /// <summary>
            /// 商品代碼
            /// </summary>
            public string ProductId
            {
                get { return m_ProductId; }
                set { m_ProductId = value; }
            }
            /// <summary>
            /// 年月
            /// </summary>
            public string Period
            {
                get { return m_Period; }
                set { m_Period = value; }
            }
            /// <summary>
            /// C/P
            /// </summary>
            public string Cp
            {
                get { return m_Cp; }
                set { m_Cp = value; }
            }
            /// <summary>
            /// Call/Put
            /// </summary>
            public string CPFullName
            {
                get
                {
                    if (m_Cp.Length > 0)
                        return m_Cp.ToLower() == "c" ? "Call" : "Put";
                    else
                        return "";
                }
            }
            /// <summary>
            /// 履約價
            /// </summary>
            public string Strike
            {
                get { return m_Strike; }
                set { m_Strike = value; }
            }
            /// <summary>
            /// 商品類別碼(第二隻腳)
            /// </summary>
            public string ProductClass2
            {
                get { return m_ProductClass2; }
                set { m_ProductClass2 = value; }
            }
            /// <summary>
            /// 商品類別名稱(第二隻腳)
            /// </summary>
            public string ProductShortDsc2
            {
                get { return m_ProductShortDsc2; }
                set { m_ProductShortDsc2 = value; }
            }
            /// <summary>
            /// 商品代碼(第二隻腳)
            /// </summary>
            public string ProductId2
            {
                get { return m_ProductId2; }
                set { m_ProductId2 = value; }
            }
            /// <summary>
            /// 年月(第二隻腳)
            /// </summary>
            public string Period2
            {
                get { return m_Period2; }
                set { m_Period2 = value; }
            }
            /// <summary>
            /// C/P(第二隻腳)
            /// </summary>
            public string Cp2
            {
                get { return m_Cp2; }
                set { m_Cp2 = value; }
            }
            /// <summary>
            /// Call/Put(第二隻腳)
            /// </summary>
            public string CPFullName2
            {
                get
                {

                    if (m_Cp2.Length > 0)
                        return m_Cp2.ToLower() == "c" ? "Call" : "Put";
                    else
                        return "";
                }
            }
            /// <summary>
            /// 履約價(第二隻腳)
            /// </summary>
            public string Strike2
            {
                get { return m_Strike2; }
                set { m_Strike2 = value; }
            }
            /// <summary>
            /// 商品名稱
            /// </summary>
            public string ProductName
            {
                get { return m_ProductName; }
                set { m_ProductName = value; }
            }
            /// <summary>
            /// 商品種類1:期貨/2:選擇權/3:選擇權複式/4:期貨複式
            /// </summary>
            public string ProductKind
            {
                get { return m_ProductKind; }
                set { m_ProductKind = value; }
            }
            /// <summary>
            /// 複式種類1:價格價差/2:時間價差/3:跨式/4:勒式/5:轉換逆轉換
            /// </summary>
            public int MultipleKind
            {
                get { return m_MultipleKind; }
                set { m_MultipleKind = value; }
            }
            /// <summary>
            /// 舊商品類別碼
            /// </summary>
            public string Commodiy1
            {
                get { return m_Commodiy1; }
                set { m_Commodiy1 = value; }
            }
            /// <summary>
            /// 舊商品類別碼(第二隻腳)
            /// </summary>
            public string Commodiy2
            {
                get { return m_Commodiy2; }
                set { m_Commodiy2 = value; }
            }
        }


        public static ProductInfo getProductInfoByProductId(string ProductId)
        {

            ProductInfo item = new ProductInfo();
            string CommodityId = ProductId.Trim();
            item.ProductId = CommodityId;
            item.MultipleKind = -1;
            if (CommodityId.Length == 5)
            {
                item.ComType = "0";
                item.ProductClass = CommodityId.Substring(0, 3);
                item.Period = getPeriod(CommodityId.Substring(3));
                item.ProductKind = "1";
                DataRow[] drs = systemconfigs.ProductMain.Select("KIND_ID ='" + item.ProductClass + "'");
                if (drs.Length > 0)
                {
                    item.Commodiy1 = drs[0]["COMNO"].ToString().Trim();
                    item.ProductShortDsc = drs[0]["NAME"].ToString();
                }
                item.ProductName = item.ProductShortDsc + " " + item.Period.Substring(4);
            }
            else if (CommodityId.Length == 10)
            {
                item.ComType = "1";
                item.ProductClass = CommodityId.Substring(0, 3);
                item.Period = getPeriod(CommodityId.Substring(8));
                item.Cp = getOptionCP(CommodityId.Substring(8, 1));
                item.ProductKind = "2";
                DataRow[] drs = drs = systemconfigs.ProductMain.Select("KIND_ID ='" + item.ProductClass + "'");
                if (drs.Length > 0)
                {
                    item.Commodiy1 = drs[0]["COMNO"].ToString().Trim();
                    item.ProductShortDsc = drs[0]["NAME"].ToString();
                    double strike = 0;
                    double.TryParse(CommodityId.Substring(3, 5), out strike);
                    double strike_decimal = 0;
                    double.TryParse(drs[0]["STRIKE_DECIMAIL"].ToString(), out strike_decimal);
                    item.Strike = String.Format("{0:#0.###}", (strike / Math.Pow(10, strike_decimal)));
                }
                item.ProductName = item.ProductShortDsc + " " + item.Period.Substring(4) + " " + item.Cp + " " + item.Strike;
            }
            else if (CommodityId.Length == 8 || CommodityId.Length == 11)//期貨價差
            {
                item.ComType = "0";
                item.ProductId = CommodityId.Substring(0, 5);
                if (CommodityId.Length == 8)
                {
                    item.ProductClass = CommodityId.Substring(0, 3);
                    item.ProductClass2 = CommodityId.Substring(0, 3);
                    item.Period = getPeriod(CommodityId.Substring(3, 2));
                    item.Period2 = getPeriod(CommodityId.Substring(6, 2));
                    item.ProductId2 = item.ProductClass2 + CommodityId.Substring(6, 2);
                }
                else if (CommodityId.Length == 11)
                {
                    item.ProductClass = CommodityId.Substring(0, 3);
                    item.ProductClass2 = CommodityId.Substring(6, 3);
                    item.Period = getPeriod(CommodityId.Substring(3, 2));
                    item.Period2 = getPeriod(CommodityId.Substring(9, 2));
                    item.ProductId2 = item.ProductClass2 + CommodityId.Substring(9, 2);
                }
                DataRow[] drs = systemconfigs.ProductMain.Select("KIND_ID ='" + item.ProductClass + "'");
                if (drs.Length > 0)
                {
                    item.ProductShortDsc = item.ProductShortDsc2 = drs[0]["NAME"].ToString();
                    item.Commodiy1 = item.Commodiy2 = drs[0]["COMNO"].ToString().Trim();
                }
                if (CommodityId.Length == 11)
                {
                    drs = systemconfigs.ProductMain.Select("KIND_ID ='" + item.ProductClass2 + "'");
                    if (drs.Length > 0)
                    {
                        item.ProductShortDsc2 = drs[0]["NAME"].ToString();
                        item.Commodiy2 = drs[0]["COMNO"].ToString().Trim();
                    }
                }
                item.MultipleKind = 0;
                if (CommodityId.Length == 8)
                    item.ProductName = item.ProductShortDsc + item.Period.Substring(4) + "-" + item.Period2.Substring(4);
                else
                    item.ProductName = item.ProductShortDsc + item.Period.Substring(4) + "-" + item.ProductShortDsc2 + item.Period2.Substring(4);
                item.ProductKind = "4";
            }
            else if (CommodityId.Length == 16 && CommodityId.Substring(8, 1) == "/")//價格價差
            {
                item.ComType = "1";
                item.ProductClass = item.Commodiy1 = CommodityId.Substring(0, 3);
                item.ProductClass2 = item.Commodiy2 = item.ProductClass;
                item.Period = getPeriod(CommodityId.Substring(14, 2));
                item.Period2 = item.Period;
                item.Cp = getOptionCP(CommodityId.Substring(14, 1));
                item.Cp2 = item.Cp;
                item.ProductId = CommodityId.Substring(0, 8) + CommodityId.Substring(14, 2);
                item.ProductId2 = item.ProductClass2 + CommodityId.Substring(9);
                DataRow[] drs = systemconfigs.ProductMain.Select("KIND_ID ='" + item.ProductClass + "'");
                if (drs.Length > 0)
                {
                    item.ProductShortDsc = item.ProductShortDsc2 = drs[0]["NAME"].ToString().Trim();
                    double strike_decimal = 0;
                    double.TryParse(drs[0]["STRIKE_DECIMAIL"].ToString(), out strike_decimal);
                    double strike = 0;
                    double.TryParse(CommodityId.Substring(3, 5), out strike);
                    item.Strike = String.Format("{0:#0.###}", (strike / Math.Pow(10, strike_decimal)));
                    double strike2 = 0;
                    double.TryParse(CommodityId.Substring(9, 5), out strike2);
                    item.Strike2 = String.Format("{0:#0.###}", (strike2 / Math.Pow(10, strike_decimal)));
                }
                item.ProductName = item.ProductShortDsc + " " + item.Period.Substring(4) + " " + item.Cp + " " + item.Strike + "-" + item.Strike2;
                item.ProductKind = "3";
                item.MultipleKind = 1;
            }
            else if (CommodityId.Length == 13 || (CommodityId.Length == 16 && CommodityId.Substring(10, 1) == "/"))//時間價差、跨式、逆轉換
            {
                string Type = CommodityId.Substring(10, 1);
                item.ComType = "1";
                item.ProductClass = item.Commodiy1 = CommodityId.Substring(0, 3);
                item.ProductClass2 = item.Commodiy2 = item.ProductClass;
                item.Period = getPeriod(CommodityId.Substring(8, 2));
                item.Period2 = getPeriod(CommodityId.Substring(11, 2));
                item.Cp = getOptionCP(CommodityId.Substring(8, 1));
                item.Cp2 = getOptionCP(CommodityId.Substring(11, 1));
                item.ProductId = CommodityId.Substring(0, 10);
                item.ProductId2 = item.ProductClass2 + CommodityId.Substring(3, 5) + CommodityId.Substring(11, 2);
                if (CommodityId.Length == 16 && CommodityId.Substring(10, 1) == "/")
                {
                    item.Period2 = getPeriod(CommodityId.Substring(14, 2));
                    item.Cp2 = getOptionCP(CommodityId.Substring(14, 1));
                    item.ProductId2 = item.ProductClass2 + CommodityId.Substring(3, 5) + CommodityId.Substring(14, 2);
                }

                DataRow[] drs = systemconfigs.ProductMain.Select("KIND_ID ='" + item.ProductClass + "'");
                if (drs.Length > 0)
                {
                    item.ProductShortDsc = item.ProductShortDsc2 = drs[0]["NAME"].ToString().Trim();
                    double strike_decimal = 0;
                    double.TryParse(drs[0]["STRIKE_DECIMAIL"].ToString(), out strike_decimal);
                    double strike = 0;
                    double.TryParse(CommodityId.Substring(3, 5), out strike);
                    item.Strike = item.Strike2 = String.Format("{0:#0.###}", (strike / Math.Pow(10, strike_decimal)));

                }
                if (Type == "/")
                {
                    if (CommodityId.Length == 16 && CommodityId.Substring(10, 1) == "/")
                    {
                        DataRow[] drfind = systemconfigs.ProductMain.Select("KIND_ID ='" + CommodityId.Substring(11, 3) + "'");
                        if (drfind.Length > 0)
                        {
                            item.ProductClass2 = item.Commodiy2 = CommodityId.Substring(11, 3);
                            item.ProductShortDsc2 = drfind[0]["NAME"].ToString().Trim();
                            item.ProductName = item.ProductShortDsc + " " + item.Period.Substring(4) + Type + drfind[0]["NAME"].ToString().Trim() + item.Period2.Substring(4) + " " + item.Strike + " " + item.Cp;
                        }
                    }
                    else
                    {
                        item.ProductName = item.ProductShortDsc + " " + item.Period.Substring(4) + Type + item.Period2.Substring(4) + " " + item.Strike + " " + item.Cp;
                    }
                    item.MultipleKind = 2;
                }
                else
                {
                    item.ProductName = item.ProductShortDsc + " " + item.Period.Substring(4) + " " + item.Cp + Type + item.Cp2 + " " + item.Strike;
                    if (Type == ":")
                    {
                        item.MultipleKind = 3;
                    }
                    else { item.MultipleKind = 5; }
                }
                item.ProductKind = "3";
            }
            else if (CommodityId.Length == 18)// 勒式
            {
                item.ComType = "1";
                item.ProductClass = item.Commodiy1 = CommodityId.Substring(0, 3);
                item.ProductClass2 = item.Commodiy2 = item.ProductClass;
                item.Period = getPeriod(CommodityId.Substring(8, 2));
                item.Period2 = getPeriod(CommodityId.Substring(16, 2));
                item.Cp = getOptionCP(CommodityId.Substring(8, 1));
                item.Cp2 = getOptionCP(CommodityId.Substring(16, 1));
                item.ProductId = CommodityId.Substring(0, 10);
                item.ProductId2 = item.ProductClass2 + CommodityId.Substring(11, 5) + CommodityId.Substring(16, 2);
                DataRow[] drs = systemconfigs.ProductMain.Select("KIND_ID ='" + item.ProductClass + "'");
                if (drs.Length > 0)
                {
                    item.ProductShortDsc = item.ProductShortDsc2 = drs[0]["NAME"].ToString().Trim();
                    double strike_decimal = 0;
                    double.TryParse(drs[0]["STRIKE_DECIMAIL"].ToString(), out strike_decimal);
                    double strike = 0;
                    double.TryParse(CommodityId.Substring(3, 5), out strike);
                    item.Strike = String.Format("{0:#0.###}", (strike / Math.Pow(10, strike_decimal)));
                    double strike2 = 0;
                    double.TryParse(CommodityId.Substring(11, 5), out strike2);
                    item.Strike2 = String.Format("{0:#0.###}", (strike2 / Math.Pow(10, strike_decimal)));
                }
                item.ProductName = item.ProductShortDsc + " " + item.Period2.Substring(4) + " " + item.Cp + " " + item.Strike + ":" + item.Cp2 + " " + item.Strike2;
                item.ProductKind = "3";
                item.MultipleKind = 4;
            }
            return item;
        }
        public static string getAccountNameForACTNO(string ACTNO)
        {
            DataRow[] drs = frmMain.UserConfigs.AccountData.Select("ACTNO='" + ACTNO + "'");
            if (drs.Length > 0)
            {
                return drs[0]["name"].ToString();
            }
            else
                return "";

        }
        public static string getCompanyForACTNO(string ACTNO)
        {
            DataRow dr = null;
            frmMain.UserConfigs._AccountIdData.TryGetValue(ACTNO, out dr);
            if (dr != null)
            {
                return dr["Company"].ToString();
            }
            else
                return "";

        }


        public static string getMK_FlagForACTNO(string ACTNO)
        {
            DataRow dr = null;
            frmMain.UserConfigs._AccountIdData.TryGetValue(ACTNO, out dr);
            if (dr != null)
            {
                return dr["MARKETFLAG"].ToString();
            }
            else
                return "";
        }

        public static string getID_NOForACTNO(string ACTNO)
        {
            DataRow dr = null;
            frmMain.UserConfigs._AccountIdData.TryGetValue(ACTNO, out dr);
            if (dr != null)
            {
                return dr["ID"].ToString();
            }
            else
                return "";
        }
        public static string getMIT_FlagForACTNO(string ACTNO)
        {
            DataRow dr = null;
            frmMain.UserConfigs._AccountIdData.TryGetValue(ACTNO, out dr);
            if (dr != null)
            {
                return dr["MIT_FLAG"].ToString();
            }
            else
                return "";
        }
        /// <summary>
        /// 壓縮byte
        /// </summary>
        public static byte[] zipdata(string[] arr)
        {

            BinaryFormatter ser = new BinaryFormatter();
            MemoryStream unMS = new MemoryStream();
            ser.Serialize(unMS, arr);

            byte[] bytes = unMS.ToArray();
            int lenbyte = bytes.Length;

            MemoryStream compMs = new MemoryStream();
            GZipStream compStream = new GZipStream(compMs, CompressionMode.Compress, true);
            compStream.Write(bytes, 0, lenbyte);

            compStream.Close();
            unMS.Close();
            compMs.Close();
            return compMs.ToArray();
        }
        public static DataSet SerialUnZip(byte[] data)
        {
            try
            {
                MemoryStream input = new MemoryStream();
                input.Write(data, 0, data.Length);
                input.Position = 0;
                GZipStream gzip = new GZipStream(input, CompressionMode.Decompress, true);

                MemoryStream output = new MemoryStream();
                byte[] buffer = new byte[4096];
                int read = -1;
                read = gzip.Read(buffer, 0, buffer.Length);
                while (read > 0)
                {
                    output.Write(buffer, 0, read);
                    read = gzip.Read(buffer, 0, buffer.Length);
                }
                gzip.Close();
                byte[] rebytes = output.ToArray();
                output.Close();
                input.Close();

                MemoryStream ms = new MemoryStream(rebytes);
                BinaryFormatter bf = new BinaryFormatter();
                object obj = bf.Deserialize(ms);
                DataSet dsData = (DataSet)obj;

                return dsData;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
        }
        public static string[] SerialUnZipArray(byte[] data)
        {
            try
            {
                MemoryStream input = new MemoryStream();
                input.Write(data, 0, data.Length);
                input.Position = 0;
                GZipStream gzip = new GZipStream(input, CompressionMode.Decompress, true);

                MemoryStream output = new MemoryStream();
                byte[] buffer = new byte[4096];
                int read = -1;
                read = gzip.Read(buffer, 0, buffer.Length);
                while (read > 0)
                {
                    output.Write(buffer, 0, read);
                    read = gzip.Read(buffer, 0, buffer.Length);
                }
                gzip.Close();
                byte[] rebytes = output.ToArray();
                output.Close();
                input.Close();

                MemoryStream ms = new MemoryStream(rebytes);
                BinaryFormatter bf = new BinaryFormatter();
                object obj = bf.Deserialize(ms);
                string[] arrData = (string[])obj;

                return arrData;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
        }


        public static void SetColumnCheckStyle(DataGridView Grid, string Name, int Width, bool Visable, bool Sort,bool DispalyCheckAll)
        {
            DDSCDataGridViewCheckBoxColumn dgvColumn = new DDSCDataGridViewCheckBoxColumn(false);
         
            dgvColumn.DataPropertyName = Name;
            dgvColumn.Name = Name;
            dgvColumn.HeaderText = "";
            dgvColumn.Width = Width;
            dgvColumn.Visible = Visable;
  
            
          
            dgvColumn.ReadOnly = false;
            if (!Sort)
                dgvColumn.SortMode = DataGridViewColumnSortMode.NotSortable;
            dgvColumn.DisplayIndex = Grid.Columns.Count;
            Grid.Columns.Add(dgvColumn);
        }
        public static void SetColumnTextExStyle(DataGridView Grid, string Name, string headname, int Width, bool Visable, bool Sort)
        {
            DDSCDataGridViewTextBoxColumn dgvColumn = new DDSCDataGridViewTextBoxColumn();
            
            dgvColumn.DataPropertyName = Name;
            dgvColumn.Name = Name;
            dgvColumn.ReadOnly = true;
            dgvColumn.Visible = Visable;
            dgvColumn.Width = Width;
            dgvColumn.HeaderText = headname;
            if (!Sort)
                dgvColumn.SortFlag = Sort;
            dgvColumn.DisplayIndex = Grid.Columns.Count;
            Grid.Columns.Add(dgvColumn);
        }

        public static void SetColumnTextStyle(DataGridView Grid, string Name,string headname, int Width, bool Visable, bool Sort)
        {
            DataGridViewTextBoxColumn dgvColumn = new DataGridViewTextBoxColumn();
        
            dgvColumn.DataPropertyName = Name;
            dgvColumn.Name = Name;
            dgvColumn.ReadOnly = true;
            dgvColumn.Visible = Visable;
            dgvColumn.Width = Width;
            dgvColumn.HeaderText = headname;
            if (!Sort)
                dgvColumn.SortMode = DataGridViewColumnSortMode.NotSortable;
            dgvColumn.DisplayIndex = Grid.Columns.Count;
            Grid.Columns.Add(dgvColumn);
        }
        public static void SetColumnAddStyle(DataGridView Grid, string Name, int Width, bool Visable, bool Sort)
        {
            DDSCDataGridViewTextBoxColumn dgvColumn = new DDSCDataGridViewTextBoxColumn(); 
            dgvColumn.Name = Name;
            dgvColumn.ReadOnly = true;
            dgvColumn.Visible = Visable;
            dgvColumn.Width = Width;
            dgvColumn.HeaderText = Name;
            if (!Sort)
                dgvColumn.SortMode = DataGridViewColumnSortMode.NotSortable;
            dgvColumn.DisplayIndex = Grid.Columns.Count;
            Grid.Columns.Add(dgvColumn);
        }
        public static void SetColumnGroupStyle(DataGridView Grid, string Name, int Width, bool Visable, bool Sort)
        {
            DataGridViewGroupColumn dgvColumn = new DataGridViewGroupColumn();
            dgvColumn.DataPropertyName = Name;
            dgvColumn.Name = Name;
            dgvColumn.ReadOnly = true;
            dgvColumn.Visible = Visable;
            dgvColumn.Width = Width;
           
            dgvColumn.HeaderText = "";
            if (!Sort)
                dgvColumn.SortMode = DataGridViewColumnSortMode.NotSortable;
            dgvColumn.DisplayIndex = Grid.Columns.Count;
            Grid.Columns.Add(dgvColumn);
        }

        

        public static void SetStyle(string prog_name, string collectId, Dictionary<string, object> dicControls)
        {
            try
            {

                if (collectId == "")
                    prog_name = prog_name.Split(':')[0];
                if (frmMain.UserConfigs.FORM_SET == null) return;
                foreach (DataRow drColumn in frmMain.mobjDataAgent.objControlManager.GridSet.Select("collect_Id='" + collectId + "' and PROG_NAME='" + prog_name + "'  ", "GRID_NAME,DISPLAY_INDEX"))
                {
                    if (drColumn["TYPE"].ToString() == "TEXT")
                    {
                        DataGridViewTextBoxColumn dgvColumn = new DataGridViewTextBoxColumn();
                        dgvColumn.DataPropertyName = drColumn["COLUMN_NAME"].ToString();
                        dgvColumn.Name = drColumn["COLUMN_NAME"].ToString();

                        dgvColumn.Visible = drColumn["VISIBLE"].ToString() == "Y" ? true : false;
                        dgvColumn.HeaderText = drColumn["HEADER_TEXT"].ToString();
                        if (dgvColumn.Visible)
                        {
                            dgvColumn.Width = int.Parse(drColumn["WIDTH"].ToString());
                            dgvColumn.DisplayIndex = int.Parse(drColumn["DISPLAY_INDEX"].ToString());

                            if (drColumn["SORT"].ToString() == "N")
                            {
                                dgvColumn.SortMode = DataGridViewColumnSortMode.NotSortable;
                            }
                        }

                        ((DataGridView)dicControls[drColumn["GRID_NAME"].ToString()]).Columns.Add(dgvColumn);
                    }
                    else if (drColumn["TYPE"].ToString() == "BUTTON")
                    {
                        DataGridViewButtonColumn dgvColumn = new DataGridViewButtonColumn();
                        dgvColumn.DataPropertyName = drColumn["COLUMN_NAME"].ToString();
                        dgvColumn.Name = drColumn["COLUMN_NAME"].ToString();

                        dgvColumn.Visible = drColumn["VISIBLE"].ToString() == "Y" ? true : false;
                        dgvColumn.HeaderText = drColumn["HEADER_TEXT"].ToString();
                        if (dgvColumn.Visible)
                        {
                            dgvColumn.Width = int.Parse(drColumn["WIDTH"].ToString());
                            dgvColumn.DisplayIndex = int.Parse(drColumn["DISPLAY_INDEX"].ToString());

                            if (drColumn["SORT"].ToString() == "N")
                            {
                                dgvColumn.SortMode = DataGridViewColumnSortMode.NotSortable;
                            }

                        }
                        ((DataGridView)dicControls[drColumn["GRID_NAME"].ToString()]).Columns.Add(dgvColumn);
                    }

                }
                foreach (DataRow dr in frmMain.UserConfigs.FORM_SET.Select("collect_Id='" + collectId + "' and PROG_NAME='" + prog_name + "'"))
                {

                    string name = dr["SET_NAME"].ToString();
                    string value = dr["SET_VALUE"].ToString();
                    string type = dr["TYPE"].ToString();
                    setDisplay(name, type, value, dicControls);

                }
            }
            catch (Exception ex)
            {
            }
        }
        public static void SetOneControlStyle(string controlname, string prog_name, string collectId, Dictionary<string, object> dicControls, DataTable dtPROGSet, DataTable dtDisplaySet)
        {

            if (dtPROGSet == null) return;


            foreach (DataRow dr in dtPROGSet.Select(" PROG_NAME='" + prog_name.Split(':')[0] + "' and SET_DESC like '%" + controlname + "%' ", "seq"))
            {
                string desc = dr["SET_DESC"].ToString();
                string ID = dr["SET_ID"].ToString();
                string value = dr["DEFUALT_VALUE"].ToString();
                string type = dr["TYPE"].ToString();


                DataRow drFind = dtDisplaySet.Rows.Find(new object[] { collectId, prog_name, ID });
                if (drFind != null)
                {
                    value = drFind["SET_VALUE"].ToString();
                }

                setDisplay(desc, type, value, dicControls);

            }

        }
        public static void setProprety(PropertyDescriptor prop, object col, string name, string type, string value)
        {
            if (prop != null)
            {



                if (type == "System.Drawing.Point")
                {
                    System.Drawing.Point po = new System.Drawing.Point();
                    po.X = int.Parse(value.Split(',')[0].Split('=')[1]);
                    po.Y = int.Parse(value.Split(',')[1].Split('=')[1].TrimEnd('}'));
                    prop.SetValue(col, po);
                }
                else if (type == "System.Boolean")
                {

                    prop.SetValue(col, bool.Parse(value));
                }
                else if (type == "System.Int32" || type == "System.Int16")
                {
                    prop.SetValue(col, int.Parse(value));
                }
                else if (type == "System.String")
                {
                    prop.SetValue(col, value);
                }
                else if (type == "System.Drawing.Color")
                {
                    prop.SetValue(col, System.Drawing.Color.FromName(value));
                }
                else if (type == "FormWindowState")
                {
                    if (value == "Normal")
                    {
                        prop.SetValue(col, System.Windows.Forms.FormWindowState.Normal);
                    }
                    else if (value == "Maximized")
                    {
                        prop.SetValue(col, System.Windows.Forms.FormWindowState.Maximized);
                    }
                    else if (value == "Minimized")
                    {
                        prop.SetValue(col, System.Windows.Forms.FormWindowState.Minimized);
                    }

                }
                else if (type == "Font")
                {

                    prop.SetValue(col, new System.Drawing.Font(value.Split(',')[0], float.Parse(value.Split(',')[1]), (System.Drawing.FontStyle)int.Parse(value.Split(',')[2])));

                }

            }
        }
        public static void setDisplay(string desc, string type, string value, Dictionary<string, object> dicControls)
        {
            try
            {
                PropertyDescriptor prop = null;
                string name = "";
                string property = "";
                string tab = "";
                if (desc.Contains(":"))
                {
                    tab = desc.Split(':')[0];
                    string kind = desc.Split(':')[1];
                    name = desc.Split(':')[2].Split('.')[0];
                    property = desc.Split(':')[2].Split('.')[1];
                    foreach (System.Windows.Forms.TabPage p in ((System.Windows.Forms.TabControl)dicControls[tab]).TabPages)
                    {

                        if (p.Controls.Count > 0)
                        {
                            System.Windows.Forms.DataGridView dgv = ((System.Windows.Forms.DataGridView)p.Controls[0]);

                            if (dgv.DataSource != null)
                            {
                                if (kind == "c")
                                {
                                    prop = TypeDescriptor.GetProperties(dgv.Columns[name])[property];
                                    setProprety(prop, dgv.Columns[name], name, type, value);
                                }
                                else if (kind == "s")
                                {
                                    prop = TypeDescriptor.GetProperties(dgv.DefaultCellStyle)[property];
                                    setProprety(prop, dgv.DefaultCellStyle, name, type, value);
                                }

                            }
                        }
                    }

                }
                else
                {
                    name = desc.Split('.')[0];
                    property = desc.Split('.')[1];
                    prop = TypeDescriptor.GetProperties(dicControls[name])[property];
                    setProprety(prop, dicControls[name], name, type, value);

                }
            }
            catch (Exception ex)
            {
            }
        }
        public static string getOptionCP(string period)
        {
            period = period.ToUpper();
            string[] cperiod = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L" };
            string[] pperiod = { "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X" };
            string cp = "";
            if (Array.IndexOf<string>(cperiod, period) != -1)
            {
                cp = "C";
            }
            else if (Array.IndexOf<string>(pperiod, period) != -1)
            {
                cp = "P";
            }

            return cp;
        }
        public static int getMonth(string period)
        {
            period = period.ToUpper();
            string[] cperiod = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L" };
            string[] pperiod = { "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X" };
            int returnperiod = 0;
            if (Array.IndexOf<string>(cperiod, period) != -1)
            {
                returnperiod = (Array.IndexOf<string>(cperiod, period) + 1);
            }
            else if (Array.IndexOf<string>(pperiod, period) != -1)
            {
                returnperiod = (Array.IndexOf<string>(pperiod, period) + 1);
            }

            return returnperiod;
        }
        public static string getMonthCode(int month, string cp)
        {
            string monthcode = "";
            if (cp == "" || cp == "C")
            {

                string[] cperiod = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L" };
                monthcode = cperiod[month - 1];
            }
            else
            {
                string[] pperiod = { "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X" };
                monthcode = pperiod[month - 1];
            }

            return monthcode;
        }
        public static string getYearCode(string year)
        {

            return year.Substring(year.Length - 1);
        }

        public static string getPeriod(string code)
        {

            string monthcode = code.Substring(0, 1).ToUpper();
            string[] cperiod = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L" };
            string[] pperiod = { "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X" };
            int montho = 0;
            if (Array.IndexOf<string>(cperiod, monthcode) != -1)
            {
                montho = (Array.IndexOf<string>(cperiod, monthcode) + 1);
            }
            else if (Array.IndexOf<string>(pperiod, monthcode) != -1)
            {
                montho = (Array.IndexOf<string>(pperiod, monthcode) + 1);
            }

            //return "201" + code.Substring(1) + montho.ToString().PadLeft(2, '0');
            return systemconfigs.LogDate.Substring(0, 3) + code.Substring(1) + montho.ToString().PadLeft(2, '0');
        }
        public static string getStrikePrice(string CommodityId)
        {
            DataRow[] dr = systemconfigs.OptionData.Select("Commodity_Id='" + CommodityId + "' ");
            return dr[0]["strike_price"].ToString().Trim();

        }
        /// <summary>
        /// 取得目前價位tick
        /// </summary>
        public static decimal addTick(string KIND_ID, decimal dblPrice, decimal tick)
        {
            decimal dblTick = 0;
            decimal returnPrice = dblPrice;
            for (int j = 0; j < Math.Abs(tick); j++)
            {
                KIND_ID = MYcls.CommonFunction.getWeekNameProductClass(KIND_ID);
                DataRow[] drs = systemconfigs.ProductMain.Select("KIND_ID ='" + KIND_ID + "'");
                string STOCK_ID = "";
                if (drs.Length > 0)
                {
                    if (drs[0]["COMTYPE"].ToString().Trim() == "0" && drs[0]["SUBTYPE"].ToString().Trim() == "S")
                        STOCK_ID = "STF";
                    else if (drs[0]["COMTYPE"].ToString().Trim() == "1" && drs[0]["SUBTYPE"].ToString().Trim() == "S")
                        STOCK_ID = "STO";
                }
                //依照商品類別,取得該價位tick
                DataRow[] dr_ProductUnit = MYcls.systemconfigs.TickData.Select(" KIND_ID ='" + KIND_ID + "' ", "range");
                if (dr_ProductUnit.Length == 0)
                    dr_ProductUnit = MYcls.systemconfigs.TickData.Select(" KIND_ID ='" + STOCK_ID + "' ", "range");

                if (dr_ProductUnit.Length > 0)
                {
                    //預設最小tick
                    dblTick = decimal.Parse(dr_ProductUnit[0]["tick"].ToString());
                    for (int i = 0; i < dr_ProductUnit.Length; i++)
                    {
                        //v3.0.0.28	修正7086閃電下單夾價差商品的報價區, 最高 & 最低 & 價格 tick 錯誤
                        //判斷正負數
                        if (returnPrice > 0)
                        {
                            if (returnPrice >= decimal.Parse(dr_ProductUnit[i]["range"].ToString()))
                            {
                                dblTick = decimal.Parse(dr_ProductUnit[i]["tick"].ToString());
                            }
                        }
                        else if (returnPrice < 0)
                        {
                            if (returnPrice <= decimal.Parse("-" + dr_ProductUnit[i]["range"].ToString()))
                            {
                                dblTick = decimal.Parse(dr_ProductUnit[i]["tick"].ToString());
                            }
                        }
                    }
                }
                returnPrice = returnPrice + dblTick * Math.Sign(tick);
            }

            return returnPrice;
        }
        public static string getProductId(string ClassId, string Class_Name, string Settlement_month, string Strike_Price, string CP)
        {
            string productid = "";
            try
            {
                if (ClassId == "1") //期貨
                {
                    //DataRow[] dr = systemconfigs.FutureData.Select("KIND_ID='" + Class_Name + "' and SETTLEMENT_MONTH='" + Settlement_month + "'");
                    //if (dr.Length > 0)
                    //{
                    //    return dr[0]["Commodity_Id"].ToString().Trim();
                    //}
                    //else
                    //{
                    //    return "";
                    //}

                    //改由期交所邏輯組成
                    productid = Class_Name.Trim() + getMonthCode(int.Parse(Settlement_month.Substring(4, 2)), "") + getYearCode(Settlement_month.Substring(3, 1));
                }
                else   //選擇權
                {
                    //DataRow[] dr = systemconfigs.OptionData.Select("KIND_ID='" + Class_Name + "' and SETTLEMENT_MONTH='" + Settlement_month + "' and CP='" + CP + "' and STRIKE_PRICE='" + Strike_Price + "'");
                    //if (dr.Length > 0)
                    //{
                    //    return dr[0]["Commodity_Id"].ToString().Trim();
                    //}
                    //else
                    //{
                    //    return "";
                    //}
                    Class_Name = Class_Name.Trim();
                    DataRow[] drs = drs = systemconfigs.ProductMain.Select("KIND_ID ='" + Class_Name + "'");
                    if (drs.Length > 0)
                    {

                        double strike = 0;

                        double strike_decimal = 0;
                        double.TryParse(drs[0]["STRIKE_DECIMAIL"].ToString(), out strike_decimal);
                        double tmpStrike_Price = double.Parse(Strike_Price);

                        tmpStrike_Price = tmpStrike_Price * Math.Pow(10, strike_decimal);

                        productid = Class_Name.Trim() + tmpStrike_Price.ToString("00000") + getMonthCode(int.Parse(Settlement_month.Substring(4, 2)), CP) + getYearCode(Settlement_month.Substring(3, 1));

                    }

                }
            }
            catch (Exception ex)
            {

            }
            return productid;
        }
        public static string getProductId(string ClassId, string Class_Name, string Class_Name2, string Settlement_month1, string Settlement_month2, string CP1, string CP2, string Strike_Price1, string Strike_Price2, string bs1, string bs2, ref string multiBS)
        {

            string yearcode1 = getYearCode(Settlement_month1.Substring(0, 4));
            string monthcode1 = getMonthCode(int.Parse(Settlement_month1.Substring(4)), CP1);
            string yearcode2 = getYearCode(Settlement_month2.Substring(0, 4));
            string monthcode2 = getMonthCode(int.Parse(Settlement_month2.Substring(4)), CP2);

            double yearmonth1 = int.Parse(Settlement_month1) + getProductClassShortWeekNameInt(Class_Name);
            double yearmonth2 = int.Parse(Settlement_month2) + getProductClassShortWeekNameInt(Class_Name2);
            if (ClassId == "1") //期貨
            {
                if (yearmonth1 != yearmonth2)//20130627 1.0.0.32 小台短天期修改 by peter
                {
                    if (yearmonth1 > yearmonth2)
                    {
                        changeFutureFoot(ref  bs1, ref  bs2, ref monthcode1, ref monthcode2, ref  yearcode1, ref yearcode2);

                    }
                    multiBS = bs2;
                    if (Class_Name != Class_Name2 && Class_Name.Contains("MX"))   //20130627 1.0.0.32 小台短天期修改 by peter
                        return Class_Name + monthcode1 + yearcode1 + "/" + Class_Name2 + monthcode2 + yearcode2;
                    else
                        return Class_Name + monthcode1 + yearcode1 + "/" + monthcode2 + yearcode2;
                }
            }
            else   //選擇權
            {


                DataRow[] drs = drs = systemconfigs.ProductMain.Select("KIND_ID ='" + Class_Name + "'");
                if (drs.Length > 0)
                {

                    double strike_decimal = 0;
                    double.TryParse(drs[0]["STRIKE_DECIMAIL"].ToString(), out strike_decimal);
                    double tmpStrike_Price = double.Parse(Strike_Price1);

                    tmpStrike_Price = tmpStrike_Price * Math.Pow(10, strike_decimal);
                    Strike_Price1 = tmpStrike_Price.ToString("00000");
                    tmpStrike_Price = double.Parse(Strike_Price2);

                    tmpStrike_Price = tmpStrike_Price * Math.Pow(10, strike_decimal);
                    Strike_Price2 = tmpStrike_Price.ToString("00000");
                }
                if (yearmonth1 != yearmonth2)//跨月價差
                {
                    if (CP1 == CP2)
                    {
                        if (yearmonth1 > yearmonth2)
                        {
                            changeOptionFoot(ref Class_Name, ref Class_Name2, ref  bs1, ref  bs2, ref monthcode1, ref monthcode2, ref  yearcode1, ref yearcode2, ref Strike_Price1, ref Strike_Price2, ref CP1, ref CP2);

                        }
                        multiBS = bs2;

                        if (Class_Name != Class_Name2 && Class_Name.Contains("TX"))
                            return Class_Name + Strike_Price1 + monthcode1 + yearcode1 + "/" + Class_Name2 + monthcode2 + yearcode2;
                        else
                            return Class_Name + Strike_Price1 + monthcode1 + yearcode1 + "/" + monthcode2 + yearcode2;





                    }
                }
                else
                {


                    //判斷買賣別如果相同為跨式\勒式組合
                    if (bs1 == bs2)
                    {
                        if (CP1 != CP2)
                        {
                            if (CP1 == "P")
                            {
                                changeOptionFoot(ref Class_Name, ref Class_Name2, ref  bs1, ref  bs2, ref monthcode1, ref monthcode2, ref  yearcode1, ref yearcode2, ref Strike_Price1, ref Strike_Price2, ref CP1, ref CP2);
                            }
                            multiBS = bs2;
                            //跨式,價位相同
                            if (Strike_Price1 == Strike_Price2)
                            {
                                return Class_Name + Strike_Price1 + monthcode1 + yearcode1 + ":" + monthcode2 + yearcode2;

                            }
                            else
                            {
                                //勒式
                                return Class_Name + Strike_Price1 + monthcode1 + yearcode1 + ":" + Strike_Price2 + monthcode2 + yearcode2;

                            }
                        }

                    }
                    else
                    {
                        //價格價差,價位不同
                        if (Strike_Price1 != Strike_Price2)
                        {
                            if (CP1 == CP2)
                            {

                                if ((CP1 == "C" && int.Parse(Strike_Price1) < int.Parse(Strike_Price2)) || (CP1 == "P" && int.Parse(Strike_Price1) > int.Parse(Strike_Price2)))
                                {
                                    changeOptionFoot(ref Class_Name, ref Class_Name2, ref  bs1, ref  bs2, ref monthcode1, ref monthcode2, ref  yearcode1, ref yearcode2, ref Strike_Price1, ref Strike_Price2, ref CP1, ref CP2);
                                }
                                multiBS = bs2;
                                return Class_Name + Strike_Price1 + "/" + Strike_Price2 + monthcode1 + yearcode1;
                            }

                        }
                        else
                        {

                            if (CP1 != CP2)
                            {


                                if (CP1 == "P")
                                {
                                    changeOptionFoot(ref Class_Name, ref Class_Name2, ref  bs1, ref  bs2, ref monthcode1, ref monthcode2, ref  yearcode1, ref yearcode2, ref Strike_Price1, ref Strike_Price2, ref CP1, ref CP2);

                                }
                                multiBS = bs2;
                                return Class_Name + Strike_Price1 + monthcode1 + yearcode1 + "-" + monthcode2 + yearcode2;

                            }

                        }
                    }
                }
            }
            return "";
        }
        public static void changeOptionFoot(ref string class_id1, ref string class_id2, ref string bs1, ref string bs2, ref string monthcode1, ref string monthcode2, ref string yearcode1, ref string yearcode2, ref string strikeprice1, ref string strikeprice2, ref string cp1, ref string cp2)
        {
            string tempMonthcode = "";
            string tempYearcode = "";
            string tempstrikeprice = "";
            string tempcp = "";
            string tempbs = "";
            string tempclass_id = "";


            tempMonthcode = monthcode1;
            tempYearcode = yearcode1;
            tempstrikeprice = strikeprice1;
            tempcp = cp1;
            tempbs = bs1;

            monthcode1 = monthcode2;
            yearcode1 = yearcode2;
            strikeprice1 = strikeprice2;
            cp1 = cp2;
            bs1 = bs2;

            monthcode2 = tempMonthcode;
            yearcode2 = tempYearcode;

            strikeprice2 = tempstrikeprice;
            cp2 = tempcp;
            bs2 = tempbs;

            tempclass_id = class_id1;
            class_id1 = class_id2;
            class_id2 = tempclass_id;
        }
        public static void changeFutureFoot(ref string bs1, ref string bs2, ref string monthcode1, ref string monthcode2, ref string yearcode1, ref string yearcode2)
        {
            string tempMonthcode = "";
            string tempYearcode = "";
            string tempbs = "";

            tempMonthcode = monthcode1;
            tempYearcode = yearcode1;
            tempbs = bs1;

            monthcode1 = monthcode2;
            yearcode1 = yearcode2;
            bs1 = bs2;


            monthcode2 = tempMonthcode;
            yearcode2 = tempYearcode;
            bs2 = tempbs;

        }
        public static string getARGBString(System.Drawing.Color color)
        {
            return color.A.ToString() + "," + color.R.ToString() + "," + color.G.ToString() + "," + color.B.ToString();
        }
        public static System.Drawing.Color getStringToColor(string color)
        {
            return System.Drawing.Color.FromArgb(int.Parse(color.Split(',')[0].ToString().Trim()), int.Parse(color.Split(',')[1].ToString().Trim()), int.Parse(color.Split(',')[2].ToString().Trim()), int.Parse(color.Split(',')[3].ToString().Trim()));
        }
    //    public static void exportExcel(string ProgName, DataTable dtExportData, DataGridViewColumnCollection dgvColumns, DataTable dtExportDetailData, DataGridViewColumnCollection dgvDetailColumns)
    //    {
    //        SaveFileDialog of = new SaveFileDialog();
    //        of.Filter = "Excel Worksheets|*.xls";
    //        ProgramInfo info = frmMain.UserConfigs.ProgramSet.GetData( ProgName.Split(':')[0]);
           
    //        string  defaultFilename="";
    //        if (info != null)
    //            defaultFilename =   info.prog_desc + ".xls";
    //        of.FileName = defaultFilename;

    //        of.ShowDialog();
    //        Microsoft.Office.Interop.Excel.Worksheet wsheet;
    //        Microsoft.Office.Interop.Excel.Workbook wbook;
    //        Microsoft.Office.Interop.Excel.Application wapp = new Microsoft.Office.Interop.Excel.Application();
    //        wapp.Visible = false;
    //        wbook = wapp.Workbooks.Add(true);
    //        wsheet = (Microsoft.Office.Interop.Excel.Worksheet)wbook.ActiveSheet;
    //        int iX = 1;
    //        int iY = 1;
    //        System.Data.DataTable dtData = new System.Data.DataTable();
    //        dtData.Columns.Add("index", typeof(int));
    //        dtData.Columns.Add("name", typeof(string));
    //        dtData.Columns.Add("text", typeof(string));

    //        foreach (DataGridViewColumn dgvColumn in dgvColumns)
    //        {
    //            if (dgvColumn.Visible)
    //            {
    //                System.Data.DataRow drData = dtData.NewRow();
    //                drData["index"] = dgvColumn.DisplayIndex;
    //                drData["name"] = dgvColumn.Name;
    //                drData["text"] = dgvColumn.HeaderText;
    //                dtData.Rows.Add(drData);
    //            }
    //        }

    //        foreach (System.Data.DataRow dr in dtData.Select("", "index"))
    //        {
    //            wsheet.Cells[iY, iX] = dr["text"].ToString().Trim();
    //            iX++;
    //        }

    //        for (int i = 0; i < dtExportData.Rows.Count; i++)
    //        {
    //            int j = 0;
    //            iY++;
    //            foreach (System.Data.DataRow drData in dtData.Select("", "index"))
    //            {
    //                try
    //                {
    //                    wsheet.Cells[iY, j + 1] = (dtExportData.Rows[i][drData["name"].ToString().Trim()] == null) ? "" : dtExportData.Rows[i][drData["name"].ToString().Trim()].ToString();
    //                }
    //                catch (Exception ex)
    //                {
    //                    //  MessageBox.Show(ex.Message);
    //                }
    //                j++;
    //            }
    //        }
    //        if (dgvDetailColumns != null)
    //        {
    //            System.Data.DataTable dtDetail = new System.Data.DataTable();
    //            dtDetail.Columns.Add("index", typeof(int));
    //            dtDetail.Columns.Add("name", typeof(string));
    //            dtDetail.Columns.Add("text", typeof(string));

    //            foreach (DataGridViewColumn dgvColumn in dgvDetailColumns)
    //            {
    //                if (dgvColumn.Visible)
    //                {
    //                    System.Data.DataRow drData = dtDetail.NewRow();
    //                    drData["index"] = dgvColumn.DisplayIndex;
    //                    drData["name"] = dgvColumn.Name;
    //                    drData["text"] = dgvColumn.HeaderText;
    //                    dtDetail.Rows.Add(drData);
    //                }
    //            }
    //            iX = 1;
    //            iY += 2;
    //            foreach (System.Data.DataRow dr in dtDetail.Select("", "index"))
    //            {
    //                wsheet.Cells[iY, iX] = dr["text"].ToString().Trim();
    //                iX++;
    //            }
    //            for (int i = 0; i < dtExportDetailData.Rows.Count; i++)
    //            {
    //                int j = 0;
    //                iY++;
    //                foreach (System.Data.DataRow drData in dtDetail.Select("", "index"))
    //                {
    //                    try
    //                    {
    //                        wsheet.Cells[iY, j + 1] = (dtExportDetailData.Rows[i][drData["name"].ToString().Trim()] == null) ? "" : dtExportDetailData.Rows[i][drData["name"].ToString().Trim()].ToString();
    //                    }
    //                    catch (Exception ex)
    //                    {
    //                        //  MessageBox.Show(ex.Message);
    //                    }
    //                    j++;
    //                }
    //            }
    //        }

    //        wapp.Visible = true;
    //        wapp.DisplayAlerts = false;
    //        wapp.UserControl = true;
    //        if (of.FileName != defaultFilename)
    //            wbook.SaveAs(of.FileName, Type.Missing,
    //Type.Missing, Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlNoChange,
    //Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
    //        wapp.DisplayAlerts = true;
    //    }
        // from 3.0.0.8
        //private string[] MultipleProductId(string type, string ID_1st, string ID_2nd, string bs1, string bs2, string productdesc)
        //{


        //    string[] strReturn = new string[13];//第一個id,第二個策略
        //    //預設串英文
        //    strReturn[2] = ID_1st + "  " + ID_2nd;

        //    string classid = ID_1st.Substring(0, 3);
        //    string period1 = ID_1st.Substring(ID_1st.Length - 2, 2);
        //    string period2 = ID_2nd.Substring(ID_2nd.Length - 2, 2);
        //    int yearmonth1 = int.Parse("201" + period1.Substring(1, 1) + getOptionPeriod(period1.Substring(0, 1)).ToString().PadLeft(2, '0'));
        //    int yearmonth2 = int.Parse("201" + period2.Substring(1, 1) + getOptionPeriod(period2.Substring(0, 1)).ToString().PadLeft(2, '0'));

        //    if (type == "3")
        //    {

        //        string strikeprice1 = ID_1st.Substring(3, 5);
        //        string strikeprice2 = ID_2nd.Substring(3, 5);
        //        string cp1 = getOptionCP(period1.Substring(0, 1));
        //        string cp2 = getOptionCP(period2.Substring(0, 1));

        //        //判斷買賣別如果相同為跨式\勒式組合
        //        if (bs1 == bs2)
        //        {
        //            if (yearmonth1 == yearmonth2)
        //            {
        //                if (cp1 != cp2)
        //                {
        //                    if (cp1 == "P")
        //                    {
        //                        changeOptionFoot(ref  ID_1st, ref  ID_2nd, ref  bs1, ref  bs2, ref  period1, ref period2, ref strikeprice1, ref strikeprice2, ref cp1, ref cp2);
        //                    }
        //                    //跨式,價位相同
        //                    if (strikeprice1 == strikeprice2)
        //                    {
        //                        strReturn[0] = classid + strikeprice1 + period1 + ":" + period2;
        //                        strReturn[1] = "3";

        //                        strReturn[2] = productdesc + decimal.Parse(strikeprice1).ToString("#0.#") + cp1 + ":" + cp2 + getOptionPeriod(period2.Substring(0, 1));

        //                    }
        //                    else
        //                    {
        //                        //勒式
        //                        strReturn[0] = classid + strikeprice1 + period1 + ":" + strikeprice2 + period2;
        //                        strReturn[1] = "4";

        //                        strReturn[2] = productdesc + decimal.Parse(strikeprice1).ToString("#0.#") + cp1 + ":" + decimal.Parse(strikeprice2).ToString("#0.#") + cp2 + getOptionPeriod(period1.Substring(0, 1));
        //                    }
        //                }
        //            }
        //        }
        //        else
        //        {
        //            //價格價差,價位不同
        //            if (strikeprice1 != strikeprice2)
        //            {
        //                if (yearmonth1 == yearmonth2)
        //                {
        //                    if (cp1 == cp2)
        //                    {


        //                        if ((cp1 == "C" && int.Parse(strikeprice1) < int.Parse(strikeprice2)) || (cp1 == "P" && int.Parse(strikeprice1) > int.Parse(strikeprice2)))
        //                        {
        //                            changeOptionFoot(ref  ID_1st, ref  ID_2nd, ref  bs1, ref  bs2, ref  period1, ref period2, ref strikeprice1, ref strikeprice2, ref cp1, ref cp2);
        //                        }


        //                        strReturn[0] = classid + strikeprice1 + "/" + strikeprice2 + period2;
        //                        strReturn[1] = "1";
        //                        strReturn[2] = productdesc + decimal.Parse(strikeprice1).ToString("#0.#") + "/" + decimal.Parse(strikeprice2).ToString("#0.#") + cp1 + getOptionPeriod(period2.Substring(0, 1));
        //                    }
        //                }

        //            }
        //            else
        //            {
        //                //判斷月份如不相同為跨月價差                    
        //                if (yearmonth1 != yearmonth2)
        //                {

        //                    if (cp1 == cp2)
        //                    {


        //                        if (yearmonth1 > yearmonth2)
        //                        {
        //                            changeOptionFoot(ref  ID_1st, ref  ID_2nd, ref  bs1, ref  bs2, ref  period1, ref period2, ref strikeprice1, ref strikeprice2, ref cp1, ref cp2);

        //                        }

        //                        strReturn[0] = classid + strikeprice1 + period1 + "/" + period2;
        //                        strReturn[1] = "2";
        //                        strReturn[2] = productdesc + decimal.Parse(strikeprice1).ToString("#0.#") + cp1 + getOptionPeriod(period1.Substring(0, 1)) + "/" + getOptionPeriod(period2.Substring(0, 1));
        //                    }
        //                }
        //                else if (yearmonth1 == yearmonth2)
        //                {
        //                    if (cp1 != cp2)
        //                    {


        //                        if (cp1 == "P")
        //                        {
        //                            changeOptionFoot(ref  ID_1st, ref  ID_2nd, ref  bs1, ref  bs2, ref  period1, ref period2, ref strikeprice1, ref strikeprice2, ref cp1, ref cp2);

        //                        }
        //                        strReturn[0] = classid + strikeprice1 + period1 + "-" + period2;
        //                        strReturn[1] = "5";
        //                        strReturn[2] = productdesc + decimal.Parse(strikeprice1).ToString("#0.#") + cp1 + "-" + cp2 + getOptionPeriod(period1.Substring(0, 1));
        //                    }
        //                }
        //            }
        //        }
        //        strReturn[7] = cp1;
        //        strReturn[8] = cp2;
        //        strReturn[9] = decimal.Parse(strikeprice1).ToString("#0.#");
        //        strReturn[10] = decimal.Parse(strikeprice2).ToString("#0.#");
        //    }
        //    else if (type == "4")
        //    {


        //        if (yearmonth1 != yearmonth2)
        //        {


        //            if (yearmonth1 > yearmonth2)
        //            {
        //                changeFutureFoot(ref  ID_1st, ref  ID_2nd, ref  bs1, ref  bs2, ref  period1, ref period2);

        //            }

        //            strReturn[0] = classid + period1 + "/" + period2;
        //            strReturn[1] = "0";
        //            strReturn[2] = productdesc + getOptionPeriod(period1.Substring(0, 1)) + "/" + getOptionPeriod(period2.Substring(0, 1));
        //        }
        //    }
        //    strReturn[3] = ID_1st;
        //    strReturn[4] = ID_2nd;
        //    strReturn[5] = bs1;
        //    strReturn[6] = bs2;

        //    strReturn[11] = "201" + period1.Substring(1, 1) + getOptionPeriod(period1.Substring(0, 1)).ToString().PadLeft(2, '0');
        //    strReturn[12] = "201" + period2.Substring(1, 1) + getOptionPeriod(period2.Substring(0, 1)).ToString().PadLeft(2, '0');

        //    return strReturn;
        //}
        //編碼 
        public static string GetCheckNo(string acct)
        {
            string s = acct;
            int len = s.Length;
            int idx = 1;
            Int32 total = 0;
            string checkNo = "";

            for (idx = 1; idx <= len; idx++)
            {
                total += idx * Convert.ToInt32(s.Substring(idx - 1, 1));

            }

            for (idx = total.ToString().Length; idx > 0; idx--)
            {
                checkNo += total.ToString().Substring(idx - 1, 1);
            }
            return checkNo;
        }
        public static string getErrorMsg(string msgcode)
        {
            string err = "";
            DataRow[] dr = systemconfigs.MessageCode.Select("msgcode='" + msgcode + "' ");
            if (dr.Length > 0)
            {
                err = dr[0]["msgdata"].ToString().Trim();

            }
            return err;
        }
        public static string GenerateHash(string Filename)
        {
            //Create an encoding object to ensure the encoding standard for the source text
            //Retrieve a byte array based on the source text
            byte[] ByteSourceText = System.IO.File.ReadAllBytes(Filename);
            //Instantiate an MD5 Provider object
            SHA256Managed SHA256 = new SHA256Managed();
            //Compute the hash value from the source
            byte[] ByteHash = SHA256.ComputeHash(ByteSourceText);
            //And convert it to String format for return
            return BitConverter.ToString(ByteHash);
        }
        public static string TripleDESEncode(string value, string key)
        {
            TripleDESCryptoServiceProvider des = new TripleDESCryptoServiceProvider();
            des.IV = new byte[8];
            PasswordDeriveBytes pdb = new PasswordDeriveBytes(key, new byte[-1 + 1]);
            des.Key = pdb.CryptDeriveKey("RC2", "MD5", 128, new byte[8]);
            System.IO.MemoryStream ms = new System.IO.MemoryStream((value.Length * 2) - 1);
            CryptoStream encStream = new CryptoStream(ms, des.CreateEncryptor(), CryptoStreamMode.Write);
            byte[] plainBytes = Encoding.UTF8.GetBytes(value);
            encStream.Write(plainBytes, 0, plainBytes.Length);
            encStream.FlushFinalBlock();
            byte[] encryptedBytes = new byte[(ms.Length)];
            ms.Position = 0;
            ms.Read(encryptedBytes, 0, System.Convert.ToInt32(ms.Length));
            encStream.Close();
            return Convert.ToBase64String(encryptedBytes);
        }
        public static string TripleDESDecode(string value, string key)
        {
            TripleDESCryptoServiceProvider des = new TripleDESCryptoServiceProvider();
            des.IV = new byte[8];
            PasswordDeriveBytes pdb = new PasswordDeriveBytes(key, new byte[-1 + 1]);
            des.Key = pdb.CryptDeriveKey("RC2", "MD5", 128, new byte[8]);
            byte[] encryptedBytes = Convert.FromBase64String(value);
            System.IO.MemoryStream ms = new System.IO.MemoryStream(value.Length);
            CryptoStream decStream = new CryptoStream(ms, des.CreateDecryptor(), CryptoStreamMode.Write);
            decStream.Write(encryptedBytes, 0, encryptedBytes.Length);
            decStream.FlushFinalBlock();
            byte[] plainBytes = new byte[(ms.Length)];
            ms.Position = 0;
            ms.Read(plainBytes, 0, System.Convert.ToInt32(ms.Length));
            decStream.Close();
            return Encoding.UTF8.GetString(plainBytes);
        }
        /// <summary>
        /// 取得桌面路徑
        /// </summary>
        public static string getDesktopPath()
        {
            string strReturnPath = "";
            try
            {

                string userprofile = Environment.GetEnvironmentVariable("USERPROFILE");


                strReturnPath = userprofile + @"\桌面";
                if (!Directory.Exists(strReturnPath)) strReturnPath = userprofile + @"\Desktop";

            }
            catch (Exception ex)
            {
                throw (ex);
            }
            return strReturnPath;
        }
        public static string getOrderConditionDesc(string code)
        {
            string desc = "";
            switch (code)
            {
                case "R":
                    desc = "ROD";
                    break;
                case "I":
                    desc = "IOC";
                    break;
                case "F":
                    desc = "FOK";
                    break;
            }
            return desc;
        }
        public static string getOpenOffFlagDesc(string code)
        {
            string desc = "";
            switch (code.Trim())
            {
                case "":
                    desc = "自動";
                    break;
                //case "2":
                //    desc = "自動";
                //    break;
                case "0":
                    desc = "新倉";
                    break;
                case "1":
                    desc = "平倉";
                    break;
            }
            return desc;
        }
        public static string getDTradeDesc(string code)
        {
            string desc = "";
            switch (code)
            {
                case "2":
                case "Y":
                    desc = "當沖";
                    break;
                case "":
                case "0":
                case "1":
                case "N":
                    desc = "非當沖";
                    break;
            }
            return desc;
        }
        public static string getProductKindDesc(string code)
        {
            string desc = "";
            switch (code)
            {
                case "1":
                    desc = "期貨";
                    break;
                case "2":
                    desc = "選擇權";
                    break;
                case "3":
                    desc = "複式選擇權";
                    break;
                case "4":
                    desc = "複式期貨";
                    break;
            }
            return desc;
        }
        public static string getOrderMediaDesc(string code)
        {
            string desc = "";
            switch (code)
            {
                case "0":
                    desc = "現場";
                    break;
                case "1":
                    desc = "電話";
                    break;
                case "2":
                    desc = "MAIL";
                    break;
                case "3":
                    desc = "傳真";
                    break;
                case "A":
                    desc = "API下單";
                    break;
            }
            return desc;
        }
        public static string getOrderConditionCode(string desc)
        {
            string code = "";
            switch (desc)
            {
                case "ROD":
                    code = "R";
                    break;
                case "IOC":
                    code = "I";
                    break;
                case "FOK":
                    code = "F";
                    break;
            }
            return code;
        }
        public static string getOpenOffFlagCode(string desc)
        {
            string code = "";
            switch (desc)
            {
                case "自動":
                    code = "";
                    break;
                case "新倉":
                    code = "0";
                    break;
                case "平倉":
                    code = "1";
                    break;
            }
            return code;
        }
        public static string getDTradeCode(string desc)
        {
            string code = "";
            switch (desc)
            {
                case "當沖":
                    code = "Y";
                    break;
                case "非當沖":
                    code = "N";
                    break;
            }
            return code;
        }
        public static string getProductKindCode(string desc)
        {
            string code = "";
            switch (desc)
            {
                case "期貨":
                    code = "1";
                    break;
                case "選擇權":
                    code = "2";
                    break;
                case "複式選擇權":
                    code = "3";
                    break;
                case "複式期貨":
                    code = "4";
                    break;
            }
            return code;
        }
        public static string getOrderMediaCode(string desc)
        {
            string code = "";
            switch (desc)
            {
                case "現場":
                    code = "0";
                    break;
                case "電話":
                    code = "1";
                    break;
                case "MAIL":
                    code = "2";
                    break;
                case "傳真":
                    code = "3";
                    break;
                case "API下單":
                    code = "A";
                    break;
            }
            return code;
        }
        public static decimal getFinalPrice(string productkind, string productid)
        {
            decimal finalprice = 0;
            if (productkind == "1" || productkind == "4")
            {
                DataRow[] dr = systemconfigs.FutureData.Select("COMMODITY_ID='" + productid + "' ");
                if (dr.Length > 0)
                {
                    finalprice = decimal.Parse(dr[0]["closeprice"].ToString().Trim());

                }
            }
            else if (productkind == "2" || productkind == "3")
            {
                DataRow[] dr = systemconfigs.OptionData.Select("COMMODITY_ID='" + productid + "' ");
                if (dr.Length > 0)
                {
                    finalprice = decimal.Parse(dr[0]["closeprice"].ToString().Trim());

                }
            }

            return decimal.Parse(finalprice.ToString("#0.####"));
        }
        public static string getProductClassShortWeekName(string ProductClass)
        {
            string week = "";
            if (ProductClass == "TX1")
                week = "W1";
            else if (ProductClass == "TX2")
                week = "W2";
            else if (ProductClass == "TX4")
                week = "W4";
            else if (ProductClass == "TX5")
                week = "W5";
            else if (ProductClass == "MX1")        //20130627 1.0.0.32 小台短天期修改 by peter
                week = "W1";
            else if (ProductClass == "MX2")
                week = "W2";
            else if (ProductClass == "MX4")
                week = "W4";
            else if (ProductClass == "MX5")
                week = "W5";
            return week;

        }
        public static string getWeekNameProductClassForOptionData(string ProductClass, string week)
        {
            string Product = ProductClass;

            if (ProductClass == "TXO")
            {
                if (week == "W1")
                    Product = "TX1";
                else if (week == "W2")
                    Product = "TX2";
                else if (week == "W4")
                    Product = "TX4";
                else if (week == "W5")
                    Product = "TX5";
            }
            return Product;

        }
        public static double getProductClassShortWeekNameInt(string ProductClass)
        {
            double week = 0.3;
            if (ProductClass == "TX1")
                week = 0.1;
            else if (ProductClass == "TX2")
                week = 0.2;
            else if (ProductClass == "TX4")
                week = 0.4;
            else if (ProductClass == "TX5")
                week = 0.5;
            else if (ProductClass == "MX1")         //20130627 1.0.0.32 小台短天期修改 by peter
                week = 0.1;
            else if (ProductClass == "MX2")
                week = 0.2;
            else if (ProductClass == "MX4")
                week = 0.4;
            else if (ProductClass == "MX5")
                week = 0.5;

            return week;

        }
        public static string getWeekNameProductClass(string ProductClass)
        {
            string Product = ProductClass;
            if (ProductClass == "TX1")
                Product = "TXO";
            else if (ProductClass == "TX2")
                Product = "TXO";
            else if (ProductClass == "TX4")
                Product = "TXO";
            else if (ProductClass == "TX5")
                Product = "TXO";
            else if (ProductClass == "MX1")         //20130627 1.0.0.32 小台短天期修改 by peter
                Product = "MXF";
            else if (ProductClass == "MX2")
                Product = "MXF";
            else if (ProductClass == "MX4")
                Product = "MXF";
            else if (ProductClass == "MX5")
                Product = "MXF";
            return Product;

        }

        public static string checkPrice(string productkind, string productid, decimal dblPrice, decimal MAX_PRICE, decimal MIN_PRICE)
        {
            if (MAX_PRICE == 0 && MIN_PRICE == 0)
            {
                //取得商品漲跌停價 
                //期貨
                if (productkind == "1")
                {
                    DataRow[] drData = MYcls.systemconfigs.FutureData.Select("Commodity_Id='" + productid + "'");
                    if (drData.Length > 0)
                    {
                        MAX_PRICE = decimal.Parse(drData[0]["MAX_PRICE"].ToString());
                        MIN_PRICE = decimal.Parse(drData[0]["MIN_PRICE"].ToString());
                    }
                }
                else if (productkind == "2")//選擇權
                {
                    DataRow[] drData = MYcls.systemconfigs.OptionData.Select("Commodity_Id='" + productid + "'");
                    if (drData.Length > 0)
                    {
                        MAX_PRICE = decimal.Parse(drData[0]["MAX_PRICE"].ToString());
                        MIN_PRICE = decimal.Parse(drData[0]["MIN_PRICE"].ToString());
                    }
                }
                else if (productkind == "4")//價差
                {
                    string id1 = "";
                    string id2 = "";
                    //20130627 1.0.0.32 小台短天期修改 by peter   
                    if (productid.Trim().Length != 11)
                    {
                        id1 = productid.Substring(0, 5);
                        id2 = productid.Substring(0, 3) + productid.Substring(6, 2);
                    }
                    else
                    {
                        id1 = productid.Substring(0, 5);
                        id2 = productid.Substring(6, 3) + productid.Substring(9, 2);
                    }
                    decimal max1 = 0;
                    decimal max2 = 0;
                    decimal min1 = 0;
                    decimal min2 = 0;
                    DataRow[] drData = MYcls.systemconfigs.FutureData.Select("Commodity_Id='" + id1 + "'");
                    if (drData.Length > 0)
                    {
                        max1 = decimal.Parse(drData[0]["MAX_PRICE"].ToString());
                        min1 = decimal.Parse(drData[0]["MIN_PRICE"].ToString());
                    }
                    drData = MYcls.systemconfigs.FutureData.Select("Commodity_Id='" + id2 + "'");
                    if (drData.Length > 0)
                    {
                        max2 = decimal.Parse(drData[0]["MAX_PRICE"].ToString());
                        min2 = decimal.Parse(drData[0]["MIN_PRICE"].ToString());
                    }
                    MAX_PRICE = max2 - min1;
                    MIN_PRICE = min2 - max1;
                }
            }
            if (dblPrice > MAX_PRICE)
            {
                return "超過漲停價!!";
            }
            if (dblPrice < MIN_PRICE)
            {
                return "超過跌停價!!";
            }
            decimal dblTick = 0;
            string KIND_ID = MYcls.CommonFunction.getWeekNameProductClass(productid.Substring(0, 3));
            //DataRow[] drs = systemconfigs.ProductMain.Select("KIND_ID ='" + KIND_ID + "'");
            //if (drs.Length > 0)
            //{
            //    if (drs[0]["COMTYPE"].ToString().Trim() == "0" && drs[0]["SUBTYPE"].ToString().Trim() == "S")
            //        KIND_ID = "STF";
            //    else if (drs[0]["COMTYPE"].ToString().Trim() == "1" && drs[0]["SUBTYPE"].ToString().Trim() == "S")
            //        KIND_ID = "STO";
            //}
            //依照商品類別,取得該價位tick
            DataRow[] dr_ProductUnit = MYcls.systemconfigs.TickData.Select(" KIND_ID ='" + KIND_ID + "' ", "range");
            if (dr_ProductUnit.Length > 0)
            {
                //預設最小tick
                dblTick = decimal.Parse(dr_ProductUnit[0]["tick"].ToString());
                for (int i = 0; i < dr_ProductUnit.Length; i++)
                {
                    //v3.0.0.28	修正7086閃電下單夾價差商品的報價區, 最高 & 最低 & 價格 tick 錯誤
                    //判斷正負數
                    if (dblPrice > 0)
                    {
                        if (dblPrice >= decimal.Parse(dr_ProductUnit[i]["range"].ToString()))
                        {
                            dblTick = decimal.Parse(dr_ProductUnit[i]["tick"].ToString());
                        }
                    }
                    else if (dblPrice < 0)
                    {
                        if (dblPrice <= decimal.Parse("-" + dr_ProductUnit[i]["range"].ToString()))
                        {
                            dblTick = decimal.Parse(dr_ProductUnit[i]["tick"].ToString());
                        }
                    }
                }
            }
            if (dblPrice % dblTick > 0)
            {
                return "價格跳動點不符";
            }


            return "";
        }
        public static bool checkLastMonth(string ProductKind, string Productid)
        {
            bool bolReturn = true;
            //string strMonth = "201" + Productid.Substring(Productid.Length - 1, 1) + getMonth(Productid.Substring(Productid.Length - 2, 1)).ToString().PadLeft(2, '0');
            string strMonth = systemconfigs.LogDate.Substring(0, 3) + Productid.Substring(Productid.Length - 1, 1) + getMonth(Productid.Substring(Productid.Length - 2, 1)).ToString().PadLeft(2, '0');
            if (ProductKind == "1" || ProductKind == "4")
            {
                DataRow[] dr = MYcls.systemconfigs.FutureData.Select("KIND_ID='" + Productid.Substring(0, 3) + "'", "SETTLEMENT_MONTH");
                bolReturn = dr.Length > 0 && dr[0]["SETTLEMENT_MONTH"].ToString() == strMonth ? true : false;
            }
            else
            {
                DataRow[] dr = MYcls.systemconfigs.OptionData.Select("KIND_ID='" + Productid.Substring(0, 3) + "'", "SETTLEMENT_MONTH");
                bolReturn = dr.Length > 0 && dr[0]["SETTLEMENT_MONTH"].ToString() == strMonth ? true : false;
            }
            return bolReturn;
        }
        /// <summary>
        /// 取得目前價位tick
        /// </summary>
        public static decimal getTicks(string KIND_ID, decimal dblPrice1, decimal dblPrice2)
        {
            decimal dblTick = 0;
            decimal highprice = 0;
            decimal lowprice = 0;
            if (dblPrice1 < dblPrice2)
            {
                highprice = dblPrice2;
                lowprice = dblPrice1;
            }
            else
            {
                highprice = dblPrice1;
                lowprice = dblPrice2;
            }
            while (lowprice < highprice)
            {
                lowprice = addTick(KIND_ID, lowprice, 1);
                dblTick = dblTick + 1;
            }

            return dblTick;
        }
        public static string get_md5(string inputstr)
        {
            MD5 md5Hasher = MD5.Create();
            byte[] data = md5Hasher.ComputeHash(Encoding.Default.GetBytes(inputstr));
            StringBuilder sBuilder = new StringBuilder();

            for (int i = 0; i < data.Length; i++)
            {
                sBuilder.Append(data[i].ToString("x2"));
            }

            md5Hasher = null;

            return Convert.ToString(sBuilder);
        }


        public static void ShowMessageBox(Form form, string caption, string msg)
        {
            if (form == null)
                MessageBox.Show(new Form() { TopMost = true }, msg, caption);
            else
                MessageBox.Show(form, msg, caption);
        }

        public static void ShowWarningMessageBox(Form form, string msg)
        {
            if (form == null)
                MessageBox.Show(new Form() { TopMost = true }, msg, "警告");
            else
                MessageBox.Show(form, msg, "警告");
        }


        public static string EncString(string pwd)
        {
            Int32 i = 0;
            string encPwd = "";
            try
            {
                if (pwd != "")
                {
                    for (i = 0; i < pwd.Length; i++)
                    {
                        encPwd = encPwd + Convert.ToChar(159 - ((int)Convert.ToChar(pwd.Substring(i, 1)))).ToString();
                    }
                }
            }
            catch (Exception ex)
            {

            }
            return encPwd;
        }
    }
}
