﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.IO;
using System.Windows.Forms;
using com.ddsc.tool;
using com.ddsc.BI.F;
using System.Runtime.InteropServices;
using System.Globalization;
using System.Web.Script.Serialization;
using System.Net;
using System.Web;
using System.Drawing;

namespace VIPTradingSystem.MYcls
{
    public class DataAgent
    {

        public bool  DataLoadFlag = false;
        private DataTable _Position = null;

        public DataTable Position
        {
            get { return _Position; }
            set { _Position = value; }
        }


        //紀錄上一次交易連線IP
        string _keepTradeIP = "";

        bool _TradeAlertEnable = true;
        SeqDataProvider _SeqDataProvider;
        string testfileName = AppDomain.CurrentDomain.BaseDirectory.ToString().TrimEnd() + "\\example.txt";
        StreamReader Reader;
        private System.Threading.Thread test;
        private LService.LService objWS_VIPService;
        /// <summary>
        /// 控制項管理模組
        /// </summary>
        private ControlManager mobj_ControlManager;
        /// <summary>
        /// 行情模組
        /// </summary>
        private InfoStringHandle mobj_InfoStringHandle;
        /// <summary>
        /// 回報統合模組
        /// </summary>
        public com.ddsc.BI.F.FReplyIntegration mobj_ReplyIntegration;
        /// <summary>
        /// 交易處理
        /// </summary>
        public TradeStringHandle mobj_TradeStringHandle;
        /// <summary>
        /// 帳務處理
        /// </summary>
        private AccountManager mobj_AccountManager;
        /// <summary>
        /// 行情ip
        /// </summary>
        public string mstr_MarketInfoServerIp;
        /// <summary>
        /// 行情接收port
        /// </summary>
        public int mstr_MarketInfoServerPort;
        /// <summary>
        /// 交易ip
        /// </summary>
        public string mstr_TradeServerIp;
        /// <summary>
        /// 交易port
        /// </summary> 
        public int mstr_TradePort;
        /// <summary>
        /// 登入ip
        /// </summary>
        public string mstr_LoginerverIp;
        /// <summary>
        /// 交易連線
        /// </summary>
        public com.ddsc.net.TcpClient mobj_TradeAPClient;
        /// <summary>
        /// 行情連線
        /// </summary>
        public com.ddsc.net.TcpClient _MarketAPClient;
        private MarketParser _MarketParser;
        public MarketParser MarketParser
        {
            get { return _MarketParser; }
            set { _MarketParser = value; }
        }
        /// <summary>
        /// 檢查時間是否清盤登出
        /// </summary>
        private Timer mtmr_CheckTime;
        private System.Windows.Forms.Timer mtmr_getTime;
        HotKeyManager _HotKeyManager;
        regManager _regManager;
        public static com.ddsc.tool.LogManager _LM;
        public System.Windows.Forms.Timer GetTime
        {
            get
            {
                return mtmr_getTime;
            }
            set
            {
                mtmr_getTime = value;
            }
        }
        public DateTime dtTimer
        {
            get
            {
                return m_dtTimer;
            }
            set
            {
                m_dtTimer = value;
            }
        }
        public TimeSpan tSTime
        {
            get
            {
                return m_tsTime;
            }
            set
            {
                m_tsTime = value;
            }
        }
        public bool m_bolTimer = false;
        public bool m_bolAccount = false;
        public DateTime m_dtTimer;
        public TimeSpan m_tsTime;
        private delegate void parseDelegate(string data);

        private delegate void parseMarketInfoDataDelegate(string strData);
        private int mint_queryLoginTimeCount = 0;
        [DllImport("user32", EntryPoint = "FindWindowA", ExactSpelling = true, CharSet = CharSet.Ansi, SetLastError = true)]
        private static extern int FindWindow(string lpClassName, string lpWindowName);
        [DllImport("user32", EntryPoint = "PostMessageA", ExactSpelling = true, CharSet = CharSet.Ansi, SetLastError = true)]
        private static extern int PostMessage(int hwnd, int wMsg, int wParam, int lParam);

        public static string BASEPATH = "";//; @"c:\DDSCSystem\Psg\Legal";
        public static string CURRENTPATH = "current";
        public DataAgent()
        {
            BASEPATH = AppDomain.CurrentDomain.BaseDirectory.ToString().TrimEnd();
            mobj_ControlManager = new ControlManager();
            objWS_VIPService = new LService.LService();
            System.Net.ServicePointManager.DefaultConnectionLimit = 500;
            objWS_VIPService.Timeout = 15000;

        }
        ~DataAgent()
        {


        }


        private void ClearData()
        {


            int now = int.Parse(frmMain.UserConfigs.ServerDateTime.Substring(8, 4));//yyyyMMddHHmmssfff
            int begin = int.Parse(frmMain.UserConfigs.ClearDataTime);//mmss


            SeqDataProvider _TransferDate = new SeqDataProvider("TransferDate", DataAgent.BASEPATH + "\\log\\current");

            string data = _TransferDate.Get(DateTime.Now.ToString("yyyyMMdd"));
            _TransferDate.close(); //為了要COPY所以要先CLOSE
            if (data != "Y")
            {


                if (now > begin)//跨日
                {
                    string ParentDirectory = DateTime.Now.AddDays(-1).ToString("yyyyMMdd");
                    string path = "";
                    string descpath = "";

                    descpath = DataAgent.BASEPATH.Trim() + "\\Log\\" + ParentDirectory;
                    path = DataAgent.BASEPATH.TrimEnd() + "\\Log\\" + CURRENTPATH;

                    if (!System.IO.Directory.Exists(descpath))//如果昨日目錄(昨日開盤日期)不存在，把昨天到今天的CURRENT名稱改成昨日日期
                    {
                        if (System.IO.Directory.Exists(path))
                        {
                            System.IO.Directory.Move(path, descpath);
                        }
                    }
                    _TransferDate = new SeqDataProvider("TransferDate", DataAgent.BASEPATH + "\\log\\current");
                    _TransferDate.Add(DateTime.Now.ToString("yyyyMMdd"), "Y");
                    _TransferDate.close();
                    //當日準備清盤但還未找到清盤FLAG，
                    //下一盤清盤日期為當日清盤日期+1天
                    frmMain.UserConfigs.ClearDataDate = DateTime.Now.AddDays(1).ToString("yyyyMMdd");
                }
                else
                {
                    //當日沒找到清盤資料FLAG，且時間小於清盤時間
                    //下一盤清盤日期為當日
                    frmMain.UserConfigs.ClearDataDate = DateTime.Now.ToString("yyyyMMdd");
                }
                
            }
            else if (data == "Y")
            {
                //當日找到清盤資料FLAG
               //下一盤清盤日期為當日清盤日期+1天
                frmMain.UserConfigs.ClearDataDate = DateTime.Now.AddDays(1).ToString("yyyyMMdd");
            }
        }

        private void init()
        {
            CURRENTPATH = "current";
            _LM = new com.ddsc.tool.LogManager();




            ClearData();






            _LM.AddFileWriter("DataAgentLog", new com.ddsc.tool.FileWriter(DataAgent.BASEPATH, CURRENTPATH, "DataAgentLog", ""));

            _LM.AddFileWriter("ControlManagerLog", new com.ddsc.tool.FileWriter(DataAgent.BASEPATH, CURRENTPATH, "ControlManagerLog", ""));

            _LM.AddFileWriter("HotKeyManagerLog", new com.ddsc.tool.FileWriter(DataAgent.BASEPATH, CURRENTPATH, "HotKeyManagerLog", ""));



            _LM.AddFileWriter("regManagerLog", new com.ddsc.tool.FileWriter(DataAgent.BASEPATH, CURRENTPATH, "regManagerLog", ""));

            _LM.AddFileWriter("RegisterSocketLog", new com.ddsc.tool.FileWriter(DataAgent.BASEPATH, CURRENTPATH, "RegisterSocketLog", ""));


            _LM.AddFileWriter("InfoStringHandleLog", new com.ddsc.tool.FileWriter(DataAgent.BASEPATH, CURRENTPATH, "InfoStringHandleLog", ""));
            _LM.AddFileWriter("TradeStringHandleLog", new com.ddsc.tool.FileWriter(DataAgent.BASEPATH, CURRENTPATH, "TradeStringHandleLog", ""));

            _LM.AddFileWriter("UIErrorLog", new com.ddsc.tool.FileWriter(DataAgent.BASEPATH, CURRENTPATH, "UIErrorLog", ""));
            _LM.AddFileWriter("UIEventLog", new com.ddsc.tool.FileWriter(DataAgent.BASEPATH, CURRENTPATH, "UIEventLog", ""));


            _LM.AddFileWriter("TradeStringHandleOrder", new com.ddsc.tool.FileWriter(DataAgent.BASEPATH, CURRENTPATH, "TradeStringHandleOrder", ""));
            _LM.AddFileWriter("TradeStringHandleReply", new com.ddsc.tool.FileWriter(DataAgent.BASEPATH, CURRENTPATH, "TradeStringHandleReply", ""));
            _LM.AddFileWriter("ReplyLog", new com.ddsc.tool.FileWriter(DataAgent.BASEPATH, CURRENTPATH, "ReplyLog", frmMain.logid));

            _LM.AddFileWriter("TradeAPClientLog", new com.ddsc.tool.FileWriter(DataAgent.BASEPATH, CURRENTPATH, "TradeAPClientLog", ""));
            _LM.AddFileWriter("MarketInfoSocketLog", new com.ddsc.tool.FileWriter(DataAgent.BASEPATH, CURRENTPATH, "MarketInfoSocketLog", ""));
            _LM.AddFileWriter("AccountManagerLog", new com.ddsc.tool.FileWriter(DataAgent.BASEPATH, CURRENTPATH, "AccountManager", ""));



            //  objWS_VIPService.WS_getLOGIN_TIMECompleted += new VIPService.WS_getLOGIN_TIMECompletedEventHandler(objWS_VIPService_WS_getLOGIN_TIMECompleted);
            //objWS_AccountService = new VIPTradingSystem.AccountService.BOSHistoryQuery();





        }
        private object LockVIPService = new object();
        public LService.LService WS_LService
        {

            get
            {
                lock (LockVIPService)
                {
                    return objWS_VIPService;
                }
            }
            set
            {
                lock (LockVIPService)
                {
                    objWS_VIPService = value;
                }
            }

        }
        /// <summary>
        /// 行情模組
        /// </summary>
        public InfoStringHandle objInfoStringHandle
        {
            get
            {
                return mobj_InfoStringHandle;
            }
            set
            {
                mobj_InfoStringHandle = value;
            }
        }
        /// <summary>

        /// <summary>
        /// 交易socket
        /// </summary>
        public com.ddsc.net.TcpClient objTradeSocketClient
        {
            get
            {
                return mobj_TradeAPClient;
            }
            set
            {
                mobj_TradeAPClient = value;
            }
        }
        /// <summary>
        /// 回報處理
        /// </summary>
        public com.ddsc.BI.F.FReplyIntegration objReplyIntegration
        {
            get
            {
                return mobj_ReplyIntegration;
            }
            set
            {
                mobj_ReplyIntegration = value;
            }
        }
        /// <summary>
        /// 交易處理
        /// </summary>
        public TradeStringHandle objTradeStringHandle
        {
            get
            {
                return mobj_TradeStringHandle;
            }
            set
            {
                mobj_TradeStringHandle = value;
            }
        }
        /// <summary>
        /// 帳務處理
        /// </summary>
        public AccountManager objAccountManager
        {
            get
            {
                return mobj_AccountManager;
            }
            set
            {
                mobj_AccountManager = value;
            }
        }
        /// <summary>
        /// 控制項管理模組
        /// </summary>
        public ControlManager objControlManager
        {
            get
            {
                return mobj_ControlManager;
            }
            set
            {
                mobj_ControlManager = value;
            }
        }
        public HotKeyManager HotKeyManager
        {
            get { return this._HotKeyManager; }
        }
        public regManager regManager
        {
            get { return this._regManager; }
        }
        /// <summary>
        /// 登入系統
        /// </summary>
        public string login(string server, string userid, string password)
        {
            string strReturnMsg = "";
            try
            {
#if !DDSCTESTMODE
                objWS_VIPService.Url = "http://" + server + "/WS_LService/LService.asmx";
                objWS_VIPService.Discover();
#endif
                mstr_LoginerverIp = server;
                bool ret = frmMain.mobjDataAgent.WS_LService.CheckUser(userid, CommonFunction.EncString(password));

                if (!ret)
                {
                    return "密碼輸入錯誤!";
                }
                else
                {
                }








                byte[] bb = frmMain.mobjDataAgent.WS_LService.WS_AccountList();

                DataSet ds = CommonFunction.SerialUnZip(bb);

                frmMain.UserConfigs.AccountData = new DataTable();
                frmMain.UserConfigs.AccountData.Columns.Add("COMPANY");
                frmMain.UserConfigs.AccountData.Columns.Add("ACTNO");
                frmMain.UserConfigs.AccountData.Columns.Add("NAME");
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    frmMain.UserConfigs.AccountData.Rows.Add(new string[2] {"F008000"
                                    , dr["account"].ToString().Trim()  });

                }



                bb = frmMain.mobjDataAgent.WS_LService.WS_GetClearDataTime();

                ds = CommonFunction.SerialUnZip(bb);

                frmMain.UserConfigs.ServerDateTime = ds.Tables[0].Rows[0][0].ToString();
                frmMain.UserConfigs.ClearDataTime = ds.Tables[1].Rows[0][0].ToString();
                frmMain.UserConfigs.LoginID = userid.Trim();
                if (!frmMain.UserConfigs.bolIDlogin)
                {
                    frmMain.UserConfigs.LoginACNO = userid;
                }
                frmMain.UserConfigs.PW = password;

            }
            catch (Exception ex)
            {

                return ex.Message;
            }
            return strReturnMsg;
        }
      
        /// <summary>
        /// 啟動背景
        /// </summary>
        public void start()
        {
            try
            {
                

                init();
                _TradeAlertEnable = true;

                //    getSystemIni();
                getUserIni();


                mobj_InfoStringHandle = new InfoStringHandle();
                mobj_ReplyIntegration = new com.ddsc.BI.F.FReplyIntegration();

                mobj_ReplyIntegration.DataEncode = true;
                mobj_ReplyIntegration.UserID = frmMain.UserConfigs.LoginID;
                mobj_ReplyIntegration.ReceivedReturn += new ReceivedReturnEventHandler(mobj_ReplyIntegration_ReceivedReturn);
                mobj_ReplyIntegration.Error += new com.ddsc.BI.F.FReplyIntegration.ErrorEventHandler(mobj_ReplyIntegration_Error);
                mobj_TradeStringHandle = new TradeStringHandle(this);


                // initPosition();

                // GetReply();

                //_MarketParser = new MarketParser();
                //enabledMarketSocket(true);
                enabledTradeAPClient(true);
                //_MarketParser.parseMarket += new MarketParser.parseMarketInfoDataEventHandler(_MarketParser_parseMarket);

                //  mobj_AccountManager = new AccountManager(this);
                ////設定音效
                //mobj_ControlManager.SetSoundLocation();
                ////初始快速鍵控管
                //this._regManager = new regManager();
                //this._HotKeyManager = new HotKeyManager();
                //this._HotKeyManager.DataTable = frmMain.UserConfigs.User_HotKeySet;
                //this._HotKeyManager.addRegItems();
                //this._HotKeyManager.excuteData();
                //foreach (DataRow dr in frmMain.UserConfigs.User_HotKeySet.Rows)
                //{
                //    _HotKeyManager.getItem(dr["function"].ToString())._KeyDown += new HotKeyItem.KeyDownCallback(DataAgent__KeyDown);//買/賣   
                //}
                //_HotKeyManager.MouseEvent += new MouseEventHandler(_HotKeyManager_MouseEvent);
                //setCommonHotkey();
              
                mobj_ControlManager.ini_Main();
                //2014/12/26 add by irving MIT委託Flag，True：MIT預先委託到市場，False：等待觸價
                //systemconfigs.bolMITOrderFlag = false;
                //登入檢查
                //if (systemconfigs.LogDate.Length >= 8 && systemconfigs.LogTime.Length >= 8)
                //{
                //    int year = int.Parse(systemconfigs.LogDate.Substring(0, 4));
                //    int month = int.Parse(systemconfigs.LogDate.Substring(4, 2));
                //    int day = int.Parse(systemconfigs.LogDate.Substring(6, 2));
                //    int hour = int.Parse(systemconfigs.LogTime.Substring(0, 2));
                //    int minute = int.Parse(systemconfigs.LogTime.Substring(3, 2));
                //    int second = int.Parse(systemconfigs.LogTime.Substring(6, 2));
                //    systemconfigs.dmNow = systemconfigs.dmLogin = new DateTime(year, month, day, hour, minute, second);
                //}

                //m_tsTime = new TimeSpan(0, 0, frmMain.UserConfigs.A_TIME_SECONDS);
                //mtmr_getTime = new Timer();
                //mtmr_getTime.Interval = 1000;
                //    mtmr_getTime.Tick += new EventHandler(mtmr_getTime_Tick);
                //mtmr_getTime.Start();
                //mtmr_CheckTime = new Timer();
                //mtmr_CheckTime.Interval = 60000;//3分鐘檢查一次
                //mtmr_CheckTime.Tick += new EventHandler(mtmr_CheckTime_Tick);
                //mtmr_CheckTime.Start();
                //Reader = new StreamReader(testfileName);
                //test = new System.Threading.Thread(new System.Threading.ThreadStart(testExample));
                //test.IsBackground = true;
                //test.Start();
            }
            catch (Exception ex)
            {
                _LM.WriteLog("DataAgentLog", "start:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }

        }

        private void initPosition()
        {
            byte[] bb = frmMain.mobjDataAgent.WS_LService.WS_PostionList();

            DataSet ds = CommonFunction.SerialUnZip(bb);

            if (ds.Tables.Count > 0)
            {
                _Position = ds.Tables[0];
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    MatchTotalItem Item = new MatchTotalItem();
                    Item.BROKERID = dr["BROKERID"].ToString();
                    Item.INVESTORACNO = dr["Account"].ToString();
                    Item.SUBACT = "";// SUBACT;
                    Item.SECURITYEXCHANGE = dr["SECURITYEXCHANGE"].ToString();
                    Item.SECURITYTYPE1 = dr["SECURITYTYPE"].ToString();
                    Item.SYMBOL1 = dr["SYMBOL1"].ToString();
                    Item.MATURITYMONTHYEAR1 = dr["MATURITYMONTHYEAR1"].ToString();
                    Item.PUTORCALL1 = dr["PUTORCALL1"].ToString();
                    Item.STRIKEPRICE1 = decimal.Parse(dr["STRIKEPRICE1"].ToString());
                    Item.STRIKEPRICE1 = Decimal.Parse(Item.STRIKEPRICE1.ToString("0.#######"));
                    Item.SIDE1 = dr["SIDE1"].ToString();
               
                    Item.SYMBOL2 = dr["SYMBOL2"].ToString();
                    Item.MATURITYMONTHYEAR2 = dr["MATURITYMONTHYEAR2"].ToString();
                    Item.PUTORCALL2 = dr["PUTORCALL2"].ToString();
                    Item.STRIKEPRICE2 = decimal.Parse(dr["STRIKEPRICE2"].ToString());

                    Item.STRIKEPRICE2 = Decimal.Parse(Item.STRIKEPRICE2.ToString("0.#######"));
                    Item.SIDE2 = dr["SIDE2"].ToString();
                    if (Item.SECURITYTYPE1.Trim() == "FUT")
                    {
                        if ( Item.SYMBOL2.Trim().Length>0)
                        {
                            Item.SECURITYTYPE2 = dr["SECURITYTYPE"].ToString();
                            Item.PRODUCTKIND = "4";
                        }
                        else 
                        Item.PRODUCTKIND = "1";
                    }
                    else
                    {
                        if (Item.SYMBOL2.Trim().Length > 0)
                        {
                            Item.SECURITYTYPE2 = dr["SECURITYTYPE"].ToString();
                            Item.PRODUCTKIND = "3";
                        }
                        else
                            Item.PRODUCTKIND = "2";
                    }
         

                    frmMain.mobjDataAgent.objTradeStringHandle.MatchTotalProvider.AddMatchQty("", Item, dr["BS"].ToString()
                        , decimal.Parse(dr["PRICE"].ToString()), int.Parse(dr["QTY"].ToString()));
                }
            }

        }




        void _MarketParser_parseMarket(string strData)
        {
            mobj_InfoStringHandle.parseData(strData);
        }

        private void testExample()
        {
            string tmp = "";
            int count = 0;
            int highlowcount = 0;
            while (true)
            {
                if (Reader.Peek() == -1)
                {
                    Reader.BaseStream.Position = 0;

                }
                tmp = Reader.ReadLine();
                mobj_InfoStringHandle.parseData(tmp);

                mobj_InfoStringHandle.parseData("25TXFK4@" + (8999 - highlowcount).ToString() + "@" + (8980 - highlowcount).ToString() + "@884444");
                highlowcount++;
                if (highlowcount > 10)
                {
                    highlowcount = 0;
                }
                if (count == 100)
                {
                    System.Threading.Thread.Sleep(500);
                    count = 0;
                }
                count++;

            }
        }

        void mobj_ReplyIntegration_Error(string msg)
        {
            _LM.WriteLog("DataAgentLog", "mobj_ReplyIntegration_Error:" + msg);
        }
        public void GetReply()
        {
            try
            {
                string[] datas = _SeqDataProvider.GetArray(0, 9999999);

                foreach (string data in datas)
                {
                    byte[] body = ASCIIEncoding.Default.GetBytes(data.Substring(20, data.Length - 20));
                    string OldSeq = data.Substring(0, 9);
                    string NewSeq = data.Substring(10, 9);
                    SockClientParserFunction.DDSCHead DDSCHead = new SockClientParserFunction.DDSCHead();
                    DDSCHead.HEAD = new byte[1] { SockClientParserFunction.DDSCSocketHead.Reply };
                    DDSCHead.MESSAGETIME = ASCIIEncoding.ASCII.GetBytes(DateTime.Now.ToString("HHmmssfff"));
                    DDSCHead.LENGTH = BitConverter.GetBytes(UInt16.Parse(body.Length.ToString()));
                    if (BitConverter.IsLittleEndian)
                        Array.Reverse(DDSCHead.LENGTH);
                    byte[] retBuffer = new byte[50 + body.Length + 1];
                    DDSCHead.OLDSEQ = ASCIIEncoding.ASCII.GetBytes(OldSeq);
                    DDSCHead.NEWSEQ = ASCIIEncoding.ASCII.GetBytes(NewSeq);
                    DDSCHead.USERID = ASCIIEncoding.ASCII.GetBytes("".PadRight(20, ' '));
                    byte[] headbyte = SockClientParserFunction.StructureToByteArray(DDSCHead);
                    Array.Copy(headbyte, 0, retBuffer, 0, headbyte.Length);
                    Array.Copy(body, 0, retBuffer, headbyte.Length, body.Length);
                    retBuffer[retBuffer.Length - 1] = SockClientParserFunction.DDSCSocketHead.End;

                    SockClientParserFunction.Reply Reply = new SockClientParserFunction.Reply();
                    string KeepData = ASCIIEncoding.Default.GetString(retBuffer, 50 + Marshal.SizeOf(Reply), retBuffer.Length - 50 - Marshal.SizeOf(Reply) - 1);

                    string OrderKind = "";
                    string OrderTag = "";
                    string AE = "";
                    string AD = "";
                    string pseq = "";
                    //KeepData
                    //AD=Time Slice|2|500|20161004172843726|20161004182843000|35000|5|0^          代表委託母單
                    //AD=Time Slice|2|5|20161006114551410|20161006114851000|34000|1|0^pseq=A000C0002^ 代表委託出去的單子 子單
                    foreach (string f in KeepData.Split('^'))
                    {
                        if (f.IndexOf("OrderKind") > -1)
                        {
                            OrderKind = f.Split('=')[1];
                        }
                        if (f.IndexOf("AD") > -1)
                        {
                            AD = f.Split('=')[1];
                        }
                        if (f.IndexOf("pseq") > -1)
                        {
                            pseq = f.Split('=')[1];
                        }
                        if (f.IndexOf("OrderTag") > -1)
                        {
                            OrderTag = f.Split('=')[1];
                        }
                        if (f.IndexOf("AE") > -1)
                        {
                            AE = f.Split('=')[1];
                        }

                    }
                  
                    if (OrderKind == "P")
                        mobj_TradeStringHandle.ParseProgramTradeReply(retBuffer);
                    else
                    {
                        retBuffer = mobj_ReplyIntegration.DataEncode ? SockClientParserFunction.EncodeData(retBuffer) : retBuffer;
                        mobj_ReplyIntegration.Received(retBuffer);
                    }
                  
                }
             
                //mobj_ReplyIntegration.Clear();
                //string acccounts = "";
                //string companys = "";

                //foreach (DataRow dr in frmMain.UserConfigs.AccountData.Rows)
                //{
                //    acccounts += dr["actno"].ToString().Trim() + ",";
                //    if (!companys.Contains(dr["company"].ToString().Trim()))
                //    {
                //        companys += dr["company"].ToString().Trim() + ",";
                //    }
                //}
                //acccounts = acccounts.Remove(acccounts.Length - 1, 1);
                //companys = companys.Remove(companys.Length - 1, 1);


                //byte[] bt = null;// objWS_VIPService.WS_getOrderReplyByWorking(companys, acccounts);

                //DataTable dtData = MYcls.CommonFunction.SerialUnZip(bt).Tables[0];
                //if (dtData.Rows.Count > 0)
                //{
                //    foreach (DataRow dr in dtData.Rows)
                //    {

                //        DataRow drNew = mobj_ReplyIntegration.OrderReply.NewRow();
                //        foreach (DataColumn dc in dtData.Columns)
                //        {
                //            if (mobj_ReplyIntegration.OrderReply.Columns.Contains(dc.ColumnName))
                //            {
                //                drNew[dc.ColumnName] = dr[dc.ColumnName].ToString();
                //            }
                //        }
                //        mobj_ReplyIntegration.AddRow("", drNew);

                //    }


                //}
            }
            catch (Exception ex)
            {
                _LM.WriteLog("DataAgentLog", "GetReply:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        /// <summary>
        /// 關閉背景
        /// </summary>
        public void close()
        {

            _keepTradeIP = "";
            _TradeAlertEnable = false;

            if (mtmr_CheckTime != null)
            {
                mtmr_CheckTime.Stop();
                mtmr_CheckTime.Dispose();
            }
            if (mtmr_getTime != null)
            {
                mtmr_getTime.Stop();
                mtmr_getTime.Dispose();
            }
            //enabledMarketSocket(false);
            enabledTradeAPClient(false);

            if (mobj_InfoStringHandle != null)
            {
                mobj_InfoStringHandle.Dispose();
            }
            //foreach (DataRow dr in frmMain.UserConfigs.User_HotKeySet.Rows)
            //{
            //  _HotKeyManager.getItem(dr["function"].ToString())._KeyDown -= new HotKeyItem.KeyDownCallback(DataAgent__KeyDown);//買/賣   
            //}
            //_HotKeyManager.MouseEvent -= new MouseEventHandler(_HotKeyManager_MouseEvent);
            //_HotKeyManager.Dispose();

            objControlManager.clearStatusBar();

            _LM.CloseWriteLog("DataAgentLog");
            _LM.CloseWriteLog("ControlManagerLog");
            _LM.CloseWriteLog("HotKeyManagerLog");
            _LM.CloseWriteLog("regManagerLog");
            _LM.CloseWriteLog("RegisterSocketLog");
            _LM.CloseWriteLog("InfoStringHandleLog");
            _LM.CloseWriteLog("TradeStringHandleLog");
            _LM.CloseWriteLog("UIErrorLog");
            _LM.CloseWriteLog("UIEventLog");
            _LM.CloseWriteLog("TradeStringHandleOrder");
            _LM.CloseWriteLog("TradeStringHandleReply");
            _LM.CloseWriteLog("ReplyLog");
            _LM.CloseWriteLog("TradeAPClientLog");
            _LM.CloseWriteLog("MarketInfoSocketLog");
            _LM.CloseWriteLog("AccountManagerLog");
            _LM.Dispose();
            if (mobj_ReplyIntegration != null)
            {
                mobj_ReplyIntegration.Dispose();
            }
            if (mobj_AccountManager != null)
            {
                mobj_AccountManager.Dispose();
            }
            objControlManager.close();

            _SeqDataProvider.close();

        }
        private void dispose()
        {

            GC.SuppressFinalize(this);
        }
        /// <summary>
        /// 取得系統組態
        /// </summary>
        public void getSystemIni()
        {
            try
            {
                DataSet ds = CommonFunction.SerialUnZip(objWS_VIPService.WS_INI());
                systemconfigs.FutureData = ds.Tables["FutureData"];
                systemconfigs.OptionData = ds.Tables["OptionData"];
                systemconfigs.ProductMain = ds.Tables["ProductMain"];
                systemconfigs.TickData = ds.Tables["TickData"];
                systemconfigs.MessageCode = ds.Tables["MessageCode"];

                if (ds.Tables["SystemDateTime"].Rows.Count > 0)
                {
                    systemconfigs.LogDate = ds.Tables["SystemDateTime"].Rows[0]["NOWDATE"].ToString();
                    systemconfigs.LogTime = ds.Tables["SystemDateTime"].Rows[0]["NOWTIME"].ToString();
                    systemconfigs.ClearTime = ds.Tables["SystemDateTime"].Rows[0]["CLEARTIME"].ToString();
                }
                systemconfigs.ACTextMapping.Clear();
                systemconfigs.ACTextMapping.Add("POSITION_PRICE", "均價");
                systemconfigs.ACTextMapping.Add("POSITION_QTY", "部位");
                systemconfigs.ACTextMapping.Add("FLOAT_PROFIT", "浮動損益");
                systemconfigs.ACTextMapping.Add("INCOME_BALANCE", "平倉損益");
                systemconfigs.ACTextMapping.Add("U_FLOAT_PROFIT", "淨浮損");
                systemconfigs.ACTextMapping.Add("U_INCOME_BALANCE", "淨損益");
                systemconfigs.ACNameMapping.Clear();
                systemconfigs.ACNameMapping.Add("均價", "POSITION_PRICE");
                systemconfigs.ACNameMapping.Add("部位", "POSITION_QTY");
                systemconfigs.ACNameMapping.Add("浮動損益", "FLOAT_PROFIT");
                systemconfigs.ACNameMapping.Add("平倉損益", "INCOME_BALANCE");
                systemconfigs.ACNameMapping.Add("淨浮損", "U_FLOAT_PROFIT");
                systemconfigs.ACNameMapping.Add("淨損益", "U_INCOME_BALANCE");
                //依照解析度調整條件單寬度
                // 找出字體大小,並算出比例
                float dpiX, dpiY;
                Graphics graphics = mobj_ControlManager.V_frmMain.CreateGraphics();
                dpiX = graphics.DpiX;
                dpiY = graphics.DpiY;
                systemconfigs.dpiPercent = ((dpiX == 96) ? 100 : (dpiX == 120) ? 125 : 150);

            }
            catch (Exception ex)
            {
                _LM.WriteLog("DataAgentLog", "getSystemIni:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        /// <summary>
        /// 取得使用者組態
        /// </summary>
        public void getUserIni()
        {
            try
            {
                DataSet ds = CommonFunction.SerialUnZip(objWS_VIPService.WS_USERINI(frmMain.UserConfigs.LoginID));


                frmMain.UserConfigs.ServerSet = ds.Tables["ServerSet"];
                if (frmMain.UserConfigs.MASTER) //登入主機或備援機
                {//正式機 取 有設定 DEFAULT
                    foreach (DataRow dr in frmMain.UserConfigs.ServerSet.Select("ISDEFAULT='Y'"))
                    {
                        if (dr["TYPE"].ToString() == "M")
                        {
                            mstr_MarketInfoServerIp = dr["SERVERIP"].ToString();
                            mstr_MarketInfoServerPort = int.Parse(dr["SERVERPORT"].ToString());
                        }
                        else if (dr["TYPE"].ToString() == "S")
                        {

                        }
                        else if (dr["TYPE"].ToString() == "T")
                        {
                            mstr_TradeServerIp = dr["SERVERIP"].ToString();

                            mstr_TradePort = int.Parse(dr["SERVERPORT"].ToString());
                        }
                        else if (dr["TYPE"].ToString() == "W")
                        {
                            //mstr_LoginerverIp = dr["SERVERIP"].ToString();
                        }
                    }
                }
                else
                {//備援機 取沒有設定 DEFAULT
                    foreach (DataRow dr in frmMain.UserConfigs.ServerSet.Select("ISDEFAULT<>'Y'"))
                    {
                        if (dr["TYPE"].ToString() == "M")
                        {
                            mstr_MarketInfoServerIp = dr["SERVERIP"].ToString();
                            mstr_MarketInfoServerPort = int.Parse(dr["SERVERPORT"].ToString());
                        }
                        else if (dr["TYPE"].ToString() == "S")
                        {

                        }
                        else if (dr["TYPE"].ToString() == "T")
                        {
                            mstr_TradeServerIp = dr["SERVERIP"].ToString();

                            mstr_TradePort = int.Parse(dr["SERVERPORT"].ToString());
                        }
                        else if (dr["TYPE"].ToString() == "W")
                        {
                            //mstr_LoginerverIp = dr["SERVERIP"].ToString();
                        }
                    }
                }

                DataTable dtProgramSet = new DataTable("ProgramSet");
                dtProgramSet.Columns.Add("MOD_DESC");
                dtProgramSet.Columns.Add("MOD_SEQ");
                dtProgramSet.Columns.Add("MODID");
                dtProgramSet.Columns.Add("PROG_NAME");
                dtProgramSet.Columns.Add("PROG_DESC");
                dtProgramSet.Columns.Add("REMARK");
                dtProgramSet.Columns.Add("CLASS");
                dtProgramSet.Columns.Add("MULTIFORM");
                dtProgramSet.Rows.Add(new string[] { "交易", "1", "Order", "frmTrade", "下單介面", "", "1", "Y" });
                dtProgramSet.Rows.Add(new string[] { "回報", "2", "Reply", "frmReply", "改單介面", "", "2", "N" });
                dtProgramSet.Rows.Add(new string[] { "維護", "3", "Main", "frmProductSet", "商品維護", "", "3", "N" });
                dtProgramSet.Rows.Add(new string[] { "維護", "3", "Main", "frmAccountSet", "帳號維護", "", "4", "N" });
                dtProgramSet.Rows.Add(new string[] { "維護", "3", "Main", "frmPostionSet", "部位維護", "", "5", "N" });
                dtProgramSet.Rows.Add(new string[] { "維護", "3", "Main", "frmTranferData", "成交資料轉檔", "", "6", "N" });

                //ds.Tables.Add(dtProgramSet);

                frmMain.UserConfigs.CollectionSet = ds.Tables["CollectionSet"];
                frmMain.UserConfigs.FORM_SET = ds.Tables["FORM_SET"];
                objControlManager.GridSet = ds.Tables["GRID_SET"];

                // frmMain.UserConfigs.ProgramSet = new userconfigs.Program(ds.Tables["ProgramSet"]);
                frmMain.UserConfigs.ProgramSet = new userconfigs.Program(dtProgramSet);//不用DB
                frmMain.UserConfigs.intDefualtBuyBackColor = System.Drawing.Color.MistyRose.ToArgb();
                frmMain.UserConfigs.intDefualtSellBackColor = System.Drawing.Color.FromArgb(192, 255, 192).ToArgb();
                frmMain.UserConfigs.intDefualtMultiBackColor = System.Drawing.Color.Purple.ToArgb();
                frmMain.UserConfigs.strExcelPath = "桌面";

                if (ds.Tables["LogInfo"].Rows.Count > 0)
                {
                    frmMain.UserConfigs.logDate = ds.Tables["LogInfo"].Rows[0]["logDate"].ToString();

                    frmMain.UserConfigs.logTime = ds.Tables["LogInfo"].Rows[0]["logTime"].ToString();
                }
            }
            catch (Exception ex)
            {
                _LM.WriteLog("DataAgentLog", "getUserIni:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }

        }


        /// <summary>
        /// 啟動/關閉行情接收連線
        /// </summary>
        public void enabledMarketSocket(bool bolEnabled)
        {
            return;
            try
            {

                if (bolEnabled)
                {
                    _MarketAPClient = new com.ddsc.net.TcpClient();
                    _MarketAPClient.ReconnectTime = 2;
                    _MarketAPClient.Sended += new com.ddsc.net.TcpClient.SendedHandler(_MarketAPClient_Sended);
                    _MarketAPClient.Error += new com.ddsc.net.TcpClient.ErrorHandler(_MarketAPClient_Error);
                    _MarketAPClient.connected += new com.ddsc.net.TcpClient.connectedHandler(_MarketAPClient_connected);
                    _MarketAPClient.Disconnected += new com.ddsc.net.TcpClient.disconnectedHandler(_MarketAPClient_Disconnected);
                    _MarketAPClient.Received += new com.ddsc.net.TcpClient.ReceivedHandler(_MarketAPClient_Received);
                    _MarketAPClient.Connect(mstr_MarketInfoServerIp, mstr_MarketInfoServerPort);
                }
                else
                {
                    if (_MarketAPClient != null)
                    {
                        _MarketAPClient.Close();
                        _MarketAPClient.Sended -= new com.ddsc.net.TcpClient.SendedHandler(_MarketAPClient_Sended);
                        _MarketAPClient.Error -= new com.ddsc.net.TcpClient.ErrorHandler(_MarketAPClient_Error);
                        _MarketAPClient.connected -= new com.ddsc.net.TcpClient.connectedHandler(_MarketAPClient_connected);
                        _MarketAPClient.Received -= new com.ddsc.net.TcpClient.ReceivedHandler(_MarketAPClient_Received);
                    }
                }
            }
            catch (Exception ex)
            {
                _LM.WriteLog("DataAgentLog", "enabledMarketSocket:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        /// <summary>
        /// 啟動/關閉交易連線
        /// </summary>
        public void enabledTradeAPClient(bool bolEnabled)
        {
            try
            {
                if (bolEnabled)
                {
                    mobj_TradeAPClient = new com.ddsc.net.TcpClient();
                    mobj_TradeAPClient.ReconnectTime = 2;
                    mobj_TradeAPClient.HandShakeTime = 30;
                    mobj_TradeAPClient.Error += new com.ddsc.net.TcpClient.ErrorHandler(mobj_TradeAPClient_Error);
                    mobj_TradeAPClient.Disconnected += new com.ddsc.net.TcpClient.disconnectedHandler(mobj_TradeAPClient_Disconnected);

                    mobj_TradeAPClient.Received += new com.ddsc.net.TcpClient.ReceivedHandler(mobj_TradeAPClient_Received);
                    mobj_TradeAPClient.connected += new com.ddsc.net.TcpClient.connectedHandler(mobj_TradeAPClient_connected);
                    mobj_TradeAPClient.Connect(mstr_TradeServerIp, mstr_TradePort);



                }
                else
                {
                    if (mobj_TradeAPClient != null)
                    {


                        mobj_TradeAPClient.Close();

                        mobj_TradeAPClient.Error -= new com.ddsc.net.TcpClient.ErrorHandler(mobj_TradeAPClient_Error);
                        mobj_TradeAPClient.Disconnected -= new com.ddsc.net.TcpClient.disconnectedHandler(mobj_TradeAPClient_Disconnected);

                        mobj_TradeAPClient.Received -= new com.ddsc.net.TcpClient.ReceivedHandler(mobj_TradeAPClient_Received);
                        mobj_TradeAPClient.connected -= new com.ddsc.net.TcpClient.connectedHandler(mobj_TradeAPClient_connected);

                    }
                }
            }
            catch (Exception ex)
            {
                _LM.WriteLog("DataAgentLog", "enabledTradeAPClient:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }


        }
        void mobj_ReplyIntegration_ReceivedReturn(ReceivedReturnEventArgs e)
        {
            if (e.ReceiveAcion == ReceivedAcion.ReceivedConnected)
            {
                mobj_TradeAPClient.HandShakeBuffer = SockClientParserFunction.EncodeData(mobj_ReplyIntegration.CombineAck());
            }
        }
        void mobj_TradeAPClient_Error(com.ddsc.net.TcpClient s, string msg)
        {


            _LM.WriteLog("TradeAPClientLog", "錯誤" + msg);

        }
        bool _TradeAlertEnableAlert = false;

        private delegate void MyDelegate();
        private delegate int MeDelegatePara();


        private void Alert()
        {
            //  DialogResult d = MessageBox.Show("交易連線已關閉，如有帳務相關問題，請手動查詢!!\n報價下單夾[查詢]\n委託、成交、帳務[更新]", "警告"
            DialogResult d = MessageBox.Show("＊網路連線中斷－委託、成交及帳務將無法自動更新，請按 [查詢] 按鍵", "警告"
                                , MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
            if (d == DialogResult.OK)
                _TradeAlertEnableAlert = false;

        }
        void mobj_TradeAPClient_Disconnected(com.ddsc.net.TcpClient Tcp)
        {

            try
            {
                if (_SeqDataProvider != null)
                {
                    _SeqDataProvider.close();
                    _SeqDataProvider = null;
                }
                objControlManager.refreshStatusBar("Trade", true, "交易連線已關閉");
                _LM.WriteLog("TradeAPClientLog", "交易連線已關閉");
                //if (_TradeAlertEnable)
                //{


                //    if (!_TradeAlertEnableAlert)
                //    {

                //        _TradeAlertEnableAlert = true;

                //        MyDelegate D = new MyDelegate(Alert);
                //        D.BeginInvoke(null, null);
                //        //DialogResult d = F.ShowDialog(frmMain.mobjDataAgent.objControlManager.V_frmMain);
                //    }



                //}

            }
            catch (Exception ex)
            {
            }

        }

        void mobj_TradeAPClient_connected(com.ddsc.net.TcpClient Tcp)
        {
            try
            {
                DataLoadFlag = true;
                string ip = ((System.Net.IPEndPoint)(Tcp.Socket.RemoteEndPoint)).Address.ToString();
                if (_SeqDataProvider == null)
                    _SeqDataProvider = new SeqDataProvider("ReplyData" + ip, DataAgent.BASEPATH + "\\log\\current");
                if (_keepTradeIP != ip)
                {
                    _keepTradeIP = ip;
                    //由於走TCP THREAD 所以要用MAIN THREAD去清資料
                    MyDelegate m = new MyDelegate(mobj_TradeStringHandle.ClearData);
                    frmMain.mobjDataAgent.objControlManager.V_frmMain.Invoke(m);
                    //mobj_TradeStringHandle.ClearData();

                    initPosition();
                    GetReply();

                }
                MyDelegate o = new MyDelegate(mobj_ControlManager.initOpenform);
                frmMain.mobjDataAgent.objControlManager.V_frmMain.Invoke(o);


                //  第一先註冊USERID ，從取得SEQ
                //  第二註冊該USERID的交易帳號
                //
                //

                byte[] buffer = mobj_ReplyIntegration.CombineConnect(new string[0]); //先註冊USERID 
                mobj_TradeAPClient.Send(buffer);
                string[] comact = new string[frmMain.UserConfigs.AccountData.Rows.Count];//
                for (int i = 0; i < frmMain.UserConfigs.AccountData.Rows.Count; i++)
                {
                    DataRow dr = frmMain.UserConfigs.AccountData.Rows[i];

                    comact[i] = dr["COMPANY"].ToString() + dr["ACTNO"].ToString().Trim() + "".PadRight(7, ' ');
                    byte[] TradeConnect_buffer = com.ddsc.BI.F.SockClientParserFunction.EncodeData(
                        mobj_ReplyIntegration.CombineRegTradeAct(dr["COMPANY"].ToString(), dr["ACTNO"].ToString().Trim(), ""));
                    mobj_TradeAPClient.Send(TradeConnect_buffer);
                    _LM.WriteLog("TradeAPClientLog", comact[i]);
                }

                objControlManager.refreshStatusBar("Trade", false, "交易連線成功");

                string replyseq = (_SeqDataProvider.Count + 1).ToString();

                byte[] Covert_buffer = com.ddsc.BI.F.SockClientParserFunction.EncodeData(
                      mobj_ReplyIntegration.CombineCover(replyseq));

                _LM.WriteLog("TradeAPClientLog", "Recover replyseq=" + replyseq);
                mobj_TradeAPClient.Send(Covert_buffer);
                _LM.WriteLog("TradeAPClientLog", replyseq);

                _LM.WriteLog("TradeAPClientLog", "交易連線成功");
                // mobj_TradeAPClientLog.WriteEntryData("交易連線成功");
                DataLoadFlag = false;
            }
            catch (Exception ex)
            {
                _LM.WriteLog("TradeAPClientLog", "mobj_TradeAPClient_connected:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        void mobj_TradeAPClient_Received(com.ddsc.net.TcpClient Tcp, byte[] buffer)
        {
            try
            {

                byte[] retbuffer = mobj_ReplyIntegration.DataEncode ? com.ddsc.BI.F.SockClientParserFunction.DecodeData(buffer) : buffer;
                _LM.WriteLog("ReplyLog", Encoding.Default.GetString(retbuffer));

                byte[] b = mobj_ReplyIntegration.Received(buffer);
                string seq = com.ddsc.BI.F.SockClientParserFunction.getDDSCRawDataNewSeq(retbuffer);
                string OldSeq = com.ddsc.BI.F.SockClientParserFunction.getDDSCRawDataOldSeq(retbuffer);
                if (buffer[0] == SockClientParserFunction.DDSCSocketHead.ProgramTradeReply)
                {
                    mobj_TradeStringHandle.ParseProgramTradeReply(retbuffer);
                }

                if (buffer[0] == SockClientParserFunction.DDSCSocketHead.Reply ||
                    buffer[0] == SockClientParserFunction.DDSCSocketHead.ProgramTradeReply)
                    VipReplayAddSeq(OldSeq, seq, ref retbuffer);

                if (buffer[0] == SockClientParserFunction.DDSCSocketHead.Connected || buffer[0] == SockClientParserFunction.DDSCSocketHead.Alive)
                {

                    string ServerDateTime = DateTime.Now.ToString("yyyyMMdd") + Encoding.Default.GetString(retbuffer, 1, 9);
                    frmMain.UserConfigs.ServerDateTime = ServerDateTime;
                    frmMain.mobjDataAgent.objControlManager.V_frmMain.CheckClearTime();
                }

            }
            catch (Exception ex)
            {
                _LM.WriteLog("TradeAPClientLog", "mobj_TradeAPClient_Received:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }


        private void VipReplayAddSeq(string oldseq, string newseq, ref byte[] buffer)
        {

            int ReplyCount = _SeqDataProvider.Count + 1;
            byte[] Countbyte = ASCIIEncoding.Default.GetBytes(ReplyCount.ToString().PadLeft(10, '0'));
            Array.Copy(Countbyte, 0, buffer, 50, 10);
            if (!_SeqDataProvider.check((ReplyCount).ToString()))
                _SeqDataProvider.Add((ReplyCount).ToString(), oldseq.PadRight(10, ' ') + newseq.PadRight(10, ' ') + ASCIIEncoding.Default.GetString(buffer, 50, buffer.Length - 50 - 1));//排除 0x0a



        }
        void _MarketAPClient_Received(com.ddsc.net.TcpClient s, byte[] buffer)
        {
            try
            {


                buffer = SockClientParserFunction.DecodeData(buffer);
                string data = ASCIIEncoding.ASCII.GetString(buffer, 50, buffer.Length - 50 - 1);
                if (buffer[0] == MarketSockClientParserFunction.DDSCSocketHead.Reply)
                {
                    _MarketParser.PutData2Queue(data);
                }
            }
            catch (Exception ex)
            {
                _LM.WriteLog("MarketInfoSocketLog", "_MarketAPClient_Received:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        void _MarketAPClient_connected(com.ddsc.net.TcpClient s)
        {
            try
            {
                _MarketAPClient.HandShakeBuffer = mobj_ReplyIntegration.CombineAck();
                _MarketAPClient.Send(SockClientParserFunction.EncodeData(mobj_ReplyIntegration.CombineConnect(new string[] { "" })));
                byte[] bb = null;


                objControlManager.refreshStatusBar("Market", false, "行情連線成功");

                _LM.WriteLog("MarketInfoSocketLog", "行情連線成功");
                _MarketParser.ReRegisterALL();
            }
            catch (Exception ex)
            {
                _LM.WriteLog("_MarketAPClient_connected", "_MarketAPClient_Received:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        void _MarketAPClient_Disconnected(com.ddsc.net.TcpClient Tcp)
        {
            try
            {
                objControlManager.refreshStatusBar("Market", true, "行情連線已關閉");

                _LM.WriteLog("MarketInfoSocketLog", "行情連線已關閉");
            }
            catch (Exception ex)
            {
                _LM.WriteLog("_MarketAPClient_connected", "_MarketAPClient_Disconnected:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        void _MarketAPClient_Error(com.ddsc.net.TcpClient s, string msg)
        {
            try
            {
                _LM.WriteLog("MarketInfoSocketLog", "錯誤" + msg);
            }
            catch (Exception ex)
            {
                _LM.WriteLog("_MarketAPClient_connected", "_MarketAPClient_Disconnected:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        byte[] _MarketAPClient_Sended(com.ddsc.net.TcpClient s, byte[] buffer)
        {
            buffer = SockClientParserFunction.DecodeData(buffer);

            _LM.WriteLog("MarketInfoSocketLog", "sended" + Encoding.ASCII.GetString(buffer));
            return null;
        }

        private void addFormRow(string COLLECT_ID, string PROG_NAME, string SET_NAME, string SET_VALUE, string TYPE)
        {
            DataRow dr = frmMain.UserConfigs.FORM_SET.NewRow();
            dr["COLLECT_ID"] = COLLECT_ID;
            dr["PROG_NAME"] = PROG_NAME;
            dr["SET_NAME"] = SET_NAME;
            dr["SET_VALUE"] = SET_VALUE;
            dr["TYPE"] = TYPE;
            frmMain.UserConfigs.FORM_SET.Rows.Add(dr);
        }
        private void addGridRow(string COLLECT_ID, string PROG_NAME, string GRID_NAME, string COLUMN_NAME, string HEADER_TEXT, string WIDTH, string DISPLAY_INDEX, string VISIBLE, string TAB, string SORT, string TYPE)
        {
            DataRow dr = objControlManager.GridSet.NewRow();
            dr["COLLECT_ID"] = COLLECT_ID;
            dr["PROG_NAME"] = PROG_NAME;
            dr["GRID_NAME"] = GRID_NAME;
            dr["COLUMN_NAME"] = COLUMN_NAME;
            dr["HEADER_TEXT"] = HEADER_TEXT;
            dr["WIDTH"] = WIDTH;
            dr["DISPLAY_INDEX"] = DISPLAY_INDEX;
            dr["VISIBLE"] = VISIBLE;
            dr["TAB"] = TAB;
            dr["SORT"] = SORT;
            dr["TYPE"] = TYPE;
            objControlManager.GridSet.Rows.Add(dr);
        }

        void mtmr_CheckTime_Tick(object sender, EventArgs e)
        {
            try
            {
                //累加間隔時間來計算目前時間
                systemconfigs.dmNow = systemconfigs.dmNow.AddMilliseconds(mtmr_CheckTime.Interval);

                //累加時間的日期與登入日期比較
                if ((systemconfigs.dmNow.ToString("yyyyMMdd", System.Globalization.CultureInfo.CreateSpecificCulture("en-US")) != systemconfigs.LogDate)
                    || ((systemconfigs.dmNow.ToString("yyyyMMdd", System.Globalization.CultureInfo.CreateSpecificCulture("en-US")) == systemconfigs.LogDate)
                        && (DateTime.Parse(systemconfigs.LogTime) <= DateTime.Parse(systemconfigs.ClearTime))))
                {
                    int hour = int.Parse(systemconfigs.ClearTime.Substring(0, 2));
                    int minute = int.Parse(systemconfigs.ClearTime.Substring(3, 2));
                    int second = int.Parse(systemconfigs.ClearTime.Substring(6, 2));

                    DateTime dmlogin = new DateTime(systemconfigs.dmNow.Year, systemconfigs.dmNow.Month, systemconfigs.dmNow.Day, hour, minute, second);



                    //累加時間如果大於清盤時間,重新登入
                    if (systemconfigs.dmNow >= dmlogin)
                    {
                        objControlManager.V_frmMain.toolbtnLogin_Click(null, null);
                    }

                }
                mint_queryLoginTimeCount++;
                //    objWS_VIPService.WS_getLOGIN_TIMEAsync(new object[] { mint_queryLoginTimeCount });
            }
            catch (Exception ex)
            {
                _LM.WriteLog("DataAgentLog", "mtmr_CheckTime_Tick:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }

        public void setUser_HotKeySet()
        {
            try
            {
                //frmMain.UserConfigs.User_HotKeySet = new DataTable();
                //frmMain.UserConfigs.User_HotKeySet.Columns.Add("hotkeyIndex");
                //frmMain.UserConfigs.User_HotKeySet.Columns.Add("function");
                //frmMain.UserConfigs.User_HotKeySet.Columns.Add("hotkey");
                //frmMain.UserConfigs.User_HotKeySet.Columns.Add("hotkeykey");
                //frmMain.UserConfigs.User_HotKeySet.Columns.Add("hotkeycontrol");
                //frmMain.UserConfigs.User_HotKeySet.Columns.Add("hotkeyshfit");
                //frmMain.UserConfigs.User_HotKeySet.Columns.Add("hotkeyalt");
                //frmMain.UserConfigs.User_HotKeySet.Columns.Add("value");
                //frmMain.UserConfigs.User_HotKeySet.Columns.Add("index");

                KeysConverter kc = new KeysConverter();
                if (frmMain.UserConfigs.QTY_HOTKEY1)
                {
                    int keyValue = (int)kc.ConvertFromString(frmMain.UserConfigs.QTY_HOTKEY_KEY1);
                    frmMain.UserConfigs.User_HotKeySet.Rows.Add(new object[] { frmMain.UserConfigs.LoginID, keyValue, frmMain.UserConfigs.QTY_HOTKEY_KEY1, frmMain.UserConfigs.QTY_HOTKEY_KEY1, keyValue, "", "", "", "QTY:" + frmMain.UserConfigs.QTY_HOTKEY_VALUE1, frmMain.UserConfigs.User_HotKeySet.Rows.Count });
                }
                if (frmMain.UserConfigs.QTY_HOTKEY2)
                {
                    int keyValue = (int)kc.ConvertFromString(frmMain.UserConfigs.QTY_HOTKEY_KEY2);
                    frmMain.UserConfigs.User_HotKeySet.Rows.Add(new object[] { frmMain.UserConfigs.LoginID, keyValue, frmMain.UserConfigs.QTY_HOTKEY_KEY2, frmMain.UserConfigs.QTY_HOTKEY_KEY2, keyValue, "", "", "", "QTY:" + frmMain.UserConfigs.QTY_HOTKEY_VALUE2, frmMain.UserConfigs.User_HotKeySet.Rows.Count });
                }
                if (frmMain.UserConfigs.QTY_HOTKEY3)
                {
                    int keyValue = (int)kc.ConvertFromString(frmMain.UserConfigs.QTY_HOTKEY_KEY3);
                    frmMain.UserConfigs.User_HotKeySet.Rows.Add(new object[] { frmMain.UserConfigs.LoginID, keyValue, frmMain.UserConfigs.QTY_HOTKEY_KEY3, frmMain.UserConfigs.QTY_HOTKEY_KEY3, keyValue, "", "", "", "QTY:" + frmMain.UserConfigs.QTY_HOTKEY_VALUE3, frmMain.UserConfigs.User_HotKeySet.Rows.Count });
                }
                if (frmMain.UserConfigs.QTY_HOTKEY4)
                {
                    int keyValue = (int)kc.ConvertFromString(frmMain.UserConfigs.QTY_HOTKEY_KEY4);
                    frmMain.UserConfigs.User_HotKeySet.Rows.Add(new object[] { frmMain.UserConfigs.LoginID, keyValue, frmMain.UserConfigs.QTY_HOTKEY_KEY4, frmMain.UserConfigs.QTY_HOTKEY_KEY4, keyValue, "", "", "", "QTY:" + frmMain.UserConfigs.QTY_HOTKEY_VALUE4, frmMain.UserConfigs.User_HotKeySet.Rows.Count });
                }
                if (frmMain.UserConfigs.QTY_HOTKEY5)
                {
                    int keyValue = (int)kc.ConvertFromString(frmMain.UserConfigs.QTY_HOTKEY_KEY5);
                    frmMain.UserConfigs.User_HotKeySet.Rows.Add(new object[] { frmMain.UserConfigs.LoginID, keyValue, frmMain.UserConfigs.QTY_HOTKEY_KEY5, frmMain.UserConfigs.QTY_HOTKEY_KEY5, keyValue, "", "", "", "QTY:" + frmMain.UserConfigs.QTY_HOTKEY_VALUE5, frmMain.UserConfigs.User_HotKeySet.Rows.Count });
                }

                if (frmMain.UserConfigs.MIT_HOTKEY)
                {
                    int keyValue = (int)kc.ConvertFromString(frmMain.UserConfigs.MIT_HOTKEY_KEY);
                    frmMain.UserConfigs.User_HotKeySet.Rows.Add(new object[] { frmMain.UserConfigs.LoginID, keyValue, frmMain.UserConfigs.MIT_HOTKEY_KEY, frmMain.UserConfigs.MIT_HOTKEY_KEY, keyValue, "", "", "", "MITDEL:", frmMain.UserConfigs.User_HotKeySet.Rows.Count });
                }
                if (frmMain.UserConfigs.MP_HOTKEY)
                {
                    int keyValue = (int)kc.ConvertFromString(frmMain.UserConfigs.MP_HOTKEY_BKEY);
                    frmMain.UserConfigs.User_HotKeySet.Rows.Add(new object[] { frmMain.UserConfigs.LoginID, keyValue, frmMain.UserConfigs.MP_HOTKEY_BKEY, frmMain.UserConfigs.MP_HOTKEY_BKEY, keyValue, "", "", "", "MB:", frmMain.UserConfigs.User_HotKeySet.Rows.Count });
                    keyValue = (int)kc.ConvertFromString(frmMain.UserConfigs.MP_HOTKEY_SKEY);
                    frmMain.UserConfigs.User_HotKeySet.Rows.Add(new object[] { frmMain.UserConfigs.LoginID, keyValue, frmMain.UserConfigs.MP_HOTKEY_SKEY, frmMain.UserConfigs.MP_HOTKEY_SKEY, keyValue, "", "", "", "MS:", frmMain.UserConfigs.User_HotKeySet.Rows.Count });
                }
                if (frmMain.UserConfigs.CA_HOTKEY)
                {
                    int keyValue = (int)kc.ConvertFromString(frmMain.UserConfigs.CA_HOTKEY_KEY);
                    frmMain.UserConfigs.User_HotKeySet.Rows.Add(new object[] { frmMain.UserConfigs.LoginID, keyValue, frmMain.UserConfigs.CA_HOTKEY_KEY, frmMain.UserConfigs.CA_HOTKEY_KEY, keyValue, "", "", "", "CA:", frmMain.UserConfigs.User_HotKeySet.Rows.Count });
                }
                if (frmMain.UserConfigs.BM_HOTKEY)
                {
                    int keyValue = (int)kc.ConvertFromString(frmMain.UserConfigs.BM_HOTKEY_KEY);
                    frmMain.UserConfigs.User_HotKeySet.Rows.Add(new object[] { frmMain.UserConfigs.LoginID, keyValue, frmMain.UserConfigs.BM_HOTKEY_KEY, frmMain.UserConfigs.BM_HOTKEY_KEY, keyValue, "", "", "", "BM:" + frmMain.UserConfigs.BM_HOTKEY_VALUE + ":" + frmMain.UserConfigs.BM_HOTKEY_BTICK.ToString() + ":" + frmMain.UserConfigs.BM_HOTKEY_STICK.ToString(), frmMain.UserConfigs.User_HotKeySet.Rows.Count });
                }
                if (frmMain.UserConfigs.NUMER_KEYBOARD)
                {

                    //7
                    int keyValue = (int)kc.ConvertFromString(Keys.Home.ToString());
                    frmMain.UserConfigs.User_HotKeySet.Rows.Add(new object[] { frmMain.UserConfigs.LoginID, keyValue, Keys.Home.ToString(), Keys.Home.ToString(), keyValue, "", "", "", "QTY:" + "7", frmMain.UserConfigs.User_HotKeySet.Rows.Count });
                    //8
                    keyValue = (int)kc.ConvertFromString(Keys.Up.ToString());
                    frmMain.UserConfigs.User_HotKeySet.Rows.Add(new object[] { frmMain.UserConfigs.LoginID, keyValue, Keys.Up.ToString(), Keys.Up.ToString(), keyValue, "", "", "", "QTY:" + "8", frmMain.UserConfigs.User_HotKeySet.Rows.Count });
                    //9
                    keyValue = (int)kc.ConvertFromString(Keys.PageUp.ToString());
                    frmMain.UserConfigs.User_HotKeySet.Rows.Add(new object[] { frmMain.UserConfigs.LoginID, keyValue, Keys.PageUp.ToString(), Keys.PageUp.ToString(), keyValue, "", "", "", "QTY:" + "9", frmMain.UserConfigs.User_HotKeySet.Rows.Count });
                    //4
                    keyValue = (int)kc.ConvertFromString(Keys.Left.ToString());
                    frmMain.UserConfigs.User_HotKeySet.Rows.Add(new object[] { frmMain.UserConfigs.LoginID, keyValue, Keys.Left.ToString(), Keys.Left.ToString(), keyValue, "", "", "", "QTY:" + "4", frmMain.UserConfigs.User_HotKeySet.Rows.Count });


                    //5
                    keyValue = (int)kc.ConvertFromString(Keys.Clear.ToString());
                    frmMain.UserConfigs.User_HotKeySet.Rows.Add(new object[] { frmMain.UserConfigs.LoginID, keyValue, Keys.Clear.ToString(), Keys.Clear.ToString(), keyValue, "", "", "", "QTY:" + "5", frmMain.UserConfigs.User_HotKeySet.Rows.Count });


                    //6
                    keyValue = (int)kc.ConvertFromString(Keys.Right.ToString());
                    frmMain.UserConfigs.User_HotKeySet.Rows.Add(new object[] { frmMain.UserConfigs.LoginID, keyValue, Keys.Right.ToString(), Keys.Right.ToString(), keyValue, "", "", "", "QTY:" + "6", frmMain.UserConfigs.User_HotKeySet.Rows.Count });


                    //1
                    keyValue = (int)kc.ConvertFromString(Keys.End.ToString());
                    frmMain.UserConfigs.User_HotKeySet.Rows.Add(new object[] { frmMain.UserConfigs.LoginID, keyValue, Keys.End.ToString(), Keys.End.ToString(), keyValue, "", "", "", "QTY:" + "1", frmMain.UserConfigs.User_HotKeySet.Rows.Count });


                    //2
                    keyValue = (int)kc.ConvertFromString(Keys.Down.ToString());
                    frmMain.UserConfigs.User_HotKeySet.Rows.Add(new object[] { frmMain.UserConfigs.LoginID, keyValue, Keys.Down.ToString(), Keys.Down.ToString(), keyValue, "", "", "", "QTY:" + "2", frmMain.UserConfigs.User_HotKeySet.Rows.Count });


                    //3
                    keyValue = (int)kc.ConvertFromString(Keys.Next.ToString());
                    frmMain.UserConfigs.User_HotKeySet.Rows.Add(new object[] { frmMain.UserConfigs.LoginID, keyValue, Keys.Next.ToString(), Keys.Next.ToString(), keyValue, "", "", "", "QTY:" + "3", frmMain.UserConfigs.User_HotKeySet.Rows.Count });


                    //0
                    keyValue = (int)kc.ConvertFromString(Keys.Insert.ToString());
                    frmMain.UserConfigs.User_HotKeySet.Rows.Add(new object[] { frmMain.UserConfigs.LoginID, keyValue, Keys.Insert.ToString(), Keys.Insert.ToString(), keyValue, "", "", "", "QTY:" + "0", frmMain.UserConfigs.User_HotKeySet.Rows.Count });

                }
            }
            catch (Exception ex)
            {
                _LM.WriteLog("DataAgentLog", "setCommonHotkey:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }


    }
}
