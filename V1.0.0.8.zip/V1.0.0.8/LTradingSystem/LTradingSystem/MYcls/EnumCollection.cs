﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VIPTradingSystem.MYcls
{

     public enum QueryAction
    {
        NoAction, Previous, Next, First, End
    }

     public enum EnumOrderType { Order = 0, Cancel=4, Replace=5 };

    public class OrderType
    {
        public static string Order = "0";
        public static string Cancel = "4";
        public static string Replace = "5";
    
    }
    public class EnumCollection
    {

    }
}
