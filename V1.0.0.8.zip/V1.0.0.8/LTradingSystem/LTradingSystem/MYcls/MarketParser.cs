﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Runtime.InteropServices;
namespace VIPTradingSystem.MYcls
{
    public class MarketParser
    {
        public struct Item
        {
            public RegitemKind Type;
            public ProductKind ProductKind;
            public string ProductID;
        }
        public enum ProductKind
        {
            Future = 1, Option = 2, mOption, mFuture = 4
        }
        public enum RegitemKind
        {
            I010 = 10, I020 = 20, I021 = 21, I022 = 22, I023 = 23, I080 = 80, I082 = 82, ALL = 99
        }


        private Dictionary<string, int> _I010;
        private Dictionary<string, int> _I020;
        private Dictionary<string, int> _I021;
        private Dictionary<string, int> _I022;
        private Dictionary<string, int> _I023;
        private Dictionary<string, int> _I080;

        private Dictionary<string, int> _I082;
        private object _locker = new object();

        private System.Threading.Thread m_Thread;
        private Queue<string> _QueueData = new Queue<string>();

        public delegate void parseMarketInfoDataEventHandler(string strData);

        public event parseMarketInfoDataEventHandler parseMarket;


        public MarketParser()
        {
            //string = type+productid int =reg count
            _QueueData = new Queue<string>();
            _I010 = new Dictionary<string, int>(); ;
            _I020 = new Dictionary<string, int>();
            _I021 = new Dictionary<string, int>();
            _I022 = new Dictionary<string, int>();
            _I023 = new Dictionary<string, int>();
            _I080 = new Dictionary<string, int>();
            _I082 = new Dictionary<string, int>();



            m_Thread = new System.Threading.Thread(new ThreadStart(execQueueData));

            m_Thread.IsBackground = true;
            m_Thread.Start();
        }
        public void Dispose()
        {
            if (m_Thread != null)
            {
                PutData2Queue("");
                m_Thread.Abort();
                m_Thread = null;
            }
            if (_I010 != null)
            {
                _I010.Clear();
                _I010 = null;
            }
            if (_I020 != null)
            {
                _I020.Clear();
                _I020 = null;
            }
            if (_I021 != null)
            {
                _I021.Clear();
                _I021 = null;
            }
            if (_I022 != null)
            {
                _I022.Clear();
                _I022 = null;
            }
            if (_I023 != null)
            {
                _I023.Clear();
                _I023 = null;
            }
            if (_I080 != null)
            {
                _I080.Clear();
                _I080 = null;
            }
            if (_I082 != null)
            {
                _I082.Clear();
                _I082 = null;
            }
            if (_QueueData != null)
            {
                _QueueData.Clear();
                _QueueData = null;
            }


        }

        public byte[] RegItemALL()
        {

            try
            {

 

                MarketSockClientParserFunction.DDSCdata DDSCdata = new MarketSockClientParserFunction.DDSCdata();
                DDSCdata.TYPE = ASCIIEncoding.ASCII.GetBytes(((int)RegitemKind.ALL).ToString());
                DDSCdata.PRODUCTKIND = ASCIIEncoding.ASCII.GetBytes(((int)0).ToString());
                DDSCdata.PRODUCTID = ASCIIEncoding.ASCII.GetBytes("".PadRight(20, ' '));

                byte[] buffer = MarketSockClientParserFunction.StructureToByteArray(DDSCdata);
              
                MarketAPClientSend(MarketSockClientParserFunction.DDSCSocketHead.RegItem, buffer);
              
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return null;
        }


        public byte[] unRegItemALL()
        {

            try
            {

                MarketSockClientParserFunction.DDSCdata DDSCdata = new MarketSockClientParserFunction.DDSCdata();
                DDSCdata.TYPE = ASCIIEncoding.ASCII.GetBytes(((int)RegitemKind.ALL).ToString());
                DDSCdata.PRODUCTKIND = ASCIIEncoding.ASCII.GetBytes(((int)0).ToString());
                DDSCdata.PRODUCTID = ASCIIEncoding.ASCII.GetBytes("".PadRight(20, ' '));

                byte[] buffer = MarketSockClientParserFunction.StructureToByteArray(DDSCdata);
 
                MarketAPClientSend(MarketSockClientParserFunction.DDSCSocketHead.unRegItem, buffer);
                
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return null;
        }




        public byte[] RegItem(RegitemKind Type, ProductKind ProductKind, string ProductID)
        {
            string Product = ((int)ProductKind).ToString() + ProductID;
            int count = 0;
            try
            {
                lock (_locker)
                {
                    switch (Type)
                    {
                        case RegitemKind.I010:
                            if (_I010.ContainsKey(Product))
                            {
                                count = _I010[Product];
                                count++;
                                _I010[Product] = count;
                            }
                            else
                            {
                                _I010.Add(Product, 1);
                            }
                            break;
                        case RegitemKind.I020:
                            if (_I020.ContainsKey(Product))
                            {
                                count = _I020[Product];
                                count++;
                                _I020[Product] = count;
                            }
                            else
                            {
                                _I020.Add(Product, 1);
                            }
                            break;
                        case RegitemKind.I021:
                            if (_I021.ContainsKey(Product))
                            {
                                count = _I021[Product];
                                count++;
                                _I021[Product] = count;
                            }
                            else
                            {
                                _I021.Add(Product, 1);
                            }
                            break;
                        case RegitemKind.I022:
                            if (_I022.ContainsKey(Product))
                            {
                                count = _I022[Product];
                                count++;
                                _I022[Product] = count;
                            }
                            else
                            {
                                _I022.Add(Product, 1);
                            }
                            break;
                        case RegitemKind.I023:
                            if (_I023.ContainsKey(Product))
                            {
                                count = _I023[Product];
                                count++;
                                _I023[Product] = count;
                            }
                            else
                            {
                                _I023.Add(Product, 1);
                            }
                            break;
                        case RegitemKind.I080:
                            if (_I080.ContainsKey(Product))
                            {
                                count = _I080[Product];
                                count++;
                                _I080[Product] = count;
                            }
                            else
                            {
                                _I080.Add(Product, 1);
                            }
                            break;
                        case RegitemKind.I082:
                            if (_I082.ContainsKey(Product))
                            {
                                count = _I082[Product];
                                count++;
                                _I082[Product] = count;
                            }
                            else
                            {
                                _I082.Add(Product, 1);
                            }
                            break;
                    }

                }

                if (count > 1)//當count=1時才註冊商品
                {
                    return null;
                }
               

                MarketSockClientParserFunction.DDSCdata DDSCdata = new MarketSockClientParserFunction.DDSCdata();
                DDSCdata.TYPE = ASCIIEncoding.ASCII.GetBytes(((int)Type).ToString());
                DDSCdata.PRODUCTKIND = ASCIIEncoding.ASCII.GetBytes(((int)ProductKind).ToString());
                DDSCdata.PRODUCTID = ASCIIEncoding.ASCII.GetBytes(ProductID.PadRight(20, ' '));

                byte[] buffer = MarketSockClientParserFunction.StructureToByteArray(DDSCdata);
         

                MarketAPClientSend(MarketSockClientParserFunction.DDSCSocketHead.RegItem, buffer);
                return buffer;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return null;
        }


 


        public byte[] unRegItem(RegitemKind Type, ProductKind ProductKind, string ProductID)
        {

            try
            {
                string Product  = ((int)ProductKind).ToString() + ProductID;
                int count = 0;
                lock (_locker)
                {
                    switch (Type)
                    {
                        case RegitemKind.I010:
                            if (_I010.ContainsKey(Product))
                            {
                                count = _I010[Product];
                                count--;
                                if (count == 0)
                                {
                                    _I010.Remove(Product);
                                }
                            }

                            break;
                        case RegitemKind.I020:
                            if (_I020.ContainsKey(Product))
                            {
                                count = _I020[Product];
                                count--;
                                if (count == 0)
                                {
                                    _I020.Remove(Product);
                                }
                            }

                            break;
                        case RegitemKind.I021:
                            if (_I021.ContainsKey(Product))
                            {
                                count = _I021[Product];
                                count--;
                                if (count == 0)
                                {
                                    _I021.Remove(Product);
                                }
                            }

                            break;
                        case RegitemKind.I022:
                            if (_I022.ContainsKey(Product))
                            {
                                count = _I022[Product];
                                count--;
                                if (count == 0)
                                {
                                    _I022.Remove(Product);
                                }
                            }

                            break;
                        case RegitemKind.I023:
                            if (_I023.ContainsKey(Product))
                            {
                                count = _I023[Product];
                                count--;
                                if (count == 0)
                                {
                                    _I023.Remove(Product);
                                }
                            }

                            break;
                        case RegitemKind.I080:
                            if (_I080.ContainsKey(Product))
                            {
                                count = _I080[Product];
                                count--;
                                if (count == 0)
                                {
                                    _I080.Remove(Product);
                                }
                            }

                            break;
                        case RegitemKind.I082:
                            if (_I082.ContainsKey(Product))
                            {
                                count = _I082[Product];
                                count--;
                                if (count == 0)
                                {
                                    _I082.Remove(Product);
                                }
                            }

                            break;
                    }

                }
                return null;
                if (count < 1) return null; //count=0 時才反註冊
 
         

                MarketSockClientParserFunction.DDSCdata DDSCdata = new MarketSockClientParserFunction.DDSCdata();
                DDSCdata.TYPE = ASCIIEncoding.ASCII.GetBytes(((int)Type).ToString());
                DDSCdata.PRODUCTKIND = ASCIIEncoding.ASCII.GetBytes(((int)ProductKind).ToString());
                DDSCdata.PRODUCTID = ASCIIEncoding.ASCII.GetBytes(ProductID.PadRight(20, ' '));

                byte[] buffer = MarketSockClientParserFunction.StructureToByteArray(DDSCdata);
          
                MarketAPClientSend(MarketSockClientParserFunction.DDSCSocketHead.unRegItem, buffer);
               
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return null;
        }

 
        public byte[] unRegItemAll()
        {
            List<byte> body = new List<byte>();
            List<byte> raw = new List<byte>();
            string PRODUCTKIND;
            string PRODUCTID;
            byte[] head = null;
            byte[] data = null;
            byte[] Ret = null;
            try
            {
                lock (_locker)
                {

                    foreach (string key in _I010.Keys)
                    {
                        if (_I010.ContainsKey(key))
                        {
                            PRODUCTKIND = key.Substring(0, 1);
                            PRODUCTID = key.Substring(1, key.Length - 1);
                            MarketSockClientParserFunction.DDSCdata DDSCdata = new MarketSockClientParserFunction.DDSCdata();
                            DDSCdata.TYPE = ASCIIEncoding.ASCII.GetBytes(((int)RegitemKind.I010).ToString());
                            DDSCdata.PRODUCTKIND = ASCIIEncoding.ASCII.GetBytes(PRODUCTKIND);
                            DDSCdata.PRODUCTID = ASCIIEncoding.ASCII.GetBytes(PRODUCTID.PadRight(20, ' '));
                            data = MarketSockClientParserFunction.StructureToByteArray(DDSCdata);
                            MarketAPClientSend(MarketSockClientParserFunction.DDSCSocketHead.unRegItem, data);
                        }
                    }
                    foreach (string key in _I020.Keys)
                    {
                        if (_I020.ContainsKey(key))
                        {
                            PRODUCTKIND = key.Substring(0, 1);
                            PRODUCTID = key.Substring(1, key.Length - 1);
                            MarketSockClientParserFunction.DDSCdata DDSCdata = new MarketSockClientParserFunction.DDSCdata();
                            DDSCdata.TYPE = ASCIIEncoding.ASCII.GetBytes(((int)RegitemKind.I020).ToString());
                            DDSCdata.PRODUCTKIND = ASCIIEncoding.ASCII.GetBytes(PRODUCTKIND);
                            DDSCdata.PRODUCTID = ASCIIEncoding.ASCII.GetBytes(PRODUCTID.PadRight(20, ' '));
                            data = MarketSockClientParserFunction.StructureToByteArray(DDSCdata);
                            MarketAPClientSend(MarketSockClientParserFunction.DDSCSocketHead.unRegItem, data);
                        }
                    }
                    foreach (string key in _I021.Keys)
                    {
                        if (_I021.ContainsKey(key))
                        {
                            PRODUCTKIND = key.Substring(0, 1);
                            PRODUCTID = key.Substring(1, key.Length - 1);
                            MarketSockClientParserFunction.DDSCdata DDSCdata = new MarketSockClientParserFunction.DDSCdata();
                            DDSCdata.TYPE = ASCIIEncoding.ASCII.GetBytes(((int)RegitemKind.I021).ToString());
                            DDSCdata.PRODUCTKIND = ASCIIEncoding.ASCII.GetBytes(PRODUCTKIND);
                            DDSCdata.PRODUCTID = ASCIIEncoding.ASCII.GetBytes(PRODUCTID.PadRight(20, ' '));
                            data = MarketSockClientParserFunction.StructureToByteArray(DDSCdata);
                            MarketAPClientSend(MarketSockClientParserFunction.DDSCSocketHead.unRegItem, data);
                        }
                    }
                    foreach (string key in _I022.Keys)
                    {
                        if (_I022.ContainsKey(key))
                        {
                            PRODUCTKIND = key.Substring(0, 1);
                            PRODUCTID = key.Substring(1, key.Length - 1);
                            MarketSockClientParserFunction.DDSCdata DDSCdata = new MarketSockClientParserFunction.DDSCdata();
                            DDSCdata.TYPE = ASCIIEncoding.ASCII.GetBytes(((int)RegitemKind.I022).ToString());
                            DDSCdata.PRODUCTKIND = ASCIIEncoding.ASCII.GetBytes(PRODUCTKIND);
                            DDSCdata.PRODUCTID = ASCIIEncoding.ASCII.GetBytes(PRODUCTID.PadRight(20, ' '));
                            data = MarketSockClientParserFunction.StructureToByteArray(DDSCdata);
                            MarketAPClientSend(MarketSockClientParserFunction.DDSCSocketHead.unRegItem, data);
                        }
                    }

                    foreach (string key in _I023.Keys)
                    {
                        if (_I023.ContainsKey(key))
                        {
                            PRODUCTKIND = key.Substring(0, 1);
                            PRODUCTID = key.Substring(1, key.Length - 1);
                            MarketSockClientParserFunction.DDSCdata DDSCdata = new MarketSockClientParserFunction.DDSCdata();
                            DDSCdata.TYPE = ASCIIEncoding.ASCII.GetBytes(((int)RegitemKind.I023).ToString());
                            DDSCdata.PRODUCTKIND = ASCIIEncoding.ASCII.GetBytes(PRODUCTKIND);
                            DDSCdata.PRODUCTID = ASCIIEncoding.ASCII.GetBytes(PRODUCTID.PadRight(20, ' '));
                            data = MarketSockClientParserFunction.StructureToByteArray(DDSCdata);
                            MarketAPClientSend(MarketSockClientParserFunction.DDSCSocketHead.unRegItem, data);
                        }
                    }

                    foreach (string key in _I080.Keys)
                    {
                        if (_I080.ContainsKey(key))
                        {
                            PRODUCTKIND = key.Substring(0, 1);
                            PRODUCTID = key.Substring(1, key.Length - 1);
                            MarketSockClientParserFunction.DDSCdata DDSCdata = new MarketSockClientParserFunction.DDSCdata();
                            DDSCdata.TYPE = ASCIIEncoding.ASCII.GetBytes(((int)RegitemKind.I080).ToString());
                            DDSCdata.PRODUCTKIND = ASCIIEncoding.ASCII.GetBytes(PRODUCTKIND);
                            DDSCdata.PRODUCTID = ASCIIEncoding.ASCII.GetBytes(PRODUCTID.PadRight(20, ' '));
                            data = MarketSockClientParserFunction.StructureToByteArray(DDSCdata);
                            MarketAPClientSend(MarketSockClientParserFunction.DDSCSocketHead.unRegItem, data);
                        }
                    }

                    foreach (string key in _I082.Keys)
                    {
                        if (_I082.ContainsKey(key))
                        {
                            PRODUCTKIND = key.Substring(0, 1);
                            PRODUCTID = key.Substring(1, key.Length - 1);
                            MarketSockClientParserFunction.DDSCdata DDSCdata = new MarketSockClientParserFunction.DDSCdata();
                            DDSCdata.TYPE = ASCIIEncoding.ASCII.GetBytes(((int)RegitemKind.I082).ToString());
                            DDSCdata.PRODUCTKIND = ASCIIEncoding.ASCII.GetBytes(PRODUCTKIND);
                            DDSCdata.PRODUCTID = ASCIIEncoding.ASCII.GetBytes(PRODUCTID.PadRight(20, ' '));
                            data = MarketSockClientParserFunction.StructureToByteArray(DDSCdata);
                            MarketAPClientSend(MarketSockClientParserFunction.DDSCSocketHead.unRegItem, data);
                        }
                    }
                }

                _I010.Clear();
                _I020.Clear();
                _I021.Clear();
                _I022.Clear();
                _I023.Clear();
                _I080.Clear();
                _I082.Clear();
               

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return null;
        }


        public byte[] ReRegisterALL()
        {

            string PRODUCTKIND;
            string PRODUCTID;
            byte[] Ret = null;
            byte[] data = null;
            try
            {
                lock (_locker)
                {
                    foreach (string key in _I010.Keys)
                    {
                        if (_I010.ContainsKey(key))
                        {
                            PRODUCTKIND = key.Substring(0, 1);
                            PRODUCTID = key.Substring(1, key.Length - 1);
                            MarketSockClientParserFunction.DDSCdata DDSCdata = new MarketSockClientParserFunction.DDSCdata();
                            DDSCdata.TYPE = ASCIIEncoding.ASCII.GetBytes(((int)RegitemKind.I010).ToString());
                            DDSCdata.PRODUCTKIND = ASCIIEncoding.ASCII.GetBytes(PRODUCTKIND);
                            DDSCdata.PRODUCTID = ASCIIEncoding.ASCII.GetBytes(PRODUCTID.PadRight(20, ' '));
                            data = MarketSockClientParserFunction.StructureToByteArray(DDSCdata);
                            MarketAPClientSend(MarketSockClientParserFunction.DDSCSocketHead.RegItem,data);
                        }
                    }
                    foreach (string key in _I020.Keys)
                    {
                        if (_I020.ContainsKey(key))
                        {
                            PRODUCTKIND = key.Substring(0, 1);
                            PRODUCTID = key.Substring(1, key.Length - 1);
                            MarketSockClientParserFunction.DDSCdata DDSCdata = new MarketSockClientParserFunction.DDSCdata();
                            DDSCdata.TYPE = ASCIIEncoding.ASCII.GetBytes(((int)RegitemKind.I020).ToString());
                            DDSCdata.PRODUCTKIND = ASCIIEncoding.ASCII.GetBytes(PRODUCTKIND);
                            DDSCdata.PRODUCTID = ASCIIEncoding.ASCII.GetBytes(PRODUCTID.PadRight(20, ' '));
                            data = MarketSockClientParserFunction.StructureToByteArray(DDSCdata);
                            MarketAPClientSend(MarketSockClientParserFunction.DDSCSocketHead.RegItem, data);
                        }
                    }
                    foreach (string key in _I021.Keys)
                    {
                        if (_I021.ContainsKey(key))
                        {
                            PRODUCTKIND = key.Substring(0, 1);
                            PRODUCTID = key.Substring(1, key.Length - 1);
                            MarketSockClientParserFunction.DDSCdata DDSCdata = new MarketSockClientParserFunction.DDSCdata();
                            DDSCdata.TYPE = ASCIIEncoding.ASCII.GetBytes(((int)RegitemKind.I021).ToString());
                            DDSCdata.PRODUCTKIND = ASCIIEncoding.ASCII.GetBytes(PRODUCTKIND);
                            DDSCdata.PRODUCTID = ASCIIEncoding.ASCII.GetBytes(PRODUCTID.PadRight(20, ' '));
                            data = MarketSockClientParserFunction.StructureToByteArray(DDSCdata);
                            MarketAPClientSend(MarketSockClientParserFunction.DDSCSocketHead.RegItem, data);
                        }
                    }
                    foreach (string key in _I022.Keys)
                    {
                        if (_I022.ContainsKey(key))
                        {
                            PRODUCTKIND = key.Substring(0, 1);
                            PRODUCTID = key.Substring(1, key.Length - 1);
                            MarketSockClientParserFunction.DDSCdata DDSCdata = new MarketSockClientParserFunction.DDSCdata();
                            DDSCdata.TYPE = ASCIIEncoding.ASCII.GetBytes(((int)RegitemKind.I022).ToString());
                            DDSCdata.PRODUCTKIND = ASCIIEncoding.ASCII.GetBytes(PRODUCTKIND);
                            DDSCdata.PRODUCTID = ASCIIEncoding.ASCII.GetBytes(PRODUCTID.PadRight(20, ' '));
                            data = MarketSockClientParserFunction.StructureToByteArray(DDSCdata);
                            MarketAPClientSend(MarketSockClientParserFunction.DDSCSocketHead.RegItem, data);
                        }
                    }

                    foreach (string key in _I023.Keys)
                    {
                        if (_I023.ContainsKey(key))
                        {
                            PRODUCTKIND = key.Substring(0, 1);
                            PRODUCTID = key.Substring(1, key.Length - 1);
                            MarketSockClientParserFunction.DDSCdata DDSCdata = new MarketSockClientParserFunction.DDSCdata();
                            DDSCdata.TYPE = ASCIIEncoding.ASCII.GetBytes(((int)RegitemKind.I023).ToString());
                            DDSCdata.PRODUCTKIND = ASCIIEncoding.ASCII.GetBytes(PRODUCTKIND);
                            DDSCdata.PRODUCTID = ASCIIEncoding.ASCII.GetBytes(PRODUCTID.PadRight(20, ' '));
                            data = MarketSockClientParserFunction.StructureToByteArray(DDSCdata);
                            MarketAPClientSend(MarketSockClientParserFunction.DDSCSocketHead.RegItem, data);
                        }
                    }

                    foreach (string key in _I080.Keys)
                    {
                        if (_I080.ContainsKey(key))
                        {
                            PRODUCTKIND = key.Substring(0, 1);
                            PRODUCTID = key.Substring(1, key.Length - 1);
                            MarketSockClientParserFunction.DDSCdata DDSCdata = new MarketSockClientParserFunction.DDSCdata();
                            DDSCdata.TYPE = ASCIIEncoding.ASCII.GetBytes(((int)RegitemKind.I080).ToString());
                            DDSCdata.PRODUCTKIND = ASCIIEncoding.ASCII.GetBytes(PRODUCTKIND);
                            DDSCdata.PRODUCTID = ASCIIEncoding.ASCII.GetBytes(PRODUCTID.PadRight(20, ' '));
                            data = MarketSockClientParserFunction.StructureToByteArray(DDSCdata);
                            MarketAPClientSend(MarketSockClientParserFunction.DDSCSocketHead.RegItem, data);
                        }
                    }

                    foreach (string key in _I082.Keys)
                    {
                        if (_I082.ContainsKey(key))
                        {
                            PRODUCTKIND = key.Substring(0, 1);
                            PRODUCTID = key.Substring(1, key.Length - 1);
                            MarketSockClientParserFunction.DDSCdata DDSCdata = new MarketSockClientParserFunction.DDSCdata();
                            DDSCdata.TYPE = ASCIIEncoding.ASCII.GetBytes(((int)RegitemKind.I082).ToString());
                            DDSCdata.PRODUCTKIND = ASCIIEncoding.ASCII.GetBytes(PRODUCTKIND);
                            DDSCdata.PRODUCTID = ASCIIEncoding.ASCII.GetBytes(PRODUCTID.PadRight(20, ' '));
                            data = MarketSockClientParserFunction.StructureToByteArray(DDSCdata);
                            MarketAPClientSend(MarketSockClientParserFunction.DDSCSocketHead.RegItem, data);
                        }
                    }
                }


            }
            catch (Exception ex)
            {
                throw ex;
            }
            return Ret;
        }

        private void MarketAPClientSend(byte  headCode,byte[] body)
        {
            byte[] Ret = null;

            List<byte> raw = new List<byte>();
            byte[] head = null;
            byte[] data = null;
            MarketSockClientParserFunction.DDSCHead DDSCHead = new MarketSockClientParserFunction.DDSCHead();
            DDSCHead.HEAD = new byte[1]{headCode};
            DDSCHead.MESSAGETIME = ASCIIEncoding.ASCII.GetBytes(DateTime.Now.ToString("HHmmssfff"));
            DDSCHead.OLDSEQ = ASCIIEncoding.ASCII.GetBytes("".PadRight(8, ' '));
            DDSCHead.NEWSEQ = ASCIIEncoding.ASCII.GetBytes("".PadRight(8, ' '));
            DDSCHead.USERID = ASCIIEncoding.ASCII.GetBytes("".PadRight(20, ' '));
            DDSCHead.SOURCECODE = ASCIIEncoding.ASCII.GetBytes("".PadRight(1, ' '));
            DDSCHead.ORDER_SRC = ASCIIEncoding.ASCII.GetBytes("".PadRight(1, ' '));
            DDSCHead.LENGTH = BitConverter.GetBytes(UInt16.Parse(body.Length.ToString()));
            if (BitConverter.IsLittleEndian)
                Array.Reverse(DDSCHead.LENGTH);
            head = MarketSockClientParserFunction.StructureToByteArray(DDSCHead);
            raw.AddRange(head);
            raw.AddRange(body);
            raw.AddRange(new byte[] { MarketSockClientParserFunction.DDSCSocketHead.End });
            Ret = raw.ToArray();
            frmMain.mobjDataAgent._MarketAPClient.Send(com.ddsc.BI.F.SockClientParserFunction.EncodeData(Ret));

        }


        public void PutData2Queue(string str_Data)
        {

            lock (_locker)
            {
                _QueueData.Enqueue(str_Data);

                Monitor.Pulse(_locker);

            }

        }
        private void execQueueData()
        {
            while (true)
            {
                string data;
                lock (_locker)
                {
                    while (_QueueData.Count == 0) Monitor.Wait(_locker);

                    data = _QueueData.Dequeue();
                }
                if (data != "")
                {

                    string[] dataArray = data.ToString().Split('|');

                    for (int i = 1; i < dataArray.Length; i++)
                    {
                        // parseMarketInfoData(dataArray[i]);
                        if (parseMarket != null)
                        {
                            parseMarket(dataArray[i]);
                        }
                    }



                }
                else break;
            }

        }

    }

    public class MarketSockClientParserFunction
    {
        public static class DDSCSocketHead
        {
            public const byte Connecting = 0x01;
            public const byte Connected = 0x02;

            public const byte End = 0x0a;
            public const byte Alive = 0x13;

            public const byte RegItem = 0x20;
            public const byte unRegItem = 0x21;
            public const byte Other = 0x22;


            public const byte Reply = 0x23;


        }




        [StructLayoutAttribute(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
        public struct DDSCHead
        {
            //head 46
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
            public byte[] HEAD;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)] //hhmmssfff
            public byte[] MESSAGETIME;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)] //000 000~ zzz zzz
            public byte[] OLDSEQ;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)] //000 000~ zzz zzz
            public byte[] NEWSEQ;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
            public byte[] USERID;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
            public byte[] SOURCECODE;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
            public byte[] ORDER_SRC;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
            public byte[] LENGTH;
        }


        [StructLayoutAttribute(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
        public struct DDSCdata
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)] //20 21 22 23 80 82
            public byte[] TYPE;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)] // 1 F 2 O 3 MO 4 MF
            public byte[] PRODUCTKIND;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)] //
            public byte[] PRODUCTID;

        }


        public static byte[] StructureToByteArray(object structObj)
        {
            int size = Marshal.SizeOf(structObj);
            IntPtr buffer = Marshal.AllocHGlobal(size);
            try
            {
                Marshal.StructureToPtr(structObj, buffer, false);
                byte[] bytes = new byte[size];
                Marshal.Copy(buffer, bytes, 0, size);
                return bytes;
            }
            finally
            {
                Marshal.FreeHGlobal(buffer);
            }
        }








        /// <summary>
        /// 取得old seq
        /// </summary>
        /// <param name="buffer"></param>
        /// <returns></returns>
        public static string getDDSCRawDataOldSeq(byte[] buffer)
        {
            return ASCIIEncoding.ASCII.GetString(buffer, 10, 6);
        }
        /// <summary>
        ///  取得new seq
        /// </summary>
        /// <param name="buffer"></param>
        /// <returns></returns>
        public static string getDDSCRawDataNewSeq(byte[] buffer)
        {
            return ASCIIEncoding.ASCII.GetString(buffer, 16, 6);
        }

        /// <summary>
        /// 取得DDSC MessageTime
        /// </summary>
        /// <param name="buffer"></param>
        /// <returns></returns>
        public static string getDDSCMessageTime(byte[] buffer)
        {
            return ASCIIEncoding.ASCII.GetString(buffer, 1, 9);
        }
        public static string getExecType(byte[] buffer)
        {
            return ASCIIEncoding.ASCII.GetString(buffer, 46 + 15, 1);
        }

 

    }

    public class ParserStruct<T>
    {
        public static void ByteArrayToStructure(byte[] bytearray, ref T obj)
        {
            int len = Marshal.SizeOf(obj);
            IntPtr i = Marshal.AllocHGlobal(len);
            Marshal.Copy(bytearray, 0, i, len);
            obj = (T)Marshal.PtrToStructure(i, typeof(T));
            Marshal.FreeHGlobal(i);
        }

        public static void ByteArrayToStructure(byte[] bytearray, int index, ref T obj)
        {
            int len = Marshal.SizeOf(obj);
            IntPtr i = Marshal.AllocHGlobal(len);
            Marshal.Copy(bytearray, index, i, len);
            obj = (T)Marshal.PtrToStructure(i, typeof(T));
            Marshal.FreeHGlobal(i);
        }
    }
}
