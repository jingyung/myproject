﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
namespace VIPTradingSystem.MYcls
{
    public class OrderReplyProvider
    {

        public object _locker = new object();
        /// <summary>
        /// keep 策略單與子單資料
        /// </summary>
        Dictionary<string, List<DataRow>> _StrategySeqData;
        /// <summary>
        /// keep 策略單資料
        /// </summary>
        Dictionary<string, DataRow> _StrategyKeepData;

        private Dictionary<string, string> _StrategyDataForcheck;

        private Dictionary<string, DataRow> _SeqData;

        private Dictionary<string, DataRow> _NetWorkidData;




        private Dictionary<string, DataRow> _SeqDataForReplyMain;

        private Dictionary<string, DataRow> _NetWorkidDataForReplyMain;

        Dictionary<string, DataRow> _StrategyKeepDataForReplyMain;


        private Dictionary<string, DataRow> _MatchData;

        private DataTable _StrategyData;


        private DataTable _ReplyMain;

        public DataTable ReplyMain
        {
            get { return _ReplyMain; }
            set { _ReplyMain = value; }
        }
        private DataTable _ReplyDetail;

        private DataTable _OrderReply;

        public DataTable OrderReply
        {
            get { return _OrderReply; }
            set { _OrderReply = value; }
        }
        public OrderReplyProvider()
        {
            //   initStrategyData();
            initOrderReply();
            _SeqData = new Dictionary<string, DataRow>();

            _NetWorkidData = new Dictionary<string, DataRow>();
            _StrategyKeepData = new Dictionary<string, DataRow>();

            _StrategySeqData = new Dictionary<string, List<DataRow>>();

            _SeqDataForReplyMain = new Dictionary<string, DataRow>();
            _NetWorkidDataForReplyMain = new Dictionary<string, DataRow>();

            _StrategyKeepDataForReplyMain = new Dictionary<string, DataRow>();

            _MatchData = new Dictionary<string, DataRow>();

            _StrategyDataForcheck = new Dictionary<string, string>();
        }
        ~OrderReplyProvider()
        {
            Dispose();
        }

        public void ClearData()
        {
            _SeqData.Clear();
            _NetWorkidData.Clear();
            foreach (string key in _StrategySeqData.Keys)
            {
                _StrategySeqData[key].Clear();
            }

            _StrategySeqData.Clear();
            _StrategyKeepData.Clear();

            _OrderReply.Rows.Clear();

        }

        public void Dispose()
        {
            ClearData();
        }
        private void initStrategyData()
        {
            _StrategyData = new DataTable("OrderReply");

            _StrategyData.Columns.Add("PRICE", typeof(decimal));//委託價格

            _StrategyData.Columns.Add("ORDERQTY", typeof(int));  //委託數量
            _StrategyData.Columns.Add("MATCHQTY", typeof(int));//成交數量
            _StrategyData.Columns.Add("NOMATCHQTY", typeof(int));//未成交數量
            _StrategyData.Columns.Add("UNDQTY", typeof(int));//已委託策略單
            _StrategyData.Columns.Add("DELQTY", typeof(int));//已刪除數量

            _StrategyData.Columns.Add("SEQ", typeof(string));

            _StrategyData.Columns.Add("time", typeof(string));


            _StrategyData.Columns["PRICE"].DefaultValue = 0;
            _StrategyData.Columns["STOPPRICE"].DefaultValue = 0;
            _StrategyData.Columns["ORDERQTY"].DefaultValue = 0;
            _StrategyData.Columns["MATCHQTY"].DefaultValue = 0;
            _StrategyData.Columns["ORDERQTY"].DefaultValue = 0;
            _StrategyData.Columns["UNDQTY"].DefaultValue = 0;
            _StrategyData.Columns["DELQTY"].DefaultValue = 0;
            _StrategyData.Columns["SEQ"].DefaultValue = "";

            DataColumn[] dcPrimaryKey = {   _StrategyData.Columns["SEQ"] 
                                      
                                        };
            _StrategyData.PrimaryKey = dcPrimaryKey;



        }

        private void initOrderReply()
        {
            _OrderReply = new DataTable("OrderReply");
            _OrderReply.Columns.Add("TRADEDATE", typeof(string));//委託日期
            _OrderReply.Columns.Add("ORDERNO", typeof(string));//委託書號
            _OrderReply.Columns.Add("ORDERTIME", typeof(string));//委託時間
            _OrderReply.Columns.Add("BROKERID", typeof(string));//期貨商代號
            _OrderReply.Columns.Add("INVESTORACNO", typeof(string));//客戶帳號
            _OrderReply.Columns.Add("SUBACT", typeof(string));//客戶帳號
            _OrderReply.Columns.Add("BS", typeof(string));//買賣別
            _OrderReply.Columns.Add("PRODUCTKIND", typeof(string));//商品種類
            _OrderReply.Columns.Add("SECURITYEXCHANGE", typeof(string));
            _OrderReply.Columns.Add("SECURITYTYPE1", typeof(string));
            _OrderReply.Columns.Add("SYMBOL1", typeof(string));
            _OrderReply.Columns.Add("MATURITYMONTHYEAR1", typeof(string));
            _OrderReply.Columns.Add("PUTORCALL1", typeof(string));
            _OrderReply.Columns.Add("STRIKEPRICE1", typeof(decimal));
            _OrderReply.Columns.Add("SIDE1", typeof(string));
            _OrderReply.Columns.Add("SECURITYTYPE2", typeof(string));
            _OrderReply.Columns.Add("SYMBOL2", typeof(string));
            _OrderReply.Columns.Add("MATURITYMONTHYEAR2", typeof(string));
            _OrderReply.Columns.Add("PUTORCALL2", typeof(string));
            _OrderReply.Columns.Add("STRIKEPRICE2", typeof(decimal));
            _OrderReply.Columns.Add("SIDE2", typeof(string));
            _OrderReply.Columns.Add("PRICE", typeof(decimal));//委託價格
            _OrderReply.Columns.Add("STOPPRICE", typeof(decimal));//委託價格
            _OrderReply.Columns.Add("ORDERQTY", typeof(int));  //委託數量
            _OrderReply.Columns.Add("MATCHQTY", typeof(int));//成交數量
            _OrderReply.Columns.Add("NOMATCHQTY", typeof(int));//未成交數量
            _OrderReply.Columns.Add("UNDQTY", typeof(int));//已委託策略單
            _OrderReply.Columns.Add("DELQTY", typeof(int));//已刪除數量
            _OrderReply.Columns.Add("STATUSCODE", typeof(string));//委託狀態碼
            _OrderReply.Columns.Add("ORDERSTATUS", typeof(string));//委託狀態
            _OrderReply.Columns.Add("CLORDID", typeof(string));//網路流水序號
            _OrderReply.Columns.Add("OPENCLOSE", typeof(string));// 新倉；O:平 倉；C 
            _OrderReply.Columns.Add("TIMEINFORCE", typeof(string));//委託條件 R I F
            _OrderReply.Columns.Add("ORDERTYPE", typeof(string));//委託方式 M L P
            _OrderReply.Columns.Add("EXPIREDATE", typeof(string));// 
            _OrderReply.Columns.Add("DTRADE", typeof(string));// 
            _OrderReply.Columns.Add("MDATE", typeof(string));//異動時間
            _OrderReply.Columns.Add("SEQ", typeof(string));
            _OrderReply.Columns.Add("SOURCECODE", typeof(string));//下單別
            _OrderReply.Columns.Add("IP", typeof(string));//IP
            _OrderReply.Columns.Add("ORDERID", typeof(string));//IP
            _OrderReply.Columns.Add("TARGETID", typeof(string));//上手代號
            _OrderReply.Columns.Add("ACCOUNT", typeof(string));//上手帳號
            _OrderReply.Columns.Add("ADVANCED", typeof(string));//策略名稱
            _OrderReply.Columns.Add("ADVANCED_TEXT", typeof(string));//策略內容
            _OrderReply.Columns.Add("SEQ_AD", typeof(string)); //策略單 編號
            _OrderReply.Columns.Add("ORDERKIND", typeof(string)); //委託種類 ORDERKIND=P 程式單
            OrderReply.Columns.Add("AVGPRICE", typeof(decimal)); //策略單 編號

            _OrderReply.Columns.Add("product", typeof(string));
            _OrderReply.Columns.Add("contract", typeof(string));
            _OrderReply.Columns.Add("NO", typeof(string));
            _OrderReply.Columns.Add("time", typeof(decimal));
            _OrderReply.Columns.Add("ParentCancel", typeof(bool));
            _OrderReply.Columns["ParentCancel"].DefaultValue = false;
            _OrderReply.Columns["product"].Expression = CommonFunction.ProductExpression;

            _OrderReply.Columns["contract"].Expression = CommonFunction.ContractExpression;
            _OrderReply.Columns.Add("check", typeof(bool));

            _OrderReply.Columns.Add("BEFOREPRICE", typeof(decimal));//委託價格
            _OrderReply.Columns.Add("BEFORESTOPPRICE", typeof(decimal));//委託價格
            _OrderReply.Columns.Add("BEFOREORDERQTY", typeof(int));  //委託數量
            _OrderReply.Columns.Add("BEFOREMATCHQTY", typeof(int));//成交數量
            _OrderReply.Columns.Add("BEFORENOMATCHQTY", typeof(int));//未成交數量
            _OrderReply.Columns.Add("BEFOREUNDQTY", typeof(int));//已委託策略單
            _OrderReply.Columns.Add("BEFOREDELQTY", typeof(int));//已刪除數量
            _OrderReply.Columns.Add("AE", typeof(string));// 
            _OrderReply.Columns.Add("ORDERTAG", typeof(string));// 
            _OrderReply.Columns.Add("KEEPDATA", typeof(string));//已刪除數量
            _OrderReply.Columns.Add("checkflag", typeof(bool));//標記子單是否有勾 



            _OrderReply.Columns.Add("OPENCLOSE_DISPLAY", typeof(string));// 新倉；O:平 倉；C 
            _OrderReply.Columns.Add("TIMEINFORCE_DISPLAY", typeof(string));//委託條件 0=R 3=I 4=F
            _OrderReply.Columns.Add("ORDERTYPE_DISPLAY", typeof(string));//委託方式 1=Market 2=Limit 3=Stop 4=Stop Limit
            _OrderReply.Columns.Add("STATUSCODE_DISPLAY", typeof(string));//委託狀態碼
            _OrderReply.Columns.Add("ORDERSTATUS_DISPLAY", typeof(string));//委託狀態




            _OrderReply.Columns["OPENCLOSE_DISPLAY"].Expression = "IIF(OPENCLOSE='O','Open','Close')";
            _OrderReply.Columns["TIMEINFORCE_DISPLAY"].Expression = "IIF(TIMEINFORCE='0','Day',        IIF(TIMEINFORCE='3','Ioc',   IIF(TIMEINFORCE='4','Fok',TIMEINFORCE)))";
            _OrderReply.Columns["ORDERTYPE_DISPLAY"].Expression = " IIF(ORDERTYPE='1','Market',   IIF(ORDERTYPE='2','Limit',   IIF(ORDERTYPE='3','Stop','Stop Limit')))";
            _OrderReply.Columns["STATUSCODE_DISPLAY"].Expression = @"IIF(
                                                                        (STATUSCODE='0000'  )  
                                                                         ,'W',              IIF(STATUSCODE='0002'    ,'C'
,   IIF(STATUSCODE='0007'    ,'R',IIF(STATUSCODE='0004'    ,'F', IIF(  STATUSCODE='0003'    ,'P', IIF(  STATUSCODE='0010'    ,'T',STATUSCODE))) ))
                                                        )";





            _OrderReply.Columns["ORDERSTATUS_DISPLAY"].Expression = @"IIF(
                                                                        (STATUSCODE='0000'  )  
                                                                         ,'Working',              IIF(STATUSCODE='0002'    ,'Canceled',   IIF(STATUSCODE='0007'    
,'Replaced',IIF(STATUSCODE='0004'    ,'Filled', IIF(  STATUSCODE='0003'    ,'Partially Filled',  IIF(  STATUSCODE='0010'    ,'Waiting',IIF(  STATUSCODE='E'    ,'ERROR',ORDERSTATUS)))) ))
                                                        )";


            _OrderReply.Columns.Add("ORDERTIME_DISPLAY", typeof(string));//成交時間

            _OrderReply.Columns.Add("TRADEDATE_DISPLAY", typeof(string));
            _OrderReply.Columns["ORDERTIME_DISPLAY"].Expression = @"SUBSTRING(ORDERTIME,1,2) +':' +SUBSTRING(ORDERTIME,3,2) +':'+
                                                                        SUBSTRING(ORDERTIME,5,2) +'.'+
                                                                            SUBSTRING(ORDERTIME,7,3)   ";
            _OrderReply.Columns["TRADEDATE_DISPLAY"].Expression = @"SUBSTRING(TRADEDATE,1,4) +'/' +SUBSTRING(TRADEDATE,5,2) +'/'+
                                                                        SUBSTRING(TRADEDATE,7,2)  ";

            _OrderReply.Columns["check"].DefaultValue = false;

            _OrderReply.Columns["checkflag"].DefaultValue = false;


            _OrderReply.Columns["AVGPRICE"].DefaultValue = 0;
            _OrderReply.Columns["UNDQTY"].DefaultValue = 0;

            _OrderReply.Columns["PRICE"].DefaultValue = 0;
            _OrderReply.Columns["STOPPRICE"].DefaultValue = 0;
            _OrderReply.Columns["ORDERQTY"].DefaultValue = 0;
            _OrderReply.Columns["MATCHQTY"].DefaultValue = 0;
            _OrderReply.Columns["NOMATCHQTY"].DefaultValue = 0;
            _OrderReply.Columns["DELQTY"].DefaultValue = 0;

            _OrderReply.Columns["ORDERKIND"].DefaultValue = "";
            _OrderReply.Columns["BEFOREUNDQTY"].DefaultValue = 0;
            _OrderReply.Columns["BEFOREPRICE"].DefaultValue = 0;
            _OrderReply.Columns["BEFORESTOPPRICE"].DefaultValue = 0;
            _OrderReply.Columns["BEFOREORDERQTY"].DefaultValue = 0;
            _OrderReply.Columns["BEFOREMATCHQTY"].DefaultValue = 0;
            _OrderReply.Columns["BEFORENOMATCHQTY"].DefaultValue = 0;
            _OrderReply.Columns["BEFOREDELQTY"].DefaultValue = 0;



            _OrderReply.Columns["SEQ"].DefaultValue = "";
            _OrderReply.Columns["BROKERID"].DefaultValue = "";
            _OrderReply.Columns["ORDERNO"].DefaultValue = "";
            _OrderReply.Columns["CLORDID"].DefaultValue = "";
            _OrderReply.Columns["TARGETID"].DefaultValue = "";
            _OrderReply.Columns["ACCOUNT"].DefaultValue = "";

            _OrderReply.Columns["ORDERID"].DefaultValue = "";

            _OrderReply.CaseSensitive = true;

            DataColumn[] dcPrimaryKey = {   _OrderReply.Columns["SEQ"] 
                                            ,_OrderReply.Columns["BROKERID"]
                                          ,_OrderReply.Columns["ORDERNO"]
                                          ,_OrderReply.Columns["CLORDID"]
                                           ,_OrderReply.Columns["ORDERID"]
                                        };
            _OrderReply.PrimaryKey = dcPrimaryKey;

            _ReplyMain = _OrderReply.Clone();

            _ReplyDetail = _OrderReply.Clone();

        }

        public void SetOrderStrategyData(ReplyUIObject ee, string ADVANCED_TEXT)
        {
            //策略單沒有網路單號，只有SEQ 
            DataRow dr = null;
            string seq = ee.SEQ;
            string CLORDID = ee.CLORDID;
            lock (_locker)
            {

                if (ee.EXECTYPE == "0")
                {
                    dr = _OrderReply.NewRow();
                    dr["TRADEDATE"] = ee.TRADEDATE;
                    dr["ORDERNO"] = ee.ORDERNO;
                    dr["ORDERTIME"] = ee.ORDERTIME;
                    dr["BROKERID"] = ee.BROKERID;
                    dr["INVESTORACNO"] = ee.INVESTORACNO;
                    dr["SUBACT"] = ee.SUBACT;
                    dr["BS"] = ee.BS;
                    dr["PRODUCTKIND"] = ee.PRODUCTKIND;
                    dr["SECURITYEXCHANGE"] = ee.SECURITYEXCHANGE;
                    dr["SECURITYTYPE1"] = ee.SECURITYTYPE1;
                    dr["SYMBOL1"] = ee.SYMBOL1;
                    dr["MATURITYMONTHYEAR1"] = ee.MATURITYMONTHYEAR1;
                    dr["PUTORCALL1"] = ee.PUTORCALL1;
                    dr["STRIKEPRICE1"] = ee.STRIKEPRICE1;
                    dr["SIDE1"] = ee.SIDE1;
                    dr["SECURITYTYPE2"] = ee.SECURITYTYPE2;
                    dr["SYMBOL2"] = ee.SYMBOL2;
                    dr["MATURITYMONTHYEAR2"] = ee.MATURITYMONTHYEAR2;
                    dr["PUTORCALL2"] = ee.PUTORCALL2;
                    dr["STRIKEPRICE2"] = ee.STRIKEPRICE2;
                    dr["SIDE2"] = ee.SIDE2;
                    dr["PRICE"] = ee.PRICE;
                    dr["STOPPRICE"] = ee.STOPPRICE;
                    dr["ORDERQTY"] = ee.ORDERQTY;
                    dr["MATCHQTY"] = ee.MATCHQTY;
                    dr["NOMATCHQTY"] = ee.NOMATCHQTY;
                    dr["DELQTY"] = ee.DELQTY;
                    dr["STATUSCODE"] = ee.STATUSCODE;
                    dr["ORDERSTATUS"] = ee.ORDERSTATUS;

                    dr["OPENCLOSE"] = ee.OPENCLOSE;
                    dr["TIMEINFORCE"] = ee.TIMEINFORCE;
                    dr["ORDERTYPE"] = ee.ORDERTYPE;
                    dr["EXPIREDATE"] = ee.EXPIREDATE;
                    dr["DTRADE"] = ee.DTRADE;
                    dr["MDATE"] = ee.MDATE;
                    dr["SEQ"] = ee.SEQ;
                    dr["SEQ_AD"] = ee.SEQ;
                    dr["SOURCECODE"] = ee.SOURCECODE;
                    dr["IP"] = ee.IP;
                    dr["ADVANCED"] = ADVANCED_TEXT.Split('|')[0];
                    dr["ADVANCED_TEXT"] = ADVANCED_TEXT;
                    dr["ORDERKIND"] = ee.ORDERKIND;
                    dr["KEEPDATA"] = ee.KEEPDATA;

                    dr["ORDERTAG"] = ee.ORDERTAG;
                    dr["AE"] = ee.AE;
                    dr["time"] = decimal.Parse(DateTime.Now.ToString("yyyyMMddHHmmssfff"));
                    _OrderReply.Rows.Add(dr);

                    if (seq.Trim().Length > 0)
                    {
                        _SeqData[seq] = dr;
                        List<DataRow> d = new List<DataRow>();
                        d.Add(dr);

                        tmpSEQ = ee.PSEQ;
                        _StrategySeqData[seq] = d;
                    }
                }
            }
        }

        public void SetReplyStrategyData(ReplyUIObject ee, string ADVANCED_TEXT)
        {
            //策略單沒有網路單號，只有SEQ 
            DataRow dr = null;
            string seq = ee.SEQ;
            string CLORDID = ee.CLORDID;
            lock (_locker)
            {
                if (_SeqData.TryGetValue(seq, out dr))
                {
                    dr["STATUSCODE"] = ee.STATUSCODE;
                    dr["ORDERSTATUS"] = ee.ORDERSTATUS;
                    if (ee.EXECTYPE == "0")
                    {
                        dr["TRADEDATE"] = ee.TRADEDATE;
                        dr["ORDERTIME"] = ee.ORDERTIME;//策略單委託時間不用更新
                        dr["UNDQTY"] = ee.NOMATCHQTY;//策略單的NOMATCHQTY為UNDQTY
                        dr["STATUSCODE"] = "0010";
                    }
                    else if (ee.EXECTYPE == "4")
                    {
                        dr["ParentCancel"] = true;
                        dr["UNDQTY"] = 0;
                    }

                    dr["PRICE"] = ee.PRICE;

                    dr["time"] = decimal.Parse(ee.TRADEDATE + ee.ORDERTIME);
                    dr["KEEPDATA"] = ee.KEEPDATA;
                    dr["CLORDID"] = CLORDID;
                    _StrategyKeepData[seq] = dr;



                    List<DataRow> list = null;
                    if (_StrategySeqData.TryGetValue(ee.PSEQ, out list))//洗母單與各子單最新時間GROUP
                    {


                        foreach (DataRow d in list)
                        {
                            d["time"] = dr["time"];
                        }

                        tmpSEQ = ee.PSEQ;

                    }
                }
                else
                {
                    if (ee.EXECTYPE == "0")
                    {
                        dr = _OrderReply.NewRow();
                        dr["TRADEDATE"] = ee.TRADEDATE;
                        dr["ORDERNO"] = ee.ORDERNO;
                        dr["ORDERTIME"] = ee.ORDERTIME;
                        dr["BROKERID"] = ee.BROKERID;
                        dr["INVESTORACNO"] = ee.INVESTORACNO;
                        dr["SUBACT"] = ee.SUBACT;
                        dr["BS"] = ee.BS;
                        dr["PRODUCTKIND"] = ee.PRODUCTKIND;
                        dr["SECURITYEXCHANGE"] = ee.SECURITYEXCHANGE;
                        dr["SECURITYTYPE1"] = ee.SECURITYTYPE1;
                        dr["SYMBOL1"] = ee.SYMBOL1;
                        dr["MATURITYMONTHYEAR1"] = ee.MATURITYMONTHYEAR1;
                        dr["PUTORCALL1"] = ee.PUTORCALL1;
                        dr["STRIKEPRICE1"] = ee.STRIKEPRICE1;
                        dr["SIDE1"] = ee.SIDE1;
                        dr["SECURITYTYPE2"] = ee.SECURITYTYPE2;
                        dr["SYMBOL2"] = ee.SYMBOL2;
                        dr["MATURITYMONTHYEAR2"] = ee.MATURITYMONTHYEAR2;
                        dr["PUTORCALL2"] = ee.PUTORCALL2;
                        dr["STRIKEPRICE2"] = ee.STRIKEPRICE2;
                        dr["SIDE2"] = ee.SIDE2;
                        dr["PRICE"] = ee.PRICE;
                        dr["STOPPRICE"] = ee.STOPPRICE;
                        dr["ORDERQTY"] = ee.ORDERQTY;
                        dr["MATCHQTY"] = ee.MATCHQTY;
                        dr["NOMATCHQTY"] = 0;
                        dr["UNDQTY"] = ee.NOMATCHQTY;//策略單的NOMATCHQTY為UNDQTY
                        dr["DELQTY"] = ee.DELQTY;
                        dr["STATUSCODE"] = ee.STATUSCODE;
                        dr["ORDERSTATUS"] = ee.ORDERSTATUS;

                        dr["OPENCLOSE"] = ee.OPENCLOSE;
                        dr["TIMEINFORCE"] = ee.TIMEINFORCE;
                        dr["ORDERTYPE"] = ee.ORDERTYPE;
                        dr["EXPIREDATE"] = ee.EXPIREDATE;
                        dr["DTRADE"] = ee.DTRADE;
                        dr["MDATE"] = ee.MDATE;
                        dr["SEQ"] = ee.SEQ;
                        dr["SEQ_AD"] = ee.SEQ;
                        dr["SOURCECODE"] = ee.SOURCECODE;
                        dr["IP"] = ee.IP;
                        dr["ADVANCED"] = ADVANCED_TEXT.Split('|')[0];
                        dr["ADVANCED_TEXT"] = ADVANCED_TEXT;
                        dr["CLORDID"] = CLORDID;
                        dr["time"] = decimal.Parse(ee.TRADEDATE + ee.ORDERTIME);
                        dr["ORDERKIND"] = ee.ORDERKIND;
                        dr["KEEPDATA"] = ee.KEEPDATA;
                        dr["ORDERTAG"] = ee.ORDERTAG;
                        dr["AE"] = ee.AE;
                        _OrderReply.Rows.Add(dr);

                        if (seq.Trim().Length > 0)
                        {
                            _SeqData[seq] = dr;
                            List<DataRow> d = new List<DataRow>();
                            d.Add(dr);
                            tmpSEQ = ee.PSEQ;
                            _StrategySeqData[seq] = d;
                        }

                        _StrategyKeepData[seq] = dr;
                    }
                }
            }
        }

        public void SetOrderData(ReplyUIObject ee)
        {
            DataRow dr = null;
            string seq = ee.SEQ;
            string CLORDID = ee.CLORDID;
            lock (_locker)
            {
                if (ee.EXECTYPE == "0")
                {
                    dr = _OrderReply.NewRow();
                    dr["TRADEDATE"] = ee.TRADEDATE;
                    dr["ORDERNO"] = ee.ORDERNO;
                    dr["ORDERTIME"] = ee.ORDERTIME;
                    dr["BROKERID"] = ee.BROKERID;
                    dr["INVESTORACNO"] = ee.INVESTORACNO;
                    dr["SUBACT"] = ee.SUBACT;
                    dr["BS"] = ee.BS;
                    dr["PRODUCTKIND"] = ee.PRODUCTKIND;
                    dr["SECURITYEXCHANGE"] = ee.SECURITYEXCHANGE;
                    dr["SECURITYTYPE1"] = ee.SECURITYTYPE1;
                    dr["SYMBOL1"] = ee.SYMBOL1;
                    dr["MATURITYMONTHYEAR1"] = ee.MATURITYMONTHYEAR1;
                    dr["PUTORCALL1"] = ee.PUTORCALL1;
                    dr["STRIKEPRICE1"] = ee.STRIKEPRICE1;
                    dr["SIDE1"] = ee.SIDE1;
                    dr["SECURITYTYPE2"] = ee.SECURITYTYPE2;
                    dr["SYMBOL2"] = ee.SYMBOL2;
                    dr["MATURITYMONTHYEAR2"] = ee.MATURITYMONTHYEAR2;
                    dr["PUTORCALL2"] = ee.PUTORCALL2;
                    dr["STRIKEPRICE2"] = ee.STRIKEPRICE2;
                    dr["SIDE2"] = ee.SIDE2;
                    dr["PRICE"] = ee.PRICE;
                    dr["STOPPRICE"] = ee.STOPPRICE;
                    dr["ORDERQTY"] = ee.ORDERQTY;
                    dr["MATCHQTY"] = ee.MATCHQTY;
                    dr["NOMATCHQTY"] = ee.NOMATCHQTY;
                    dr["DELQTY"] = ee.DELQTY;
                    dr["STATUSCODE"] = ee.STATUSCODE;
                    dr["ORDERSTATUS"] = ee.ORDERSTATUS;
                    dr["CLORDID"] = ee.CLORDID;
                    dr["OPENCLOSE"] = ee.OPENCLOSE;
                    dr["TIMEINFORCE"] = ee.TIMEINFORCE;
                    dr["ORDERTYPE"] = ee.ORDERTYPE;
                    dr["EXPIREDATE"] = ee.EXPIREDATE;
                    dr["DTRADE"] = ee.DTRADE;
                    dr["MDATE"] = ee.MDATE;
                    dr["SEQ"] = ee.SEQ;
                    dr["SOURCECODE"] = ee.SOURCECODE;
                    dr["IP"] = ee.IP;
                    dr["ORDERID"] = ee.ORDERID;
                    dr["TARGETID"] = ee.TARGETID;
                    dr["SEQ_AD"] = ee.PSEQ;
                    dr["ORDERKIND"] = ee.ORDERKIND;
                    dr["time"] = decimal.Parse(ee.TRADEDATE + ee.ORDERTIME);
                    dr["KEEPDATA"] = ee.KEEPDATA;
                    dr["ORDERTAG"] = ee.ORDERTAG;
                    dr["AE"] = ee.AE;
                    _OrderReply.Rows.Add(dr);

                    if (seq.Trim().Length > 0)
                        _SeqData[seq] = dr;
                    if (CLORDID.Trim().Length > 0)
                        _NetWorkidData[CLORDID] = dr;

                }
                else
                {
                    if (_SeqData.TryGetValue(seq, out dr))
                    {

                        dr["STATUSCODE"] = ee.STATUSCODE;
                        dr["ORDERSTATUS"] = ee.ORDERSTATUS;
                    }
                    else if (_NetWorkidData.TryGetValue(CLORDID, out dr))
                    {
                        dr["STATUSCODE"] = ee.STATUSCODE;
                        dr["ORDERSTATUS"] = ee.ORDERSTATUS;
                    }


                }
            }
        }

        string tmpSEQ = "";
        /// <summary>
        /// 
        /// </summary>
        /// <param name="ee"></param>
        /// <returns>回傳之前剩餘口數</returns>
        public DataRow SetReplyData(ReplyUIObject ee, MatchUIObject mee)
        {

            int beforeNOMATCHQTY = 0;
            DataRow dr = null;
            string seq = ee.SEQ;
            string CLORDID = ee.CLORDID;
            bool NewFlag = false;
            lock (_locker)
            {
                if (_SeqData.TryGetValue(seq, out dr))
                {

                }
                else if (_NetWorkidData.TryGetValue(CLORDID, out dr))
                {

                }
                else
                {
                    NewFlag = true;
                    dr = _OrderReply.NewRow();
                }
                //遇到複式單 猜成單子腳的單子不算
                if (mee != null)
                {
                    if (!NewFlag) //要接正常回報才可以走這段邏輯
                    {
                        if (dr["PRODUCTKIND"].ToString() != mee.PRODUCTKIND) return null;
                    }
                    else
                    {

                    }
                }



                if (ee.EXECTYPE != "0")
                {
                    dr["BEFOREPRICE"] = dr["PRICE"];
                    dr["BEFORESTOPPRICE"] = dr["STOPPRICE"];
                    dr["BEFOREORDERQTY"] = dr["ORDERQTY"];
                    dr["BEFOREMATCHQTY"] = dr["MATCHQTY"];
                    dr["BEFORENOMATCHQTY"] = dr["NOMATCHQTY"];
                    dr["BEFOREDELQTY"] = dr["DELQTY"];
                }




                dr["TRADEDATE"] = ee.TRADEDATE;
                dr["ORDERNO"] = ee.ORDERNO;
                dr["ORDERTIME"] = ee.ORDERTIME;
                dr["BROKERID"] = ee.BROKERID;
                dr["INVESTORACNO"] = ee.INVESTORACNO;
                dr["SUBACT"] = ee.SUBACT;
                dr["BS"] = ee.BS;
                dr["PRODUCTKIND"] = ee.PRODUCTKIND;
                dr["SECURITYEXCHANGE"] = ee.SECURITYEXCHANGE;
                dr["SECURITYTYPE1"] = ee.SECURITYTYPE1;
                dr["SYMBOL1"] = ee.SYMBOL1;
                dr["MATURITYMONTHYEAR1"] = ee.MATURITYMONTHYEAR1;
                dr["PUTORCALL1"] = ee.PUTORCALL1;
                dr["STRIKEPRICE1"] = ee.STRIKEPRICE1;
                dr["SIDE1"] = ee.SIDE1;
                dr["SECURITYTYPE2"] = ee.SECURITYTYPE2;
                dr["SYMBOL2"] = ee.SYMBOL2;
                dr["MATURITYMONTHYEAR2"] = ee.MATURITYMONTHYEAR2;
                dr["PUTORCALL2"] = ee.PUTORCALL2;
                dr["STRIKEPRICE2"] = ee.STRIKEPRICE2;
                dr["SIDE2"] = ee.SIDE2;
                dr["PRICE"] = ee.PRICE;
                dr["STOPPRICE"] = ee.STOPPRICE;
                dr["ORDERQTY"] = ee.ORDERQTY;
                dr["MATCHQTY"] = ee.MATCHQTY;
                dr["NOMATCHQTY"] = ee.NOMATCHQTY;
                dr["DELQTY"] = ee.DELQTY;
                dr["STATUSCODE"] = ee.STATUSCODE;
                dr["ORDERSTATUS"] = ee.ORDERSTATUS;
                dr["CLORDID"] = ee.CLORDID;
                dr["OPENCLOSE"] = ee.OPENCLOSE;
                dr["TIMEINFORCE"] = ee.TIMEINFORCE;
                dr["ORDERTYPE"] = ee.ORDERTYPE;
                dr["EXPIREDATE"] = ee.EXPIREDATE;
                dr["DTRADE"] = ee.DTRADE;
                dr["MDATE"] = ee.MDATE;
                dr["SEQ"] = ee.SEQ;
                dr["SOURCECODE"] = ee.SOURCECODE;
                dr["IP"] = ee.IP;
                dr["ORDERID"] = ee.ORDERID;
                dr["TARGETID"] = ee.TARGETID;
                dr["ACCOUNT"] = ee.ACCOUNT;
                dr["ORDERKIND"] = ee.ORDERKIND;
                dr["SEQ_AD"] = ee.PSEQ;
                if (ee.PSEQ.Length > 0)
                {
                }
                else
                    dr["SEQ_AD"] = ee.SEQ;

                dr["time"] = decimal.Parse(ee.TRADEDATE + ee.ORDERTIME);
                dr["KEEPDATA"] = ee.KEEPDATA;
                dr["ORDERTAG"] = ee.ORDERTAG;
                dr["AE"] = ee.AE;

                if (_StrategyDataForcheck.ContainsKey(ee.PSEQ))
                {
                    dr["check"] = true;
                    string key = ee.BROKERID.Trim() + ee.INVESTORACNO.Trim() + ee.SUBACT.Trim() + ee.ORDERNO.Trim();
                    frmMain.mobjDataAgent.objTradeStringHandle.MatchReplyProvider.AddStrategySeq(key);
                    frmMain.mobjDataAgent.objTradeStringHandle.MatchTotalProvider.AddCheck(ee.ORDERNO.Trim());
                }

                DataRow sd = null;


                if (_StrategyKeepData.TryGetValue(ee.PSEQ, out sd))//
                {



                    switch (ee.EXECTYPE)
                    {
                        case "0"://new
                            sd["UNDQTY"] = (int)sd["UNDQTY"] - ee.NOMATCHQTY;
                            if ((int)sd["UNDQTY"] < 0) sd["UNDQTY"] = 0;//避免變成負
                            sd["NOMATCHQTY"] = (int)sd["NOMATCHQTY"] + ee.NOMATCHQTY;

                            break;
                        case "4":

                            sd["NOMATCHQTY"] = (int)sd["NOMATCHQTY"] - ee.DELQTY;
                            if ((int)sd["NOMATCHQTY"] < 0) sd["NOMATCHQTY"] = 0;//避免變成負

                            sd["DELQTY"] = (int)sd["DELQTY"] + ee.DELQTY;
                            break;
                        case "5"://replace  刪單回報策略單不需要扣
                            //sd["NOMATCHQTY"] = (int)sd["NOMATCHQTY"] - (int)dr["ORDERQTY"];
                            //sd["DELQTY"] = (int)sd["DELQTY"] + ee.DELQTY;
                            break;
                        case "1"://fill
                        case "2":
                            if (mee.EXECTRANSTYPE == "0")
                            {
                                if (mee != null)
                                {
                                    sd["AVGPRICE"] = (((decimal)sd["AVGPRICE"] * (int)sd["MATCHQTY"] + mee.MATCHQTY * mee.MATCHPRICE)) / (mee.MATCHQTY + (int)sd["MATCHQTY"]);
                                    sd["NOMATCHQTY"] = (int)sd["NOMATCHQTY"] - mee.MATCHQTY; ;
                                    if ((int)sd["NOMATCHQTY"] < 0) sd["NOMATCHQTY"] = 0;//避免變成負
                                    sd["MATCHQTY"] = (int)sd["MATCHQTY"] + mee.MATCHQTY; ;
                                }
                            }
                            else if (mee.EXECTRANSTYPE == "1" || mee.EXECTRANSTYPE == "2")
                            {
                                DataRow[] drs = frmMain.mobjDataAgent.objTradeStringHandle.MatchReplyProvider.MatchDetailReply.Select(@"TRADEDATE='" + ee.TRADEDATE + "' and ORDERID='" + ee.ORDERID + "' and EXECID='" + mee.EXECREFID + "'  ");
                                if (drs.Length > 0)
                                {
                                    DataRow ddr = drs[0];



                                    //當分母為零時不進入除法，直接給直
                                    if (((int)sd["MATCHQTY"] - (int)ddr["MATCHQTY"]) == 0)
                                    {
                                        sd["AVGPRICE"] = 0;
                                        sd["MATCHQTY"] = 0;

                                        sd["NOMATCHQTY"] = (int)sd["NOMATCHQTY"] + (int)ddr["MATCHQTY"]; ;

                                    }
                                    else
                                    {
                                        //現在成交均價與成交口數減掉該筆成交單子
                                        sd["AVGPRICE"] = (((decimal)sd["AVGPRICE"] * (int)sd["MATCHQTY"]) - (decimal)ddr["MATCHPRICE"] * (int)ddr["MATCHQTY"]) / ((int)sd["MATCHQTY"] - (int)ddr["MATCHQTY"]);
                                        sd["NOMATCHQTY"] = (int)sd["NOMATCHQTY"] + (int)ddr["MATCHQTY"]; ;
                                        sd["MATCHQTY"] = (int)dr["MATCHQTY"] - (int)ddr["MATCHQTY"];

                                    }
                                    if (ee.EXECTRANSTYPE == "2")
                                    {
                                        sd["AVGPRICE"] = (((decimal)sd["AVGPRICE"] * (int)sd["MATCHQTY"] + mee.MATCHQTY * mee.MATCHPRICE)) / ((int)sd["MATCHQTY"] + mee.MATCHQTY);
                                        sd["NOMATCHQTY"] = (int)sd["NOMATCHQTY"] - mee.MATCHQTY; ;
                                        sd["MATCHQTY"] = (int)sd["MATCHQTY"] + mee.MATCHQTY; ;
                                    }

                                }
                            }
                            break;

                        default:
                            if ((int)sd["UNDQTY"] > 0)//錯誤單出單
                                sd["UNDQTY"] = (int)sd["UNDQTY"] - ee.ORDERQTY;

                            break;
                    }

                    //執行前	T	Waiting	已經設定好條件送出，但還沒到起始時間(子單都還未開始執行)
                    //執行中	W	Working	開始執行後，但子單都未成交
                    //執行中	P	Working	開始執行後，有子單成交(只要有成交，不管是部分或全部，或子單是否都執行完)
                    //最終狀態	F	Filled	所有子單都執行完，且都成交
                    //最終狀態	C	Cancelled	開始執行後，從母單直接取消(不管各子單是什麼狀態)

                    if ((int)sd["MATCHQTY"] > 0)
                    {
                        if ((int)sd["ORDERQTY"] == (int)sd["MATCHQTY"])
                        {
                            sd["STATUSCODE"] = "0004";
                        }
                        else if ((int)sd["ORDERQTY"] > (int)sd["MATCHQTY"])
                        {
                            sd["STATUSCODE"] = "0003";
                        }
                    }
                    else if ((int)sd["MATCHQTY"] == 0)
                    {
                        if ((int)sd["ORDERQTY"] == (int)sd["UNDQTY"])
                        {
                            sd["STATUSCODE"] = "0010";
                        }
                        else if ((int)sd["ORDERQTY"] == (int)sd["NOMATCHQTY"])
                        {
                            sd["STATUSCODE"] = "0000";
                        }
                        else if ((int)sd["ORDERQTY"] == (int)sd["DELQTY"])
                        {
                            sd["STATUSCODE"] = "0002";
                        }
                        else if ((int)sd["NOMATCHQTY"] > 0)
                        {

                            sd["STATUSCODE"] = "0000";
                        }
                        else if ((int)sd["DELQTY"] > 0)
                        {
                            sd["STATUSCODE"] = "0002";
                        }
                        else
                        {
                            sd["STATUSCODE"] = "E";
                        }
                    }
                    else
                        sd["STATUSCODE"] = "E";
                    if ((bool)sd["ParentCancel"])
                    {
                        sd["STATUSCODE"] = "0002";
                    }

                    // sd["UNDQTY"]
                    //     /sd["DELQTY"] 
                    //  sd["MATCHQTY"] 
                    //sd["NOMATCHQTY"]


                }

                if (mee != null)
                {
                    SetMatchReplyData(dr, mee);
                }


                if (NewFlag)
                    _OrderReply.Rows.Add(dr);
                if (seq.Trim().Length > 0)
                    _SeqData[seq] = dr;
                if (CLORDID.Trim().Length > 0)
                    _NetWorkidData[CLORDID] = dr;


                return dr;
            }

        }

        public void SetMatchReplyData(DataRow dr, MatchUIObject ee)
        {
            //if (   dr["PRODUCTKIND"].ToString()!= ee.PRODUCTKIND ) return;
            if (ee.EXECTRANSTYPE == "0")
            {
                dr["AVGPRICE"] = (((decimal)dr["AVGPRICE"] * (int)dr["BEFOREMATCHQTY"] + ee.MATCHQTY * ee.MATCHPRICE)) / ((int)dr["BEFOREMATCHQTY"] + ee.MATCHQTY);
            }

            else if (ee.EXECTRANSTYPE == "1" || ee.EXECTRANSTYPE == "2")
            {

                DataRow[] drs = frmMain.mobjDataAgent.objTradeStringHandle.MatchReplyProvider.MatchDetailReply.Select(@"TRADEDATE='" + ee.TRADEDATE + "' and ORDERID='" + ee.ORDERID + "' and EXECID='" + ee.EXECREFID + "'  ");


                if (drs.Length > 0)
                {
                    DataRow ddr = drs[0];
                    //當分母為零時不進入除法，直接給直
                    if (((int)dr["BEFOREMATCHQTY"] - (int)ddr["MATCHQTY"]) == 0)
                    {
                        dr["AVGPRICE"] = 0;
                        dr["BEFOREMATCHQTY"] = 0;
                    }
                    else
                    {
                        //現在成交均價與成交口數減掉該筆成交單子
                        dr["AVGPRICE"] = (((decimal)dr["AVGPRICE"] * (int)dr["BEFOREMATCHQTY"]) - (decimal)ddr["MATCHPRICE"] * (int)ddr["MATCHQTY"]) / ((int)dr["BEFOREMATCHQTY"] - (int)ddr["MATCHQTY"]);
                        dr["BEFOREMATCHQTY"] = (int)dr["BEFOREMATCHQTY"] - (int)ddr["MATCHQTY"];
                    }
                    if (ee.EXECTRANSTYPE == "2")
                        dr["AVGPRICE"] = (((decimal)dr["AVGPRICE"] * (int)dr["BEFOREMATCHQTY"] + ee.MATCHQTY * ee.MATCHPRICE)) / ((int)dr["BEFOREMATCHQTY"] + ee.MATCHQTY);

                }
            }

        }


        public DataRow SetReplyDataForMain(ReplyUIObject ee, MatchUIObject mee)
        {

            int beforeNOMATCHQTY = 0;
            DataRow dr = null;
            string seq = ee.SEQ;
            string CLORDID = ee.CLORDID;
            bool NewFlag = false;
            lock (_locker)
            {
                if (_SeqDataForReplyMain.TryGetValue(seq, out dr))
                {

                }
                else if (_NetWorkidDataForReplyMain.TryGetValue(CLORDID, out dr))
                {

                }
                else
                {
                    NewFlag = true;
                    dr = _ReplyMain.NewRow();
                }
                //遇到複式單 猜成單子腳的單子不算
                if (mee != null)
                {

                    if (!NewFlag) //要接正常回報才可以走這段邏輯
                    {
                        if (dr["PRODUCTKIND"].ToString() != mee.PRODUCTKIND) return null;
                    }
                    else
                    {

                    }
                }

                if (ee.EXECTYPE != "0")
                {
                    dr["BEFOREPRICE"] = dr["PRICE"];
                    dr["BEFORESTOPPRICE"] = dr["STOPPRICE"];
                    dr["BEFOREORDERQTY"] = dr["ORDERQTY"];
                    dr["BEFOREMATCHQTY"] = dr["MATCHQTY"];
                    dr["BEFORENOMATCHQTY"] = dr["NOMATCHQTY"];
                    dr["BEFOREDELQTY"] = dr["DELQTY"];
                }




                dr["TRADEDATE"] = ee.TRADEDATE;
                dr["ORDERNO"] = ee.ORDERNO;
                dr["ORDERTIME"] = ee.ORDERTIME;
                dr["BROKERID"] = ee.BROKERID;
                dr["INVESTORACNO"] = ee.INVESTORACNO;
                dr["SUBACT"] = ee.SUBACT;
                dr["BS"] = ee.BS;
                dr["PRODUCTKIND"] = ee.PRODUCTKIND;
                dr["SECURITYEXCHANGE"] = ee.SECURITYEXCHANGE;
                dr["SECURITYTYPE1"] = ee.SECURITYTYPE1;
                dr["SYMBOL1"] = ee.SYMBOL1;
                dr["MATURITYMONTHYEAR1"] = ee.MATURITYMONTHYEAR1;
                dr["PUTORCALL1"] = ee.PUTORCALL1;
                dr["STRIKEPRICE1"] = ee.STRIKEPRICE1;
                dr["SIDE1"] = ee.SIDE1;
                dr["SECURITYTYPE2"] = ee.SECURITYTYPE2;
                dr["SYMBOL2"] = ee.SYMBOL2;
                dr["MATURITYMONTHYEAR2"] = ee.MATURITYMONTHYEAR2;
                dr["PUTORCALL2"] = ee.PUTORCALL2;
                dr["STRIKEPRICE2"] = ee.STRIKEPRICE2;
                dr["SIDE2"] = ee.SIDE2;
                dr["PRICE"] = ee.PRICE;
                dr["STOPPRICE"] = ee.STOPPRICE;
                dr["ORDERQTY"] = ee.ORDERQTY;
                dr["MATCHQTY"] = ee.MATCHQTY;
                dr["NOMATCHQTY"] = ee.NOMATCHQTY;
                dr["DELQTY"] = ee.DELQTY;
                dr["STATUSCODE"] = ee.STATUSCODE;
                dr["ORDERSTATUS"] = ee.ORDERSTATUS;
                dr["CLORDID"] = ee.CLORDID;
                dr["OPENCLOSE"] = ee.OPENCLOSE;
                dr["TIMEINFORCE"] = ee.TIMEINFORCE;
                dr["ORDERTYPE"] = ee.ORDERTYPE;
                dr["EXPIREDATE"] = ee.EXPIREDATE;
                dr["DTRADE"] = ee.DTRADE;
                dr["MDATE"] = ee.MDATE;
                dr["SEQ"] = ee.SEQ;
                dr["SOURCECODE"] = ee.SOURCECODE;
                dr["IP"] = ee.IP;
                dr["ORDERID"] = ee.ORDERID;
                dr["TARGETID"] = ee.TARGETID;
                dr["ACCOUNT"] = ee.ACCOUNT;
                dr["ORDERKIND"] = ee.ORDERKIND;
                dr["SEQ_AD"] = ee.PSEQ;
                if (ee.PSEQ.Length > 0)
                {
                }
                else
                    dr["SEQ_AD"] = ee.SEQ;

                dr["time"] = decimal.Parse(ee.TRADEDATE + ee.ORDERTIME);
                dr["KEEPDATA"] = ee.KEEPDATA;
                dr["ORDERTAG"] = ee.ORDERTAG;
                dr["AE"] = ee.AE;

                DataRow sd = null;


                if (_StrategyKeepDataForReplyMain.TryGetValue(ee.PSEQ, out sd))//
                {



                    switch (ee.EXECTYPE)
                    {
                        case "0"://new
                            sd["UNDQTY"] = (int)sd["UNDQTY"] - ee.NOMATCHQTY;
                            if ((int)sd["UNDQTY"] < 0) sd["UNDQTY"] = 0;//避免變成負
                            sd["NOMATCHQTY"] = (int)sd["NOMATCHQTY"] + ee.NOMATCHQTY;

                            break;
                        case "4":

                            sd["NOMATCHQTY"] = (int)sd["NOMATCHQTY"] - ee.DELQTY;
                            if ((int)sd["NOMATCHQTY"] < 0) sd["NOMATCHQTY"] = 0;//避免變成負
                            sd["DELQTY"] = (int)sd["DELQTY"] + ee.DELQTY;
                            break;
                        case "5"://replace  刪單回報策略單不需要扣
                            //sd["NOMATCHQTY"] = (int)sd["NOMATCHQTY"] - (int)dr["ORDERQTY"];
                            //sd["DELQTY"] = (int)sd["DELQTY"] + ee.DELQTY;
                            break;
                        case "1"://fill
                        case "2":
                            if (mee.EXECTRANSTYPE == "0")
                            {
                                if (mee != null)
                                {
                                    sd["AVGPRICE"] = (((decimal)sd["AVGPRICE"] * (int)sd["MATCHQTY"] + mee.MATCHQTY * mee.MATCHPRICE)) / (mee.MATCHQTY + (int)sd["MATCHQTY"]);
                                    sd["NOMATCHQTY"] = (int)sd["NOMATCHQTY"] - mee.MATCHQTY; ;
                                    if ((int)sd["NOMATCHQTY"] < 0) sd["NOMATCHQTY"] = 0;//避免變成負
                                    sd["MATCHQTY"] = (int)sd["MATCHQTY"] + mee.MATCHQTY; ;
                                }
                            }
                            else if (mee.EXECTRANSTYPE == "1" || mee.EXECTRANSTYPE == "2")
                            {
                                DataRow[] drs = frmMain.mobjDataAgent.objTradeStringHandle.MatchReplyProvider.MatchDetailReply.Select(@"TRADEDATE='" + ee.TRADEDATE + "' and ORDERID='" + ee.ORDERID + "' and EXECID='" + mee.EXECREFID + "'  ");
                                if (drs.Length > 0)
                                {
                                    DataRow ddr = drs[0];



                                    //當分母為零時不進入除法，直接給直
                                    if (((int)sd["MATCHQTY"] - (int)ddr["MATCHQTY"]) == 0)
                                    {
                                        sd["AVGPRICE"] = 0;
                                        sd["MATCHQTY"] = 0;

                                        sd["NOMATCHQTY"] = (int)sd["NOMATCHQTY"] + (int)ddr["MATCHQTY"]; ;

                                    }
                                    else
                                    {
                                        //現在成交均價與成交口數減掉該筆成交單子
                                        sd["AVGPRICE"] = (((decimal)sd["AVGPRICE"] * (int)sd["MATCHQTY"]) - (decimal)ddr["MATCHPRICE"] * (int)ddr["MATCHQTY"]) / ((int)sd["MATCHQTY"] - (int)ddr["MATCHQTY"]);
                                        sd["NOMATCHQTY"] = (int)sd["NOMATCHQTY"] + (int)ddr["MATCHQTY"]; ;
                                        sd["MATCHQTY"] = (int)dr["MATCHQTY"] - (int)ddr["MATCHQTY"];

                                    }
                                    if (ee.EXECTRANSTYPE == "2")
                                    {
                                        sd["AVGPRICE"] = (((decimal)sd["AVGPRICE"] * (int)sd["MATCHQTY"] + mee.MATCHQTY * mee.MATCHPRICE)) / ((int)sd["MATCHQTY"] + mee.MATCHQTY);
                                        sd["NOMATCHQTY"] = (int)sd["NOMATCHQTY"] - mee.MATCHQTY; ;
                                        sd["MATCHQTY"] = (int)sd["MATCHQTY"] + mee.MATCHQTY; ;
                                    }

                                }
                            }
                            break;

                        default:
                            if ((int)sd["UNDQTY"] > 0)//錯誤單出單
                                sd["UNDQTY"] = (int)sd["UNDQTY"] - ee.ORDERQTY;

                            break;
                    }

                    //執行前	T	Waiting	已經設定好條件送出，但還沒到起始時間(子單都還未開始執行)
                    //執行中	W	Working	開始執行後，但子單都未成交
                    //執行中	P	Working	開始執行後，有子單成交(只要有成交，不管是部分或全部，或子單是否都執行完)
                    //最終狀態	F	Filled	所有子單都執行完，且都成交
                    //最終狀態	C	Cancelled	開始執行後，從母單直接取消(不管各子單是什麼狀態)

                    if ((int)sd["MATCHQTY"] > 0)
                    {
                        if ((int)sd["ORDERQTY"] == (int)sd["MATCHQTY"])
                        {
                            sd["STATUSCODE"] = "0004";
                        }
                        else if ((int)sd["ORDERQTY"] > (int)sd["MATCHQTY"])
                        {
                            sd["STATUSCODE"] = "0003";
                        }
                    }
                    else if ((int)sd["MATCHQTY"] == 0)
                    {
                        if ((int)sd["ORDERQTY"] == (int)sd["UNDQTY"])
                        {
                            sd["STATUSCODE"] = "0010";
                        }
                        else if ((int)sd["ORDERQTY"] == (int)sd["NOMATCHQTY"])
                        {
                            sd["STATUSCODE"] = "0000";
                        }
                        else if ((int)sd["ORDERQTY"] == (int)sd["DELQTY"])
                        {
                            sd["STATUSCODE"] = "0002";
                        }
                        else if ((int)sd["NOMATCHQTY"] > 0)
                        {

                            sd["STATUSCODE"] = "0000";
                        }
                        else if ((int)sd["DELQTY"] > 0)
                        {
                            sd["STATUSCODE"] = "0002";
                        }
                        else
                        {
                            sd["STATUSCODE"] = "E";
                        }
                    }
                    else
                        sd["STATUSCODE"] = "E";
                    if ((bool)sd["ParentCancel"])
                    {
                        sd["STATUSCODE"] = "0002";
                    }

                    // sd["UNDQTY"]
                    //     /sd["DELQTY"] 
                    //  sd["MATCHQTY"] 
                    //sd["NOMATCHQTY"]


                }



                if (NewFlag)
                {
                    if (sd == null)
                        _ReplyMain.Rows.Add(dr);
                }
                if (seq.Trim().Length > 0)
                    _SeqDataForReplyMain[seq] = dr;
                if (CLORDID.Trim().Length > 0)
                    _NetWorkidDataForReplyMain[CLORDID] = dr;


                return dr;
            }

        }


        public void SetReplyStrategyDataForMain(ReplyUIObject ee, string ADVANCED_TEXT)
        {
            //策略單沒有網路單號，只有SEQ 
            DataRow dr = null;
            string seq = ee.SEQ;
            string CLORDID = ee.CLORDID;
            lock (_locker)
            {
                if (_SeqDataForReplyMain.TryGetValue(seq, out dr))
                {
                    dr["STATUSCODE"] = ee.STATUSCODE;
                    dr["ORDERSTATUS"] = ee.ORDERSTATUS;
                    if (ee.EXECTYPE == "0")
                    {
                        dr["TRADEDATE"] = ee.TRADEDATE;
                        dr["ORDERTIME"] = ee.ORDERTIME;//策略單委託時間不用更新
                        dr["UNDQTY"] = ee.NOMATCHQTY;//策略單的NOMATCHQTY為UNDQTY
                        dr["STATUSCODE"] = "0010";
                    }
                    else if (ee.EXECTYPE == "4")
                    {
                        dr["ParentCancel"] = true;
                        dr["UNDQTY"] = 0;
                    }

                    dr["PRICE"] = ee.PRICE;

                    dr["time"] = decimal.Parse(ee.TRADEDATE + ee.ORDERTIME);
                    dr["KEEPDATA"] = ee.KEEPDATA;
                    dr["CLORDID"] = CLORDID;
                    _StrategyKeepDataForReplyMain[seq] = dr;



                }
                else
                {
                    if (ee.EXECTYPE == "0")
                    {
                        dr = _ReplyMain.NewRow();
                        dr["TRADEDATE"] = ee.TRADEDATE;
                        dr["ORDERNO"] = ee.ORDERNO;
                        dr["ORDERTIME"] = ee.ORDERTIME;
                        dr["BROKERID"] = ee.BROKERID;
                        dr["INVESTORACNO"] = ee.INVESTORACNO;
                        dr["SUBACT"] = ee.SUBACT;
                        dr["BS"] = ee.BS;
                        dr["PRODUCTKIND"] = ee.PRODUCTKIND;
                        dr["SECURITYEXCHANGE"] = ee.SECURITYEXCHANGE;
                        dr["SECURITYTYPE1"] = ee.SECURITYTYPE1;
                        dr["SYMBOL1"] = ee.SYMBOL1;
                        dr["MATURITYMONTHYEAR1"] = ee.MATURITYMONTHYEAR1;
                        dr["PUTORCALL1"] = ee.PUTORCALL1;
                        dr["STRIKEPRICE1"] = ee.STRIKEPRICE1;
                        dr["SIDE1"] = ee.SIDE1;
                        dr["SECURITYTYPE2"] = ee.SECURITYTYPE2;
                        dr["SYMBOL2"] = ee.SYMBOL2;
                        dr["MATURITYMONTHYEAR2"] = ee.MATURITYMONTHYEAR2;
                        dr["PUTORCALL2"] = ee.PUTORCALL2;
                        dr["STRIKEPRICE2"] = ee.STRIKEPRICE2;
                        dr["SIDE2"] = ee.SIDE2;
                        dr["PRICE"] = ee.PRICE;
                        dr["STOPPRICE"] = ee.STOPPRICE;
                        dr["ORDERQTY"] = ee.ORDERQTY;
                        dr["MATCHQTY"] = ee.MATCHQTY;
                        dr["NOMATCHQTY"] = 0;
                        dr["UNDQTY"] = ee.NOMATCHQTY;//策略單的NOMATCHQTY為UNDQTY
                        dr["DELQTY"] = ee.DELQTY;
                        dr["STATUSCODE"] = ee.STATUSCODE;
                        dr["ORDERSTATUS"] = ee.ORDERSTATUS;

                        dr["OPENCLOSE"] = ee.OPENCLOSE;
                        dr["TIMEINFORCE"] = ee.TIMEINFORCE;
                        dr["ORDERTYPE"] = ee.ORDERTYPE;
                        dr["EXPIREDATE"] = ee.EXPIREDATE;
                        dr["DTRADE"] = ee.DTRADE;
                        dr["MDATE"] = ee.MDATE;
                        dr["SEQ"] = ee.SEQ;
                        dr["SEQ_AD"] = ee.SEQ;
                        dr["SOURCECODE"] = ee.SOURCECODE;
                        dr["IP"] = ee.IP;
                        dr["ADVANCED"] = ADVANCED_TEXT.Split('|')[0];
                        dr["ADVANCED_TEXT"] = ADVANCED_TEXT;
                        dr["CLORDID"] = CLORDID;
                        dr["time"] = decimal.Parse(ee.TRADEDATE + ee.ORDERTIME);
                        dr["ORDERKIND"] = ee.ORDERKIND;
                        dr["KEEPDATA"] = ee.KEEPDATA;
                        dr["ORDERTAG"] = ee.ORDERTAG;
                        dr["AE"] = ee.AE;
                        _ReplyMain.Rows.Add(dr);

                        if (seq.Trim().Length > 0)
                        {
                            _SeqDataForReplyMain[seq] = dr;

                        }

                        _StrategyKeepDataForReplyMain[seq] = dr;
                    }
                }
            }
        }


        public DataRow[] GetNoWorkData()
        {
            lock (_locker)
            {
                DataRow[] drs = _OrderReply.Select("NOMATCHQTY >0 AND  ORDERKIND <>'P'");
                return drs;
            }
        }
        public DataRow[] GetWorkData()
        {
            lock (_locker)
            {
                DataRow[] drs = _OrderReply.Select("NOMATCHQTY >0 or UNDQTY>0 ");
                return drs;
            }
        }
        public DataRow[] GetNoWorkDataByParent(string seq)
        {
            lock (_locker)
            {
                DataRow[] drs = _OrderReply.Select("NOMATCHQTY >0 AND  ORDERKIND <>'P' AND SEQ_AD='" + seq + "'");
                return drs;
            }
        }

        public static Int64 String2Int(String strValue)
        {
            System.Text.RegularExpressions.Regex regex =
                new System.Text.RegularExpressions.Regex(@"[^a-zA-Z0-9]");

            if (!regex.IsMatch(strValue))
            {
                Int64 intValue = 0;
                String strArr = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
                // 去除前端0
                for (int i = 0; i < strValue.Length; i++)
                {
                    if (strValue.Substring(i, 1) != "0")
                    {
                        strValue = strValue.Substring(i, strValue.Length - i);
                        break;
                    }
                }

                for (int i = 0; i < strValue.Length; i++)
                {
                    int intIndexOf = strArr.IndexOf(strValue.Substring(i, 1));
                    Int64 intBon = 0;
                    intBon = (strValue.Length - 1 - i);
                    intBon = (Int64)Math.Pow(strArr.Length, intBon);
                    intValue += intIndexOf * intBon;
                }
                return intValue;
            }
            else
            {
                return 0;
            }
        }
        public void AddStrategySeq(string seq)
        {
            lock (_locker)
            {
                _StrategyDataForcheck[seq] = seq;
            }
        }
        public void DelStrategySeq(string seq)
        {
            lock (_locker)
            {
                _StrategyDataForcheck.Remove(seq);
            }
        }
    }
}
