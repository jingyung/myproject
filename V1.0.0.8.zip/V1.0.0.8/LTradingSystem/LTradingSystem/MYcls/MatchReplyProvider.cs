﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
namespace VIPTradingSystem.MYcls
{
    public class MatchReplyProvider
    {
        public object _locker = new object();
        private Dictionary<string, List<DataRow>> _MatchData;
        private Dictionary<string, List<DataRow>> _TmpMatchData;


        private DataTable _TmpMatchDetailReply;

        public DataTable TmpMatchDetailReply
        {
            get { return _TmpMatchDetailReply; }
            set { _TmpMatchDetailReply = value; }
        }
        private DataTable _MatchDetailReply;

        public DataTable MatchDetailReply
        {
            get { return _MatchDetailReply; }
            set { _MatchDetailReply = value; }
        }
        public MatchReplyProvider()
        {
            initMatchDetail();
            _MatchData = new Dictionary<string, List<DataRow>>();

            _TmpMatchData = new Dictionary<string, List<DataRow>>();

        }
        ~MatchReplyProvider()
        {
            Dispose();
        }
        public void ClearData()
        {

            foreach (string key in _MatchData.Keys)
            {
                _MatchData[key].Clear();
            }
            _MatchData.Clear();
            _MatchDetailReply.Rows.Clear();
        }

        public void Dispose()
        {
            ClearData();
        }


        private void initMatchDetail()
        {
            _MatchDetailReply = new DataTable("MATCHDETAILREPLY");
            _MatchDetailReply.Columns.Add("TRADEDATE", typeof(string));
            _MatchDetailReply.Columns.Add("MATCHTIME", typeof(string));//成交時間
            _MatchDetailReply.Columns.Add("BROKERID", typeof(string));//期貨商代號
            _MatchDetailReply.Columns.Add("INVESTORACNO", typeof(string));//下單帳號
            _MatchDetailReply.Columns.Add("SUBACT", typeof(string));//客戶帳號
            _MatchDetailReply.Columns.Add("ORDERNO", typeof(string));//委託書號

            _MatchDetailReply.Columns.Add("PRODUCTKIND", typeof(string));//商品種類
            _MatchDetailReply.Columns.Add("BS", typeof(string));//買賣別
            _MatchDetailReply.Columns.Add("SECURITYEXCHANGE", typeof(string));

            _MatchDetailReply.Columns.Add("SECURITYTYPE1", typeof(string));
            _MatchDetailReply.Columns.Add("SYMBOL1", typeof(string));
            _MatchDetailReply.Columns.Add("MATURITYMONTHYEAR1", typeof(string));
            _MatchDetailReply.Columns.Add("PUTORCALL1", typeof(string));
            _MatchDetailReply.Columns.Add("STRIKEPRICE1", typeof(decimal));
            _MatchDetailReply.Columns.Add("SIDE1", typeof(string));
            _MatchDetailReply.Columns.Add("PRICE1", typeof(decimal));//成交價格

            _MatchDetailReply.Columns.Add("SECURITYTYPE2", typeof(string));
            _MatchDetailReply.Columns.Add("SYMBOL2", typeof(string));
            _MatchDetailReply.Columns.Add("MATURITYMONTHYEAR2", typeof(string));
            _MatchDetailReply.Columns.Add("PUTORCALL2", typeof(string));
            _MatchDetailReply.Columns.Add("STRIKEPRICE2", typeof(decimal));
            _MatchDetailReply.Columns.Add("SIDE2", typeof(string));
            _MatchDetailReply.Columns.Add("PRICE2", typeof(decimal));//成交價格

            _MatchDetailReply.Columns.Add("MATCHPRICE", typeof(decimal));//成交價格
            _MatchDetailReply.Columns.Add("MATCHQTY", typeof(int));//成交數量

            _MatchDetailReply.Columns.Add("CLORDID", typeof(string));//網路流水序號

            _MatchDetailReply.Columns.Add("OPENCLOSE", typeof(string));//新平倉碼

            _MatchDetailReply.Columns.Add("EXECID", typeof(string));//回報序號
            _MatchDetailReply.Columns.Add("MDATE", typeof(string));//

            _MatchDetailReply.Columns.Add("ORDERID", typeof(string));//回報序號

            _MatchDetailReply.Columns.Add("TARGETID", typeof(string));//回報序號
            _MatchDetailReply.Columns.Add("ACCOUNT", typeof(string));//

            _MatchDetailReply.Columns.Add("AE", typeof(string));// 
            _MatchDetailReply.Columns.Add("STATE", typeof(string));// 
            _MatchDetailReply.Columns.Add("ORDERTAG", typeof(string));// 
            _MatchDetailReply.Columns.Add("KEEPDATA", typeof(string));//已刪除數量
            _MatchDetailReply.Columns.Add("PSEQ", typeof(string)); //策略單 編號
            _MatchDetailReply.Columns.Add("product", typeof(string));
            _MatchDetailReply.Columns.Add("contract", typeof(string));
            _MatchDetailReply.Columns["product"].Expression = CommonFunction.ProductExpression;
            _MatchDetailReply.Columns["contract"].Expression = CommonFunction.ContractExpression;
            _MatchDetailReply.Columns.Add("MATCHTIME_DISPLAY", typeof(string));//成交時間

            _MatchDetailReply.Columns.Add("TRADEDATE_DISPLAY", typeof(string));
            _MatchDetailReply.Columns["MATCHTIME_DISPLAY"].Expression = @"SUBSTRING(MATCHTIME,1,2) +':' +SUBSTRING(MATCHTIME,3,2) +':'+
                                                                        SUBSTRING(MATCHTIME,5,2) +'.'+
                                                                            SUBSTRING(MATCHTIME,7,3)   ";
            _MatchDetailReply.Columns["TRADEDATE_DISPLAY"].Expression = @"SUBSTRING(TRADEDATE,1,4) +'/' +SUBSTRING(TRADEDATE,5,2) +'/'+
                                                                        SUBSTRING(TRADEDATE,7,2)  ";

            DataColumn[] dcPrimaryKey = { _MatchDetailReply.Columns["BROKERID"]
                                            , _MatchDetailReply.Columns["ORDERNO"]
                                            , _MatchDetailReply.Columns["EXECID"]
                                            , _MatchDetailReply.Columns["CLORDID"]
                                    , _MatchDetailReply.Columns["ORDERID"]
                                        };
            _MatchDetailReply.PrimaryKey = dcPrimaryKey;
            _MatchDetailReply.DefaultView.Sort = "MDATE desc";
            _MatchDetailReply.CaseSensitive = true;


            _TmpMatchDetailReply = _MatchDetailReply.Clone();
        }


        public void SetData(MatchUIObject ee)
        {
            DataRow dr = null;
            lock (_locker)
            {
                if (ee.EXECTRANSTYPE != "0")//0=new ,1=cancel ,2=correct
                {
                    DataRow[] drs = _MatchDetailReply.Select(@"TRADEDATE='" + ee.TRADEDATE + "' and ORDERID='" + ee.ORDERID + "' and EXECID='" + ee.EXECREFID + "'  ");
                    if (drs.Length > 0)
                    {
                        dr = drs[0];
                        MatchTotalItem Item = new MatchTotalItem();
                        Item.BROKERID = dr["BROKERID"].ToString();
                        Item.INVESTORACNO = dr["INVESTORACNO"].ToString();
                        Item.SUBACT = "";// SUBACT;
                        Item.SECURITYEXCHANGE = dr["SECURITYEXCHANGE"].ToString();
                        Item.SECURITYTYPE1 = dr["SECURITYTYPE1"].ToString();
                        Item.SYMBOL1 = dr["SYMBOL1"].ToString();
                        Item.MATURITYMONTHYEAR1 = dr["MATURITYMONTHYEAR1"].ToString();
                        Item.PUTORCALL1 = dr["PUTORCALL1"].ToString();
                        Item.STRIKEPRICE1 = decimal.Parse(dr["STRIKEPRICE1"].ToString());
                        Item.SIDE1 = dr["SIDE1"].ToString();
                        Item.SECURITYTYPE2 = dr["SECURITYTYPE2"].ToString();
                        Item.SYMBOL2 = dr["SYMBOL2"].ToString();
                        Item.MATURITYMONTHYEAR2 = dr["MATURITYMONTHYEAR2"].ToString();
                        Item.PUTORCALL2 = dr["PUTORCALL2"].ToString();
                        Item.STRIKEPRICE2 = decimal.Parse(dr["STRIKEPRICE2"].ToString());
                        Item.SIDE2 = dr["SIDE2"].ToString();
                        Item.PRODUCTKIND = dr["PRODUCTKIND"].ToString();

                        frmMain.mobjDataAgent.objTradeStringHandle.MatchTotalProvider.DelMatchQty(dr["ORDERNO"].ToString(), Item, dr["BS"].ToString()
                             , decimal.Parse(dr["MATCHPRICE"].ToString()), int.Parse(dr["MATCHQTY"].ToString()));


                        if (ee.EXECTRANSTYPE == "1")
                        {

                            dr.Delete();

                        }
                        else
                        {
                            dr.BeginEdit();
                            dr["TRADEDATE"] = ee.TRADEDATE;
                            dr["MATCHTIME"] = ee.MATCHTIME;
                            dr["BROKERID"] = ee.BROKERID;
                            dr["INVESTORACNO"] = ee.INVESTORACNO;
                            dr["SUBACT"] = ee.SUBACT;
                            dr["ORDERNO"] = ee.ORDERNO;
                            dr["PRODUCTKIND"] = ee.PRODUCTKIND;
                            dr["BS"] = ee.BS;
                            dr["SECURITYEXCHANGE"] = ee.SECURITYEXCHANGE;
                            dr["SECURITYTYPE1"] = ee.SECURITYTYPE1;
                            dr["SYMBOL1"] = ee.SYMBOL1;
                            dr["MATURITYMONTHYEAR1"] = ee.MATURITYMONTHYEAR1;
                            dr["PUTORCALL1"] = ee.PUTORCALL1;
                            dr["STRIKEPRICE1"] = ee.STRIKEPRICE1;
                            dr["SIDE1"] = ee.SIDE1;
                            dr["PRICE1"] = ee.PRICE1;
                            dr["SECURITYTYPE2"] = ee.SECURITYTYPE2;
                            dr["SYMBOL2"] = ee.SYMBOL2;
                            dr["MATURITYMONTHYEAR2"] = ee.MATURITYMONTHYEAR2;
                            dr["PUTORCALL2"] = ee.PUTORCALL2;
                            dr["STRIKEPRICE2"] = ee.STRIKEPRICE2;
                            dr["SIDE2"] = ee.SIDE2;
                            dr["PRICE2"] = ee.PRICE2;
                            dr["MATCHPRICE"] = ee.MATCHPRICE;
                            dr["MATCHQTY"] = ee.MATCHQTY;
                            dr["CLORDID"] = ee.CLORDID;
                            dr["OPENCLOSE"] = ee.OPENCLOSE;
                            dr["EXECID"] = ee.EXECID;
                            dr["MDATE"] = ee.MDATE;
                            dr["ORDERID"] = ee.ORDERID;
                            dr["TARGETID"] = ee.TARGETID;
                            dr["ACCOUNT"] = ee.ACCOUNT;
                            dr["STATE"] = ee.STATE;
                            dr["ORDERTAG"] = ee.ORDERTAG;
                            dr["AE"] = ee.AE;
                            dr["PSEQ"] = ee.PSEQ;
                            dr.EndEdit();


                            frmMain.mobjDataAgent.objTradeStringHandle.MatchTotalProvider.AddMatchQty(dr["ORDERNO"].ToString(), Item, dr["BS"].ToString()
                                 , decimal.Parse(dr["MATCHPRICE"].ToString()), int.Parse(dr["MATCHQTY"].ToString()));


                        }

                    }
                }
                if (ee.EXECTRANSTYPE == "0")
                {
                    dr = _MatchDetailReply.NewRow();

                    dr["TRADEDATE"] = ee.TRADEDATE;
                    dr["MATCHTIME"] = ee.MATCHTIME;
                    dr["BROKERID"] = ee.BROKERID;
                    dr["INVESTORACNO"] = ee.INVESTORACNO;
                    dr["SUBACT"] = ee.SUBACT;
                    dr["ORDERNO"] = ee.ORDERNO;
                    dr["PRODUCTKIND"] = ee.PRODUCTKIND;
                    dr["BS"] = ee.BS;
                    dr["SECURITYEXCHANGE"] = ee.SECURITYEXCHANGE;
                    dr["SECURITYTYPE1"] = ee.SECURITYTYPE1;
                    dr["SYMBOL1"] = ee.SYMBOL1;
                    dr["MATURITYMONTHYEAR1"] = ee.MATURITYMONTHYEAR1;
                    dr["PUTORCALL1"] = ee.PUTORCALL1;
                    dr["STRIKEPRICE1"] = ee.STRIKEPRICE1;
                    dr["SIDE1"] = ee.SIDE1;
                    dr["PRICE1"] = ee.PRICE1;
                    dr["SECURITYTYPE2"] = ee.SECURITYTYPE2;
                    dr["SYMBOL2"] = ee.SYMBOL2;
                    dr["MATURITYMONTHYEAR2"] = ee.MATURITYMONTHYEAR2;
                    dr["PUTORCALL2"] = ee.PUTORCALL2;
                    dr["STRIKEPRICE2"] = ee.STRIKEPRICE2;
                    dr["SIDE2"] = ee.SIDE2;
                    dr["PRICE2"] = ee.PRICE2;
                    dr["MATCHPRICE"] = ee.MATCHPRICE;
                    dr["MATCHQTY"] = ee.MATCHQTY;
                    dr["CLORDID"] = ee.CLORDID;
                    dr["OPENCLOSE"] = ee.OPENCLOSE;
                    dr["EXECID"] = ee.EXECID;
                    dr["MDATE"] = ee.MDATE;
                    dr["ORDERID"] = ee.ORDERID;
                    dr["TARGETID"] = ee.TARGETID;
                    dr["ACCOUNT"] = ee.ACCOUNT;
                    dr["STATE"] = ee.STATE;
                    dr["ORDERTAG"] = ee.ORDERTAG;
                    dr["AE"] = ee.AE;
                    dr["PSEQ"] = ee.PSEQ;

                    _MatchDetailReply.Rows.Add(dr);


                }
                string key = ee.BROKERID.Trim() + ee.INVESTORACNO.Trim() + ee.SUBACT.Trim() + ee.ORDERNO.Trim();
                List<DataRow> list = null;
                if (_MatchData.TryGetValue(key, out list))
                {
                    if (ee.EXECTRANSTYPE == "1")
                    {
                        list.Remove(dr);
                    }
                    else if (ee.EXECTRANSTYPE == "0")
                        list.Add(dr);
                }
                else
                {

                    list = new List<DataRow>();
                    list.Add(dr);
                    _MatchData[key] = list;
                }


                List<DataRow> tmplist = null;
                if (_TmpMatchData.TryGetValue(key, out tmplist))
                {
                    DataRow drNew = _TmpMatchDetailReply.NewRow();
                    CopySrcToDesRow(drNew, dr);
                    _TmpMatchDetailReply.Rows.Add(drNew);
                    tmplist.Add(drNew);

                }



            }
        }


        public DataRow[] GetMatch(string key)
        {
            lock (_locker)
            {
                List<DataRow> list = null;
                if (_MatchData.TryGetValue(key, out list))
                {
                    return list.ToArray();
                }
                return null;
            }
        }

        public DataRow[] GetMatchAddTmp(string key)
        {
            lock (_locker)
            {
                List<DataRow> list = null;
                if (_MatchData.TryGetValue(key, out list))
                {
                    foreach (DataRow tmp in list.ToArray())
                    {
                        DataRow drNew = _TmpMatchDetailReply.NewRow();
                        CopySrcToDesRow(drNew, tmp);
                        _TmpMatchDetailReply.Rows.Add(drNew);
                        List<DataRow> tmplist = null;
                        if (_TmpMatchData.TryGetValue(key, out tmplist))
                        {

                            tmplist.Add(drNew);
                        }
                        else
                        {

                            tmplist = new List<DataRow>();
                            tmplist.Add(drNew);
                            _TmpMatchData[key] = tmplist;
                        }
                    }

                    return list.ToArray();
                }
                else
                {
                    List<DataRow> tmplist = new List<DataRow>();

                    _TmpMatchData[key] = tmplist;
                }
                return null;
            }
        }




        public void Delete(string key, DataRow dr)
        {
            lock (_locker)
            {
                _TmpMatchData.Remove(key);


                dr.Delete();
            }
        }
        public DataRow[] GetMatchFortmp(string key)
        {
            lock (_locker)
            {
                List<DataRow> list = null;
                if (_TmpMatchData.TryGetValue(key, out list))
                {



                    return list.ToArray();
                }
                return null;
            }
        }



        public void Deletetmp(string key, DataRow dr)
        {
            lock (_locker)
            {
                _TmpMatchData.Remove(key);
                DataRow drNew = _MatchDetailReply.NewRow();
                CopySrcToDesRow(drNew, dr);
                _MatchDetailReply.Rows.Add(drNew);

                List<DataRow> list = null;
                if (_MatchData.TryGetValue(key, out list))
                {

                    list.Add(drNew);
                }
                else
                {

                    list = new List<DataRow>();
                    list.Add(drNew);
                    _MatchData[key] = list;
                }

                dr.Delete();
            }
        }
        private void CopySrcToDesRow(DataRow Src, DataRow Des)
        {

            //  Src.ItemArray = Des.ItemArray;
            for (int i = 0; i < Des.ItemArray.Length; i++)
            {
                Src[i] = Des[i];
            }
        }

        public void AddStrategySeq(string key)
        {
            lock (_locker)
            {

                List<DataRow> tmplist = null;
                if (!_TmpMatchData.TryGetValue(key, out tmplist))
                {
                    tmplist = new List<DataRow>();

                    _TmpMatchData[key] = tmplist;

                }
                else
                {


                }

            }
        }
        public void DelStrategySeq(string key)
        {
            lock (_locker)
            {
                _TmpMatchData.Remove(key);
            }
        }
    }
}
