﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VIPTradingSystem.MYcls
{
    public class ReplyUIObject
    {
        public string ORDERKIND { set; get; }
        public string EXECTYPE { set; get; }
        public string TRADEDATE { set; get; }
        public string ORDERNO { set; get; }
        public string ORDERTIME { set; get; }
        public string BROKERID { set; get; }
        public string INVESTORACNO { set; get; }
        public string SUBACT { set; get; }
        public string BS { set; get; }
        public string PRODUCTKIND { set; get; }
        public string SECURITYEXCHANGE { set; get; }
        public string SECURITYTYPE1 { set; get; }
        public string SYMBOL1 { set; get; }
        public string MATURITYMONTHYEAR1 { set; get; }
        public string PUTORCALL1 { set; get; }
        public decimal STRIKEPRICE1 { set; get; }
        public string SIDE1 { set; get; }
        public string SECURITYTYPE2 { set; get; }
        public string SYMBOL2 { set; get; }
        public string MATURITYMONTHYEAR2 { set; get; }
        public string PUTORCALL2 { set; get; }
        public decimal STRIKEPRICE2 { set; get; }
        public string SIDE2 { set; get; }
        public decimal PRICE { set; get; }
        public decimal STOPPRICE { set; get; }
        public int ORDERQTY { set; get; }
        public int MATCHQTY { set; get; }
        public int NOMATCHQTY { set; get; }
        public int DELQTY { set; get; }
        public string STATUSCODE { set; get; }
        public string ORDERSTATUS { set; get; }
        public string CLORDID { set; get; }
        public string OPENCLOSE { set; get; }
        public string TIMEINFORCE { set; get; }
        public string ORDERTYPE { set; get; }
        public string EXPIREDATE { set; get; }
        public string DTRADE { set; get; }
        public string MDATE { set; get; }
        public string SEQ { set; get; }
        public string SOURCECODE { set; get; }
        public string IP { set; get; }
        public string ORDERID { set; get; }
        public string TARGETID { set; get; }
        public string ACCOUNT { set; get; }
        public string AD { set; get; }
        public string PSEQ { set; get; }
        public string KEEPDATA { set; get; }
        public string AE { set; get; }
        public string ORDERTAG { set; get; }



        public string EXECTRANSTYPE { set; get; }
        public delegate void ReceiveReplyCallback(ReplyUIObject e);
        public event ReceiveReplyCallback _ReceiveReply;
        public delegate void ReceiveOrderCallback(ReplyUIObject e);
        public event ReceiveOrderCallback _ReceiveOrder;
        public ReplyUIObject()
        {
            ORDERKIND = "";
            EXECTYPE = "";
            TRADEDATE = "";
            ORDERNO = "";
            ORDERTIME = "";
            BROKERID = "";
            INVESTORACNO = "";
            SUBACT = "";
            BS = "";
            PRODUCTKIND = "";
            SECURITYEXCHANGE = "";
            SECURITYTYPE1 = "";
            SYMBOL1 = "";
            MATURITYMONTHYEAR1 = "";
            PUTORCALL1 = "";
            STRIKEPRICE1 = 0;
            SIDE1 = "";
            SECURITYTYPE2 = "";
            SYMBOL2 = "";
            MATURITYMONTHYEAR2 = "";
            PUTORCALL2 = "";
            STRIKEPRICE2 = 0;
            SIDE2 = "";
            PRICE = 0;
            STOPPRICE = 0;
            ORDERQTY = 0;
            MATCHQTY = 0;
            NOMATCHQTY = 0;
            DELQTY = 0;
            STATUSCODE = "";
            ORDERSTATUS = "";
            CLORDID = "";
            OPENCLOSE = "";
            TIMEINFORCE = "";
            ORDERTYPE = "";
            EXPIREDATE = "";
            DTRADE = "";
            MDATE = "";
            SEQ = "";
            SOURCECODE = "";
            IP = "";
            ORDERID = "";
            TARGETID = "";
            ACCOUNT = "";
            AD = "";
            PSEQ = "";
            KEEPDATA = "";
            AE = "";
            ORDERTAG = "";
            EXECTRANSTYPE = "";
        }
        public void raiseReceiveReply(ReplyUIObject ee)
        {

            if (_ReceiveReply != null)
            {
                _ReceiveReply(ee);
            }
        }
        public void raiseReceiveOrder(ReplyUIObject ee)
        {
            if (_ReceiveOrder != null)
            {
                _ReceiveOrder(ee);
            }
        }
    }
}
