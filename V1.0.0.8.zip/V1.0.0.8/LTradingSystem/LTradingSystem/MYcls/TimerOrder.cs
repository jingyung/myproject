﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using com.ddsc.core;
using System.Threading;

namespace VIPTradingSystem.MYcls
{
    public class TimerOrder
    {
        public event TickHandler TickEvent;
        public delegate void TickHandler(DateTime TIME, string QTY);
        private QueuePoolByLock<TimeItem> _QEvent;
        public struct TimeItem
        {
            public void init()
            {
                NO = "";
                QTY = "";
            }
            public string NO;
            public DateTime TIME;
            public string QTY;
        }
        int TotalQty = 0;
        int Qty = 0;
        int Times = 0;
        int Interval = 0;
        int Count = 0;
        DateTime BeginTime = new DateTime();
        DateTime EndTime = new DateTime();
        public Dictionary<int, TimeItem> OrderList = new Dictionary<int, TimeItem>();
        System.Timers.Timer timer = new System.Timers.Timer();

        public TimerOrder()
        {

            _QEvent = new QueuePoolByLock<TimeItem>(1);
            _QEvent.ParameterExcute += new QueuePoolByLock<TimeItem>.ParameterHandler(_QEvent_ParameterExcute);
            _QEvent.Go();
            timer.Elapsed += new System.Timers.ElapsedEventHandler(timer_Elapsed);
        }
        /// <summary>
        ///   設定變數 
        /// </summary>
        /// <param name="totalqty">總口數</param>
        /// <param name="qty">每次送單口數</param>
        /// <param name="ratio">比率</param>
        /// <param name="interval">間隔時間(毫秒)</param> 
        /// <param name="BeginTime">開始時間</param>
        /// <param name="EndTime">結束時間</param>
        public void setParam(int p_totalqty, int p_qty, decimal p_ratio,ref int p_interval, DateTime p_BeginTime, DateTime p_EndTime)
        {
            //設定送出次數
            if (p_ratio == 0)//判斷是不是依照比率
            {
                Times = p_totalqty / p_qty;
                if (p_totalqty % p_qty > 0)
                    Times = Times + 1;
            }
            else
            {
                Times = Convert.ToInt16(Math.Ceiling(1 / p_ratio));//無條件進位
                p_qty = p_totalqty / Times;
            }
            //設定間隔時間
            if (p_BeginTime < DateTime.Now)//如果時間超過,起始時間用當下時間
                p_BeginTime = DateTime.Now;

            Interval = p_interval;
            if (Interval == 0)//判斷是不是定時分單.總秒數/次數
            {
                if ((p_EndTime - p_BeginTime).TotalSeconds < 0)
                    return;
                Interval = Convert.ToInt32((p_EndTime - p_BeginTime).TotalMilliseconds)  / Times;
            }
            p_interval = Interval;
            timer.Interval = Interval;
            TotalQty = p_totalqty;
            Qty = p_qty;
            BeginTime = p_BeginTime;
            EndTime = p_EndTime;
            OrderList.Clear();
            Count = 0;

            for (int i = 0; i < Times; i++)
            {
                TimeItem TimeItem = new TimeItem();
                TimeItem.init();
                TimeItem.NO = i.ToString();
                if (i < (Times - 1))
                    TimeItem.QTY = Qty.ToString();
                else
                {
                    TimeItem.QTY = (TotalQty - i * Qty).ToString();//最後一次用剩餘口數送出
                }
 

                    TimeItem.TIME = BeginTime.AddMilliseconds(Interval * (i ));
                OrderList.Add(i, TimeItem);
            }

        }
        public void start()
        {
            timer.Start();
        }
        public void stop()
        {
            timer.Stop();
        }
        public void dispose()
        {
            if (_QEvent != null)
            {

                _QEvent.ParameterExcute -= new QueuePoolByLock<TimeItem>.ParameterHandler(_QEvent_ParameterExcute);
                _QEvent.Dispose();
            }
            GC.SuppressFinalize(this);
        }
        private void timer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            if (BeginTime <= DateTime.Now)
            {
                if (Count < Times)
                {
                    _QEvent.PutData2Queue(OrderList[Count]);
                    Count++;
                }
                else
                {
                    timer.Stop();
                }
            }
        }
        private void _QEvent_ParameterExcute(TimeItem ff)
        {
            try
            {
                onTickEvent(ff.TIME, ff.QTY);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private void onTickEvent(DateTime TIME, string QTY)
        {
            if (TickEvent != null)
                TickEvent(TIME, QTY);
        }
    }
}
