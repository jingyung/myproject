using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Collections;

namespace VIPTradingSystem.MYcls
{
    public class infoQManager
    {
        
        private  SyncEvents syncConnectionEvents = new SyncEvents();
        public delegate void parseMarketInfoDataEventHandler(string strData);

        public event parseMarketInfoDataEventHandler parseMarket;
        private  Queue<string> m_QueueData = new Queue<string>();
        private System.Threading.Thread m_objTrdSocket;
        private void execStartThread()
        {
            if (m_objTrdSocket != null)
            {
                m_objTrdSocket.Abort();
            }
            m_objTrdSocket = new System.Threading.Thread(new ThreadStart(execQueueData));
            m_objTrdSocket.Start();
        }
        private void AbortThread()
        {
 
            if (m_objTrdSocket != null)
            {
                m_objTrdSocket.Abort();
            }
        }
        public infoQManager()
        {
            execStartThread();
        }

        ~infoQManager()
        {
            Dispose();
        }
        public void Dispose()
        {
            AbortThread();
         
            GC.SuppressFinalize(this);

        }
        public void PutData2Queue(string str_Data)
        {
           
          
                lock (((ICollection)m_QueueData).SyncRoot)
                {
                    m_QueueData.Enqueue(str_Data);
                    syncConnectionEvents.NewItemEvent.Set();
                }
                
            
           
        }
        private void execQueueData()
        {
            while (WaitHandle.WaitAny(syncConnectionEvents.EventArray) != 1)
            {
                do
                {

                    string data = "";
                    lock (((ICollection)m_QueueData).SyncRoot)
                    {

                        if (m_QueueData.Count > 0)
                        {
                            //�P�_����DEQ��Ʃ�bDATA�ܼƸ�
                            data =  m_QueueData.Dequeue();


                        }

                    }
               
                    //����T�w���o��ư��e��ưʧ@
                    if (data != "")
                    {
                        if (parseMarket != null)
                        {
                            parseMarket(data);
                        }
                    }
                } while (m_QueueData.Count > 0);
          
            }
        }
        public class SyncEvents
        {
            private EventWaitHandle _newItemEvent;
            private EventWaitHandle _exitThreadEvent;
            private WaitHandle[] _eventArray;
            public SyncEvents()
            {

                _newItemEvent = new AutoResetEvent(false);
                _exitThreadEvent = new ManualResetEvent(false);
                _eventArray = new WaitHandle[2];
                _eventArray[0] = _newItemEvent;
                _eventArray[1] = _exitThreadEvent;
            }

            public EventWaitHandle ExitThreadEvent
            {
                get { return _exitThreadEvent; }
            }
            public EventWaitHandle NewItemEvent
            {
                get { return _newItemEvent; }
            }
            public WaitHandle[] EventArray
            {
                get { return _eventArray; }
            }

 
        }
    }
}
