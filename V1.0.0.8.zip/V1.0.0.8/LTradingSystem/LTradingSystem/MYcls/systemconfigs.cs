﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
namespace VIPTradingSystem.MYcls
{
    public class systemconfigs
    {
        /// <summary>
        /// 選擇權商品檔
        /// </summary>
        private static DataTable mdtOptionData;
        /// <summary>
        /// 期貨商品檔
        /// </summary>
        private static DataTable mdtFutureData;
        /// <summary>
        /// 商品主檔
        /// </summary>
        private static DataTable mdtProductMain;
        /// <summary>
        /// 跳動點檔
        /// </summary>
        private static DataTable mdtTickData;
        /// <summary>
        /// 委託狀態檔
        /// </summary>
        private static DataTable mdtMessageCode;
        /// <summary>
        /// 委託來源檔
        /// </summary>
        private static DataTable mdtOrderSource;
        /// <summary>
        /// 系統登入日期
        /// </summary>
        private static string  mstrLogDate;
        /// <summary>
        /// 系統登入時間
        /// </summary>
        private static string mstrLogTime;
        /// <summary>
        /// 清盤時間
        /// </summary>
        private static string mstrClearTime;
        /// <summary>
        /// 目前時間
        /// </summary>
        private static DateTime  mdmNow;
        /// <summary>
        /// 登入時間
        /// </summary>
        private static DateTime mdmLogin;

        /// <summary>
        /// MITOrder設定
        /// </summary>
        private static bool mbolMITOrderFlag;
        private static Dictionary<string, string> mdcACTextMapping = new Dictionary<string, string>();
        private static Dictionary<string, string> mdcACNameMapping = new Dictionary<string, string>();
        private static int mint_dpiPercent;
        /// <summary>
        /// 期貨商品檔
        /// </summary>
        public static System.Data.DataTable FutureData
        {
            get
            {
                return mdtFutureData;
            }
            set
            {
                mdtFutureData = value;
            }
        }

        /// <summary>
        /// 選擇權商品檔
        /// </summary>
        public static System.Data.DataTable OptionData
        {
            get
            {
                return mdtOptionData;
            }
            set
            {
                mdtOptionData = value;
            }
        }

        /// <summary>
        /// 商品主檔
        /// </summary>
        public static DataTable ProductMain
        {
            get
            {
                return mdtProductMain;
            }
            set
            {
                mdtProductMain = value;
            }
        }

        /// <summary>
        /// 跳動點檔
        /// </summary>
        public static DataTable TickData
        {
            get
            {
                return mdtTickData;
            }
            set
            {
                mdtTickData = value;
            }
        }

        /// <summary>
        /// 錯誤代碼對應檔
        /// </summary>
        public static DataTable MessageCode
        {
            get
            {
                return mdtMessageCode;
            }
            set
            {
                mdtMessageCode = value;
            }
        }

    

        /// <summary>
        /// 系統登入日期
        /// </summary>
        public static string   LogDate
        {
            get
            {
                return mstrLogDate;
            }
            set
            {
                mstrLogDate = value;
            }
        }
        /// <summary>
        /// 系統登入時間
        /// </summary>
        public static string  LogTime
        {
            get
            {
                return mstrLogTime;
            }
            set
            {
                mstrLogTime = value;
            }
        }  
        /// <summary>
        /// 清盤時間
        /// </summary>
        public static string ClearTime
        {
            get
            {
                return mstrClearTime;
            }
            set
            {
                mstrClearTime = value;
            }
        }
        /// <summary>
        /// 目前時間
        /// </summary>
        public static DateTime  dmNow
        {
            get
            {
                return mdmNow ;
            }
            set
            {
                mdmNow = value;
            }
        }
        /// <summary>
        /// 登入時間
        /// </summary>
        public static DateTime dmLogin
        {
            get
            {
                return mdmLogin;
            }
            set
            {
                mdmLogin = value;
            }
        }
        /// <summary>
        /// /// MITOrder設定
        /// </summary>
        public static bool bolMITOrderFlag
        {
            get
            {
                return mbolMITOrderFlag;
            }
            set
            {
                mbolMITOrderFlag = value;
            }
        }

        /// <summary>
        /// 下單夾帳務欄位文字對應檔
        /// </summary>
        public static Dictionary<string,string> ACTextMapping
        {
            get
            {
                return mdcACTextMapping;
            }
            set
            {
                mdcACTextMapping = value;
            }
        }
        /// <summary>
        /// 下單夾帳務欄位名稱對應檔
        /// </summary>
        public static Dictionary<string, string> ACNameMapping
        {
            get
            {
                return mdcACNameMapping;
            }
            set
            {
                mdcACNameMapping = value;
            }
        }
        /// <summary>
        /// 解析度比例
        /// </summary>
        public static int dpiPercent
        {
            get
            {
                return mint_dpiPercent;
            }
            set
            {
                mint_dpiPercent = value;
            }
        }

        
    }
}
