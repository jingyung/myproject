﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using System.IO;
using System.IO.Compression;
using System.Threading;
using System.Diagnostics;

namespace DDSCHost
{
    public partial class Form1 : Form
    {
        public class CommonFunction
        {
            public static byte[] Compress(byte[] text, int index, int count)
            {
                using (var ms = new MemoryStream())
                {
                    using (GZipStream zip = new GZipStream(ms, CompressionMode.Compress))
                    {
                        zip.Write(text, index, count);

                    }
                    return ms.ToArray();
                }
            }
            public static byte[] Decompress(byte[] compressed)
            {
                using (MemoryStream ms = new MemoryStream(compressed))
                {
                    using (GZipStream zip = new GZipStream(ms, CompressionMode.Decompress))
                    using (var sr = new BinaryReader(zip, Encoding.UTF8))
                    {
                        return sr.ReadBytes(10 * 1024 * 1024);
                    }

                }

            }
        }

        public static string BASEPATH = "";
        public static string EXECFILE = "PSGLTradingSystem.exe";
        WSDW.LService _Service;


        System.IO.StreamWriter _File;
        public Form1()
        {
            try
            {


                InitializeComponent();
                this.DoubleBuffered = true;
                string fftt = Application.ProductVersion;
                BASEPATH = Path.GetDirectoryName(Application.ExecutablePath);

                _File = new StreamWriter("UpdateList.txt", true, Encoding.Default);
                _Service = new WSDW.LService();

                string server = "172.16.204.87";

#if (TESTMODE)
                server = "172.16.204.89";
#endif


#if !DDSCTESTMODE
                _Service.Url = "http://" + server + "/WS_LService/LService.asmx";
                _Service.Discover();
#endif
                //172.16.204.89

            }
            catch (Exception ex)
            {
            
                MessageBox.Show(ex.Message);
                WriteLog(ex.Message);
            }
        }
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            close();
        }
        public void WriteLog(string data)
        {
            _File.WriteLine(DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss.fff") + "-" + data);
            _File.Flush();
        }
        public void close()
        {
            try
            {


                if (_File != null)
                    _File.Close();

            }
            catch (Exception ex)
            {
            }

        }
        private void Form1_Load(object sender, EventArgs e)
        {


        }



        private void Updatefile(XmlDocument doc)
        {

            try
            {
                //PSGLTradingSystem.exe

                string tmpdir = "";
                XmlNodeList xl = doc.SelectNodes("//file");
                this.progressBar1.Maximum = xl.Count;
                int count = 0;
                foreach (XmlNode x in xl)
                {

                    StreamWriter sw_Log;
                    string DownLoadFile = x.Attributes["Directory"].Value + "\\" + x.InnerText;
                    WriteLog(DownLoadFile + "......下載開始");
                    byte[] bytefile = _Service.DownLoadFile(DownLoadFile);
                    WriteLog(DownLoadFile + "......下載成功");
                    WriteLog(DownLoadFile + "......解壓縮開始");
                    bytefile = CommonFunction.Decompress(bytefile);
                    WriteLog(DownLoadFile + "......解壓縮成功");
                    //目標路徑
                    tmpdir = AppDomain.CurrentDomain.BaseDirectory.ToString().TrimEnd() + "tmp\\" + x.Attributes["Directory"].Value;
                    string file = x.InnerText;
                    //目標檔案
                    string path = tmpdir + "\\" + file;

                    if (!Directory.Exists(tmpdir))
                    {
                        Directory.CreateDirectory(tmpdir);
                    }
                    else
                    {
                        if (count == 0)
                        {
                            Directory.Delete(tmpdir, true);
                            Directory.CreateDirectory(tmpdir);
                        }
                    }

                    sw_Log = File.CreateText(path);

                    sw_Log.BaseStream.Write(bytefile, 0, bytefile.Length);
                    sw_Log.Close();
                    this.progressBar1.Value++;
                    Application.DoEvents();
                    this.lblFile.Text = x.Attributes["Directory"].Value + "\\" + file + "......下載成功";
                    WriteLog(this.lblFile.Text);
                    count++;
                }
                string[] fileEntries = Directory.GetFiles(BASEPATH, "*", SearchOption.TopDirectoryOnly);

                string descdir = BASEPATH + "\\bak\\" + DateTime.Now.ToString("yyyyMMdd");
                if (!Directory.Exists(descdir))
                {
                    Directory.CreateDirectory(descdir);
                }

                foreach (string fileName in fileEntries)
                {
                    FileInfo fi = new FileInfo(fileName);

                    WriteLog(fi.Name + "......備份開始");
                    File.Copy(fileName, descdir + "\\" + fi.Name, true);
                    WriteLog(fi.Name + "......備份成功");
                }
                fileEntries = Directory.GetFiles(tmpdir, "*", SearchOption.TopDirectoryOnly);
                foreach (string fileName in fileEntries)
                {
                    FileInfo fi = new FileInfo(fileName);

                    if (fi.Name.ToUpper() != "PSGLDDSCHOST.EXE".ToUpper())
                    {
                        WriteLog(fi.Name + "......複製開始");
                        File.Copy(fileName, BASEPATH + "\\" + fi.Name, true);
                        WriteLog(fi.Name + "......複製成功");
                    }
                }

            }
            catch (Exception ex)
            {

                MessageBox.Show("更新失敗");
                WriteLog(ex.Message);
            }

        }

        private void Form1_Shown(object sender, EventArgs e)
        {

            string p = "V" + FileVersionInfo.GetVersionInfo(BASEPATH + "\\" + EXECFILE).ProductVersion.ToString();

            string VersionXml = _Service.GetVersion();
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(VersionXml);
            doc.Save("update.xml");
            XmlNode xn = doc.SelectSingleNode("files");
            string Version = xn.Attributes["Version"].Value;
            bool Enforce = bool.Parse(xn.Attributes["Enforce"].Value);

            if (Version != p || Enforce)
            {
                WriteLog("更新開始......" + Version);
                Updatefile(doc);
                WriteLog("更新結束......" + Version);
            }

            Application.DoEvents();
            this.progressBar1.Value = this.progressBar1.Maximum;
            this.lblFile.Text = "啟動系統";


            Process.Start(BASEPATH + "\\" + EXECFILE);

            this.Close();

        }








    }
}
