﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using System.Threading;
using System.IO;
using System.Diagnostics;
namespace DDSCHost
{
    static class Program
    {
        /// <summary>
        /// 應用程式的主要進入點。
        /// </summary>
        [STAThread]
        static void Main()
        {

            string fff = Path.GetFileName(Application.ExecutablePath);

            Mutex mutex = new Mutex(false, Path.GetFileName(Application.ExecutablePath).ToLower());

            if (mutex.WaitOne(1, false))
            {

                System.Security.Principal.WindowsIdentity identity = System.Security.Principal.WindowsIdentity.GetCurrent();

                Application.EnableVisualStyles();

                System.Security.Principal.WindowsPrincipal principal = new System.Security.Principal.WindowsPrincipal(identity);
                Process currentProcessByName = Process.GetCurrentProcess();
                currentProcessByName.PriorityClass = ProcessPriorityClass.RealTime;
                if (principal.IsInRole(System.Security.Principal.WindowsBuiltInRole.Administrator))
                {

                    Application.EnableVisualStyles();
                    Application.SetCompatibleTextRenderingDefault(false);
                    Application.Run(new Form1());
                }
                else
                {
                    System.Diagnostics.ProcessStartInfo startInfo = new System.Diagnostics.ProcessStartInfo();
                    startInfo.UseShellExecute = true;
                    startInfo.FileName = Application.ExecutablePath;
                    startInfo.Verb = "runas";
                    try
                    {
                        Process process = new Process();
                        process.StartInfo = startInfo;
                        process.Start();


                    }
                    catch (Exception ex)
                    {
                    }
                }




            }
            else
            {
                MessageBox.Show("程式執行中, 無法重複執行");
            }
            if (mutex != null)
            {
                mutex.Dispose();
            }


        }
    }
}
