﻿using System;
using System.Collections;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Xml.Linq;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using System.IO.Compression;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

using System.Net.Sockets;
using System.Text;
 
using System.Runtime.InteropServices;
using System.Collections.Generic;
using System.Net;  
using System.Security.Cryptography;
namespace WS_LService
{
    public class CommonFunction
    {
        /// <summary>
        /// 壓縮byte
        /// </summary>
        public static byte[] zipdata(DataSet ds)
        {

            ds.RemotingFormat = SerializationFormat.Binary;
            BinaryFormatter ser = new BinaryFormatter();
            MemoryStream unMS = new MemoryStream();
            ser.Serialize(unMS, ds);

            byte[] bytes = unMS.ToArray();
            int lenbyte = bytes.Length;

            MemoryStream compMs = new MemoryStream();
            GZipStream compStream = new GZipStream(compMs, CompressionMode.Compress, true);
            compStream.Write(bytes, 0, lenbyte);

            compStream.Close();
            unMS.Close();
            compMs.Close();
            return compMs.ToArray();
        }
        /// <summary>
        /// 壓縮byte
        /// </summary>
        public static byte[] zipdata(string[] arr)
        {

            BinaryFormatter ser = new BinaryFormatter();
            MemoryStream unMS = new MemoryStream();
            ser.Serialize(unMS, arr);

            byte[] bytes = unMS.ToArray();
            int lenbyte = bytes.Length;

            MemoryStream compMs = new MemoryStream();
            GZipStream compStream = new GZipStream(compMs, CompressionMode.Compress, true);
            compStream.Write(bytes, 0, lenbyte);

            compStream.Close();
            unMS.Close();
            compMs.Close();
            return compMs.ToArray();
        }

        public static byte[] Compress(byte[] text, int index, int count)
        {
            using (var ms = new MemoryStream())
            {
                using (GZipStream zip = new GZipStream(ms, CompressionMode.Compress))
                {
                    zip.Write(text, index, count);

                }
                return ms.ToArray();
            }
        }
        public static byte[] Decompress(byte[] compressed)
        {
            using (MemoryStream ms = new MemoryStream(compressed))
            {
                using (GZipStream zip = new GZipStream(ms, CompressionMode.Decompress))
                using (var sr = new BinaryReader(zip, Encoding.UTF8))
                {
                    return sr.ReadBytes(10 * 1024 * 1024);
                }

            }

        }





        /// <summary>
        /// 解壓縮
        /// </summary>
        public static string[] SerialUnZipArray(byte[] data)
        {
            MemoryStream input = new MemoryStream();
            input.Write(data, 0, data.Length);
            input.Position = 0;
            GZipStream gzip = new GZipStream(input, CompressionMode.Decompress, true);

            MemoryStream output = new MemoryStream();
            byte[] buffer = new byte[4096];
            int read = -1;
            read = gzip.Read(buffer, 0, buffer.Length);
            while (read > 0)
            {
                output.Write(buffer, 0, read);
                read = gzip.Read(buffer, 0, buffer.Length);
            }
            gzip.Close();
            byte[] rebytes = output.ToArray();
            output.Close();
            input.Close();

            MemoryStream ms = new MemoryStream(rebytes);
            BinaryFormatter bf = new BinaryFormatter();
            object obj = bf.Deserialize(ms);
            string[] arrData = (string[])obj;

            return arrData;
        }
        public static string SubStr(string a_SrcStr, int a_StartIndex, int a_Cnt)
        {
            Encoding l_Encoding = Encoding.GetEncoding("big5", new EncoderExceptionFallback(), new DecoderReplacementFallback(""));
            byte[] l_byte = l_Encoding.GetBytes(a_SrcStr);
            if (a_Cnt <= 0)
                return "";
            //例若長度10 
            //若a_StartIndex傳入9 -> ok, 10 ->不行 
            if (a_StartIndex + 1 > l_byte.Length)
                return "";
            else
            {
                //若a_StartIndex傳入9 , a_Cnt 傳入2 -> 不行 -> 改成 9,1 
                if (a_StartIndex + a_Cnt > l_byte.Length)
                    a_Cnt = l_byte.Length - a_StartIndex;
            }
            return l_Encoding.GetString(l_byte, a_StartIndex, a_Cnt).Trim();
        }
        /// <summary>
        /// 執行SQL指令
        /// </summary>
        public static bool runExecuteNonQuery(String[] sqlCommand)
        {
            bool bolSuccess = true;
            int count = 1;
           string  ASTR_ConfigConnection1 = ConfigurationSettings.AppSettings["ConfigSqlConnectionString1"];
           string ASTR_ConfigConnection2 = ConfigurationSettings.AppSettings["ConfigSqlConnectionString2"];
            if (ASTR_ConfigConnection1 != ASTR_ConfigConnection2)
                count = 2;
            for (int idx = 1; idx <= count; idx++)
            {
                string strConnectionString = "";
                switch (idx)
                {
                    case 1:
                        strConnectionString = ASTR_ConfigConnection1;
                        break;
                    case 2:
                        strConnectionString = ASTR_ConfigConnection2;
                        break;
                    //case 3:
                    //    if (ASTR_ConfigConnection3 == null)
                    //    {
                    //        continue;
                    //    }
                    //    strConnectionString = ASTR_ConfigConnection3;
                    //    break;
                    //case 4:
                    //    if (ASTR_ConfigConnection4 == null)
                    //    {
                    //        continue;
                    //    }
                    //    strConnectionString = ASTR_ConfigConnection4;
                    //    break;
                }
                SqlConnection conn = new SqlConnection(strConnectionString);

                SqlTransaction trans = null;
                SqlCommand cmd = null;
                int idxCurrent = 0;
                try
                {
                    try
                    {
                        conn.Open();
                    }
                    catch (Exception exConnect)
                    {
                        bolSuccess = false;
                    }
                    // create Transaction 
                    trans = conn.BeginTransaction();
                    // create SqlDbCommand
                    cmd = conn.CreateCommand();
                    // set Connection to OracleCommand Object
                    cmd.Connection = conn;
                    // set CommandType to OracleCommand Object
                    cmd.CommandType = CommandType.Text;
                    // set CommandTimeout to OracleCommand Object
                    // cmd.CommandTimeout = oleConn.getTimeout();
                    // set Transaction to  OracleCommand Object
                    cmd.Transaction = trans;
                    for (int i = 0; i < sqlCommand.Length; i++)
                    {
                        idxCurrent = i;
                        if (!sqlCommand[i].Trim().Equals(""))
                        {
                            // set SQL Statement to OracleCommand Object
                            cmd.CommandText = sqlCommand[i];
                            // exectue (run)
                            int intRecordsAffected = cmd.ExecuteNonQuery();
                        }
                    }
                    trans.Commit();
                    // set retrun DataTable :: info
                }
                catch (Exception ex)
                {
                    try
                    {
                        trans.Rollback();
                    }
                    catch (Exception oleEx)
                    {
                    }
                    bolSuccess = false;
                }
                finally
                {
                    if (trans != null)
                    {
                        trans = null;
                    }
                    if (cmd != null)
                    {
                        cmd.Dispose();
                        cmd = null;
                    }
                    if (conn != null)
                    {
                        conn.Close();
                        conn = null;
                    }
                }
            }
            return bolSuccess;

        }
        /// <summary>
        /// 執行SQL指令
        /// </summary>
        public static bool runExecuteNonQueryWithParameter(SqlCommand[] sqlCommands)
        {
            bool bolSuccess = true;
            int count = 1;
            string ASTR_ConfigConnection1 = ConfigurationSettings.AppSettings["ConfigSqlConnectionString1"];
            string ASTR_ConfigConnection2 = ConfigurationSettings.AppSettings["ConfigSqlConnectionString2"];
            if (ASTR_ConfigConnection1 != ASTR_ConfigConnection2)
                count = 2;
            for (int idx = 1; idx <= count; idx++)
            {
                string strConnectionString = "";
                switch (idx)
                {
                    case 1:
                        strConnectionString = ASTR_ConfigConnection1;
                        break;
                    case 2:
                        strConnectionString = ASTR_ConfigConnection2;
                        break;
                    //case 3:
                    //    if (ASTR_ConfigConnection3 == null)
                    //    {
                    //        continue;
                    //    }
                    //    strConnectionString = ASTR_ConfigConnection3;
                    //    break;
                    //case 4:
                    //    if (ASTR_ConfigConnection4 == null)
                    //    {
                    //        continue;
                    //    }
                    //    strConnectionString = ASTR_ConfigConnection4;
                    //    break;
                }
                SqlConnection conn = new SqlConnection(strConnectionString);

                SqlTransaction trans = null;
                SqlCommand cmd = null;
                int idxCurrent = 0;
                try
                {
                    try
                    {
                        conn.Open();
                    }
                    catch (Exception exConnect)
                    {
                        bolSuccess = false;
                    }
                    // create Transaction 
                    trans = conn.BeginTransaction();
                    // create SqlDbCommand
                    cmd = conn.CreateCommand();
                    // set Connection to OracleCommand Object
                    cmd.Connection = conn;
                    // set CommandType to OracleCommand Object
                    cmd.CommandType = CommandType.Text;
                    // set CommandTimeout to OracleCommand Object
                    // cmd.CommandTimeout = oleConn.getTimeout();
                    // set Transaction to  OracleCommand Object
                    cmd.Transaction = trans;
                    foreach (SqlCommand s in sqlCommands)
                    {
                        // set SQL Statement to OracleCommand Object
                        cmd.CommandText = s.CommandText;
                        foreach (SqlParameter p in s.Parameters)
                        {
                            cmd.Parameters.Add(p.ParameterName, p.GetType());
                            cmd.Parameters[p.ParameterName].Value = p.Value;
                        }
                        // exectue (run)
                        int intRecordsAffected = cmd.ExecuteNonQuery();
                    }
                    trans.Commit();
                    // set retrun DataTable :: info
                }
                catch (Exception ex)
                {
                    try
                    {
                        trans.Rollback();
                    }
                    catch (Exception oleEx)
                    {
                    }
                    bolSuccess = false;
                }
                finally
                {
                    if (trans != null)
                    {
                        trans = null;
                    }
                    if (cmd != null)
                    {
                        cmd.Dispose();
                        cmd = null;
                    }
                    if (conn != null)
                    {
                        conn.Close();
                        conn = null;
                    }
                }
            }
            return bolSuccess;

        }
        /// <summary>
        /// 執行SQL指令(不寫入備援)
        /// </summary>
        public static bool runExecuteNonQuery_NoBackup(String[] sqlCommand)
        {
            bool bolSuccess = true;
            string strConnectionString = ConfigurationSettings.AppSettings["ConfigSqlConnectionString1"];
        


            SqlConnection conn = new SqlConnection(strConnectionString);

            SqlTransaction trans = null;
            SqlCommand cmd = null;
            int idxCurrent = 0;
            try
            {
                try
                {
                    conn.Open();
                }
                catch (Exception exConnect)
                {
                    bolSuccess = false;
                }
                // create Transaction 
                trans = conn.BeginTransaction();
                // create SqlDbCommand
                cmd = conn.CreateCommand();
                // set Connection to OracleCommand Object
                cmd.Connection = conn;
                // set CommandType to OracleCommand Object
                cmd.CommandType = CommandType.Text;
                // set CommandTimeout to OracleCommand Object
                // cmd.CommandTimeout = oleConn.getTimeout();
                // set Transaction to  OracleCommand Object
                cmd.Transaction = trans;
                for (int i = 0; i < sqlCommand.Length; i++)
                {
                    idxCurrent = i;
                    if (!sqlCommand[i].Trim().Equals(""))
                    {
                        // set SQL Statement to OracleCommand Object
                        cmd.CommandText = sqlCommand[i];
                        // exectue (run)
                        int intRecordsAffected = cmd.ExecuteNonQuery();


                    }
                }
                trans.Commit();
                // set retrun DataTable :: info
            }
            catch (Exception ex)
            {
                try
                {
                    trans.Rollback();
                }
                catch (Exception oleEx)
                {
                }
                bolSuccess = false;
            }
            finally
            {
                if (trans != null)
                {
                    trans = null;
                }
                if (cmd != null)
                {
                    cmd.Dispose();
                    cmd = null;
                }
                if (conn != null)
                {
                    conn.Close();
                    conn = null;
                }
            }

            return bolSuccess;

        }
        /// <summary>
        /// 執行SQL UPDATE or INSERT 指令
        /// </summary>
        public static bool execDB(string str_UpDateCmd, string str_InsertDateCmd)
        {
            bool blnSuccess = false;
            int count = 1;
            string ASTR_ConfigConnection1 = ConfigurationSettings.AppSettings["ConfigSqlConnectionString1"];
            string ASTR_ConfigConnection2 = ConfigurationSettings.AppSettings["ConfigSqlConnectionString2"];
            if (ASTR_ConfigConnection1 != ASTR_ConfigConnection2)
                count = 2;
            for (int idx = 1; idx <= count; idx++)
            {
                string strConnectionString = "";
                switch (idx)
                {
                    case 1:
                        strConnectionString = ASTR_ConfigConnection1;
                        break;
                    case 2:
                        strConnectionString = ASTR_ConfigConnection2;
                        break;
                }

                SqlConnection sqlConn;
                SqlCommand sqlcmd;
                sqlConn = new SqlConnection(strConnectionString);
                sqlcmd = new SqlCommand();
                sqlcmd.Connection = sqlConn;
                sqlConn.Open();
                try
                {
                    sqlcmd.CommandText = str_UpDateCmd;
                    if (sqlcmd.ExecuteNonQuery() == 0)
                    {
                        sqlcmd.CommandText = str_InsertDateCmd;
                        sqlcmd.ExecuteNonQuery();
                    }
                    blnSuccess = true;
                }
                catch (SqlException ex)
                {
                    blnSuccess = false;
                }
                finally
                {
                    sqlConn.Close();
                }
            }
            return blnSuccess;
        }
        //取得IP
        public static string GetIpAddress()
        {
            string strIpAddr = string.Empty;

            if (HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"] == null || HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"].IndexOf("unknown") > 0)
            {
                strIpAddr = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
            }
            else if (HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"].IndexOf(",") > 0)
            {
                strIpAddr = HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"].Substring(1, HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"].IndexOf(",") - 1);
            }
            else if (HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"].IndexOf(";") > 0)
            {
                strIpAddr = HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"].Substring(1, HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"].IndexOf(";") - 1);
            }
            else
            {
                strIpAddr = HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            }
            return strIpAddr; ;
        }

        /// <summary>
        ///資料解密
        /// </summary>
        public static string fh_EncString(string pwd)
        {
            Int32 i = 0;
            string encPwd = "";

            if (pwd != "")
            {
                for (i = 0; i < pwd.Length; i++)
                {
                    encPwd = encPwd + Convert.ToChar(159 - ((int)Convert.ToChar(pwd.Substring(i, 1)))).ToString();
                }
            }

            return encPwd;
        }
        public static byte[] ReceiveRawBuffer(int Size, Socket RcvS)
        {
            try
            {
                int total = 0;
                int RcvLength = 0;
                byte[] RcvBuffer = new byte[Size];

                total += RcvS.Receive(RcvBuffer, 0, RcvBuffer.Length, System.Net.Sockets.SocketFlags.None);
                if (total > 0)
                {
                    while (total != RcvBuffer.Length)
                    {
                        total += RcvLength = RcvS.Receive(RcvBuffer, total, RcvBuffer.Length - total, SocketFlags.None);
                        if (RcvLength > 0)
                            continue;
                        else
                            throw new Exception("remote disconnected");
                    }
                }
                else
                    throw new Exception("remote disconnected");
                return RcvBuffer;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static DataSet SerialUnZip(byte[] data)
        {
            try
            {
                MemoryStream input = new MemoryStream();
                input.Write(data, 0, data.Length);
                input.Position = 0;
                GZipStream gzip = new GZipStream(input, CompressionMode.Decompress, true);

                MemoryStream output = new MemoryStream();
                byte[] buffer = new byte[4096];
                int read = -1;
                read = gzip.Read(buffer, 0, buffer.Length);
                while (read > 0)
                {
                    output.Write(buffer, 0, read);
                    read = gzip.Read(buffer, 0, buffer.Length);
                }
                gzip.Close();
                byte[] rebytes = output.ToArray();
                output.Close();
                input.Close();

                MemoryStream ms = new MemoryStream(rebytes);
                BinaryFormatter bf = new BinaryFormatter();
                object obj = bf.Deserialize(ms);
                DataSet dsData = (DataSet)obj;

                return dsData;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
        }
        public static string getSSOErrorMsg(string type, string ERROR_CODE)
        {
            string errormsg = "";
            DataTable dt = new DataTable();
            string SqlCommand = " select *from SSOERRORMSG where TYPE='" + type + "' and MSGCODE='" + ERROR_CODE + "' ";
            string ASTR_ConfigConnection1 = ConfigurationSettings.AppSettings["ConfigSqlConnectionString1"];
        
            SqlDataAdapter adp = new SqlDataAdapter(SqlCommand, ASTR_ConfigConnection1);
            adp.Fill(dt);
            if (dt.Rows.Count > 0)
                errormsg = dt.Rows[0]["MSGDATA"].ToString();
            return errormsg;

        }
        public static string getOptionCP(string period)
        {
            period = period.ToUpper();
            string[] cperiod = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L" };
            string[] pperiod = { "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X" };
            string cp = "";
            if (Array.IndexOf<string>(cperiod, period) != -1)
            {
                cp = "C";
            }
            else if (Array.IndexOf<string>(pperiod, period) != -1)
            {
                cp = "P";
            }

            return cp;
        }
        public static int getMonth(string period)
        {
            period = period.ToUpper();
            string[] cperiod = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L" };
            string[] pperiod = { "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X" };
            int returnperiod = 0;
            if (Array.IndexOf<string>(cperiod, period) != -1)
            {
                returnperiod = (Array.IndexOf<string>(cperiod, period) + 1);
            }
            else if (Array.IndexOf<string>(pperiod, period) != -1)
            {
                returnperiod = (Array.IndexOf<string>(pperiod, period) + 1);
            }

            return returnperiod;
        }
        public static string get_md5(string inputstr)
        {
            MD5 md5Hasher = MD5.Create();
            byte[] data = md5Hasher.ComputeHash(Encoding.Default.GetBytes(inputstr));
            StringBuilder sBuilder = new StringBuilder();

            for (int i = 0; i < data.Length; i++)
            {
                sBuilder.Append(data[i].ToString("x2"));
            }

            md5Hasher = null;

            return Convert.ToString(sBuilder);
        }
      
       
    }
    public class ParserStruct<T>
    {
        public static void ByteArrayToStructure(byte[] bytearray, ref T obj)
        {
            int len = Marshal.SizeOf(obj);
            IntPtr i = Marshal.AllocHGlobal(len);
            Marshal.Copy(bytearray, 0, i, len);
            obj = (T)Marshal.PtrToStructure(i, typeof(T));
            Marshal.FreeHGlobal(i);
        }

        public static void ByteArrayToStructure(byte[] bytearray, int index, ref T obj)
        {
            int len = Marshal.SizeOf(obj);
            IntPtr i = Marshal.AllocHGlobal(len);
            Marshal.Copy(bytearray, index, i, len);
            obj = (T)Marshal.PtrToStructure(i, typeof(T));
            Marshal.FreeHGlobal(i);
        }
    }
}