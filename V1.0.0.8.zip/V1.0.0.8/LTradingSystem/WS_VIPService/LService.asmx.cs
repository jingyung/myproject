﻿using System;
using System.Collections;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Xml.Linq;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using System.IO.Compression;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

using System.Net.Sockets;
using System.Text;

using System.Runtime.InteropServices;
using System.Collections.Generic;
using System.Net;
using System.Web.Script.Serialization;

using MySql.Data.MySqlClient;

using System.IO;
using System.IO.Compression;
using System.Text;
using System.Xml;
using System.Diagnostics;
namespace WS_LService
{
    /// <summary>
    ///Service1 的摘要描述
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // 若要允許使用 ASP.NET AJAX 從指令碼呼叫此 Web 服務，請取消註解下一行。
    // [System.Web.Script.Services.ScriptService]
    public class LService : System.Web.Services.WebService
    {


        string _ConfigConnection;
        string _ConfigConnectionBak;
        string _TradeConfigConnection;

        public LService()
        {

            //如果使用設計的元件，請取消註解下行程式碼 
            //InitializeComponent(); 
            _ConfigConnection = ConfigurationSettings.AppSettings["ConfigSqlConnectionString"];
            _TradeConfigConnection = ConfigurationSettings.AppSettings["TradeConfigConnection"];

            _ConfigConnectionBak = ConfigurationSettings.AppSettings["ConfigSqlConnectionStringBak"];

        }

        [WebMethod]
        public byte[] getAEData()
        {
            string[] ret = null;

            try
            {

                DataSet dsProduct = new DataSet();
                DataTable dtData = new DataTable();
                MySqlConnection conn = new MySqlConnection(_ConfigConnection);

                MySqlDataAdapter adp;
                //使用者連線設定
                adp = new MySqlDataAdapter("select *from aedata  ", conn);
                adp.Fill(dtData);

                dsProduct.Tables.Add(dtData);
                return CommonFunction.zipdata(dsProduct);


            }
            catch (Exception ex)
            {
            }
            return null;

        }

        [WebMethod]
        public bool CheckUser(string userid, string password)
        {
            bool ret = false;

            try
            {
                password = CommonFunction.fh_EncString(password);
                DataSet dsProduct = new DataSet();
                DataTable dtData = new DataTable();

                MySqlConnection conn = new MySqlConnection(_ConfigConnection);

                MySqlCommand cmd = new MySqlCommand();
                string sql = "select * from userinfo where userid=@userid and password=password(@password)   ";
                cmd.Parameters.AddWithValue("@userid", userid);
                cmd.Parameters.AddWithValue("@password", password);
                cmd.CommandText = sql;
                cmd.Connection = conn;
                cmd.CommandText = sql;
                MySqlDataAdapter adp;
                //使用者連線設定
                adp = new MySqlDataAdapter(cmd);
                adp.Fill(dtData);

                if (dtData.Rows.Count > 0)
                {
                    return true;
                }
            }
            catch (Exception ex)
            {
            }
            return ret;

        }


        [WebMethod]
        public byte[] WS_gwList()
        {
            DataSet dsProduct = new DataSet();
            DataTable dtData = new DataTable();
            MySqlConnection conn = new MySqlConnection(_ConfigConnection);

            MySqlDataAdapter adp;
            //使用者連線設定
            adp = new MySqlDataAdapter("select distinct gw from securitylist  ", conn);
            adp.Fill(dtData);

            dsProduct.Tables.Add(dtData);
            return CommonFunction.zipdata(dsProduct);
        }


        [WebMethod]
        public byte[] WS_SecurityExchangeList()
        {
            DataSet dsProduct = new DataSet();
            DataTable dtData = new DataTable();
            MySqlConnection conn = new MySqlConnection(_ConfigConnection);

            MySqlDataAdapter adp;
            //使用者連線設定
            adp = new MySqlDataAdapter("select distinct SecurityExchange from securitylist   ", conn);
            adp.Fill(dtData);

            dsProduct.Tables.Add(dtData);
            return CommonFunction.zipdata(dsProduct);
        }

        [WebMethod]
        public byte[] WS_PostionList()
        {
            DataSet dsProduct = new DataSet();
            DataTable dtData = new DataTable();
            MySqlConnection conn = new MySqlConnection(_ConfigConnection);

            MySqlDataAdapter adp;
            //使用者連線設定
            adp = new MySqlDataAdapter("SELECT * from PostionList   ", conn);
            adp.Fill(dtData);

            dsProduct.Tables.Add(dtData);
            return CommonFunction.zipdata(dsProduct);
        }


        [WebMethod]
        public byte[] WS_PostionList_H()
        {
            DataSet dsProduct = new DataSet();
            DataTable dtData = new DataTable();
            MySqlConnection conn = new MySqlConnection(_ConfigConnection);

            MySqlDataAdapter adp;
            //使用者連線設定
            adp = new MySqlDataAdapter("SELECT * from PostionList_h   ", conn);
            adp.Fill(dtData);

            dsProduct.Tables.Add(dtData);
            return CommonFunction.zipdata(dsProduct);
        }


        /// <summary>
        /// 取得使用者登入IP
        /// </summary>
        [WebMethod]
        public byte[] WS_SecurityList()
        {
            DataSet dsProduct = new DataSet();
            DataTable dtData = new DataTable();
            MySqlConnection conn = new MySqlConnection(_ConfigConnection);

            MySqlDataAdapter adp;
            //使用者連線設定
            adp = new MySqlDataAdapter("SELECT * from SecurityList   ", conn);
            adp.Fill(dtData);

            dsProduct.Tables.Add(dtData);
            return CommonFunction.zipdata(dsProduct);
        }
        [WebMethod]
        public bool WS_updSecurityList(string action, string SecurityExchange, string SecurityType
            , string Symbol1, string MaturityMonthYear1, string PutOrCall1, string StrikePrice1, string BS1
            , string Symbol2, string MaturityMonthYear2, string PutOrCall2, string StrikePrice2, string BS2

            , string GW, int locator,string code)
        {
            MySqlCommand cmd = new MySqlCommand();
            string sqlcmdAdd = "";
            if (action.ToUpper() == "ADD")
            {
                sqlcmdAdd = @"insert   into  securitylist(SecurityExchange,SecurityType
            ,Symbol1,MaturityMonthYear1,PutOrCall1,StrikePrice1,BS1
         ,Symbol2,MaturityMonthYear2,PutOrCall2
                ,StrikePrice2,BS2,Gw,locator,code,AddUser,AddDate,UpdUser,UpdDate)
	values
	(@SecurityExchange,@SecurityType,@Symbol1,@MaturityMonthYear1,@PutOrCall1,@StrikePrice1,@BS1
,@Symbol2,@MaturityMonthYear2,@PutOrCall2,@StrikePrice2,@BS2,@Gw,@locator,@code,@AddUser,now(),@UpdUser,now())";

                cmd.Parameters.AddWithValue("@SecurityExchange", SecurityExchange);
                cmd.Parameters.AddWithValue("@SecurityType", SecurityType);
                cmd.Parameters.AddWithValue("@Symbol1", Symbol1);
                cmd.Parameters.AddWithValue("@MaturityMonthYear1", MaturityMonthYear1);
                cmd.Parameters.AddWithValue("@PutOrCall1", PutOrCall1);
                cmd.Parameters.AddWithValue("@StrikePrice1", StrikePrice1);
                cmd.Parameters.AddWithValue("@BS1", BS1);


                cmd.Parameters.AddWithValue("@Symbol2", Symbol2);
                cmd.Parameters.AddWithValue("@MaturityMonthYear2", MaturityMonthYear2);
                cmd.Parameters.AddWithValue("@PutOrCall2", PutOrCall2);
                cmd.Parameters.AddWithValue("@StrikePrice2", StrikePrice2);
                cmd.Parameters.AddWithValue("@BS2", BS2);
                cmd.Parameters.AddWithValue("@Gw", GW);
                cmd.Parameters.AddWithValue("@locator", locator);
                cmd.Parameters.AddWithValue("@code", code);
                cmd.Parameters.AddWithValue("@AddUser", GetIpAddress());
                cmd.Parameters.AddWithValue("@UpdUser", GetIpAddress());
            }
            else if (action.ToUpper() == "UPD")
            {
                sqlcmdAdd = @"update securitylist set Gw=@Gw,locator=@locator,code=@code ,UpdUser=@UpdUser,UpdDate=now()
where SecurityExchange=@SecurityExchange 
and SecurityType=@SecurityType
and Symbol1=@Symbol1
and MaturityMonthYear1=@MaturityMonthYear1
and PutOrCall1=@PutOrCall1
and StrikePrice1=@StrikePrice1
and BS1=@BS1
and Symbol2=@Symbol2
and MaturityMonthYear2=@MaturityMonthYear2
and PutOrCall2=@PutOrCall2
and StrikePrice2=@StrikePrice2
and BS2=@BS2
";

                cmd.Parameters.AddWithValue("@SecurityExchange", SecurityExchange);
                cmd.Parameters.AddWithValue("@SecurityType", SecurityType);
                cmd.Parameters.AddWithValue("@Symbol1", Symbol1);
                cmd.Parameters.AddWithValue("@MaturityMonthYear1", MaturityMonthYear1);
                cmd.Parameters.AddWithValue("@PutOrCall1", PutOrCall1);
                cmd.Parameters.AddWithValue("@StrikePrice1", StrikePrice1);
                cmd.Parameters.AddWithValue("@BS1", BS1);


                cmd.Parameters.AddWithValue("@Symbol2", Symbol2);
                cmd.Parameters.AddWithValue("@MaturityMonthYear2", MaturityMonthYear2);
                cmd.Parameters.AddWithValue("@PutOrCall2", PutOrCall2);
                cmd.Parameters.AddWithValue("@StrikePrice2", StrikePrice2);
                cmd.Parameters.AddWithValue("@BS2", BS2);

                cmd.Parameters.AddWithValue("@Gw", GW);
                cmd.Parameters.AddWithValue("@locator", locator);
                cmd.Parameters.AddWithValue("@code", code);
                cmd.Parameters.AddWithValue("@AddUser", GetIpAddress());
                cmd.Parameters.AddWithValue("@UpdUser", GetIpAddress());
            }
            else if (action.ToUpper() == "DEL")
            {
                sqlcmdAdd = @"delete from  securitylist 
where SecurityExchange=@SecurityExchange 
and SecurityType=@SecurityType
and Symbol1=@Symbol1
and MaturityMonthYear1=@MaturityMonthYear1
and PutOrCall1=@PutOrCall1
and StrikePrice1=@StrikePrice1
and BS1=@BS1
and Symbol2=@Symbol2
and MaturityMonthYear2=@MaturityMonthYear2
and PutOrCall2=@PutOrCall2
and StrikePrice2=@StrikePrice2
and BS2=@BS2
";

                cmd.Parameters.AddWithValue("@SecurityExchange", SecurityExchange);
                cmd.Parameters.AddWithValue("@SecurityType", SecurityType);
                cmd.Parameters.AddWithValue("@Symbol1", Symbol1);
                cmd.Parameters.AddWithValue("@MaturityMonthYear1", MaturityMonthYear1);
                cmd.Parameters.AddWithValue("@PutOrCall1", PutOrCall1);
                cmd.Parameters.AddWithValue("@StrikePrice1", StrikePrice1);
                cmd.Parameters.AddWithValue("@BS1", BS1);


                cmd.Parameters.AddWithValue("@Symbol2", Symbol2);
                cmd.Parameters.AddWithValue("@MaturityMonthYear2", MaturityMonthYear2);
                cmd.Parameters.AddWithValue("@PutOrCall2", PutOrCall2);
                cmd.Parameters.AddWithValue("@StrikePrice2", StrikePrice2);
                cmd.Parameters.AddWithValue("@BS2", BS2);

            }
            bool ret = runExecuteNonQueryForParam(sqlcmdAdd, cmd.Parameters);


            return ret;
        }


        [WebMethod]
        public bool WS_updPostionList(string action, string BrokerID, string Account, string SecurityExchange, string SecurityType
            , string Symbol1, string MaturityMonthYear1, string PutOrCall1, decimal StrikePrice1, string Side1

             , string Symbol2, string MaturityMonthYear2, string PutOrCall2, decimal StrikePrice2, string Side2
            , int Qty, decimal Price, string BS, string Keyin)
        {
            MySqlCommand cmd = new MySqlCommand();
            string sqlcmdAdd = "";
            if (action.ToUpper() == "ADD")
            {
                sqlcmdAdd = @"insert   into  postionlist(SecurityExchange 
,SecurityType
,Brokerid      
,Account          
,Symbol1           
,MaturityMonthYear1
,PutOrCall1        
,StrikePrice1      
,Side1
,Symbol2
,MaturityMonthYear2
,PutOrCall2      
,StrikePrice2
,Side2
,BS               
,Price            
,Qty              
,Keyin            
,AddUser          
,AddDate          
,UpdUser          
,UpdDate          )
	values
	(  
@SecurityExchange 
,@SecurityType
,@Brokerid     
,@Account          
,@Symbol1           
,@MaturityMonthYear1
,@PutOrCall1        
,@StrikePrice1
,@Side1
,@Symbol2           
,@MaturityMonthYear2
,@PutOrCall2      
,@StrikePrice2
,@Side2      
,@BS               
,@Price            
,@Qty              
,@Keyin            
,@AddUser          
,now()         
,@UpdUser          
,now()         
)";
                cmd.Parameters.AddWithValue("@SecurityExchange", SecurityExchange);
                cmd.Parameters.AddWithValue("@SecurityType", SecurityType);
                cmd.Parameters.AddWithValue("@Brokerid", BrokerID);
                cmd.Parameters.AddWithValue("@Account", Account);
                cmd.Parameters.AddWithValue("@Symbol1", Symbol1);
                cmd.Parameters.AddWithValue("@MaturityMonthYear1", MaturityMonthYear1);
                cmd.Parameters.AddWithValue("@PutOrCall1", PutOrCall1);
                cmd.Parameters.AddWithValue("@StrikePrice1", StrikePrice1);
                cmd.Parameters.AddWithValue("@Side1", Side1);
                cmd.Parameters.AddWithValue("@Symbol2", Symbol2);
                cmd.Parameters.AddWithValue("@MaturityMonthYear2", MaturityMonthYear2);
                cmd.Parameters.AddWithValue("@PutOrCall2", PutOrCall2);
                cmd.Parameters.AddWithValue("@StrikePrice2", StrikePrice2);
                cmd.Parameters.AddWithValue("@Side2", Side2);

                cmd.Parameters.AddWithValue("@BS", BS);
                cmd.Parameters.AddWithValue("@Price", Price);
                cmd.Parameters.AddWithValue("@Qty", Qty);
                cmd.Parameters.AddWithValue("@Keyin", Keyin);
                cmd.Parameters.AddWithValue("@AddUser", GetIpAddress());
                cmd.Parameters.AddWithValue("@UpdUser", GetIpAddress());

            }
            else if (action.ToUpper() == "UPD")
            {
                sqlcmdAdd = @"update postionlist set  Price=@Price, Qty=@Qty,Keyin=@Keyin ,UpdUser=@UpdUser,UpdDate=now() 
where SecurityExchange=@SecurityExchange 
and SecurityType=@SecurityType
and BrokerID=@BrokerID
and Account=@Account
and Symbol1=@Symbol1
and MaturityMonthYear1=@MaturityMonthYear1
and PutOrCall1=@PutOrCall1
and StrikePrice1=@StrikePrice1
and Side1=@Side1
and Symbol2=@Symbol2
and MaturityMonthYear2=@MaturityMonthYear2
and PutOrCall2=@PutOrCall2
and StrikePrice2=@StrikePrice2
and Side2=@Side2

and BS=@BS ";

                cmd.Parameters.AddWithValue("@SecurityExchange", SecurityExchange);
                cmd.Parameters.AddWithValue("@SecurityType", SecurityType);
                cmd.Parameters.AddWithValue("@BrokerID", BrokerID);
                cmd.Parameters.AddWithValue("@Account", Account);
                cmd.Parameters.AddWithValue("@Symbol1", Symbol1);
                cmd.Parameters.AddWithValue("@MaturityMonthYear1", MaturityMonthYear1);
                cmd.Parameters.AddWithValue("@PutOrCall1", PutOrCall1);
                cmd.Parameters.AddWithValue("@StrikePrice1", StrikePrice1);
                cmd.Parameters.AddWithValue("@Side1", Side1);

                cmd.Parameters.AddWithValue("@Symbol2", Symbol2);
                cmd.Parameters.AddWithValue("@MaturityMonthYear2", MaturityMonthYear2);
                cmd.Parameters.AddWithValue("@PutOrCall2", PutOrCall2);
                cmd.Parameters.AddWithValue("@StrikePrice2", StrikePrice2);
                cmd.Parameters.AddWithValue("@Side2", Side2);


                cmd.Parameters.AddWithValue("@BS", BS);
                cmd.Parameters.AddWithValue("@Price", Price);
                cmd.Parameters.AddWithValue("@Qty", Qty);
                cmd.Parameters.AddWithValue("@Keyin", Keyin);

                cmd.Parameters.AddWithValue("@UpdUser", GetIpAddress());
            }
            else if (action.ToUpper() == "DEL")
            {
                sqlcmdAdd = @"delete from  postionlist  
where SecurityExchange=@SecurityExchange 
and SecurityType=@SecurityType
and BrokerID=@BrokerID
and Account=@Account
and Symbol1=@Symbol1
and MaturityMonthYear1=@MaturityMonthYear1
and PutOrCall1=@PutOrCall1
and StrikePrice1=@StrikePrice1
and Side1=@Side1
and Symbol2=@Symbol2
and MaturityMonthYear2=@MaturityMonthYear2
and PutOrCall2=@PutOrCall2
and StrikePrice2=@StrikePrice2
and Side2=@Side2

and BS=@BS ";
                cmd.Parameters.AddWithValue("@SecurityExchange", SecurityExchange);
                cmd.Parameters.AddWithValue("@SecurityType", SecurityType);
                cmd.Parameters.AddWithValue("@BrokerID", BrokerID);
                cmd.Parameters.AddWithValue("@Account", Account);
                cmd.Parameters.AddWithValue("@Symbol1", Symbol1);
                cmd.Parameters.AddWithValue("@MaturityMonthYear1", MaturityMonthYear1);
                cmd.Parameters.AddWithValue("@PutOrCall1", PutOrCall1);
                cmd.Parameters.AddWithValue("@StrikePrice1", StrikePrice1);
                cmd.Parameters.AddWithValue("@Side1", Side1);

                cmd.Parameters.AddWithValue("@Symbol2", Symbol2);
                cmd.Parameters.AddWithValue("@MaturityMonthYear2", MaturityMonthYear2);
                cmd.Parameters.AddWithValue("@PutOrCall2", PutOrCall2);
                cmd.Parameters.AddWithValue("@StrikePrice2", StrikePrice2);
                cmd.Parameters.AddWithValue("@Side2", Side2);
                cmd.Parameters.AddWithValue("@BS", BS);
                cmd.Parameters.AddWithValue("@Price", Price);
                cmd.Parameters.AddWithValue("@Qty", Qty);
                cmd.Parameters.AddWithValue("@Keyin", Keyin);


            }
            bool ret = runExecuteNonQueryForParam(sqlcmdAdd, cmd.Parameters);


            return ret;
        }

        [WebMethod]
        public byte[] WS_AccountList()
        {
            DataSet dsProduct = new DataSet();
            DataTable dtData = new DataTable();
            MySqlConnection conn = new MySqlConnection(_ConfigConnection);

            MySqlDataAdapter adp;
            //使用者連線設定
            adp = new MySqlDataAdapter("SELECT * from accountList   ", conn);
            adp.Fill(dtData);

            dsProduct.Tables.Add(dtData);
            return CommonFunction.zipdata(dsProduct);
        }


        [WebMethod]
        public bool WS_updAccountList(string action, string Account, string Name)
        {
            MySqlCommand cmd = new MySqlCommand();
            string sqlcmdAdd = "";
            if (action.ToUpper() == "ADD")
            {
                sqlcmdAdd = @"insert   into  accountlist(account,name ,AddUser,AddDate,UpdUser,UpdDate)
	values
	(  @Account,@Name,@AddUser,now(),@UpdUser,now())";

                cmd.Parameters.AddWithValue("@Account", Account);
                cmd.Parameters.AddWithValue("@Name", Name);

                cmd.Parameters.AddWithValue("@AddUser", GetIpAddress());
                cmd.Parameters.AddWithValue("@UpdUser", GetIpAddress());
            }
            else if (action.ToUpper() == "UPD")
            {
                sqlcmdAdd = @"update accountlist set Name=@Name ,UpdUser=@UpdUser,UpdDate=now()
where Account=@Account 
 ";
                cmd.Parameters.AddWithValue("@Account", Account);
                cmd.Parameters.AddWithValue("@Name", Name);
                cmd.Parameters.AddWithValue("@UpdUser", GetIpAddress());
            }
            else if (action.ToUpper() == "DEL")
            {
                sqlcmdAdd = @"delete from  accountlist 
where Account=@Account  ";

                cmd.Parameters.AddWithValue("@Account", Account); ;

            }
            bool ret = runExecuteNonQueryForParam(sqlcmdAdd, cmd.Parameters);


            return ret;
        }
        /// <summary>
        /// 取得系統組態
        /// </summary>
        [WebMethod]
        public byte[] WS_INI()
        {
            DataSet ds_Product = new DataSet();
            DataTable[] dtbary = new DataTable[6] { new DataTable("futuredata"), new DataTable("optiondata"), new DataTable("productMain"), new DataTable("TickData"), new DataTable("MessageCode"), new DataTable("SystemDateTime") };
            SqlConnection conn = new SqlConnection(_ConfigConnection);
            SqlConnection commonconn = new SqlConnection(_ConfigConnection);

            SqlDataAdapter adp;



            //期貨商品檔


            adp = new SqlDataAdapter(@"SELECT    P08F.COMMODITY_ID, KIND_ID ,NAME, P08F.SETTLEMENT_MONTH
                , P08F.RAISE_PRICE MAX_PRICE,P08F.FALL_PRICE MIN_PRICE
, P08F.RAISE_PRICE2 MAX_PRICE2,P08F.FALL_PRICE2 MIN_PRICE2
, P08F.RAISE_PRICE3 MAX_PRICE3,P08F.FALL_PRICE3 MIN_PRICE3

, P08F.DECIMAL_LOCATOR,isnull(C.CLOSEPRICE,0) CLOSEPRICE
from P08F  left join (select * from (select *, ROW_NUMBER () OVER ( PARTITION BY COMMODITYID order by MATCHDATE  desc )row_no  
from DAVIPMARKETDB.dbo.CLOSEPRICE )C where row_no=1)C on P08F.COMMODITY_ID = ltrim(rtrim(C.COMMODITYID) )  
left join P09F on substring(P08F.COMMODITY_ID,1,3)=P09F.KIND_ID order by (case  when KIND_ID='TXF' then '1'   
when KIND_ID='MXF'then '2'  when KIND_ID='EXF'then '3'  when KIND_ID='FXF'then '4'  when KIND_ID='MSF'then '5'  else '6' end)
,KIND_ID,SETTLEMENT_MONTH", commonconn);
            adp.Fill(dtbary[0]);

            //選擇權商品檔
            adp = new SqlDataAdapter(@"SELECT    P08O.COMMODITY_ID, KIND_ID ,NAME, P08O.SETTLEMENT_MONTH
, P08O.RAISE_PRICE MAX_PRICE,P08O.FALL_PRICE MIN_PRICE
, P08O.RAISE_PRICE2 MAX_PRICE2,P08O.FALL_PRICE2 MIN_PRICE2
, P08O.RAISE_PRICE3 MAX_PRICE3,P08O.FALL_PRICE3 MIN_PRICE3
, P08O.DECIMAL_LOCATOR,P08O.CP_CODE CP,P08O.STRIKE_PRICE
,isnull(C.CLOSEPRICE,0) CLOSEPRICE from P08O left join (select * from (select *
, ROW_NUMBER () OVER ( partition by COMMODITYID order by MATCHDATE  desc )row_no   from DAVIPMARKETDB.dbo.CLOSEPRICE )C
where row_no=1)C on P08O.COMMODITY_ID = ltrim(C.COMMODITYID ) left join P09O on substring(P08O.COMMODITY_ID,1,3)=P09O.KIND_ID ", commonconn);
            adp.Fill(dtbary[1]);

            //商品主檔 
            adp = new SqlDataAdapter(@"select COMTYPE,KIND_ID,COMNO ,CONTRACT_SIZE,NAME 
                ,  replicate('0', (6-len( DISPLAYCODE ))) +   CONVERT(nvarchar, DISPLAYCODE ) AS DISPLAYCODE,STOCK_ID  
,SUBTYPE ,PRICE_DECIMAIL ,STRIKE_DECIMAIL from (select  COMTYPE,KIND_ID,COMNO ,CONTRACT_SIZE,NAME,case when SUBTYPE='S' 
then  replicate(case when SUBSTRING(STOCK_ID,1,1)='0' then '0' else '1' end, (6-len( STOCK_ID ))) +   CONVERT(nvarchar, STOCK_ID )  else convert(char(6),row_number () OVER (  partition by COMTYPE order by (case when SUBTYPE='S'then 999999 else(case when (KIND_ID='TXF' or  KIND_ID='TXO'   )then '1' when (    KIND_ID='TX1'   or  KIND_ID='TX2'  or  KIND_ID='TX4' or  KIND_ID='TX5' ) then '2' when KIND_ID='MXF'then '2' when (KIND_ID='EXF' or  KIND_ID='TEO') then '3' when( KIND_ID='FXF'or  KIND_ID='TFO') then '4' when (KIND_ID='MSF'  or  KIND_ID='MSO' )then '5' else '6' end)  end)) )end DISPLAYCODE ,STOCK_ID  ,SUBTYPE ,PRICE_DECIMAIL ,STRIKE_DECIMAIL  from (select P.*,isnull(TRANSLATE_VALUES.COMNO,(case when COMTYPE='0' then 'FI'+P.KIND_ID else P.KIND_ID end))COMNO from( (select '0'COMTYPE,* from P09F )union all (select '1'COMTYPE,* from P09O ))P left join TRANSLATE_VALUES on P.KIND_ID=TRANSLATE_VALUES.KIND_ID )P  )PRODUCT order by  DISPLAYCODE", commonconn);
            adp.Fill(dtbary[2]);


            //跳動點檔
            adp = new SqlDataAdapter("select * from TICKDATA ", commonconn);
            adp.Fill(dtbary[3]);

            //委託狀態檔
            adp = new SqlDataAdapter(" select  *  from ERRORMAPPING ", commonconn);
            adp.Fill(dtbary[4]);


            //系統時間
            adp = new SqlDataAdapter("    select convert(char(8),getdate(),108) NOWTIME,convert(char(8),getdate(),112)NOWDATE,CLEARTIME  FROM DAVIPCONFIGDB.dbo.SERVERSET ", conn);
            adp.Fill(dtbary[5]);



            for (int Index = 0; Index < dtbary.Length; Index++)
            {
                ds_Product.Tables.Add(dtbary[Index]);
            }
            //ds_Product.WriteXml(@"c:\ini_data.xml");
            //ds_Product.WriteXmlSchema(@"c:\ini_Schema.xml");
            return CommonFunction.zipdata(ds_Product);
            // return "astring";
        }



        [WebMethod]
        public byte[] WS_USERINI(string UserId)
        {
            //  新增login記錄
            string strLogTime = DateTime.Now.ToString("HH:mm:ss.fff");
            string strLogDate = DateTime.Now.ToString("yyyyMMdd");



            string strLogOutDate = DateTime.Now.ToString("yyyyMMdd");
            string strLogOutTime = DateTime.Now.ToString("HH:mm:ss.fff");
            MySqlCommand cmd = new MySqlCommand();
            string sqlcmd = @"insert into USER_SESSION_LOG  (USERID,LOGIN_DATE,LOGIN_TIME,LOGIN_IP,STATUS) 
        values(@USERID,@LOGIN_DATE,@LOGIN_TIME ,@LOGIN_IP,'0')";
            cmd.Parameters.AddWithValue("@USERID", UserId);
            cmd.Parameters.AddWithValue("@LOGIN_DATE", strLogDate);
            cmd.Parameters.AddWithValue("@LOGIN_TIME", strLogTime);
            cmd.Parameters.AddWithValue("@LOGIN_IP", CommonFunction.GetIpAddress());


            bool ret = runExecuteNonQueryForParam(sqlcmd, cmd.Parameters);




            DataSet ds_Product = new DataSet();
            DataTable[] dtbary = new DataTable[8] { new DataTable("ServerSet"), new DataTable("CollectionSet"), new DataTable("FORM_SET"), new DataTable("ProgramSet"), new DataTable("user_hotkeyset"), new DataTable("InfoTradeSet"), new DataTable("GRID_SET"), new DataTable("LogInfo") };


            //定義GROUP =A 為預設值 
            //使用者連線設定
            cmd = new MySqlCommand();
            sqlcmd = @"SELECT USERID,TYPE,SEQ,SERVERIP,SERVERPORT,SERVERDSC,ISDEFAULT,SORTNO  from USER_SERVER_SET where USERID=@USERID union all select @USERID USERID ,TYPE,SEQ,SERVERIP,SERVERPORT,SERVERDSC,ISDEFAULT,SORTNO from DEFAULT_SERVER_SET where  GROUPID='DEFAULT' 
   AND TYPE not in( SELECT distinct TYPE  from USER_SERVER_SET where USERID=@USERID)";
            cmd.Parameters.AddWithValue("@USERID", UserId);
            runExecuteQueryForParam(sqlcmd, cmd.Parameters, ref   dtbary[0]);

            //使用者版面設定
            cmd = new MySqlCommand();
            sqlcmd = @"select * from COLLECTION_SET  where USERID=@USERID order by ISDEFUALT";
            cmd.Parameters.AddWithValue("@USERID", UserId);
            runExecuteQueryForParam(sqlcmd, cmd.Parameters, ref   dtbary[1]);

            //視窗樣式設定檔
            cmd = new MySqlCommand();
            sqlcmd = @" select  COLLECT_ID,PROG_NAME,SET_NAME,SET_VALUE,TYPE from USER_FORM_SET where USERID=@USERID
                union all select ''COLLECT_ID,PROG_NAME,SET_NAME,SET_VALUE,TYPE from DEFAULT_FORM_SET ";
            cmd.Parameters.AddWithValue("@USERID", UserId);
            runExecuteQueryForParam(sqlcmd, cmd.Parameters, ref   dtbary[2]);

            //程式設定檔

            cmd = new MySqlCommand();
            sqlcmd = @" select AUT_MODULE_MASTER.MOD_DESC,AUT_MODULE_MASTER.SEQ MOD_SEQ,AUT_MENU_CONTROL.MODID
,AUT_PROGRAM.PROG_NAME,AUT_MENU_CONTROL.SEQ,AUT_PROGRAM.PROG_DESC,AUT_PROGRAM.REMARK,AUT_PROGRAM.CLASS
,AUT_PROGRAM.MULTIFORM from (select  PROG_NAME from AUT_BY_USER where USERID=@USERID and STATUS='1'
union all select  PROG_NAME from AUT_BY_DEFAULT where ( select COUNT(USERID) from AUT_BY_USER 
where USERID=@USERID and STATUS='1')=0) AUT_BY_USER inner join (select * from AUT_MENU_CONTROL where STATUS='1') 
AUT_MENU_CONTROL on AUT_BY_USER.PROG_NAME = AUT_MENU_CONTROL.PROG_NAME inner join (select * from AUT_PROGRAM where STATUS='1') 
AUT_PROGRAM on AUT_MENU_CONTROL.PROG_NAME =AUT_PROGRAM.PROG_NAME 
inner join (select * from AUT_MODULE_MASTER where STATUS='1')AUT_MODULE_MASTER on AUT_MENU_CONTROL.MODID  =AUT_MODULE_MASTER.MODID order by AUT_MODULE_MASTER.SEQ  ,AUT_MENU_CONTROL.SEQ  ";
            cmd.Parameters.AddWithValue("@USERID", UserId);
            runExecuteQueryForParam(sqlcmd, cmd.Parameters, ref  dtbary[3]);


            //使用者快速鍵

            cmd = new MySqlCommand();
            sqlcmd = @" select  *  from USER_HOTKEYS_SET where USERID=@USERID ";
            cmd.Parameters.AddWithValue("@USERID", UserId);
            runExecuteQueryForParam(sqlcmd, cmd.Parameters, ref  dtbary[4]);

            //報價下單夾設定

            cmd = new MySqlCommand();
            sqlcmd = @" select  *  from INFOTRADE_SET where USERID=@USERID ";
            cmd.Parameters.AddWithValue("@USERID", UserId);
            runExecuteQueryForParam(sqlcmd, cmd.Parameters, ref   dtbary[5]);


            //表格欄位設定檔
            cmd = new MySqlCommand();
            sqlcmd = @" select  COLLECT_ID,PROG_NAME,GRID_NAME,COLUMN_NAME,HEADER_TEXT,WIDTH,DISPLAY_INDEX,VISIBLE
,TAB,SORT,TYPE from USER_GRID_SET  where USERID=@USERID  union all select  '' COLLECT_ID,PROG_NAME
,GRID_NAME,COLUMN_NAME,HEADER_TEXT,WIDTH,DISPLAY_INDEX,VISIBLE,TAB,SORT,TYPE from DEFAULT_GRID_SET     ";
            cmd.Parameters.AddWithValue("@USERID", UserId);
            runExecuteQueryForParam(sqlcmd, cmd.Parameters, ref   dtbary[6]);

            //登入資訊
            dtbary[7].Columns.Add("LogDate");

            dtbary[7].Columns.Add("LogTime");
            dtbary[7].Rows.Add(new object[] { strLogDate, strLogTime });


            for (int Index = 0; Index < dtbary.Length; Index++)
            {
                ds_Product.Tables.Add(dtbary[Index]);
            }
            return CommonFunction.zipdata(ds_Product);
            // return "astring";
        }


        [WebMethod]
        public bool WS_saveLogOut(string userID, string logDate, string logTime)
        {

            MySqlCommand cmd = new MySqlCommand();

            string strLogOutDate = DateTime.Now.ToString("yyyyMMdd");
            string strLogOutTime = DateTime.Now.ToString("HH:mm:ss.fff");

            string sqlcmd = @"update USER_SESSION_LOG set LOGOUT_DATE=@LOGOUT_DATE
                ,LOGOUT_TIME=@LOGOUT_TIME ,STATUS='1'
            where USERID=@USERID and LOGIN_DATE=@LOGIN_DATE
            and LOGIN_TIME=@LOGIN_TIME ";
            cmd.Parameters.AddWithValue("@LOGOUT_DATE", strLogOutDate);
            cmd.Parameters.AddWithValue("@LOGOUT_TIME", strLogOutTime);
            cmd.Parameters.AddWithValue("@USERID", userID);
            cmd.Parameters.AddWithValue("@LOGIN_DATE", logDate);
            cmd.Parameters.AddWithValue("@LOGIN_TIME", logTime);



            bool ret = runExecuteNonQueryForParam(sqlcmd, cmd.Parameters);


            return ret;
        }

        private void runExecuteQueryForParam(string sqlCommand
         , MySqlParameterCollection listsp, ref DataTable ddt)
        {
            bool bolSuccess = true;
            try
            {

                MySqlConnection conn = new MySqlConnection(_ConfigConnection);
                MySqlCommand cmd = new MySqlCommand(sqlCommand, conn);
                foreach (MySqlParameter sp in listsp)
                {
                    cmd.Parameters.Add(sp);
                }
                MySqlDataAdapter Adapter = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                Adapter.Fill(ddt);

            }
            catch (Exception ex)
            {

            }
            finally
            {


            }


        }



        private bool runExecuteNonQueryForParam(string sqlCommand
            , MySqlParameterCollection listsp)
        {
            bool bolSuccess = true;

            MySqlConnection conn = new MySqlConnection(_ConfigConnection);

            MySqlTransaction trans = null;
            MySqlCommand cmd = null;
            int idxCurrent = 0;
            try
            {
                try
                {
                    conn.Open();
                }
                catch (Exception exConnect)
                {
                    throw exConnect;
                }

                trans = conn.BeginTransaction();

                cmd = conn.CreateCommand();

                cmd.Connection = conn;

                cmd.CommandType = CommandType.Text;

                cmd.Transaction = trans;

                if (!sqlCommand.Trim().Equals(""))
                {
                    // set SQL Statement to OracleCommand Object
                    cmd.CommandText = sqlCommand;

                    foreach (MySqlParameter sp in listsp)
                    {
                        cmd.Parameters.Add(sp);
                    }

                    // exectue (run)
                    int intRecordsAffected = cmd.ExecuteNonQuery();


                }

                trans.Commit();
                // set retrun DataTable :: info
            }
            catch (Exception ex)
            {
                try
                {
                    if (trans != null)
                    {
                        trans.Rollback();
                    }
                    using (EventLog eventLog = new EventLog("Application"))
                    {
                        eventLog.Source = "Application";
                        eventLog.WriteEntry(ex.Message, EventLogEntryType.Error, 999, 1);
                    }
                }
                catch (Exception oleEx)
                {
                    /// throw oleEx;
                }
                //throw ex;
                bolSuccess = false;
            }
            finally
            {
                if (trans != null)
                {
                    trans = null;
                }
                if (cmd != null)
                {
                    cmd.Dispose();
                    cmd = null;
                }
                if (conn != null)
                {
                    conn.Close();
                    conn = null;
                }

            }


            conn = new MySqlConnection(_ConfigConnectionBak);

            trans = null;
            cmd = null;
            idxCurrent = 0;
            try
            {
                try
                {
                    conn.Open();
                }
                catch (Exception exConnect)
                {
                    throw exConnect;
                }

                trans = conn.BeginTransaction();

                cmd = conn.CreateCommand();

                cmd.Connection = conn;

                cmd.CommandType = CommandType.Text;

                cmd.Transaction = trans;

                if (!sqlCommand.Trim().Equals(""))
                {
                    // set SQL Statement to OracleCommand Object
                    cmd.CommandText = sqlCommand;

                    foreach (MySqlParameter sp in listsp)
                    {
                        cmd.Parameters.Add(sp);
                    }

                    // exectue (run)
                    int intRecordsAffected = cmd.ExecuteNonQuery();


                }

                trans.Commit();
                // set retrun DataTable :: info
            }
            catch (Exception ex)
            {
                try
                {
                    if (trans != null)
                    {
                        trans.Rollback();
                    }
                    using (EventLog eventLog = new EventLog("Application"))
                    {
                        eventLog.Source = "Application";
                        eventLog.WriteEntry(ex.Message, EventLogEntryType.Error, 999, 1);
                    }
                }
                catch (Exception oleEx)
                {
                    /// throw oleEx;
                }
                //throw ex;
                bolSuccess = false;
            }
            finally
            {
                if (trans != null)
                {
                    trans = null;
                }
                if (cmd != null)
                {
                    cmd.Dispose();
                    cmd = null;
                }
                if (conn != null)
                {
                    conn.Close();
                    conn = null;
                }

            }
            return bolSuccess;

        }


        [WebMethod]
        public byte[] WS_GetClearDataTime()
        {
            //  新增login記錄


            DataSet ds_Product = new DataSet();
            DataTable[] dtbary = new DataTable[2] { new DataTable("ServerDateTime"), new DataTable("ClearDataTime") };

            dtbary[0].Columns.Add("ServerDateTime");
            dtbary[0].Rows.Add(new object[] { DateTime.Now.ToString("yyyyMMddHHmmssfff") });

            string cleartime = ConfigurationSettings.AppSettings["ClearDataTime"];

            dtbary[1].Columns.Add("ClearDataTime");
            dtbary[1].Rows.Add(new object[] { cleartime });


            for (int Index = 0; Index < dtbary.Length; Index++)
            {
                ds_Product.Tables.Add(dtbary[Index]);
            }
            return CommonFunction.zipdata(ds_Product);
            // return "astring";
        }

        public static string GetIpAddress()
        {
            string strIpAddr = string.Empty;

            if (HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"] == null || HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"].IndexOf("unknown") > 0)
            {
                strIpAddr = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
            }
            else if (HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"].IndexOf(",") > 0)
            {
                strIpAddr = HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"].Substring(1, HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"].IndexOf(",") - 1);
            }
            else if (HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"].IndexOf(";") > 0)
            {
                strIpAddr = HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"].Substring(1, HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"].IndexOf(";") - 1);
            }
            else
            {
                strIpAddr = HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            }
            return strIpAddr; ;
        }




        [WebMethod]
        public bool WS_TransferData(string mode, string tradedate, string hh, string mm, string ss, string ms)
        {

            try
            {

                MySqlCommand cmd = new MySqlCommand();

                MySql.Data.MySqlClient.MySqlConnection MySqlConnection = new MySql.Data.MySqlClient.MySqlConnection(_TradeConfigConnection);
                MySqlCommand MySqlCommand = new MySql.Data.MySqlClient.MySqlCommand();
                MySqlCommand.CommandTimeout = 600;
                MySqlCommand.CommandType = CommandType.StoredProcedure;
                MySqlCommand.Connection = MySqlConnection;
                MySqlCommand.Connection.Open();
                MySqlCommand.CommandText = "TransferData";

                MySqlCommand.Parameters.AddWithValue("@p_mode", mode);
                MySqlCommand.Parameters.AddWithValue("@p_tradedate", tradedate);

                MySqlCommand.Parameters.AddWithValue("@p_HH", hh);
                MySqlCommand.Parameters.AddWithValue("@p_mm", mm);
                MySqlCommand.Parameters.AddWithValue("@p_ss", ss);
                MySqlCommand.Parameters.AddWithValue("@p_ms", ms);
                int ret = MySqlCommand.ExecuteNonQuery();




                if (ret > 0)
                    return true;
                else
                    return false;
            }
            catch (Exception ex)
            {
                using (EventLog eventLog = new EventLog("Application"))
                {
                    eventLog.Source = "Application";
                    eventLog.WriteEntry("WS_TransferData =" + ex.Message, EventLogEntryType.Error, 999, 1);
                }



                return false;
            }
        }


        [WebMethod]
        public bool WS_TransferDataUpload(string mode, string tradedate, string hh, string mm, string ss, string fff)
        {

            try
            {
                string matchtime = hh.PadRight(2, '0') + mm.PadRight(2, '0') + ss.PadRight(2, '0') + fff.PadRight(3, '0');

                MySqlCommand cmd = new MySqlCommand();

                MySql.Data.MySqlClient.MySqlConnection MySqlConnection = new MySql.Data.MySqlClient.MySqlConnection(_TradeConfigConnection);
                MySqlCommand MySqlCommand = new MySql.Data.MySqlClient.MySqlCommand();
                MySqlCommand.CommandTimeout = 600;

                MySqlCommand.Connection = MySqlConnection;
                MySqlCommand.Connection.Open();
                MySqlCommand.CommandText = @"update transmatch set UPLOAD='Y' 
                where tradedate=@tradedate and UPLOAD='N' " + (mode == "2" ? " and  matchtime<=@matchtime" : "");

                MySqlCommand.Parameters.AddWithValue("@tradedate", tradedate);
                if (mode == "2")
                {
                    MySqlCommand.Parameters.AddWithValue("@matchtime", matchtime);
                }
                int ret = MySqlCommand.ExecuteNonQuery();




                if (ret > 0)
                    return true;
                else
                    return false;
            }
            catch (Exception ex)
            {
                using (EventLog eventLog = new EventLog("Application"))
                {
                    eventLog.Source = "Application";
                    eventLog.WriteEntry("WS_TransferDataUpload =" + ex.Message, EventLogEntryType.Error, 999, 1);
                }



                return false;
            }
        }



        [WebMethod]
        public bool WS_Upload(string mode, string tradedate, string hh, string mm, string ss, string fff)
        {


            try
            {
                string matchtime = hh.PadRight(2, '0') + mm.PadRight(2, '0') + ss.PadRight(2, '0') + fff.PadRight(3, '0');

                if (mode == "1")
                {
                }
                else if (mode == "2")
                {
                }


                DataSet dsProduct = new DataSet();
                DataTable dtData = new DataTable();
                MySqlConnection conn = new MySqlConnection(_TradeConfigConnection);
                string sql = @"select a.tradedate,a.MATCHTIME,a.orderid,a.investoracno,a.securityexchange

 ,(case when  b.code is null then a.symbol1 when  b.code ='' then a.symbol1  else b.code end)symbol1
,a.MATURITYMONTHYEAR1,a.STRIKEPRICE1
,a.PUTORCALL1,a.BS,a.MATCHQTY,a.MATCHPRICE,a.EXECID,a.subact ,ifnull(b.gw,'') gw,ifnull(b.locator,0)locator

 from  transmatch a left join  (select distinct securityexchange,SecurityType,Symbol1
,MaturityMonthYear1,StrikePrice1,PutOrCall1,gw,locator,code from psglfconfigdb.securitylist where    IFNULL(Symbol2,'')='')b
 on (  a.SECURITYEXCHANGE=b.SecurityExchange and a.SECURITYTYPE1=b.SecurityType
 and a.SYMBOL1=b.Symbol1 and a.MATURITYMONTHYEAR1=b.MaturityMonthYear1
 and a.STRIKEPRICE1=b.StrikePrice1
 and a.PUTORCALL1=b.PutOrCall1)
 
 where tradedate=@tradedate and UPLOAD='N' " + (mode == "2" ? " and  matchtime<=@matchtime" : "") +

 @" order by a.tradedate asc ,a.MATCHTIME asc ,a.orderid asc,a.bs asc,a.execid asc";
                MySqlCommand cmd = new MySqlCommand();

                cmd.Parameters.AddWithValue("@tradedate", tradedate);
                if (mode == "2")
                {
                    cmd.Parameters.AddWithValue("@matchtime", matchtime);
                }
                cmd.CommandText = sql;
                cmd.Connection = conn;



                MySqlDataAdapter adp;
                //使用者連線設定
                adp = new MySqlDataAdapter(cmd);

                adp.Fill(dtData);

                if (dtData.Rows.Count == 0) return false;

                StringBuilder sb = new StringBuilder();
                string data = "";
                DataTable dtDic = dtData.DefaultView.ToTable(true, "gw");
                StreamWriter[] sw = new System.IO.StreamWriter[dtDic.Rows.Count];
                MemoryStream[] ms = new MemoryStream[dtDic.Rows.Count];

                for (int i = 0; i < dtDic.Rows.Count; i++)
                {
                    ms[i] = new MemoryStream();
                    sw[i] = new System.IO.StreamWriter(ms[i], Encoding.Default);
                }
                try
                {

                    foreach (DataRow dr in dtData.Rows)
                    {



                        data = string.Format("{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14},{15},{16}"
                                                 , date2as400(dr["tradedate"].ToString().Trim())
                                                 , dr["orderid"].ToString().Trim()
                                                 , dr["investoracno"].ToString().Trim()
                                                 , dr["securityexchange"].ToString().Trim()
                                                 , dr["symbol1"].ToString().Trim()
                                                 , Maturity2as400(dr["MATURITYMONTHYEAR1"].ToString().Trim())
                                                 , dr["PUTORCALL1"].ToString().Trim() == "" ? " " : decimal.Parse(dr["STRIKEPRICE1"].ToString().Trim()).ToString("#.#########")
                                                 , dr["PUTORCALL1"].ToString().Trim() == "" ? " " : dr["PUTORCALL1"].ToString().Trim()
                                                 , dr["BS"].ToString().Trim().Trim()
                                                 , dr["MATCHQTY"].ToString().Trim()
                                               //  , (decimal.Parse(dr["MATCHPRICE"].ToString().Trim())  ).ToString("#.#########")
                                                 , GetRealPrice(dr["MATCHPRICE"].ToString().Trim(),int.Parse( dr["locator"].ToString().Trim())).ToString("0.#########")
                                                 , " "
                                                 , " "
                                                   , date2as400(dr["tradedate"].ToString().Trim())
                                                    , time2as400(dr["MATCHTIME"].ToString().Trim())
                                                    , dr["subact"].ToString().Trim() == "" ? " " : dr["subact"].ToString().Trim()
                                                 , dr["EXECID"].ToString().Trim()

                                                 );

                        for (int i = 0; i < dtDic.Rows.Count; i++)
                        {
                            if (dtDic.Rows[i]["gw"].ToString().Trim() == dr["gw"].ToString().Trim())
                            {
                                sw[i].WriteLine(data);
                                sw[i].Flush();
                            }
                        }

                    }
                    for (int i = 0; i < dtDic.Rows.Count; i++)
                    {
                        ms[i].Position = 0;
                        string file = dtDic.Rows[i]["gw"].ToString().Trim() + DateTime.Now.ToString("yyyyMMdd") + "_P" + ".txt";
                        ftpUpload(ms[i], file);
                    }

                    WS_TransferDataUpload(mode, tradedate, hh, mm, ss, fff);
                }
                catch (Exception ex)
                {
                }
                finally
                {
                    for (int i = 0; i < dtDic.Rows.Count; i++)
                    {
                        sw[i].Close();
                        ms[i].Close();
                    }
                }





                return true;

            }
            catch (Exception ex)
            {
                using (EventLog eventLog = new EventLog("Application"))
                {
                    eventLog.Source = "Application";
                    eventLog.WriteEntry("WS_Upload =" + ex.Message, EventLogEntryType.Error, 999, 1);
                }

                return false;
            }
            finally
            {

            }

            return false;
        }
        public decimal GetRealPrice(string price, int locator)
        {
            decimal ret = 0;
            try
            {
                decimal decimalplace = (int)Math.Pow(10, locator);

                ret =   decimal.Parse(  price) / decimalplace  ;

            }
            catch (Exception ex)
            {

            }
            return ret;
        }

        private string Maturity2as400(string date)
        {//201610 to 102016
            string ret = "";
            try
            {
                ret = date.Substring(4, 2) + date.Substring(0, 4);
            }
            catch (Exception ex)
            {
                return date;
            }
            return ret;
        }
        private string date2as400(string date)
        {//20161019 to 10/19/2016
            string ret = "";
            try
            {
                ret = date.Substring(4, 2) + "/" + date.Substring(6, 2) + "/" + date.Substring(0, 4);
            }
            catch (Exception ex)
            {
                return date;
            }
            return ret;
        }
        private string time2as400(string time)
        {
            //HHmmssfff to HH:mm:ss
            string ret = "";
            try
            {
                ret = time.Substring(0, 2) + ":" + time.Substring(2, 2) + ":" + time.Substring(4, 2);
            }
            catch (Exception ex)
            {
                return time;
            }
            return ret;
        }


        private bool ftpUpload(string path, string fileName, string uploadUrl, string uploadFileName)
        {

            Stream requestStream = null;
            FileStream fileStream = null;
            FtpWebResponse uploadResponse = null;
            try
            {
                string UserName = ConfigurationSettings.AppSettings["FTP_User"];
                string Password = ConfigurationSettings.AppSettings["FTP_Pwd"];


                FtpWebRequest uploadRequest = (FtpWebRequest)WebRequest.Create(uploadUrl + "/" + uploadFileName);


                uploadRequest.Method = WebRequestMethods.Ftp.UploadFile;

                uploadRequest.Proxy = null;
                uploadRequest.KeepAlive = false;

                uploadRequest.Credentials = new NetworkCredential(UserName, Password);


                requestStream = uploadRequest.GetRequestStream();

                fileStream = File.Open(path + "\\" + fileName, FileMode.Open);




                byte[] buffer = new byte[1024];
                int bytesRead;

                while (true)
                {

                    bytesRead = fileStream.Read(buffer, 0, buffer.Length);
                    if (bytesRead == 0)
                        break;
                    requestStream.Write(buffer, 0, bytesRead);
                }

                requestStream.Close();
                requestStream.Dispose();
                uploadResponse = (FtpWebResponse)uploadRequest.GetResponse();
                uploadResponse.Close();

                return true;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message + ex.StackTrace);
            }

            finally
            {
                if (uploadResponse != null)
                    uploadResponse.Close();
                if (fileStream != null)
                    fileStream.Close();
                if (requestStream != null)
                    requestStream.Close();
            }

        }

        private bool ftpUpload(MemoryStream mem, string filename)
        {

            Stream requestStream = null;

            FtpWebResponse uploadResponse = null;
            try
            {
                string uploadUrl = "ftp://" + ConfigurationSettings.AppSettings["FTP_IP"] + ConfigurationSettings.AppSettings["FTP_DIR"];

                string uploadFileName = filename;




                string UserName = ConfigurationSettings.AppSettings["FTP_User"];
                string Password = ConfigurationSettings.AppSettings["FTP_Pwd"];


                FtpWebRequest uploadRequest = (FtpWebRequest)WebRequest.Create(uploadUrl + "/" + uploadFileName);


                uploadRequest.Method = WebRequestMethods.Ftp.UploadFile;

                uploadRequest.Proxy = null;
                uploadRequest.KeepAlive = false;

                uploadRequest.Credentials = new NetworkCredential(UserName, Password);


                requestStream = uploadRequest.GetRequestStream();






                byte[] buffer = new byte[1024];
                int bytesRead;

                while (true)
                {

                    bytesRead = mem.Read(buffer, 0, buffer.Length);
                    if (bytesRead == 0)
                        break;
                    requestStream.Write(buffer, 0, bytesRead);
                }

                requestStream.Close();
                requestStream.Dispose();
                uploadResponse = (FtpWebResponse)uploadRequest.GetResponse();
                uploadResponse.Close();

                return true;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message + ex.StackTrace);
            }

            finally
            {
                if (uploadResponse != null)
                    uploadResponse.Close();

                if (requestStream != null)
                    requestStream.Close();
            }

        }









        [WebMethod]
        public string GetVersion()
        {
            try
            {
                DataSet dsData = new DataSet();
                string strPath = AppDomain.CurrentDomain.BaseDirectory.ToString().TrimEnd() + "\\Update.xml";
                dsData.ReadXml(strPath);

                XmlDocument doc = new XmlDocument();
                doc.Load(strPath);
                string Version = "V" + doc.SelectSingleNode("files").Attributes["Version"].Value;

                XmlDocument ret = new XmlDocument();
                XmlElement root = ret.CreateElement("files");
                XmlAttribute a = ret.CreateAttribute("Version");
                a.Value = Version;
                root.Attributes.Append(a);
                bool Enforce = false;

                Enforce = bool.Parse(doc.SelectSingleNode("files").Attributes["Enforce"].Value);

                XmlAttribute b = ret.CreateAttribute("Enforce");
                b.Value = Enforce.ToString();
                root.Attributes.Append(b);
                string path = AppDomain.CurrentDomain.BaseDirectory.ToString().TrimEnd() + "file\\";
                string[] fileEntries = Directory.GetFiles(path, "*", SearchOption.AllDirectories);

                foreach (string fileName in fileEntries)
                {
                    FileInfo fi = new FileInfo(fileName);
                    XmlAttribute d = ret.CreateAttribute("Directory");
                    d.Value = fileName.Replace(path, "").Replace("\\" + fi.Name, "");
                    if (d.Value != Version) continue;
                    XmlElement ele = ret.CreateElement("file");
                    ele.Attributes.Append(d);
                    ele.InnerText = fi.Name;
                    root.AppendChild(ele);
                }
                ret.AppendChild(root);
                return ret.OuterXml;
            }
            catch (Exception ex)
            {
            }
            return "";
        }


        [WebMethod]
        public byte[] DownLoadFile(string file)
        {
            try
            {
                DataSet dsData = new DataSet();
                string path = AppDomain.CurrentDomain.BaseDirectory.ToString().TrimEnd() + "file\\" + file;
                FileStream fs = File.OpenRead(path);
                BinaryReader br = new BinaryReader(fs);
                byte[] g = br.ReadBytes((int)fs.Length);
                byte[] gd = CommonFunction.Compress(g, 0, g.Length);

                br.Close();
                fs.Close();

                return gd;

            }
            catch (Exception ex)
            {
            }
            return null;
        }


    }



}