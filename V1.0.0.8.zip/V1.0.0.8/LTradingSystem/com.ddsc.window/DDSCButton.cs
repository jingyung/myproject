﻿namespace com.ddsc.tool.window
{
    using System.Windows.Forms;

    public class DDSCButton : Button
    {
    }
}

