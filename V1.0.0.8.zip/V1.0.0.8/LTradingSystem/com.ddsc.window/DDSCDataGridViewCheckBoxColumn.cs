﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;
using System.Windows.Forms.VisualStyles;
namespace com.ddsc.tool.window
{
    public class DDSCCheckBoxColumnHeaderCell : DataGridViewColumnHeaderCell
    {
        public bool CheckBoxAllCheckedState { get; set; }
        private Point HeaderCellCheckBoxLocation { get; set; }
        private Size HeaderCellCheckBoxSize { get; set; }
        private Point HeaderCellLocation { get; set; }

        public DDSCCheckBoxColumnHeaderCell(bool DefaultValue)
        {
            CheckBoxAllCheckedState = DefaultValue;
            HeaderCellLocation = new Point();
        }

        private CheckBoxState Bool2CheckBoxState(bool CheckedState)
        {
            CheckBoxState result = CheckBoxState.UncheckedNormal;

            if (CheckedState == true)
                return CheckBoxState.CheckedNormal;

            return result;
        }

        protected override void Paint(
            Graphics graphics,
            Rectangle clipBounds,
            Rectangle cellBounds,
            int rowIndex,
            DataGridViewElementStates dataGridViewElementState,
            object value,
            object formattedValue,
            string errorText,
            DataGridViewCellStyle cellStyle,
            DataGridViewAdvancedBorderStyle advancedBorderStyle,
            DataGridViewPaintParts paintParts)
        {
            base.Paint(graphics, clipBounds, cellBounds, rowIndex, dataGridViewElementState, value, formattedValue, errorText, cellStyle, advancedBorderStyle, paintParts);

            // HeaderCellCheckBox 大小
            Size s = CheckBoxRenderer.GetGlyphSize(graphics, CheckBoxState.UncheckedNormal);
            // HeaderCellCheckBox 位置
            Point p = new Point();
            p.X = cellBounds.Location.X + (cellBounds.Width / 2) - (s.Width / 2);
            p.Y = cellBounds.Location.Y + (cellBounds.Height / 2) - (s.Height / 2);

            // 把相關資訊記錄到 Property 上，方便後續使用
            HeaderCellLocation = cellBounds.Location;
            HeaderCellCheckBoxLocation = p;
            HeaderCellCheckBoxSize = s;

            CheckBoxRenderer.DrawCheckBox(graphics, HeaderCellCheckBoxLocation, Bool2CheckBoxState(CheckBoxAllCheckedState));
        }

        protected override void OnMouseClick(DataGridViewCellMouseEventArgs e)
        {
            // 變數 p 是指 Click 位置
            Point p = new Point(e.X + HeaderCellLocation.X, e.Y + HeaderCellLocation.Y);
            if (p.X >= HeaderCellCheckBoxLocation.X &&
                p.X <= HeaderCellCheckBoxLocation.X + HeaderCellCheckBoxSize.Width &&
                p.Y >= HeaderCellCheckBoxLocation.Y &&
                p.Y <= HeaderCellCheckBoxLocation.Y + HeaderCellCheckBoxSize.Height)
            {
                CheckBoxAllCheckedState = !CheckBoxAllCheckedState;
                OnCheckBoxAll(new CheckBoxAllEventArgs(CheckBoxAllCheckedState));
            }

            base.OnMouseClick(e);
        }

        public event CheckBoxAllEventHandler CheckBoxAll;
        protected virtual void OnCheckBoxAll(CheckBoxAllEventArgs e)
        {
            if (CheckBoxAll != null)
                CheckBoxAll(this, e);
        }
    }

    public class CheckBoxAllEventArgs : EventArgs
    {
        public bool CheckedState { get; set; }
        public CheckBoxAllEventArgs(bool CheckedState = false)
        {
            this.CheckedState = CheckedState;
        }
    }

    public delegate void CheckBoxAllEventHandler(object sender, CheckBoxAllEventArgs e);

    public class DDSCDataGridViewCheckBoxColumn : DataGridViewCheckBoxColumn
    {
        public DDSCDataGridViewCheckBoxColumn(bool DisplayCheckBox)
        {
            if (DisplayCheckBox)
            {
                DDSCCheckBoxColumnHeaderCell HeaderCell = new DDSCCheckBoxColumnHeaderCell(false);
                this.HeaderCell = HeaderCell;
                HeaderCell.CheckBoxAll += new CheckBoxAllEventHandler(HeaderCell_CheckBoxAll);
            }
        }
     
       
        void HeaderCell_CheckBoxAll(object sender, CheckBoxAllEventArgs e)
        {
            CheckBoxAllSetColumnCheckedState(e.CheckedState);
            DataGridView.Refresh();
        }
        //public void SetCheckBoxAllCheckedState()
        //{
        //    if ((this.HeaderCell is DDSCCheckBoxColumnHeaderCell) == false) return;

        //    DDSCCheckBoxColumnHeaderCell HeaderCell = this.HeaderCell as DDSCCheckBoxColumnHeaderCell;
        //    if (HeaderCell == null) return;

        //    HeaderCell.CheckBoxAllCheckedState = ColumnCheckedStateCountEqualRowCount();
        //    // 利用 Refresh() 觸發 HeaderCell 內的 Paint Event 重繪 CheckBox 狀態，
        //    // 原想說是否可以縮小 Refresh 單位，只針對 HeaderCell 或 Column，
        //    // 但 CellHeader 和 Columm 並不是從 Control Class 繼承來的，
        //    // 沒有 Refresh() 可以使用
          
        //}
        //private bool ColumnCheckedStateCountEqualRowCount()
        //{
        //    bool result = false;
        //    if (DataGridView == null) return result;

        //    if (DataGridView.Rows.Count == ColumnCheckedStateCount())
        //        result = true;

        //    return result;
        //}
        //private int ColumnCheckedStateCount()
        //{
        //    int result = 0;
        //    if (this.DataGridView == null) return result;
        //    DataGridView.EndEdit();
        //    foreach (DataGridViewRow dvr in this.DataGridView.Rows)
        //    {
        //        if (dvr.Cells[Index].Value == null)
        //            result++;
        //        else if ((bool)dvr.Cells[Index].Value == true)
        //            result++;
        //    }
        //    //      result = this.DataGridView.Rows
        //    //.OfType<DataGridViewRow>()
        //    //.Where(r => (bool)r.Cells[Index].EditedFormattedValue == true)
        //    //.Count();


        //    return result;
        //}
        public void CheckBoxAllSetColumnCheckedState(bool CheckedState)
        {
            // 避免 Focus 的資料，因為楚於 EditMode 狀態，而在 UI 沒有正確顯示是否勾選             
            DataGridView.EndEdit();
    
            foreach (DataGridViewRow Row in DataGridView.Rows)
                Row.Cells[Index].Value = CheckedState;
        }
    }
}
