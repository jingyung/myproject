﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace com.ddsc.tool.window
{
    public class DDSCToolStripButton : ToolStripButton
    {
        public baseForm baseForm { get; set; }
    }
}
