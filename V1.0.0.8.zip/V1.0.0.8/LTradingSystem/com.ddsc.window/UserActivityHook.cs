﻿namespace com.ddsc.tool.window
{
    using System;
    using System.ComponentModel;
    using System.Reflection;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;
    using System.Windows.Forms;

    public class UserActivityHook
    {
        private int HC_ACTION;
        private int HC_NOREMOVE;
        private int hKeyboardHook;
        private int hMouseHook;
        private static HookProc KeyboardHookProcedure;
        private const int KF_ALTDOWN = 0x2000;
        private const int KF_DLGMODE = 0x800;
        private const int KF_EXTENDED = 0x100;
        private const int KF_MENUMODE = 0x1000;
        private const int KF_REPEAT = 0x4000;
        private const int KF_UP = 0x8000;
        private static HookProc MouseHookProcedure;
        private const byte VK_CAPITAL = 20;
        private const byte VK_CONTROL = 0x11;
        private const byte VK_MENU = 0x12;
        private const byte VK_NUMLOCK = 0x90;
        private const byte VK_SHIFT = 0x10;
        private const int WH_KEYBOARD = 2;
        private const int WH_KEYBOARD_LL = 13;
        private const int WH_MOUSE = 7;
        private const int WH_MOUSE_LL = 14;
        private const int WM_KEYDOWN = 0x100;
        private const int WM_KEYUP = 0x101;
        private const int WM_LBUTTONDBLCLK = 0x203;
        private const int WM_LBUTTONDOWN = 0x201;
        private const int WM_LBUTTONUP = 0x202;
        private const int WM_MBUTTONDBLCLK = 0x209;
        private const int WM_MBUTTONDOWN = 0x207;
        private const int WM_MBUTTONUP = 520;
        private const int WM_MOUSEMOVE = 0x200;
        private const int WM_MOUSEWHEEL = 0x20a;
        private const int WM_RBUTTONDBLCLK = 0x206;
        private const int WM_RBUTTONDOWN = 0x204;
        private const int WM_RBUTTONUP = 0x205;
        private const int WM_SYSKEYDOWN = 260;
        private const int WM_SYSKEYUP = 0x105;

        public event KeyEventHandler KeyDown;

        public event KeyPressEventHandler KeyPress;

        public event KeyEventHandler KeyUp;

        public event MouseEventHandler OnMouseActivity;

        public UserActivityHook()
        {
            this.HC_NOREMOVE = 3;
        }

        public UserActivityHook(bool InstallMouseHook, bool InstallKeyboardHook)
        {
            this.HC_NOREMOVE = 3;
            this.Start(InstallMouseHook, InstallKeyboardHook);
        }

        [DllImport("user32.dll", CallingConvention=CallingConvention.StdCall, CharSet=CharSet.Auto)]
        private static extern int CallNextHookEx(int idHook, int nCode, int wParam, IntPtr lParam);
        ~UserActivityHook()
        {
            this.Stop(true, true, false);
        }

        [DllImport("user32.dll", CallingConvention=CallingConvention.StdCall, CharSet=CharSet.Auto)]
        public static extern int GetAsyncKeyState(int key);
        [DllImport("kernel32.dll")]
        private static extern int GetCurrentThreadId();
        [DllImport("user32")]
        private static extern int GetKeyboardState(byte[] pbKeyState);
        [DllImport("user32.dll", CallingConvention=CallingConvention.StdCall, CharSet=CharSet.Auto)]
        public static extern int GetKeyState(int key);
       
        private int HiWord(int val)
        {
            return this.LoWord(val >> 0x10);
        }

        private int KeyboardHookProc(int nCode, int wParam, IntPtr lParam)
        {
            if ((nCode == this.HC_ACTION) && (((this.KeyDown != null) || (this.KeyUp != null)) || (this.KeyPress != null)))
            {
                lParam.ToInt32();
                if ((this.KeyDown != null) && (((lParam.ToInt32() >> 30) & 1) != 1))
                {
                    bool flag = GetAsyncKeyState(0x10) != 0;
                    bool flag2 = GetAsyncKeyState(0x12) != 0;
                    bool flag3 = GetAsyncKeyState(0x11) != 0;
                    Keys keys = (Keys) wParam;
                    KeyEventArgs e = null;
                    e = new KeyEventArgs(keys | (flag == true ? Keys.Shift : 0)
                        | (flag2 == true ? Keys.Alt : 0)
                        | (flag3 == true ? Keys.Control : 0));
                     
                    this.KeyDown(this, e);
                }
                if ((this.KeyUp != null) && (((lParam.ToInt32() >> 0x1f) & 1) == 1))
                {
                    bool flag4 = GetAsyncKeyState(0x10) != 0;
                    bool flag5 = GetAsyncKeyState(0x12) != 0;
                    bool flag6 = GetAsyncKeyState(0x11) != 0;
                    Keys keys2 = (Keys) wParam;
                    KeyEventArgs args2 = null;
                    args2 = new KeyEventArgs( keys2 | (flag4 == true ? Keys.Shift : 0)
                        | (flag5 == true ? Keys.Alt : 0)
                        | (flag6 == true ? Keys.Control: 0));
                    this.KeyUp(this, args2);
                }
            }
            return CallNextHookEx(this.hKeyboardHook, nCode, wParam, lParam);
        }

        private int LoWord(int val)
        {
            return (val & 0xffff);
        }

        private int MouseHookProc(int nCode, int wParam, IntPtr lParam)
        {
            if ((nCode >= 0) && (this.OnMouseActivity != null))
            {
                MouseLLHookStruct struct2 = (MouseLLHookStruct) Marshal.PtrToStructure(lParam, typeof(MouseLLHookStruct));
                MouseButtons none = MouseButtons.None;
                short delta = 0;
                switch (wParam)
                {
                    case 0x201:
                        none = MouseButtons.Left;
                        break;

                    case 0x204:
                        none = MouseButtons.Right;
                        break;

                    case 0x20a:
                        delta = (short) ((struct2.mouseData >> 0x10) & 0xffff);
                        break;
                }
                int clicks = 0;
                if (none != MouseButtons.None)
                {
                    if ((wParam == 0x203) || (wParam == 0x206))
                    {
                        clicks = 2;
                    }
                    else
                    {
                        clicks = 1;
                    }
                }
                MouseEventArgs e = new MouseEventArgs(none, clicks, struct2.pt.x, struct2.pt.y, delta);
                this.OnMouseActivity(this, e);
            }
            return CallNextHookEx(this.hMouseHook, nCode, wParam, lParam);
        }

        [DllImport("user32.dll", CallingConvention=CallingConvention.StdCall, CharSet=CharSet.Auto, SetLastError=true)]
        private static extern int SetWindowsHookEx(int idHook, HookProc lpfn, IntPtr hMod, int dwThreadId);
        public void Start(bool InstallMouseHook, bool InstallKeyboardHook)
        {
            if ((this.hMouseHook == 0) && InstallMouseHook)
            {
                MouseHookProcedure = new HookProc(this.MouseHookProc);

                this.hMouseHook = SetWindowsHookEx(WH_MOUSE, MouseHookProcedure, IntPtr.Zero, GetCurrentThreadId());
                if (this.hMouseHook == 0)
                {
                    int error = Marshal.GetLastWin32Error();
                    this.Stop(true, false, false);
                    throw new Win32Exception(error);
                }
            }
            if ((this.hKeyboardHook == 0) && InstallKeyboardHook)
            {
                KeyboardHookProcedure = new HookProc(this.KeyboardHookProc);
                this.hKeyboardHook = SetWindowsHookEx(2, KeyboardHookProcedure, IntPtr.Zero, GetCurrentThreadId());
                if (this.hKeyboardHook == 0)
                {
                    int num2 = Marshal.GetLastWin32Error();
                    this.Stop(false, true, false);
                    throw new Win32Exception(num2);
                }
            }
        }

        public void Stop()
        {
            this.Stop(true, true, true);
        }

        public void Stop(bool UninstallMouseHook, bool UninstallKeyboardHook, bool ThrowExceptions)
        {
            if ((this.hMouseHook != 0) && UninstallMouseHook)
            {
                int num = UnhookWindowsHookEx(this.hMouseHook);
                this.hMouseHook = 0;
                if ((num == 0) && ThrowExceptions)
                {
                    throw new Win32Exception(Marshal.GetLastWin32Error());
                }
            }
            if ((this.hKeyboardHook != 0) && UninstallKeyboardHook)
            {
                int num3 = UnhookWindowsHookEx(this.hKeyboardHook);
                this.hKeyboardHook = 0;
                if ((num3 == 0) && ThrowExceptions)
                {
                    throw new Win32Exception(Marshal.GetLastWin32Error());
                }
            }
        }

        [DllImport("user32")]
        private static extern int ToAscii(int uVirtKey, int uScanCode, byte[] lpbKeyState, byte[] lpwTransKey, int fuState);
        private int TransitionStateFlag(int val)
        {
            return (this.LoWord(val >> 0x10) & 0x8000);
        }

        [DllImport("user32.dll", CallingConvention=CallingConvention.StdCall, CharSet=CharSet.Auto, SetLastError=true)]
        private static extern int UnhookWindowsHookEx(int idHook);

        private delegate int HookProc(int nCode, int wParam, IntPtr lParam);

        [StructLayout(LayoutKind.Sequential)]
        private class KeyboardHookStruct
        {
            public int vkCode;
            public int scanCode;
            public int flags;
            public int time;
            public int dwExtraInfo;
        }

        [StructLayout(LayoutKind.Sequential)]
        private class MouseHookStruct
        {
            public UserActivityHook.POINT pt;
            public int hwnd;
            public int wHitTestCode;
            public int dwExtraInfo;
        }

        [StructLayout(LayoutKind.Sequential)]
        private class MouseLLHookStruct
        {
            public UserActivityHook.POINT pt;
            public int mouseData;
            public int flags;
            public int time;
            public int dwExtraInfo;
        }

        [StructLayout(LayoutKind.Sequential)]
        private class POINT
        {
            public int x;
            public int y;
        }
    }
}

