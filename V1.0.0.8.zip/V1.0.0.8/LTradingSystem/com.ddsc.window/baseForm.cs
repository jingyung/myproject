﻿
using System;
using System.ComponentModel;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
namespace com.ddsc.tool.window
{
    public class baseForm : Form
    {
        public string ID { get; set; }
        private Size _beforeSize;
        private event EventHandler FormBeforeClose;
        private event EventHandler MouseActive;
        public Form parentForm = null;

        public baseForm()
        {
            this.ID = "";
            this.DoubleBuffered = true;
            this.SetStyle(ControlStyles.SupportsTransparentBackColor |
               ControlStyles.OptimizedDoubleBuffer |
               ControlStyles.AllPaintingInWmPaint |
              ControlStyles.UserPaint |
              ControlStyles.ResizeRedraw |
              ControlStyles.DoubleBuffer, true);
            this.SetStyle(ControlStyles.Opaque, false);
        }
        protected internal void chkMDI_CheckedChanged(object sender, EventArgs e, bool owner)
        {
            Point point;
            CheckBox box = (CheckBox)sender;
            if (box.Checked)
            {
                point = base.PointToScreen(new Point(-SystemInformation.FrameBorderSize.Height, -SystemInformation.FrameBorderSize.Height - SystemInformation.CaptionHeight));
                base.MdiParent = null;
                base.Location = point;
                if (owner)
                {
                    base.Owner = this.parentForm;
                }
            }
            else
            {
                MdiClient client = new MdiClient();
                foreach (Control control in this.parentForm.Controls)
                {
                    if (control is MdiClient)
                    {
                        client = (MdiClient)control;
                        break;
                    }
                }
                if (((base.Left == 0) && (base.Top == 0)) || ((client.ClientSize.Height == 0) && (client.ClientSize.Width == 0)))
                {
                    point = new Point(0, 0);
                }
                else if ((this.parentForm.Top < base.Top) && (this.parentForm.Left < base.Left))
                {
                    point = client.PointToClient(new Point(base.Location.X, base.Location.Y));
                    if ((((point.X < 0) || (point.Y < 0)) || (point.X > client.ClientSize.Width)) || (point.Y > client.ClientSize.Height))
                    {
                        point = new Point(0, 0);
                    }
                }
                else
                {
                    point = new Point(0, 0);
                }
                base.MdiParent = this.parentForm;
                base.Location = point;
                if (owner)
                {
                    base.Owner = null;
                }
            }
            base.Invalidate();
        }

        private void InitializeComponent()
        {
            base.SuspendLayout();
            base.ClientSize = new Size(0x124, 0x111);
            base.Name = "baseForm";
            base.ResumeLayout(false);
        }

        protected override void OnActivated(EventArgs e)
        {
            base.OnActivated(e);
        }

        protected override void OnEnter(EventArgs e)
        {
            base.OnEnter(e);
        }

        protected virtual void onFormBeforeClose()
        {
            if (this.FormBeforeClose != null)
            {
                this.FormBeforeClose(this, EventArgs.Empty);
            }
        }

        protected override void OnGotFocus(EventArgs e)
        {
            base.OnGotFocus(e);
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            base.OnKeyDown(e);
        }

        protected override void OnKeyPress(KeyPressEventArgs e)
        {
            base.OnKeyPress(e);
        }

        protected override void OnKeyUp(KeyEventArgs e)
        {
            base.OnKeyUp(e);
        }

        protected override void OnLeave(EventArgs e)
        {
            base.OnLeave(e);
        }

        protected override void OnLostFocus(EventArgs e)
        {
            base.OnLostFocus(e);
        }

        protected override void OnMdiChildActivate(EventArgs e)
        {
            base.OnMdiChildActivate(e);
        }

        protected virtual void onMouseActive()
        {
            if (this.MouseActive != null)
            {
                this.MouseActive(this, EventArgs.Empty);
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
        }

        protected override void OnResize(EventArgs e)
        {
            if (base.WindowState == FormWindowState.Normal)
            {
                this._beforeSize.Width = base.Width;
                this._beforeSize.Height = base.Height;
            }
            base.OnResize(e);
        }

        protected override void OnResizeBegin(EventArgs e)
        {
            base.OnResizeBegin(e);
        }

        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);
        }

        protected override void OnSizeChanged(EventArgs e)
        {
            if (base.WindowState == FormWindowState.Normal)
            {
                this._beforeSize.Width = base.Width;
                this._beforeSize.Height = base.Height;
            }
            base.OnSizeChanged(e);
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            return base.ProcessCmdKey(ref msg, keyData);
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == 0x10)
            {
                this.onFormBeforeClose();
            }
            if (m.Msg == 0x21)
            {
                base.Focus();
                this.onMouseActive();
            }
            base.WndProc(ref m);
        }

        [Description("get BeforeSize"), Category("配置")]
        public Size BeforeSize
        {
            get
            {
                return this._beforeSize;
            }
        }
    }
}

