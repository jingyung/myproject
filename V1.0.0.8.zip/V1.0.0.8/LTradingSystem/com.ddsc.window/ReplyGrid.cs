﻿namespace com.ddsc.tool.window
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;

    public sealed class ReplyGrid : DataGridView
    {
        private List<CellValueStyle> _SetCellValueStyleList = new List<CellValueStyle>();
        private bool _specColumnHead = false;
        private static int u = 2;

        public ReplyGrid()
        {
            this.DoubleBuffered = true;
        }

        protected override void OnCellFormatting(DataGridViewCellFormattingEventArgs e)
        {
            try
            {
                if ((base.Rows.Count > 0) && (this._SetCellValueStyleList.Count > 0))
                {
                    foreach (CellValueStyle style in this._SetCellValueStyleList)
                    {
                        if (((style.ColumnName.Trim().Length > 0) && (style.Value.Trim().Length > 0)) && (base.Rows[e.RowIndex].Cells[style.ColumnName].Value.ToString() == style.Value))
                        {
                            e.CellStyle.BackColor = style.color;
                            e.CellStyle.SelectionBackColor = style.color;
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                throw exception;
            }
            base.OnCellFormatting(e);
        }

        protected override void OnCellPainting(DataGridViewCellPaintingEventArgs e)
        {
            base.OnCellPainting(e);
        }

        private void PaintHeader(DataGridViewCellPaintingEventArgs e, int i)
        {
            SolidBrush brush = new SolidBrush(base.GridColor);
            SolidBrush brush2 = new SolidBrush(e.CellStyle.BackColor);
            Pen pen = new Pen(brush);
            StringFormat format = new StringFormat();
            format.Alignment = StringAlignment.Center;
            format.LineAlignment = StringAlignment.Center;
            Rectangle cellBounds = e.CellBounds;
            e.Graphics.FillRectangle(brush2, cellBounds);
            e.Graphics.DrawLine(pen, cellBounds.Left, cellBounds.Bottom, cellBounds.Right, cellBounds.Bottom);
            e.Graphics.DrawLine(pen, cellBounds.Right, cellBounds.Top, cellBounds.Right, cellBounds.Bottom);
        }

        public bool MutiColumnHead
        {
            get
            {
                return this._specColumnHead;
            }
            set
            {
                this._specColumnHead = value;
            }
        }

        [Description("Set or get CellValueStyle"), Category("外觀")]
        public List<CellValueStyle> SetCellValueStyleList
        {
            get
            {
                return this._SetCellValueStyleList;
            }
        }
    }
}

