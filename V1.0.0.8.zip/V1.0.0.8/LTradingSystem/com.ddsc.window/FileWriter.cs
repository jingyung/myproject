﻿namespace com.ddsc.tool.window
{
    using System;
    using System.IO;
    using System.Text;
    using System.Diagnostics;
    public class Date
    {
        static DateTime now = DateTime.Now;
        static Stopwatch SW;
        private DateTime _Time;

        public DateTime Time
        {
            get
            {
                return _Time;
            }
        }
        private long _MS;

        public long MS
        {
            get { return _MS; }

        }


        public Date()
        {
            _Time = NowTime();
            _MS = NowMS();
        }
        public static long ElapsedMicroSeconds()
        {
            if (SW == null)
            {
                SW = new Stopwatch();
            }


            if (!SW.IsRunning)
            {
                now = DateTime.Now;
                SW.Reset();
                SW.Start();
            }
            return SW.ElapsedTicks * 1000000 / Stopwatch.Frequency;
        }


        public static long NowMS()
        {
            if (SW == null)
            {
                SW = new Stopwatch();
            }


            if (!SW.IsRunning)
            {
                now = DateTime.Now;
                SW.Reset();
                SW.Start();
            }

            return SW.ElapsedMilliseconds;
        }


        public static DateTime NowTime()
        {
            if (SW == null)
            {
                SW = new Stopwatch();
            }


            if (!SW.IsRunning)
            {
                now = DateTime.Now;
                SW.Reset();
                SW.Start();
            }

            DateTime boot = now + SW.Elapsed;
            return boot;
        }
    }
    public class FileWriter
    {
        private string ASTR_FileName = null;
        private string ASTR_FolderName = null;
        private object lockerForLog = new object();
        private StreamWriter sw_Log;
        private BinaryWriter writer;

        public FileWriter(string logid, string STR_FileName)
        {
            try
            {
                this.ASTR_FileName = STR_FileName;
                this.ASTR_FolderName = @"C:\Program Files\VIPTradingSystem\Log\" + DateTime.Now.ToString("yyyyMMdd") + @"\" + logid;
                if (!Directory.Exists(@"C:\Program Files\VIPTradingSystem\Log"))
                {
                    Directory.CreateDirectory(@"C:\Program Files\VIPTradingSystem\Log");
                }
                if (!Directory.Exists(this.ASTR_FolderName))
                {
                    Directory.CreateDirectory(this.ASTR_FolderName);
                }
                string path = @"C:\Program Files\VIPTradingSystem\Log\" + DateTime.Now.ToString("yyyyMMdd") + @"\" + logid + @"\" + this.ASTR_FileName + DateTime.Now.ToString("yyyyMMdd") + ".txt";
                if (File.Exists(path))
                {
                    this.sw_Log = File.AppendText(path);
                }
                else
                {
                    this.sw_Log = File.CreateText(path);
                }
                this.writer = new BinaryWriter(this.sw_Log.BaseStream);
                this.sw_Log.WriteLine(DateTime.Now.ToString("HH:mm:ss.fff") + "-Open Log File");
                this.sw_Log.Flush();
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        public void Close()
        {
            if (this.sw_Log.BaseStream != null)
            {
                this.sw_Log.Close();
            }
        }

        public void WriteLine(string lineToWrite)
        {
            try
            {
                lock (this.lockerForLog)
                {
                    if (this.sw_Log.BaseStream != null)
                    {
                        this.sw_Log.WriteLine(DateTime.Now.ToString("HH:mm:ss.fff") + "-" + lineToWrite);
                        this.sw_Log.Flush();
                    }
                }
            }
            catch (Exception)
            {
            }
        }

        public void WriteLine(byte[] lineToWrite)
        {
            try
            {
                lock (this.lockerForLog)
                {
                    if (this.sw_Log.BaseStream != null)
                    {
                        this.writer.Write(Encoding.ASCII.GetBytes(DateTime.Now.ToString("HH:mm:ss.fff") + "-"));
                        this.writer.Write(lineToWrite);
                        this.writer.Flush();
                    }
                }
            }
            catch (Exception)
            {
            }
        }
    }
}

