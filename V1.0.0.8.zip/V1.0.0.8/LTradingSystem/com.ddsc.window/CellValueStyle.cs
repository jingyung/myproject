﻿namespace com.ddsc.tool.window
{
    using System;
    using System.ComponentModel;
    using System.Drawing;

    public sealed class CellValueStyle
    {
        private Color m_color;
        private string m_ColumnName;
        private string m_Value;

        public CellValueStyle()
        {
            this.m_ColumnName = "";
            this.m_Value = "";
        }

        public CellValueStyle(string ColumnName, string Value, Color color)
        {
            this.m_ColumnName = "";
            this.m_Value = "";
            this.m_ColumnName = ColumnName;
            this.m_Value = Value;
            this.m_color = color;
        }

        [Category("屬性"), Description("Set or get color")]
        public Color color
        {
            get
            {
                return this.m_color;
            }
            set
            {
                this.m_color = value;
            }
        }

        [Category("屬性"), Description("Set or get ColumnName")]
        public string ColumnName
        {
            get
            {
                return this.m_ColumnName;
            }
            set
            {
                this.m_ColumnName = value;
            }
        }

        [Category("屬性"), Description("Set or get Value")]
        public string Value
        {
            get
            {
                return this.m_Value;
            }
            set
            {
                this.m_Value = value;
            }
        }
    }
}

