﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;
using System.Data;
using System.Windows.Forms.VisualStyles;
using System.ComponentModel;
using System.Reflection;
using System.Collections;
namespace com.ddsc.tool.window
{
    public class DDSCDataGridViewTextBoxColumn : DataGridViewTextBoxColumn
    {
        public bool SortFlag;
        ExHeaderCell headerCell = new ExHeaderCell();
        public DDSCDataGridViewTextBoxColumn()
        {
            SortFlag = true;
            ReadOnly = true;
            this.HeaderCell = headerCell;
            base.SortMode = DataGridViewColumnSortMode.Programmatic;
        }


    }
    public class ExHeaderCell : DataGridViewColumnHeaderCell
    {


        private String selectedFilterValue = String.Empty;

        private System.Collections.Specialized.OrderedDictionary filters =
    new System.Collections.Specialized.OrderedDictionary();

        private String currentColumnFilter = String.Empty;
        private static FilterListBox dropDownListBox = new FilterListBox();

        private Rectangle dropDownButtonBoundsValue = Rectangle.Empty;
        protected Rectangle DropDownButtonBounds
        {
            get
            {

                if (dropDownButtonBoundsValue == Rectangle.Empty)
                {
                    SetDropDownButtonBounds();
                }
                return dropDownButtonBoundsValue;
            }
        }
        private void SetDropDownButtonBounds()
        {

            Rectangle cellBounds =
                this.DataGridView.GetCellDisplayRectangle(
                this.ColumnIndex, -1, false);
            int width = 15;
            Rectangle buttonBounds = new Rectangle(cellBounds.Left + cellBounds.Width - width - 5
                         , cellBounds.Top + 5
                , width, width);
            dropDownButtonBoundsValue = buttonBounds;
        }


        public ExHeaderCell()
        {

        }

        protected override void Paint(Graphics graphics, Rectangle clipBounds, Rectangle cellBounds, int rowIndex, DataGridViewElementStates dataGridViewElementState, object value, object formattedValue, string errorText, DataGridViewCellStyle cellStyle, DataGridViewAdvancedBorderStyle advancedBorderStyle, DataGridViewPaintParts paintParts)
        {

            //Pen gridPen = new Pen(Color.Gray);
            //Brush bruBK = new SolidBrush(cellStyle.BackColor);
            int width = 15;
            // cellBounds.X += width;




            //graphics.FillRectangle(new SolidBrush(cellStyle.BackColor), rectLeft);
            //graphics.DrawRectangle(gridPen, rectLeft);


            base.Paint(graphics, clipBounds, cellBounds, rowIndex, dataGridViewElementState, value, formattedValue
                , errorText, cellStyle, advancedBorderStyle, paintParts);
            // Rectangle buttonBounds = DropDownButtonBounds;
            Rectangle buttonBounds = new Rectangle(cellBounds.Left + cellBounds.Width - width - 5
                , cellBounds.Top + 5
       , width, width);
            if (cellBounds.Width > width)
            {
                if (buttonBounds.Width < 1 || buttonBounds.Height < 1) return;
                ComboBoxState state = ComboBoxState.Normal;

                this.Style.Padding = new Padding(0, 0, 18, 0);

                ComboBoxRenderer.DrawDropDownButton(
                    graphics, buttonBounds, state);
                SetDropDownButtonBounds();
            }
        }


        protected override void OnMouseDown(DataGridViewCellMouseEventArgs e)
        {


            Rectangle cellBounds = this.DataGridView
                .GetCellDisplayRectangle(e.ColumnIndex, -1, false);


            if (this.OwningColumn.Resizable == DataGridViewTriState.True &&
                ((this.DataGridView.RightToLeft == RightToLeft.No &&
                cellBounds.Width - e.X < 6) || e.X < 6))
            {
                return;
            }

            Int32 scrollingOffset = 0;
            if (this.DataGridView.RightToLeft == RightToLeft.No &&
                this.DataGridView.FirstDisplayedScrollingColumnIndex ==
                this.ColumnIndex)
            {
                scrollingOffset =
                    this.DataGridView.FirstDisplayedScrollingColumnHiddenWidth;
            }


            if (
                DropDownButtonBounds.Contains(
                e.X + cellBounds.Left - scrollingOffset, e.Y + cellBounds.Top))
            {
                // If the current cell is in edit mode, commit the edit. 
                if (this.DataGridView.IsCurrentCellInEditMode)
                {
                    // Commit and end the cell edit.  
                    this.DataGridView.EndEdit();

                    // Commit any change to the underlying data source. 
                    BindingSource source =
                        this.DataGridView.DataSource as BindingSource;
                    if (source != null)
                    {
                        source.EndEdit();
                    }
                }
                ShowDropDownList();
            }
            else if (
                this.DataGridView.SelectionMode !=
                DataGridViewSelectionMode.ColumnHeaderSelect)
            {

                DDSCDataGridViewTextBoxColumn d = this.DataGridView.Columns[e.ColumnIndex] as DDSCDataGridViewTextBoxColumn;

                if (d.SortFlag)
                {
                    SortByColumn();
                }
                //   base.OnMouseDown(e);
            }


        }
        private void SortByColumn()
        {




            ListSortDirection direction = ListSortDirection.Ascending;
            if (this.DataGridView.SortedColumn == OwningColumn &&
                this.DataGridView.SortOrder == SortOrder.Ascending)
            {
                direction = ListSortDirection.Descending;
            }
            this.DataGridView.Sort(OwningColumn, direction);
        }

        public void ShowDropDownList()
        {


            if (this.DataGridView.CurrentRow != null &&
                this.DataGridView.CurrentRow.IsNewRow)
            {
                this.DataGridView.CurrentCell = null;
            }
            HandleDropDownListBoxEvents();
            dropDownListBox.Items.Clear();
            PopulateFilters();
            String[] filterArray = new String[filters.Count];
            filters.Keys.CopyTo(filterArray, 0);
            dropDownListBox.Items.Clear();
            dropDownListBox.Items.AddRange(filterArray);
            dropDownListBox.SelectedItem = selectedFilterValue;
            SetDropDownListBoxBounds();
            dropDownListBox.Visible = true;


            // Add dropDownListBox to the DataGridView. 
            this.DataGridView.Controls.Add(dropDownListBox);

            // Set the input focus to dropDownListBox. 
            dropDownListBox.Focus();

            // Invalidate the cell so that the drop-down button will repaint
            // in the pressed state. 
            this.DataGridView.InvalidateCell(this);
        }

        public void HideDropDownList()
        {

            dropDownListBox.Visible = false;
            UnhandleDropDownListBoxEvents();
            this.DataGridView.Controls.Remove(dropDownListBox);


            this.DataGridView.InvalidateCell(this);
        }

        private void HandleDropDownListBoxEvents()
        {
            dropDownListBox.MouseClick += new MouseEventHandler(DropDownListBox_MouseClick);
            dropDownListBox.LostFocus += new EventHandler(DropDownListBox_LostFocus);

        }


        private void UnhandleDropDownListBoxEvents()
        {
            dropDownListBox.MouseClick -= new MouseEventHandler(DropDownListBox_MouseClick);
            dropDownListBox.LostFocus -= new EventHandler(DropDownListBox_LostFocus);

        }

        private void DropDownListBox_MouseClick(object sender, MouseEventArgs e)
        {

            if (!dropDownListBox.DisplayRectangle.Contains(e.X, e.Y))
            {
                return;
            }

            UpdateFilter();
            HideDropDownList();

        }
        private void DropDownListBox_LostFocus(object sender, EventArgs e)
        {

            if (DropDownButtonBounds.Contains(
                this.DataGridView.PointToClient(new Point(
                Control.MousePosition.X, Control.MousePosition.Y))))
            {

            }
            HideDropDownList();
        }
        private void UpdateFilter()
        {
            // Continue only if the selection has changed.
            if (dropDownListBox.SelectedItem.ToString().Equals(selectedFilterValue))
            {
                return;
            }
            Dictionary<string, string> FilterList = null;
            if (this.DataGridView.Tag != null)
                FilterList = (Dictionary<string, string>)this.DataGridView.Tag;

            selectedFilterValue = dropDownListBox.SelectedItem.ToString();

            String newColumnFilter = null;

            String columnProperty =
                OwningColumn.DataPropertyName.Replace("]", @"\]");
            DataView data = null;

            if (this.DataGridView.DataSource is DataTable)
            {
                data = ((DataTable)this.DataGridView.DataSource).DefaultView;
            }
            else if (this.DataGridView.DataSource is DataView)
            {
                data = (DataView)this.DataGridView.DataSource;
            }
            string tmp = "";

            //if (data.RowFilter.IndexOf(")") > -1)
            //    tmp = data.RowFilter.Split(')')[0]+")" ;
            if (selectedFilterValue.Equals("(All)"))
            {
                //data.RowFilter = "";// FilterWithoutCurrentColumn(data.DefaultView.RowFilter);
                FilterList.Remove(columnProperty);
                //return;
            }



            switch (selectedFilterValue)
            {

                default:
                    if (!selectedFilterValue.Equals("(All)"))
                    {
                        newColumnFilter = String.Format("[{0}]='{1}'",
                            columnProperty,
                            ((String)filters[selectedFilterValue])
                            .Replace("'", "''"));

                        FilterList[columnProperty] = newColumnFilter;
                    }
                    break;
            }

            String newFilter = "";// FilterWithoutCurrentColumn(data.Filter);
            //if (String.IsNullOrEmpty(newFilter))
            //{
            // if (data.Table.Columns.Contains("SEQ_AD"))
            if (this.DataGridView.Name == "eeeedgvReply_ad")
            {
                //newFilter += newColumnFilter;
                // newFilter = newColumnFilter;
                //有母單所以不能用欄位去篩選，要用欄位所對應的母單編號去篩選
                string filer = "";
                foreach (string k in FilterList.Values)
                {
                    if (k != "default")
                        filer += "AND " + k;
                }
                if (filer.Length > 3)
                    filer = filer.Substring(3);


                // DataRow[] drs = data.Table.Select(columnProperty + "='" + selectedFilterValue + "'");
                DataRow[] drs = data.Table.Select(filer);
                if (drs != null)
                {
                    foreach (DataRow dr in drs)
                    {
                        if (dr["SEQ_AD"].ToString().Trim().Length > 0)
                            newFilter += "OR SEQ_AD ='" + dr["SEQ_AD"].ToString() + "' ";
                    }
                    if (newFilter.Length > 2)
                    {
                        newFilter = newFilter.Substring(2);
                        newFilter = "(" + newFilter + ")";
                    }
                    else
                    {
                        newFilter = filer;
                    }

                }

            }
            else
            {
                foreach (string k in FilterList.Values)
                {
                    if (k != "default")
                        newFilter += "AND " + k;
                }
                if (newFilter.Length > 3)
                    newFilter = newFilter.Substring(3);
            }
            //}
            //else
            //{
            //    newFilter += " AND " + newColumnFilter;
            //}


            // Set the filter to the new value.
            try
            {
                string d = "";
                if (!FilterList.TryGetValue("default", out d)) d = "";

                data.RowFilter = newFilter + (d.Length > 0 ? " and " + d : "");
            }
            catch (InvalidExpressionException ex)
            {
                //throw new NotSupportedException(
                //    "Invalid expression: " + newFilter, ex);
            }


            currentColumnFilter = newColumnFilter;
        }
        private void PopulateFilters()
        {

            if (this.DataGridView == null)
            {
                return;
            }

            // DataTable data = this.DataGridView.DataSource as DataTable;


            DataTable data = null;

            if (this.DataGridView.DataSource is DataTable)
            {
                data = this.DataGridView.DataSource as DataTable;
            }
            else if (this.DataGridView.DataSource is DataView)
            {
                data = ((DataView)this.DataGridView.DataSource).Table;
            }
            if (data == null) return;


            String oldFilter = data.DefaultView.RowFilter;


            filters.Clear();


            ArrayList list = new ArrayList(data.Rows.Count);

            foreach (DataRow dr in data.Rows)
            {

                string value = dr[this.OwningColumn.DataPropertyName].ToString().Trim();


                if (data.Columns.Contains("SEQ")) //有委託回報的TABLE
                {
                    if (dr["SEQ"].ToString().Trim().Length > 0)//只有一般單和母單才能
                        if (!list.Contains(value))
                        {
                            list.Add(value);
                        }
                }
                else
                    if (!list.Contains(value))
                    {
                        list.Add(value);
                    }
            }

            list.Sort();


            foreach (Object value in list)
            {

                String formattedValue = null;
                DataGridViewCellStyle style = OwningColumn.InheritedStyle;
                formattedValue = (String)GetFormattedValue(value, -1, ref style,
                    null, null, DataGridViewDataErrorContexts.Formatting);

                if (String.IsNullOrEmpty(formattedValue))
                {


                }
                else if (!filters.Contains(formattedValue))
                {



                    filters.Add(formattedValue, value.ToString());
                }
            }


            filters.Insert(0, "(All)", null);

        }

        private String FilterWithoutCurrentColumn(String filter)
        {

            if (String.IsNullOrEmpty(filter))
            {
                return String.Empty;
            }



            if (filter.IndexOf(currentColumnFilter) > 0)
            {

                return filter.Replace(
                    " AND " + currentColumnFilter, String.Empty);
            }
            else
            {
                if (filter.Length > currentColumnFilter.Length)
                {

                    return filter.Replace(
                        currentColumnFilter + " AND ", String.Empty);
                }
                else
                {

                    return String.Empty;
                }
            }
        }


        private void SetDropDownListBoxBounds()
        {

            Int32 dropDownListBoxHeight = 2;
            Int32 currentWidth = 0;
            Int32 dropDownListBoxWidth = 0;
            Int32 dropDownListBoxLeft = 0;

            using (Graphics graphics = dropDownListBox.CreateGraphics())
            {
                foreach (String filter in filters.Keys)
                {
                    SizeF stringSizeF = graphics.MeasureString(
                        filter, dropDownListBox.Font);
                    dropDownListBoxHeight += (Int32)stringSizeF.Height;
                    currentWidth = (Int32)stringSizeF.Width;
                    if (dropDownListBoxWidth < currentWidth)
                    {
                        dropDownListBoxWidth = currentWidth;
                    }
                }
            }

            dropDownListBoxWidth += 6;


            if (dropDownListBoxHeight > 100)
            {
                dropDownListBoxHeight = 100;

                dropDownListBoxWidth += SystemInformation.VerticalScrollBarWidth;
            }

            if (this.DataGridView.RightToLeft == RightToLeft.No)
            {
                dropDownListBoxLeft = DropDownButtonBounds.Right -
                    dropDownListBoxWidth + 1;
            }
            else
            {
                dropDownListBoxLeft = DropDownButtonBounds.Left - 1;
            }

            Int32 clientLeft = 1;
            Int32 clientRight = this.DataGridView.ClientRectangle.Right;
            if (this.DataGridView.DisplayedRowCount(false) <
                this.DataGridView.RowCount)
            {
                if (this.DataGridView.RightToLeft == RightToLeft.Yes)
                {
                    clientLeft += SystemInformation.VerticalScrollBarWidth;
                }
                else
                {
                    clientRight -= SystemInformation.VerticalScrollBarWidth;
                }
            }

            if (dropDownListBoxLeft < clientLeft)
            {
                dropDownListBoxLeft = clientLeft;
            }
            Int32 dropDownListBoxRight =
                dropDownListBoxLeft + dropDownListBoxWidth + 1;
            if (dropDownListBoxRight > clientRight)
            {
                if (dropDownListBoxLeft == clientLeft)
                {
                    dropDownListBoxWidth -=
                        dropDownListBoxRight - clientRight;
                }
                else
                {
                    dropDownListBoxLeft -=
                        dropDownListBoxRight - clientRight;
                    if (dropDownListBoxLeft < clientLeft)
                    {
                        dropDownListBoxWidth -= clientLeft - dropDownListBoxLeft;
                        dropDownListBoxLeft = clientLeft;
                    }
                }
            }

            // Set the ListBox.Bounds property using the calculated values. 
            dropDownListBox.Bounds = new Rectangle(dropDownListBoxLeft,
                DropDownButtonBounds.Bottom, // top of drop-down list box
                dropDownListBoxWidth, dropDownListBoxHeight);
        }



        private class FilterListBox : ListBox
        {
            /// <summary>
            /// Initializes a new instance of the FilterListBox class.
            /// </summary>
            public FilterListBox()
            {
                Visible = false;
                IntegralHeight = true;
                BorderStyle = BorderStyle.FixedSingle;
                TabStop = false;
            }

            protected override bool IsInputKey(Keys keyData)
            {
                return true;
            }

            protected override bool ProcessKeyMessage(ref Message m)
            {
                return ProcessKeyEventArgs(ref m);
            }

        }
    }
}
