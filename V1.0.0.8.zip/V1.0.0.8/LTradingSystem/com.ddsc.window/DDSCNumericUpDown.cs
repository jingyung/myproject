﻿
using System;
using System.ComponentModel;
using System.Threading;
using System.Windows.Forms;
namespace com.ddsc.tool.window
{
    public sealed class DDSCNumericUpDown : NumericUpDown
    {
        private bool m_mark = false;
        private event EventHandler TextChangeHandler;
 
        public override void DownButton()
        {
            if ((base.Value - base.Increment) >= base.Minimum)
            {
                base.Value -= base.Increment;
            }
        }

        protected override void OnKeyPress(KeyPressEventArgs e)
        {
            if (((Convert.ToInt32(e.KeyChar) >= 0x30) && (Convert.ToInt32(e.KeyChar) <= 0x39)) || (Convert.ToInt32(e.KeyChar) == 8))
            {
                if ((Convert.ToInt32(e.KeyChar) == 0x30) && (this.Text == ""))
                {
                    e.Handled = true;
                }
            }
            else
            {
                e.Handled = true;
            }
            base.OnKeyPress(e);
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.Select(0, this.Text.Length);
            base.OnMouseDown(e);
        }

        protected override void OnMouseWheel(MouseEventArgs e)
        {
        }

        protected override void OnTextBoxTextChanged(object source, EventArgs e)
        {
            if (this.TextChangeHandler != null)
            {
                this.TextChangeHandler(this, EventArgs.Empty);
            }
            base.OnTextBoxTextChanged(source, e);
        }

        protected override void OnValueChanged(EventArgs e)
        {
            base.OnValueChanged(e);
        }

        public override void UpButton()
        {
            if ((base.Value + base.Increment) <= base.Maximum)
            {
                base.Value += base.Increment;
            }
        }

        protected override void UpdateEditText()
        {
            if (this.m_mark)
            {
                if (base.Value > 0M)
                {
                    this.Text = "+" + base.Value.ToString();
                }
                else if (base.Value == 0M)
                {
                    this.Text = base.Value.ToString();
                }
                else if (base.Value < 0M)
                {
                    this.Text = base.Value.ToString();
                }
            }
            else
            {
                base.UpdateEditText();
            }
        }

        [Description("正負號mark,如為真時ThousandsSeparator、DecimalPlaces、Hexadecimal之功能失效"), Category("資料")]
        public bool mark
        {
            get
            {
                return this.m_mark;
            }
            set
            {
                this.m_mark = value;
            }
        }
    }
}

