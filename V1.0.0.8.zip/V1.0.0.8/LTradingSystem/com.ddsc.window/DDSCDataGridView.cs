﻿namespace com.ddsc.tool.window
{
    using System;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Security.Permissions;
    using System.Windows.Forms;
    using System.Collections.Generic;
    public class DDSCDataGridView : DataGridView
    {
        private ContextMenuStrip cmsColumns;
        private IContainer components = null;
        private ToolStripMenuItem toolStripMenuItem1;
        private ToolStripMenuItem toolStripMenuItem2;

        public DDSCDataGridView()
        {
            this.DoubleBuffered = true;
            this.SetStyle(ControlStyles.SupportsTransparentBackColor |
               ControlStyles.OptimizedDoubleBuffer |
               ControlStyles.AllPaintingInWmPaint |
              ControlStyles.UserPaint |
              ControlStyles.ResizeRedraw |
              ControlStyles.DoubleBuffer, true);
            this.SetStyle(ControlStyles.Opaque, false);
            base.AutoGenerateColumns = false;
            base.AllowUserToAddRows = false;
            base.AllowUserToDeleteRows = false;
            base.AllowUserToResizeColumns = true;
            base.AllowUserToOrderColumns = true;
            base.AllowUserToResizeRows = false;

            base.RowHeadersVisible = false;
            base.EnableHeadersVisualStyles = false;
            base.ColumnHeadersDefaultCellStyle.BackColor = Color.PowderBlue;
            this.RowHeadersDefaultCellStyle.SelectionBackColor = Color.Bisque;
            this.RowHeadersDefaultCellStyle.SelectionForeColor = Color.Black;
            this.DefaultCellStyle.SelectionBackColor = Color.Bisque;
            this.DefaultCellStyle.SelectionForeColor = Color.Black;
            this.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.MultiSelect = false;
            ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            ColumnHeadersHeight = 50;
            RowTemplate.DefaultCellStyle.Padding = new System.Windows.Forms.Padding(0);

            UpdateStyles();

            this.Tag = new Dictionary<string, string>();

        }

        private void changeColumnDisplayIndex()
        {
            DataRow[] rowArray = this.setSortDisplayColumns();
            for (int i = 0; i < rowArray.Length; i++)
            {
                base.Columns[rowArray[i]["name"].ToString()].DisplayIndex = i;
            }
        }
        protected override void OnCellClick(DataGridViewCellEventArgs e)
        {

            base.OnCellClick(e);
        }
        protected override void OnCurrentCellDirtyStateChanged(EventArgs e)
        {

            base.OnCurrentCellDirtyStateChanged(e);
            if (IsCurrentCellDirty)
            {
                CommitEdit(DataGridViewDataErrorContexts.Commit);
            }

        }
        protected override void OnCellValueChanged(DataGridViewCellEventArgs e)
        {
            try
            {

                base.OnCellValueChanged(e);

            }
            catch (Exception ex)
            {
            }
        }
        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components = new Container();
            this.cmsColumns = new ContextMenuStrip(this.components);
            this.toolStripMenuItem1 = new ToolStripMenuItem();
            this.toolStripMenuItem2 = new ToolStripMenuItem();
            this.cmsColumns.SuspendLayout();
            ((ISupportInitialize)this).BeginInit();
            base.SuspendLayout();
            this.cmsColumns.Items.AddRange(new ToolStripItem[] { this.toolStripMenuItem1, this.toolStripMenuItem2 });
            this.cmsColumns.Name = "cmsColumns";
            this.cmsColumns.Size = new Size(0xa6, 70);
            this.toolStripMenuItem1.Checked = true;
            this.toolStripMenuItem1.CheckState = CheckState.Checked;
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new Size(0xa5, 0x16);
            this.toolStripMenuItem1.Text = "toolStripMenuItem1";
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new Size(0xa5, 0x16);
            this.toolStripMenuItem2.Text = "toolStripMenuItem2";
            base.RowTemplate.Height = 0x18;
            this.cmsColumns.ResumeLayout(false);
            ((ISupportInitialize)this).EndInit();
            base.ResumeLayout(false);
        }

        protected override void OnColumnHeaderMouseClick(DataGridViewCellMouseEventArgs e)
        {
            base.OnColumnHeaderMouseClick(e);
            try
            {
                if (e.Button == MouseButtons.Right)
                {
                    this.cmsColumns = new ContextMenuStrip();
                    this.cmsColumns.Items.Clear();
                    foreach (DataGridViewColumn column in base.Columns)
                    {
                        if (column.HeaderText != "")
                        {
                            ToolStripMenuItem item = new ToolStripMenuItem();
                            item.Name = column.Name;
                            item.Text = column.HeaderText;
                            item.Checked = column.Visible;
                            item.Click += new EventHandler(this.t_Click);
                            this.cmsColumns.Items.Add(item);
                        }
                    }
                    this.cmsColumns.Show(Cursor.Position.X, Cursor.Position.Y);
                }
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        [SecurityPermission(SecurityAction.LinkDemand, Flags = SecurityPermissionFlag.UnmanagedCode)]
        protected override bool ProcessDataGridViewKey(KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Insert:
                case Keys.C:
                    return this.ProcessInsertKey(e.KeyData);
            }
            return base.ProcessDataGridViewKey(e);
        }

        [SecurityPermission(SecurityAction.LinkDemand, Flags = SecurityPermissionFlag.UnmanagedCode)]
        protected bool ProcessInsertKey(Keys keyData)
        {
            if ((((keyData & (Keys.Alt | Keys.Control | Keys.Shift)) == Keys.Control) || (((keyData & (Keys.Alt | Keys.Control | Keys.Shift)) == (Keys.Control | Keys.Shift)) && ((keyData & Keys.KeyCode) == Keys.C))) && (base.ClipboardCopyMode != DataGridViewClipboardCopyMode.Disable))
            {
                DataObject clipboardContent = this.GetClipboardContent();
                if (clipboardContent != null)
                {
                    Clipboard.SetText(clipboardContent.GetData(DataFormats.UnicodeText).ToString());
                    return true;
                }
            }
            return false;
        }

        public DataRow[] setSortDisplayColumns()
        {
            DataTable table = new DataTable();
            table.Columns.Add("name");
            table.Columns.Add("index", typeof(int));
            foreach (DataGridViewColumn column in base.Columns)
            {
                if (column.Visible)
                {
                    table.Rows.Add(new object[] { column.Name, column.DisplayIndex });
                }
                else
                {
                    table.Rows.Add(new object[] { column.Name, 0x1869f });
                }
            }
            return table.Select("", "index");
        }

        private void t_Click(object sender, EventArgs e)
        {
            try
            {
                ToolStripMenuItem item = (ToolStripMenuItem)sender;
                if (item.Name == "kind")
                {
                    MessageBox.Show("不允許隱藏");
                }
                else
                {
                    if (item.Checked)
                    {
                        base.Columns[item.Name].Visible = false;
                    }
                    else
                    {
                        base.Columns[item.Name].Visible = true;
                        base.Columns[item.Name].DisplayIndex = this.cmsColumns.Items.IndexOf(item);
                    }
                    this.changeColumnDisplayIndex();
                }
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            try
            {

                base.OnPaint(e);
            }
            catch (Exception ex)
            {
            }
        }

        protected override void OnDataError(bool displayErrorDialogIfNoHandler, DataGridViewDataErrorEventArgs e)
        {
            try
            {
                base.OnDataError(displayErrorDialogIfNoHandler, e);
            }
            catch (Exception ex)
            {
            }
        }

    }

    public class DataGridViewGroupColumn : DataGridViewTextBoxColumn
    {
        public DataGridViewGroupColumn()
        {
            CellTemplate = new DataGridViewGroupCell();
            ReadOnly = true;
        }
        public override DataGridViewCell CellTemplate
        {
            get
            {
                return base.CellTemplate;
            }
            set
            {
                if ((value != null) && !(value is DataGridViewGroupCell))
                {
                    throw new InvalidCastException("DataGridViewGroupCell");
                }
                base.CellTemplate = value;
            }

        }

    }
    public class DataGridViewGroupCell : DataGridViewTextBoxCell
    {


        bool _collapsed = false;
        public DataGridViewGroupCell()
        {

        }




        protected override void Paint(System.Drawing.Graphics graphics, System.Drawing.Rectangle clipBounds
            , System.Drawing.Rectangle cellBounds, int rowIndex, DataGridViewElementStates cellState, object value
            , object formattedValue, string errorText, DataGridViewCellStyle cellStyle
            , DataGridViewAdvancedBorderStyle advancedBorderStyle, DataGridViewPaintParts paintParts)
        {

            try
            {

                Pen gridPen = new Pen(DataGridView.GridColor);
                Brush bruBK = new SolidBrush(cellStyle.BackColor);
                int width = 1 * 24;
                Rectangle rectLeft = new Rectangle(cellBounds.Left, cellBounds.Top - 1, width, cellBounds.Height);
                cellBounds.X += width;
                cellBounds.Width -= width;
                base.Paint(graphics, clipBounds, cellBounds, rowIndex, cellState, value, formattedValue
                    , errorText, cellStyle, advancedBorderStyle, paintParts);
                graphics.FillRectangle(new SolidBrush(cellStyle.BackColor), rectLeft);

                graphics.DrawLine(gridPen, rectLeft.X, rectLeft.Y, rectLeft.X + rectLeft.Width, rectLeft.Y);
                graphics.DrawLine(gridPen, rectLeft.X, rectLeft.Y + rectLeft.Height, rectLeft.X + rectLeft.Width, rectLeft.Y + rectLeft.Height);


                try
                {
                    //   DDSCDataGridView d = (DDSCDataGridView)this.DataGridView;



                    rectLeft.Inflate(-7, -8);
                    int level = value.ToString().IndexOf('P');
                    if (level > -1)
                    {
                        if (_collapsed)
                        {

                            graphics.DrawRectangle(gridPen, rectLeft);
                            graphics.DrawLine(gridPen, rectLeft.X, rectLeft.Y + rectLeft.Height / 2, rectLeft.X + rectLeft.Width, rectLeft.Y + rectLeft.Height / 2);
                            graphics.DrawLine(gridPen, rectLeft.X + rectLeft.Width / 2, rectLeft.Y, rectLeft.X + rectLeft.Width / 2, rectLeft.Y + rectLeft.Height);

                        }
                        else
                        {

                            graphics.DrawRectangle(gridPen, rectLeft);
                            graphics.DrawLine(gridPen, rectLeft.X, rectLeft.Y + rectLeft.Height / 2, rectLeft.X + rectLeft.Width, rectLeft.Y + rectLeft.Height / 2);



                        }
                    }



                }
                catch (Exception ex)
                {
                }

                gridPen.Dispose();
                gridPen = null;

                bruBK.Dispose();
                bruBK = null;
            }
            catch (Exception ex)
            {
            }
        }

        protected override void OnMouseDown(DataGridViewCellMouseEventArgs e)
        {
            if (RowIndex == -1 || ColumnIndex == -1) return;
            Rectangle rect = DataGridView.GetCellDisplayRectangle(ColumnIndex, RowIndex, false);
            rect.Width = 24;
            Point pt = new Point(rect.Left + e.Location.X, rect.Top + e.Location.Y);
            if (rect.IntersectsWith(new Rectangle(pt.X, pt.Y, 1, 1)))
            {

                int level = (int)this.DataGridView[ColumnIndex, RowIndex].Value.ToString().IndexOf('P');
                if (level > -1)
                {


                    if (_collapsed)
                    {
                        Expand();
                    }
                    else
                    {
                        Collapse();
                    }
                }
            }
            base.OnMouseDown(e);
        }


        public void Expand()
        {
            _collapsed = false;
            ShowChild(true);
            base.DataGridView.InvalidateCell(this);
        }

        private void ShowChild(bool show)
        {
            try
            {

                if (RowIndex < 0) return;
                //   this.DataGridView.CurrentCell = this.DataGridView[0, 0];
                int row = this.DataGridView.CurrentCell.RowIndex;

                string group = this.DataGridView["SEQ_AD", RowIndex].Value.ToString().Trim();



                for (int i = RowIndex + 1; i < this.DataGridView.Rows.Count; i++)
                {
                    string v = this.DataGridView.Rows[i].Cells["SEQ_AD"].Value.ToString();
                    //if (v.IndexOf('.') > -1)
                    //{
                    if (v.Split('.')[0] == group)
                    {
                        this.DataGridView.Rows[i].Visible = show;
                    }
                    //}


                }

            }
            catch (Exception ex)
            {
            }



        }

        public void Collapse()
        {
            _collapsed = true;
            ShowChild(false);
            base.DataGridView.InvalidateCell(this);
        }


    }
}

