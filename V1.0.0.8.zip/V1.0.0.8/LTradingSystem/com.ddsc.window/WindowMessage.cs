﻿namespace com.ddsc.tool.window
{
    using System;

    internal static class WindowMessage
    {
        internal const int WM_CLOSE = 0x10;
        internal const int WM_CREATE = 1;
        internal const int WM_MDIACTIVATE = 0x222;
        internal const int WM_MDICASCADE = 0x227;
        internal const int WM_MDICREATE = 0x220;
        internal const int WM_MDIDESTROY = 0x221;
        internal const int WM_MDIGETACTIVE = 0x229;
        internal const int WM_MDIICONARRANGE = 0x227;
        internal const int WM_MDIMAXIMIZE = 0x225;
        internal const int WM_MDINEXT = 0x224;
        internal const int WM_MDIREFRESHMENU = 0x234;
        internal const int WM_MDIRESTORE = 0x223;
        internal const int WM_MDISETMENU = 560;
        internal const int WM_MDITILE = 550;
        internal const int WM_MOUSEACTIVATE = 0x21;
        internal const int WM_NCACTIVATE = 0x86;
    }
}

