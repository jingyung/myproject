﻿
using System;
using System.Collections;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using System.Collections.Generic;
namespace com.ddsc.tool.window
{
    public sealed class TradeGrid : DataGridView
    {
        Dictionary<decimal, DataRow> _item;

        public Dictionary<decimal, DataRow> Item
        {
            get { return _item; }
            set { _item = value; }
        }
        DataTable _dt = null;
        private Dictionary<decimal, DataRow> _PriceData;

        public void initData()
        {
            try
            {
                decimal price = 0;
                _PriceData.Clear();
                DataTable dt = (DataTable)this.DataSource;
                foreach (DataRow dr in dt.Rows)
                {
                    if (decimal.TryParse(dr["price"].ToString(), out price))
                        _PriceData[price] = dr;
                }
            }
            catch (Exception ex)
            {
            }
        }
        public DataRow SearchByPriceData(decimal price)
        {
            DataRow dr = null;
            _PriceData.TryGetValue(price, out dr);
            return dr;
        }

        private Font _font = new Font("Gautami", 9f);
        private static bool m_bolMoveBackColor;
        private decimal m_MatchPrice = 0M;
        private static Color m_MatchPriceBackColor;
        private static Color m_MatchPriceForeColor;
        private decimal m_MB1 = 0M;
        private decimal m_MB5 = 0M;
        private Color m_MBBackColor = Color.Wheat;
        private Color m_MBForeColor = Color.Red;
        private bool m_MiddleMatchPriceEnabled = false;
        private decimal m_MS1 = 0M;
        private decimal m_MS5 = 0M;
        private Color m_MSBackColor = Color.Wheat;
        private Color m_MSForeColor = Color.Green;
        private static Color m_PriceBackColor;
        private static Color m_PriceForeColor;
        private bool m_WBSBackColorEnabled = false;
        private int mint_MoveIndex;
        private bool m_bolMatchQty = false;
        private static Color m_MAXPRICEBackColor;
        private static Color m_MINPRICEBackColor;
        private decimal m_MAXPRICE = 100000;
        private decimal m_MINPRICE = 100000;
        private decimal m_BeforeMAXPRICE = 0;
        private decimal m_BeforeMINPRICE = 0;
        private bool m_bolMaxMinEnable = false;
        //盤前揭示flag
        bool m_bolBMarket = true;
        public bool bolBMarket
        {
            get
            {
                return m_bolBMarket;
            }
            set
            {
                m_bolBMarket = value;
            }
        }

        public TradeGrid()
        {
            this.DoubleBuffered = true;
            this.SetStyle(ControlStyles.SupportsTransparentBackColor |
               ControlStyles.OptimizedDoubleBuffer |
               ControlStyles.AllPaintingInWmPaint |
              ControlStyles.UserPaint |
              ControlStyles.ResizeRedraw |
              ControlStyles.DoubleBuffer, true);
            this.SetStyle(ControlStyles.Opaque, false);
            UpdateStyles();
            _PriceData = new Dictionary<decimal, DataRow>();
        }

        ~TradeGrid()
        {
            _PriceData.Clear();
        }
        protected override void OnDataSourceChanged(EventArgs e)
        {
            base.OnDataSourceChanged(e);
            _dt = (DataTable)this.DataSource;
        }

        private void InvalidateCellEx(int c, int r)
        {
            this.InvalidateCell(c, r);
            //     this.Update();
        }


        public void focusMatchPrice(DataRow drData, bool bolYellowBack)
        {
            try
            {
                int num = 0;
                num = int.Parse(drData["INDEX"].ToString());
                int num2 = (base.Height / base.RowTemplate.Height) / 2;
                int num3 = 0;
                if ((num - num2) > 0)
                {
                    num3 = num - num2;
                }
                else if ((num - num2) <= 0)
                {
                    num3 = 0;
                }
                else if ((num + num2) >= base.Rows.Count)
                {
                    num3 = base.Rows.Count - 1;
                }
                else
                {
                    num3 = num;
                }
                if (base.FirstDisplayedScrollingRowIndex != -1)
                {
                    base.FirstDisplayedScrollingRowIndex = num3;
                }
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        protected override void OnCellFormatting(DataGridViewCellFormattingEventArgs e)
        {
            try
            {
                base.OnCellFormatting(e);
                if (base.Columns[e.ColumnIndex].Name == "DisplayPrice")
                {
                    if (base.Rows[e.RowIndex].Cells["flag"].Value.ToString() == "Y")
                    {
                        e.CellStyle.ForeColor = m_MatchPriceForeColor;
                        e.CellStyle.BackColor = m_MatchPriceBackColor;
                        e.CellStyle.SelectionForeColor = m_MatchPriceForeColor;
                        e.CellStyle.SelectionBackColor = m_MatchPriceBackColor;
                    }
                    else
                    {
                        e.CellStyle.ForeColor = m_PriceForeColor;
                        e.CellStyle.SelectionForeColor = m_PriceForeColor;
                        if (m_bolMaxMinEnable)
                        {
                            if (decimal.Parse(this.Rows[e.RowIndex].Cells["Price"].Value.ToString()) == m_MAXPRICE)
                            {
                                e.CellStyle.BackColor = m_MAXPRICEBackColor;
                                e.CellStyle.SelectionBackColor = m_MAXPRICEBackColor;
                            }
                            else if (decimal.Parse(this.Rows[e.RowIndex].Cells["Price"].Value.ToString()) == m_MINPRICE)
                            {
                                e.CellStyle.BackColor = m_MINPRICEBackColor;
                                e.CellStyle.SelectionBackColor = m_MINPRICEBackColor;
                            }
                            else
                            {
                                e.CellStyle.BackColor = m_PriceBackColor;
                                e.CellStyle.SelectionBackColor = m_PriceBackColor;
                            }
                        }
                        else
                        {
                            e.CellStyle.BackColor = m_PriceBackColor;
                            e.CellStyle.SelectionBackColor = m_PriceBackColor;
                        }
                    }


                    if (e.RowIndex == 0)
                    {
                        e.CellStyle.BackColor = Color.MistyRose;
                        e.CellStyle.SelectionBackColor = Color.MistyRose;
                        e.CellStyle.ForeColor = Color.Black;
                        e.CellStyle.SelectionForeColor = Color.Black;
                    }
                    else if (e.RowIndex == (base.Rows.Count - 1))
                    {
                        e.CellStyle.BackColor = Color.FromArgb(0xc0, 0xff, 0xc0);
                        e.CellStyle.SelectionBackColor = Color.FromArgb(0xc0, 0xff, 0xc0);
                        e.CellStyle.ForeColor = Color.Black;
                        e.CellStyle.SelectionForeColor = Color.Black;
                    }
                }
                if (this.m_WBSBackColorEnabled)
                {
                    decimal num = Convert.ToDecimal(base["Price", e.RowIndex].Value);
                    if (base.Columns[e.ColumnIndex].Name == "MB")
                    {
                        if (((this.m_MB1 != 0M) && (this.m_MB5 != 0M)) && ((num >= this.m_MB5) && (num <= ((this.m_MatchPrice >= this.m_MB1) ? this.m_MatchPrice : this.m_MB1))))
                        {
                            e.CellStyle.BackColor = this.m_MBBackColor;
                            e.CellStyle.SelectionBackColor = this.m_MBBackColor;
                            e.CellStyle.ForeColor = this.m_MBForeColor;
                            e.CellStyle.SelectionForeColor = this.m_MBForeColor;
                        }
                    }
                    else if ((((base.Columns[e.ColumnIndex].Name == "MS") && (this.m_MS1 != 0M)) && (this.m_MS5 != 0M)) && ((num >= ((this.m_MatchPrice >= this.m_MS1) ? this.m_MS1 : this.m_MatchPrice)) && (num <= this.m_MS5)))
                    {
                        e.CellStyle.BackColor = this.m_MSBackColor;
                        e.CellStyle.SelectionBackColor = this.m_MSBackColor;
                        e.CellStyle.ForeColor = this.m_MSForeColor;
                        e.CellStyle.SelectionForeColor = this.m_MSForeColor;
                    }
                }
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }
        protected override void OnCellPainting(DataGridViewCellPaintingEventArgs e)
        {


            base.OnCellPainting(e);


            if (m_bolBMarket)
            {
                if (this.Columns[e.ColumnIndex].Name == "MS" || this.Columns[e.ColumnIndex].Name == "MB")
                {
                    if (this.Rows[e.RowIndex].Cells["BMarketInfo5"].Value.ToString() == "Y")
                    {
                        if (e.Value.ToString().Trim().Length > 0)
                        {
                            Pen p = new Pen(Color.Gray, 1);
                            p.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;

                            Rectangle r = new Rectangle(e.CellBounds.X, e.CellBounds.Y, e.CellBounds.Width, e.CellBounds.Height);
                            r.Inflate(-1, -1);
                            e.Graphics.FillRectangle(new SolidBrush(e.CellStyle.SelectionBackColor), e.CellBounds);

                            StringFormat sf = new StringFormat();
                            sf.Alignment = StringAlignment.Center;
                            e.Graphics.DrawString(e.Value.ToString(), e.CellStyle.Font, new SolidBrush(e.CellStyle.ForeColor), e.CellBounds, sf);
                            e.Graphics.DrawRectangle(p, r);

                            e.Handled = true;
                        }

                    }
                    else
                    {

                    }

                }
                if (this.Columns[e.ColumnIndex].Name == "DisplayPrice")
                {
                    if (this.Rows[e.RowIndex].Cells["BMarketInfo"].Value.ToString() == "Y")
                    {
                        if (e.Value.ToString().Trim().Length > 0)
                        {
                            Pen p = new Pen(Color.Gray, 1);
                            p.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;

                            Rectangle r = new Rectangle(e.CellBounds.X, e.CellBounds.Y, e.CellBounds.Width, e.CellBounds.Height);
                            r.Inflate(-1, -1);
                            e.Graphics.FillRectangle(new SolidBrush(e.CellStyle.SelectionBackColor), e.CellBounds);

                            StringFormat sf = new StringFormat();
                            sf.Alignment = StringAlignment.Center;
                            e.Graphics.DrawString(e.Value.ToString(), e.CellStyle.Font, new SolidBrush(e.CellStyle.ForeColor), e.CellBounds, sf);
                            e.Graphics.DrawRectangle(p, r);

                            e.Handled = true;
                        }
                    }
                    else
                    {

                    }
                }
            }


        }
        protected override void OnCellMouseEnter(DataGridViewCellEventArgs e)
        {
            try
            {
                if (m_bolMoveBackColor)
                {
                    this.setMoveStyle(true, base.Columns[e.ColumnIndex].Name.Substring(1, 1), e.RowIndex);
                }
            }
            catch (Exception exception)
            {
                throw exception;
            }
            base.OnCellMouseEnter(e);
        }

        protected override void OnCellMouseLeave(DataGridViewCellEventArgs e)
        {
            try
            {
                if (m_bolMoveBackColor)
                {
                    this.setMoveStyle(true, base.Columns[e.ColumnIndex].Name.Substring(1, 1), e.RowIndex);
                }
            }
            catch (Exception exception)
            {
                throw exception;
            }
            base.OnCellMouseLeave(e);
        }

        protected override void OnCellMouseMove(DataGridViewCellMouseEventArgs e)
        {
            try
            {
                if (m_bolMoveBackColor)
                {
                    this.setMoveStyle(true, base.Columns[e.ColumnIndex].Name.Substring(1, 1), e.RowIndex);
                }
            }
            catch (Exception exception)
            {
                throw exception;
            }
            base.OnCellMouseMove(e);
        }

        //protected override void OnCellPainting(DataGridViewCellPaintingEventArgs e)
        //{
        //    base.OnCellPainting(e);
        //}

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
        }

        protected override void OnResize(EventArgs e)
        {
            try
            {
                DataTable dataSource = (DataTable)base.DataSource;
                if (dataSource != null)
                {
                    DataRow drData = dataSource.Rows.Find(this.m_MatchPrice.ToString());
                    if ((drData != null) && this.m_MiddleMatchPriceEnabled)
                    {
                        this.focusMatchPrice(drData, true);
                    }
                }
            }
            catch (Exception exception)
            {
                throw exception;
            }
            base.OnResize(e);
        }

        public void setMB(decimal price, string qty, bool BMarketInfo5)
        {
            if ((price != 0) || (qty != "0"))
            {

                DataRow row = SearchByPriceData(price);
                if ((row != null) && ((row["MB"].ToString() != qty) || (qty == "")))
                {
                    row["MB"] = qty;
                    if (BMarketInfo5)
                        row["BMarketInfo5"] = "Y";
                    else
                        row["BMarketInfo5"] = "";
                    this.InvalidateCellEx(this.Columns["MB"].HeaderCell.ColumnIndex, int.Parse(row["INDEX"].ToString()));
                }
            }
        }

        private void setMoveStyle(bool bol_moveFlag, string str_bs, int rowIndex)
        {
            try
            {
                lock (((ICollection)base.Rows[rowIndex].Cells.SyncRoot))
                {
                    base.Rows[rowIndex].Selected = true;
                    this.mint_MoveIndex = rowIndex;
                }
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        public void setMS(decimal price, string qty, bool BMarketInfo5)
        {
            if ((price != 0) || (qty != "0"))
            {

                DataRow row = SearchByPriceData(price);
                if ((row != null) && ((row["MS"].ToString() != qty) || (qty == "")))
                {
                    row["MS"] = qty;
                    if (BMarketInfo5)
                        row["BMarketInfo5"] = "Y";
                    else
                        row["BMarketInfo5"] = "";
                    this.InvalidateCellEx(this.Columns["MS"].HeaderCell.ColumnIndex, int.Parse(row["INDEX"].ToString()));
                }
            }
        }

        public void setWB(decimal price, string qty)
        {

            DataRow row = SearchByPriceData(price);
            if (row != null)
            {
                if (qty == "0")
                {
                    row["WB"] = "";

                }
                else
                {
                    row["WB"] = qty;
                }
                this.InvalidateCellEx(this.Columns["WB"].HeaderCell.ColumnIndex, int.Parse(row["INDEX"].ToString()));

            }
        }

        public void setWS(decimal price, string qty)
        {

            DataRow row = SearchByPriceData(price);
            if (row != null)
            {
                if (qty == "0")
                {
                    row["WS"] = "";
                }
                else
                {
                    row["WS"] = qty;
                }
                this.InvalidateCellEx(this.Columns["WS"].HeaderCell.ColumnIndex, int.Parse(row["INDEX"].ToString()));
            }
        }

        public void setBM(decimal price, string qty)
        {
            DataRow row = SearchByPriceData(price);
            if (row != null)
            {
                if (qty == "0")
                {
                    row["BM"] = "";

                }
                else
                {
                    row["BM"] = qty;
                }
                this.InvalidateCellEx(this.Columns["BM"].HeaderCell.ColumnIndex, int.Parse(row["INDEX"].ToString()));

            }
        }

        public void setSM(decimal price, string qty)
        {

            DataRow row = SearchByPriceData(price);
            if (row != null)
            {
                if (qty == "0")
                {
                    row["SM"] = "";
                }
                else
                {
                    row["SM"] = qty;
                }
                this.InvalidateCellEx(this.Columns["SM"].HeaderCell.ColumnIndex, int.Parse(row["INDEX"].ToString()));
            }
        }

        public void setTB(decimal price, string qty)
        {
            DataRow row = SearchByPriceData(price);
            if (row != null)
            {
                if (qty == "0")
                {
                    row["TB"] = "";

                }
                else
                {
                    row["TB"] = qty;
                }
                this.InvalidateCellEx(this.Columns["TB"].HeaderCell.ColumnIndex, int.Parse(row["INDEX"].ToString()));

            }
        }

        public void setTS(decimal price, string qty)
        {

            DataRow row = SearchByPriceData(price);
            if (row != null)
            {
                if (qty == "0")
                {
                    row["TS"] = "";
                }
                else
                {
                    row["TS"] = qty;
                }
                this.InvalidateCellEx(this.Columns["TS"].HeaderCell.ColumnIndex, int.Parse(row["INDEX"].ToString()));
            }
        }
        public void updateLevelPrice(decimal BeforeBP5, decimal BeforeSP5,

    decimal BeforeBP4, decimal BeforeSP4,
    decimal BeforeBP3, decimal BeforeSP3,
    decimal BeforeBP2, decimal BeforeSP2,
    decimal BeforeBP1, decimal BeforeSP1
            , decimal BP1, string BQ1, decimal BP2, string BQ2, decimal BP3
            , string BQ3, decimal BP4, string BQ4, decimal BP5, string BQ5
            , decimal SP1, string SQ1, decimal SP2, string SQ2, decimal SP3
            , string SQ3, decimal SP4, string SQ4, decimal SP5, string SQ5, bool BMarketInfo5)
        {
            clearData(BeforeBP5, BeforeSP5
                  , BeforeBP4, BeforeSP4
                  , BeforeBP3, BeforeSP3
                  , BeforeBP2, BeforeSP2
                  , BeforeBP1, BeforeSP1, BP1, BP2, BP3, BP4, BP5
            , SP1, SP2, SP3
            , SP4, SP5, BMarketInfo5);
            if (this.m_WBSBackColorEnabled)
            {
                if (BP5 != 0M)
                {
                    this.m_MB5 = BP5;
                }
                else if (BP4 != 0M)
                {
                    this.m_MB5 = BP4;
                }
                else if (BP3 != 0M)
                {
                    this.m_MB5 = BP3;
                }
                else if (BP2 != 0M)
                {
                    this.m_MB5 = BP2;
                }
                else if (BP1 != 0M)
                {
                    this.m_MB5 = BP1;
                }
                if (SP5 != 0M)
                {
                    this.m_MS5 = SP5;
                }
                else if (SP4 != 0M)
                {
                    this.m_MS5 = SP4;
                }
                else if (SP3 != 0M)
                {
                    this.m_MS5 = SP3;
                }
                else if (SP2 != 0M)
                {
                    this.m_MS5 = SP2;
                }
                else if (SP1 != 0M)
                {
                    this.m_MS5 = SP1;
                }
                if (BP1 != 0M)
                {
                    this.m_MB1 = BP1;
                }
                else if (BP2 != 0M)
                {
                    this.m_MB1 = BP2;
                }
                else if (BP3 != 0M)
                {
                    this.m_MB1 = BP3;
                }
                else if (BP4 != 0M)
                {
                    this.m_MB1 = BP4;
                }
                else if (BP5 != 0M)
                {
                    this.m_MB1 = BP5;
                }
                if (SP1 != 0M)
                {
                    this.m_MS1 = SP1;
                }
                else if (SP2 != 0M)
                {
                    this.m_MS1 = SP2;
                }
                else if (SP3 != 0M)
                {
                    this.m_MS1 = SP3;
                }
                else if (SP4 != 0M)
                {
                    this.m_MS1 = SP4;
                }
                else if (SP5 != 0M)
                {
                    this.m_MS1 = SP5;
                }

            }
            this.setMB(BP1, BQ1, BMarketInfo5);
            this.setMB(BP2, BQ2, BMarketInfo5);
            this.setMB(BP3, BQ3, BMarketInfo5);
            this.setMB(BP4, BQ4, BMarketInfo5);
            this.setMB(BP5, BQ5, BMarketInfo5);
            this.setMS(SP1, SQ1, BMarketInfo5);
            this.setMS(SP2, SQ2, BMarketInfo5);
            this.setMS(SP3, SQ3, BMarketInfo5);
            this.setMS(SP4, SQ4, BMarketInfo5);
            this.setMS(SP5, SQ5, BMarketInfo5);

        }


        private void clearData(decimal BeforeBP5, decimal BeforeSP5
                                   , decimal BeforeBP4, decimal BeforeSP4
                                  , decimal BeforeBP3, decimal BeforeSP3
                                  , decimal BeforeBP2, decimal BeforeSP2
                                  , decimal BeforeBP1, decimal BeforeSP1
             , decimal BP1, decimal BP2, decimal BP3, decimal BP4, decimal BP5
            , decimal SP1, decimal SP2, decimal SP3
            , decimal SP4, decimal SP5
            , bool BMarketInfo5)
        {
            try
            {
                if (BeforeBP5 != BP5)
                    setClearMB(BeforeBP5, BMarketInfo5);
                if (BeforeBP4 != BP4)
                    setClearMB(BeforeBP4, BMarketInfo5);
                if (BeforeBP3 != BP3)
                    setClearMB(BeforeBP3, BMarketInfo5);
                if (BeforeBP2 != BP2)
                    setClearMB(BeforeBP2, BMarketInfo5);
                if (BeforeBP1 != BP1)
                    setClearMB(BeforeBP1, BMarketInfo5);
                if (BeforeSP5 != SP5)
                    setClearMS(BeforeSP5, BMarketInfo5);
                if (BeforeSP4 != SP4)
                    setClearMS(BeforeSP4, BMarketInfo5);
                if (BeforeSP3 != SP3)
                    setClearMS(BeforeSP3, BMarketInfo5);
                if (BeforeSP2 != SP2)
                    setClearMS(BeforeSP2, BMarketInfo5);
                if (BeforeSP1 != SP1)
                    setClearMS(BeforeSP1, BMarketInfo5);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }
        /// <summary>
        ///更新買進working數量
        /// </summary>
        public void setClearMB(decimal price, bool BMarketInfo5)
        {

            //避免衝突.先lock mdt_Price 並將資料copy至另外記憶體中做處理


            DataRow dr = SearchByPriceData(price);

            if (dr != null)
            {

                //更新working口數
                dr.BeginEdit();

                dr["MB"] = DBNull.Value;
                if (BMarketInfo5)
                    dr["BMarketInfo5"] = "Y";
                else
                    dr["BMarketInfo5"] = "";
                dr.EndEdit();
                this.InvalidateCellEx(this.Columns["MB"].HeaderCell.ColumnIndex, int.Parse(dr["INDEX"].ToString()));
                ///this.UpdateBounds(
            }

        }

        public void setClearMS(decimal price, bool BMarketInfo5)
        {

            DataRow dr = SearchByPriceData(price);
            if (dr != null)
            {

                //更新working口數
                dr.BeginEdit();

                dr["MS"] = DBNull.Value;
                if (BMarketInfo5)
                    dr["BMarketInfo5"] = "Y";
                else
                    dr["BMarketInfo5"] = "";
                dr.EndEdit();
                this.InvalidateCellEx(this.Columns["MS"].HeaderCell.ColumnIndex, int.Parse(dr["INDEX"].ToString()));

            }

        }


        public void updateMatchPrice(decimal dml_BeforeMatchPrice, decimal dml_MatchPrice, string MatchQty, bool BMarketInfo)
        {
            try
            {

                this.m_MatchPrice = dml_MatchPrice;
                DataTable dataSource = _dt;
                int currentIndex = 0;
                DataRow drData = SearchByPriceData(dml_BeforeMatchPrice);
                if (drData != null)
                {
                    currentIndex = int.Parse(drData["INDEX"].ToString());
                    drData["flag"] = "";
                    drData["DisplayPrice"] = drData["Price"].ToString();
                    drData["BMarketInfo"] = "";
                    this.InvalidateCellEx(this.Columns["DisplayPrice"].HeaderCell.ColumnIndex, currentIndex);
                }

                drData = SearchByPriceData(dml_MatchPrice);
                if (drData != null)
                {
                    currentIndex = int.Parse(drData["INDEX"].ToString());

                    if (m_bolMatchQty)
                        drData["DisplayPrice"] = drData["Price"].ToString() + " (" + MatchQty + ")";
                    else
                        drData["DisplayPrice"] = drData["Price"].ToString();


                    if (BMarketInfo)
                        drData["BMarketInfo"] = "Y";
                    else
                    {
                        drData["flag"] = "Y";
                        drData["BMarketInfo"] = "";
                    }

                    this.InvalidateCellEx(this.Columns["DisplayPrice"].HeaderCell.ColumnIndex, currentIndex);
                }

                if ((drData != null) && this.m_MiddleMatchPriceEnabled)
                {
                    this.focusMatchPrice(drData, true);
                }
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }
        public void updateMaxMinPrice(decimal dml_BeforeMaxPrice, decimal dml_MaxPrice, decimal dml_BeforeMinPrice, decimal dml_MinPrice)
        {
            try
            {
                if (m_bolMaxMinEnable)
                {
                    MAXPRICE = dml_MaxPrice;
                    DataTable dataSource = _dt;
                    int currentIndex = 0;
                    DataRow drData = SearchByPriceData(dml_BeforeMaxPrice);
                    if (drData != null)
                    {
                        currentIndex = int.Parse(drData["INDEX"].ToString());
                        this.InvalidateCellEx(this.Columns["DisplayPrice"].HeaderCell.ColumnIndex, currentIndex);
                    }

                    drData = dataSource.Rows.Find(dml_MaxPrice);
                    if (drData != null)
                    {
                        currentIndex = int.Parse(drData["INDEX"].ToString());
                        this.InvalidateCellEx(this.Columns["DisplayPrice"].HeaderCell.ColumnIndex, currentIndex);
                    }


                    MINPRICE = dml_MinPrice;
                    drData = SearchByPriceData(dml_BeforeMinPrice);
                    if (drData != null)
                    {
                        currentIndex = int.Parse(drData["INDEX"].ToString());
                        this.InvalidateCellEx(this.Columns["DisplayPrice"].HeaderCell.ColumnIndex, currentIndex);
                    }

                    drData = dataSource.Rows.Find(dml_MinPrice);
                    if (drData != null)
                    {
                        currentIndex = int.Parse(drData["INDEX"].ToString());
                        this.InvalidateCellEx(this.Columns["DisplayPrice"].HeaderCell.ColumnIndex, currentIndex);
                    }
                }
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }
        public bool bolMoveBackColor
        {
            get
            {
                return m_bolMoveBackColor;
            }
            set
            {
                m_bolMoveBackColor = value;
            }
        }

        public int int_MoveIndex
        {
            get
            {
                return this.mint_MoveIndex;
            }
            set
            {
                this.mint_MoveIndex = value;
            }
        }

        public Color MatchPriceBackColor
        {
            get
            {
                return m_MatchPriceBackColor;
            }
            set
            {
                m_MatchPriceBackColor = value;
            }
        }

        public Color MatchPriceForeColor
        {
            get
            {
                return m_MatchPriceForeColor;
            }
            set
            {
                m_MatchPriceForeColor = value;
            }
        }

        public Color MBBackColor
        {
            get
            {
                return this.m_MBBackColor;
            }
            set
            {
                this.m_MBBackColor = value;
            }
        }

        public Color MBForeColor
        {
            get
            {
                return this.m_MBForeColor;
            }
            set
            {
                this.m_MBForeColor = value;
            }
        }

        public bool MiddleMatchPriceEnabled
        {
            get
            {
                return this.m_MiddleMatchPriceEnabled;
            }
            set
            {
                this.m_MiddleMatchPriceEnabled = value;
                if (base.DataSource != null)
                {
                    DataRow[] rowArray = ((DataTable)base.DataSource).Select(" flag ='Y' ");
                    if (this.m_MiddleMatchPriceEnabled)
                    {
                        base.ScrollBars = ScrollBars.None;
                    }
                    else
                    {
                        base.ScrollBars = ScrollBars.Vertical;
                    }
                    if (rowArray.Length > 0)
                    {
                        this.focusMatchPrice(rowArray[0], true);
                    }
                }
            }
        }

        public Color MSBackColor
        {
            get
            {
                return this.m_MSBackColor;
            }
            set
            {
                this.m_MSBackColor = value;
            }
        }

        public Color MSForeColor
        {
            get
            {
                return this.m_MSForeColor;
            }
            set
            {
                this.m_MSForeColor = value;
            }
        }

        public Color PriceBackColor
        {
            get
            {
                return m_PriceBackColor;
            }
            set
            {
                m_PriceBackColor = value;
            }
        }

        public Color PriceForeColor
        {
            get
            {
                return m_PriceForeColor;
            }
            set
            {
                m_PriceForeColor = value;
            }
        }

        public bool WBSBackColorEnabled
        {
            get
            {
                return this.m_WBSBackColorEnabled;
            }
            set
            {
                this.m_WBSBackColorEnabled = value;
            }
        }
        public bool bolMatchQty
        {
            get { return m_bolMatchQty; }
            set { m_bolMatchQty = value; }
        }
        public bool bolMaxMinEnable
        {
            get { return m_bolMaxMinEnable; }
            set { m_bolMaxMinEnable = value; }
        }
        public decimal MAXPRICE
        {
            get { return m_MAXPRICE; }
            set { m_MAXPRICE = value; }
        }

        public decimal MINPRICE
        {
            get { return m_MINPRICE; }
            set { m_MINPRICE = value; }
        }
        public Color MAXPRICEBackColor
        {
            get
            {
                return m_MAXPRICEBackColor;
            }
            set
            {
                m_MAXPRICEBackColor = value;
            }
        }
        public Color MINPRICEBackColor
        {
            get
            {
                return m_MINPRICEBackColor;
            }
            set
            {
                m_MINPRICEBackColor = value;
            }
        }
    }
}

