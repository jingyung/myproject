﻿namespace com.ddsc.tool.window
{
    using System;
    using System.Windows.Forms;

    public class DDSCRadioButton : RadioButton
    {
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            switch (keyData)
            {
                case Keys.Left:
                    return true;

                case Keys.Right:
                    return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }
    }
}

