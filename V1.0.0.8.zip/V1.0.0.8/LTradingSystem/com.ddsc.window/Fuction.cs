﻿namespace com.ddsc.tool.window
{
    using System;
    public class Fuction
    {
        public class ComboBoxItem
        {
            private int m_idx;
            private string m_Text;
            private string m_Value;

            public ComboBoxItem(string Value, string Text, int idx)
            {
                this.m_Value = Value;
                this.m_Text = Text;
                this.m_idx = idx;
            }

            public override string ToString()
            {
                return this.m_Text;
            }

            public int idx
            {
                get
                {
                    return this.m_idx;
                }
                set
                {
                    this.m_idx = value;
                }
            }

            public string Text
            {
                get
                {
                    return this.m_Text;
                }
                set
                {
                    this.m_Text = value;
                }
            }

            public string Value
            {
                get
                {
                    return this.m_Value;
                }
                set
                {
                    this.m_Value = value;
                }
            }
        }
    }
}

