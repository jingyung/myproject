﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Net.Sockets;
using com.ddsc.core;
using com.ddsc.nets.server;
using com.ddsc.BI.F;

using com.ddsc.tool;
using System.Net;
using System.IO;
using System.Web;
using System.Data;
using System.Collections;
//using DGWProtocols;
using System.Data.SqlClient;
using System.Xml;
//using FDGWProtocols;
using DDSCFIX4TT;
namespace com.ddsc.TradeSocketServer
{


    public class TradeStringHandler
    {
        StrategyDataProvider _StrategyDataProvider;
        Boolean _RiskFlag = true;

        int _DGWReplyCount;
        int _DGWMatchReplyCount;
        SymbolProvider _SymbolProvider = null;

        bool _ReorderEnable = true;
        ReportProvider _ReportProvider = null;
        AccountItemProvider _AccountItemProvider = null;

        SeqProvider _OrderNo = null;
        SeqProvider _OrderNoSeq = null;
        SeqProvider _Seq = null;


        SeqDataProvider _SeqVipDataProvider = null;

        private string _SrcID = "";
        DataAgent _DataAgent;

        public DataAgent DataAgent
        {
            get { return _DataAgent; }
            set { _DataAgent = value; }
        }




        SAEAServer _SAEA;

        public SAEAServer SAEA
        {
            get { return _SAEA; }
            set { _SAEA = value; }
        }
        AccountCore _AccountCore;
        public AccountCore AccountCore
        {
            get { return _AccountCore; }
            set { _AccountCore = value; }
        }
        DBTcpClient _DBClient;
        public DBTcpClient DBClient
        {
            set { _DBClient = value; }
            get { return _DBClient; }
        }


        private QueuePoolByLock<byte[]> _SyncQ;

        public QueuePoolByLock<byte[]> SyncQ
        {
            get { return _SyncQ; }
            set { _SyncQ = value; }
        }

        private QueuePoolByLock<byte[]> _DBServerQ;

        public QueuePoolByLock<byte[]> DBServerQ
        {
            get { return _DBServerQ; }
            set { _DBServerQ = value; }
        }

        private QueuePoolByLock<string> _OrderDataQWriterQ;

        public QueuePoolByLock<string> OrderDataQWriterQ
        {
            get { return _OrderDataQWriterQ; }
            set { _OrderDataQWriterQ = value; }
        }

        private QueuePoolByLock<string> _RepleDataQReadersQ;

        public QueuePoolByLock<string> RepleDataQReadersQ
        {
            get { return _RepleDataQReadersQ; }
            set { _RepleDataQReadersQ = value; }
        }

        bool _DataEncode = false;
        public bool DataEncode
        {
            set { _DataEncode = value; }
            get { return _DataEncode; }
        }


        SaveDB[] _SaveDB;


        delegate int SignVerifyHandler(string networkid, string data, string Signature, string CertSN, string idno, string IP);
        SignVerifyHandler SignVerifyExcute;



        private string _WebCode = "";//order
        private bool _VerifyFlag = false;

        AccountQueryCore _OrderCore; //委託
        AccountQueryCore _AccountQueryCore; //一般帳務查詢

        public ActiveReplyCore _ActiveReplyCore;//主動回報

        string _CloseTime = "";
        bool _CloseTimeEnable = false;

        public TradeStringHandler(AccountCore AccountCore)
        {
            try
            {
                _StrategyDataProvider = new StrategyDataProvider();
                _AccountItemProvider = new AccountItemProvider();
                _ReportProvider = new ReportProvider();

                _RiskFlag = DataAgent.DEFAULTProvider.GetBool("RiskFlag");

                _OrderNo = new SeqProvider("OrderNo",  DataAgent.BASEPATH+ "\\log\\current");
                _OrderNoSeq = new SeqProvider("NetWorkID", DataAgent.BASEPATH + "\\log\\current");

                _SeqVipDataProvider = new SeqDataProvider("VIPReplyData", DataAgent.BASEPATH + "\\log\\current");
                _Seq = new SeqProvider("Seq", DataAgent.BASEPATH + "log\\current");

                _OrderCore = new AccountQueryCore();
                _AccountQueryCore = new AccountQueryCore();

                _ActiveReplyCore = new ActiveReplyCore();
                _SrcID = DataAgent.DEFAULTProvider.GetString("SrcID");
                _VerifyFlag = bool.Parse(DataAgent.DEFAULTProvider.GetString("VerifyFlag"));
                try
                {


                }
                catch (Exception ex)
                {

                    WriteLog("DataAgentLog", "TradeStringHandler_VA:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
                }
                _SAEA = SAEA;


                SignVerifyExcute = new SignVerifyHandler(SignVerify);
                LinkedList<Dictionary> SaveDBs = DataAgent.SettingProvider.Get("SAVEDB");

                if (SaveDBs.Count > 0)
                {
                    _SaveDB = new SaveDB[SaveDBs.Count];
                    int i = 0;
                    foreach (Dictionary obj in SaveDBs)
                    {
                        _SaveDB[i] = new SaveDB(i, obj.GetString("SaveDBConnectionString"));
                        _SaveDB[i].SaveDBEvent += new SaveDB.SaveDBHandler(_SaveDBEvent);
                        i++;
                    }
                }

                _SAEA = SAEA;
                _AccountCore = AccountCore;





                _SymbolProvider = new SymbolProvider();

                _StrategyDataProvider.OrderTrigger += new StrategyDataProvider.OrderTriggerHandler(_StrategyDataProvider_OrderTrigger);
            }
            catch (Exception ex)
            {

                WriteLog("DataAgentLog", "TradeStringHandler:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }

        }

        private bool CheckCloseTime()
        {
            try
            {

                //false時關閉此功能 
                if (!_CloseTimeEnable) return true;

                if (DateTime.Now > DateTime.Parse(_CloseTime.Split('~')[0])
                    && DateTime.Now < DateTime.Parse(_CloseTime.Split('~')[1]))
                {
                    return false;
                }

                return true;
            }
            catch (Exception ex)
            {
                WriteLog("DataAgentLog", "CheckCloseTime:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());

            }
            return true;
        }



        public void load()
        {

        }

        ~TradeStringHandler()
        {
            Dispose();
        }

        public void Dispose()
        {
            if (_StrategyDataProvider != null)
                _StrategyDataProvider.OrderTrigger -= new StrategyDataProvider.OrderTriggerHandler(_StrategyDataProvider_OrderTrigger);

            if (_AccountItemProvider != null)
                _AccountItemProvider.Dispose();
            if (_ReportProvider != null)
                _ReportProvider.Dispose();
            if (_Seq != null)
                _Seq.Dispose();


            if (_OrderNo != null)
            {
                _OrderNo.Dispose();
            }
            if (_OrderNoSeq != null)
                _OrderNoSeq.Dispose();

            if (_SeqVipDataProvider != null)
                _SeqVipDataProvider.close();
            if (_SaveDB != null)
            {
                for (int i = 0; i < _SaveDB.Length; i++)
                {
                    _SaveDB[i].SaveDBEvent -= new SaveDB.SaveDBHandler(_SaveDBEvent);
                    _SaveDB[i].SaveDBDispose();
                }
            }

            if (_OrderCore != null)
            {
                _OrderCore.Close();
            }



            GC.SuppressFinalize(this);
        }


        public void ParseDDSCData(SocketAsyncEventArgs S, byte[] buffer)
        {
            try
            {

                AccountItem item;
                string RemoteIP = ((System.Net.IPEndPoint)S.AcceptSocket.RemoteEndPoint).Address.ToString();
                switch (buffer[0])
                {
                    case SockClientParserFunction.DDSCSocketHead.Cover:
                        if (_DataEncode)
                            buffer = SockClientParserFunction.DecodeData(buffer);
                        // WriteLog("SAEAServerLogRCV" + S.AcceptSocket.RemoteEndPoint.ToString().Replace(":", ";"), buffer);
                        WriteLog("SAEAServerLogRCV" + RemoteIP, buffer);
                        ParseCover(S, buffer);
                        break;
                    case 0xFF:
                        if (_DataEncode)
                            buffer = SockClientParserFunction.DecodeData(buffer);
                        // WriteLog("SAEAServerLogRCV" + S.AcceptSocket.RemoteEndPoint.ToString().Replace(":", ";"), buffer);
                        WriteLog("SAEAServerLogRCV" + RemoteIP, buffer);
                        ParseMA(S, buffer);
                        break;

                    case SockClientParserFunction.DDSCSocketHead.Alive:
                        if (_DataEncode)
                            buffer = SockClientParserFunction.DecodeData(buffer);
                        // WriteLog("SAEAServerLogRCV" + S.AcceptSocket.RemoteEndPoint.ToString().Replace(":", ";"), buffer);
                        WriteLog("SAEAServerLogRCV" + RemoteIP, buffer);
                        ParseAlive(S, buffer);
                        break;
                    case SockClientParserFunction.DDSCSocketHead.RegTradeAct:
                        if (_DataEncode)
                            buffer = SockClientParserFunction.DecodeData(buffer);
                        //WriteLog("SAEAServerLogRCV" + S.AcceptSocket.RemoteEndPoint.ToString().Replace(":", ";"), buffer);
                        WriteLog("SAEAServerLogRCV" + RemoteIP, buffer);
                        ParseRegTradeAct(S, buffer);
                        break;
                    case SockClientParserFunction.DDSCSocketHead.Connecting:
                        if (_DataEncode)
                            buffer = SockClientParserFunction.DecodeData(buffer);
                        //WriteLog("SAEAServerLogRCV" + S.AcceptSocket.RemoteEndPoint.ToString().Replace(":", ";"), buffer);
                        WriteLog("SAEAServerLogRCV" + RemoteIP, buffer);
                        ParseConnecting(S, buffer);
                        break;

                    case SockClientParserFunction.DDSCSocketHead.GeneralTrade:
                    case 0xF1: //sync 
                        if (_DataEncode)
                            buffer = SockClientParserFunction.DecodeData(buffer);
                        //WriteLog("SAEAServerLogRCV" + S.AcceptSocket.RemoteEndPoint.ToString().Replace(":", ";"), buffer);
                        WriteLog("SAEAServerLogRCV" + RemoteIP, buffer);
                        item = new AccountItem();
                        item.init();

                        item.Protocol = DDSCProtocol.DDSC;
                        item.S = S;

                        item.Encode = _DataEncode;//跟GW設定
                        item.T2 = Date.NowTime().ToString("HH:mm:ss.fff");
                        if (buffer[0] == SockClientParserFunction.DDSCSocketHead.GeneralTrade)
                            ParseGeneralTrade(false, ref item, S, buffer, "", "", "");
                        else
                            ParseGeneralTrade(true, ref item, S, buffer, "", "", "");
                        break;

                    case SockClientParserFunction.DDSCSocketHead.ProgramTrade:
                    case 0xF2: //sync 
                        if (_DataEncode)
                            buffer = SockClientParserFunction.DecodeData(buffer);
                        //WriteLog("SAEAServerLogRCV" + S.AcceptSocket.RemoteEndPoint.ToString().Replace(":", ";"), buffer);
                        WriteLog("SAEAServerLogRCV" + RemoteIP, buffer);
                        item = new AccountItem();
                        item.init();

                        item.Protocol = DDSCProtocol.DDSC;
                        item.S = S;

                        item.Encode = _DataEncode;//跟GW設定
                        item.T2 = Date.NowTime().ToString("HH:mm:ss.fff");
                        if (buffer[0] == SockClientParserFunction.DDSCSocketHead.ProgramTrade)
                            ParseProgramTrade(false, ref item, S, buffer, "", "", "");
                        else
                            ParseProgramTrade(true, ref item, S, buffer, "", "", "");
                        break;
                    //case SockClientParserFunction.DDSCSocketHead.CATrade:
                    //    if (_DataEncode)
                    //        buffer = SockClientParserFunction.DecodeData(buffer);
                    //    //WriteLog("SAEAServerLogRCV" + S.AcceptSocket.RemoteEndPoint.ToString().Replace(":", ";"), buffer);
                    //    WriteLog("SAEAServerLogRCV" + RemoteIP, buffer);
                    //    item = new AccountItem();
                    //    item.init();

                    //    item.Protocol = DDSCProtocol.DDSC;
                    //    item.S = S;

                    //    item.Encode = _DataEncode;//跟GW設定
                    //    item.T2 = Date.NowTime().ToString("HH:mm:ss.fff");
                    //    ParseCATrade(ref item, S, buffer);
                    //    break;

                    default:



                        WriteLog("DataAgentLog", "ParseDDSCData:" + "length=" + buffer.Length + S.AcceptSocket.RemoteEndPoint.ToString() + "format error!");
                        WriteLog("DataAgentLog", "ParseDDSCData:" + ASCIIEncoding.ASCII.GetString(buffer));
                        WriteLog("DataAgentLog", "ParseDDSCData:" + ASCIIEncoding.ASCII.GetString(_DataEncode ? SockClientParserFunction.DecodeData(buffer) : buffer));
                        _SAEA.CloseClientSocket(S);
                        break;
                }


            }
            catch (Exception ex)
            {

                WriteLog("DataAgentLog", "ParseDDSCData:" + "length=" + buffer.Length + "-" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString() + S.AcceptSocket.RemoteEndPoint.ToString());
                WriteLog("DataAgentLog", "ParseDDSCData:" + ASCIIEncoding.ASCII.GetString(buffer));
                WriteLog("DataAgentLog", "ParseDDSCData:" + ASCIIEncoding.ASCII.GetString(_DataEncode ? SockClientParserFunction.DecodeData(buffer) : buffer));
                _SAEA.CloseClientSocket(S);
            }
        }



        private void ParseCover(SocketAsyncEventArgs S, byte[] buffer)
        {
            try
            {
                SockClientParserFunction.DDSCHead raw = new SockClientParserFunction.DDSCHead();

                com.ddsc.BI.F.ParserStruct<SockClientParserFunction.DDSCHead>.ByteArrayToStructure(buffer, ref raw);

                string Userid = ASCIIEncoding.ASCII.GetString(raw.USERID).Trim();
                string seq = ASCIIEncoding.ASCII.GetString(buffer, Marshal.SizeOf(typeof(SockClientParserFunction.DDSCHead))
                    , buffer.Length - Marshal.SizeOf(typeof(SockClientParserFunction.DDSCHead)) - 1);

                int REPLYSEQ = int.Parse(seq);

                int ReplyDataCount = _SeqVipDataProvider.Count;


                string[] REPLYSEQS = _SeqVipDataProvider.GetArray(REPLYSEQ, ReplyDataCount);


                if (REPLYSEQS != null)
                {
                    foreach (string data in REPLYSEQS)
                    {
                        byte[] body = ASCIIEncoding.Default.GetBytes(data.Substring(20, data.Length - 20));
                        string OldSeq = data.Substring(0, 9);
                        string NewSeq = data.Substring(10, 9);
                        SockClientParserFunction.DDSCHead DDSCHead = new SockClientParserFunction.DDSCHead();
                        DDSCHead.HEAD = new byte[1] { SockClientParserFunction.DDSCSocketHead.Reply };
                        DDSCHead.MESSAGETIME = ASCIIEncoding.ASCII.GetBytes(DateTime.Now.ToString("HHmmssfff"));
                        DDSCHead.LENGTH = BitConverter.GetBytes(UInt16.Parse(body.Length.ToString()));
                        if (BitConverter.IsLittleEndian)
                            Array.Reverse(DDSCHead.LENGTH);
                        byte[] retBuffer = new byte[50 + body.Length + 1];
                        DDSCHead.OLDSEQ = ASCIIEncoding.ASCII.GetBytes(OldSeq);
                        DDSCHead.NEWSEQ = ASCIIEncoding.ASCII.GetBytes(NewSeq);
                        DDSCHead.USERID = ASCIIEncoding.ASCII.GetBytes("".PadRight(20, ' '));
                        byte[] headbyte = SockClientParserFunction.StructureToByteArray(DDSCHead);
                        Array.Copy(headbyte, 0, retBuffer, 0, headbyte.Length);
                        Array.Copy(body, 0, retBuffer, headbyte.Length, body.Length);
                        retBuffer[retBuffer.Length - 1] = SockClientParserFunction.DDSCSocketHead.End;


                        SockClientParserFunction.Reply Reply = new SockClientParserFunction.Reply();
                        string KeepData = ASCIIEncoding.Default.GetString(retBuffer, 50 + Marshal.SizeOf(Reply), retBuffer.Length - 50 - Marshal.SizeOf(Reply) - 1);

                        //KeepData

                        ////OrderKind=P^OrderTag=^AE=^AD=Time Slice|2|500|20161004172843726|20161004182843000|35000|5|0^pseq=^

                        //AD=Time Slice|2|500|20161004172843726|20161004182843000|35000|5|0^          代表委託母單
                        //AD=Time Slice|2|5|20161006114551410|20161006114851000|34000|1|0^pseq=A000C0002^ 代表委託出去的單子 子單
                        string OrderKind = "";
                        string OrderTag = "";
                        string AE = "";
                        string AD = "";
                        string pseq = "";
                        //KeepData
                        //AD=Time Slice|2|500|20161004172843726|20161004182843000|35000|5|0^          代表委託母單
                        //AD=Time Slice|2|5|20161006114551410|20161006114851000|34000|1|0^pseq=A000C0002^ 代表委託出去的單子 子單
                        foreach (string f in KeepData.Split('^'))
                        {
                            if (f.IndexOf("OrderKind") > -1)
                            {
                                OrderKind = f.Split('=')[1];
                            }
                            if (f.IndexOf("AD") > -1)
                            {
                                AD = f.Split('=')[1];
                            }
                            if (f.IndexOf("pseq") > -1)
                            {
                                pseq = f.Split('=')[1];
                            }
                            if (f.IndexOf("OrderTag") > -1)
                            {
                                OrderTag = f.Split('=')[1];
                            }
                            if (f.IndexOf("AE") > -1)
                            {
                                AE = f.Split('=')[1];
                            }

                        }
                        if (OrderKind == "P")
                        {
                            retBuffer[0] = SockClientParserFunction.DDSCSocketHead.ProgramTradeReply;
                        }

                        SendDataToAP(S, retBuffer);

                    }
                }

            }
            catch (Exception ex)
            {
                WriteLog("DataAgentLog", "ParseConnecting:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
                throw ex;
            }
        }

        private void ParseMA(SocketAsyncEventArgs S, byte[] buffer)
        {
            try
            {
                SockClientParserFunction.DDSCHead raw = new SockClientParserFunction.DDSCHead();

                com.ddsc.BI.F.ParserStruct<SockClientParserFunction.DDSCHead>.ByteArrayToStructure(buffer, ref raw);


                raw.HEAD = new byte[] { 0xff };

                string body = "";






                if (_DBClient.Socket.Connected)
                    body += "DBClient:true\n";
                else
                    body += "DBClient:false\n";
                if (_SAEA.Active)
                    body += "SAEAServer:true\n";
                else
                    body += "SAEAServer:false\n";
                if (_DataAgent.TransferData)
                    body += "TransferData:true\n";
                else
                    body += "TransferData:false\n";



                body += "WorkDayForDomestic:" + _DataAgent.WorkDayForDomestic + "\n";
                body += "WorkDayForForeign:" + _DataAgent.WorkDayForForeign + "\n";
                body += "WorkDay:" + _DataAgent.WorkDay + "\n";
                body += "NextWorkDay:" + _DataAgent.NextWorkDay + "\n";

                byte[] bytebody = ASCIIEncoding.ASCII.GetBytes(body);

                raw.LENGTH = BitConverter.GetBytes(Convert.ToUInt16(bytebody.Length));
                if (BitConverter.IsLittleEndian)
                {
                    Array.Reverse(raw.LENGTH);
                }
                buffer = SockClientParserFunction.StructureToByteArray(raw);
                byte[] ret = new byte[buffer.Length + bytebody.Length + 1];
                Array.Copy(buffer, 0, ret, 0, buffer.Length);
                Array.Copy(bytebody, 0, ret, buffer.Length, bytebody.Length);
                ret[ret.Length - 1] = SockClientParserFunction.DDSCSocketHead.End;


                SendDataToAP(S, ret);

            }
            catch (Exception ex)
            {
                WriteLog("DataAgentLog", "ParseConnecting:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
                throw ex;
            }
        }

        private void ParseAlive(SocketAsyncEventArgs S, byte[] buffer)
        {
            try
            {
                // string len = getDDSCRawDataLength(buffer);
                SendDataToAP(S, buffer);
                //this._SAEA.SendData(S, buffer);

            }
            catch (Exception ex)
            {
                WriteLog("DataAgentLog", "ParseAlive:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
                throw ex;
            }
        }

        private void ParseRegTradeAct(SocketAsyncEventArgs S, byte[] buffer)
        {
            try
            {
                SockClientParserFunction.DDSCHead raw = new SockClientParserFunction.DDSCHead();

                com.ddsc.BI.F.ParserStruct<SockClientParserFunction.DDSCHead>.ByteArrayToStructure(buffer, ref raw);

                string Userid = ASCIIEncoding.ASCII.GetString(raw.USERID).Trim();
                string body = ASCIIEncoding.ASCII.GetString(buffer, Marshal.SizeOf(typeof(SockClientParserFunction.DDSCHead))
                    , buffer.Length - Marshal.SizeOf(typeof(SockClientParserFunction.DDSCHead)) - 1);
                ArrayList comact = new ArrayList();

                string brokerid = body.Substring(0, 7).Trim();
                string act = body.Substring(7, 7).Trim();
                string subactno = body.Substring(14, 7).Trim();
                comact.Add(brokerid + act + subactno);
                if (subactno.Length > 0)
                    _AccountCore.AddACTNOFlag(act);
                comact.Add(brokerid + act + subactno);
                Array o = comact.ToArray(typeof(string));

                _AccountCore.AddUser(Userid, (string[])o);
                if (_AccountCore.AddSAEA(Userid, S))
                {

                }
                else
                {
                    WriteLog("DataAgentLog", "ParseConnecting:" + "無此帳號:" + Userid);
                    _SAEA.CloseClientSocket(S);
                }

            }
            catch (Exception ex)
            {
                WriteLog("DataAgentLog", "ParseConnecting:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
                throw ex;
            }
        }

        private void ParseConnecting(SocketAsyncEventArgs S, byte[] buffer)
        {
            try
            {
                SockClientParserFunction.DDSCHead raw = new SockClientParserFunction.DDSCHead();

                com.ddsc.BI.F.ParserStruct<SockClientParserFunction.DDSCHead>.ByteArrayToStructure(buffer, ref raw);

                string Userid = ASCIIEncoding.ASCII.GetString(raw.USERID).Trim();
                string body = ASCIIEncoding.ASCII.GetString(buffer, Marshal.SizeOf(typeof(SockClientParserFunction.DDSCHead))
                    , buffer.Length - Marshal.SizeOf(typeof(SockClientParserFunction.DDSCHead)) - 1);
                //ArrayList comact = new ArrayList();
                //for (int i = 0; i * (7 + 7 + 7) < body.Length; i++)//brokerid(7)+act(7)+subactno(7)
                //{
                //    string brokerid = body.Substring(i * (7 + 7 + 7), 21).Substring(0, 7).Trim();
                //    string act = body.Substring(i * (7 + 7 + 7), 21).Substring(7, 7).Trim();
                //    string subactno = body.Substring(i * (7 + 7 + 7), 21).Substring(14, 7).Trim();
                //    comact.Add(brokerid + act + subactno);
                //    if (subactno.Length > 0)
                //        _AccountCore.AddACTNOFlag(act);
                //}
                //Array o = comact.ToArray(typeof(string));
                //_AccountCore.AddUser(Userid, (string[])o);
                _AccountCore.AddUser(Userid);
                if (_AccountCore.AddSAEA(Userid, S))
                {
                    raw.HEAD = new byte[] { SockClientParserFunction.DDSCSocketHead.Connected };

                    UserInfo u = _AccountCore.FindUserInfo(S);
                    byte[] seq = getSeq();

                    Array.Copy(seq, 0, raw.NEWSEQ, 0, seq.Length);
                    Array.Copy(seq, 0, raw.OLDSEQ, 0, seq.Length);
                    raw.LENGTH = BitConverter.GetBytes(UInt16.Parse("0"));
                    buffer = SockClientParserFunction.StructureToByteArray(raw);
                    byte[] ret = new byte[buffer.Length + 1];
                    Array.Copy(buffer, 0, ret, 0, buffer.Length);
                    ret[ret.Length - 1] = SockClientParserFunction.DDSCSocketHead.End;

                    //string[] arrPutIPLoginCmd = new string[1];
                    //arrPutIPLoginCmd[0] = " INSERT INTO [dbo].[TRADEIPLOG] "
                    //+ "  ([USERID],[IP],[PORT],[LOGINTIME],[STATUS],[LOGDATE])VALUES "
                    //+ "('" + Userid + "','" + S.AcceptSocket.RemoteEndPoint.ToString().Split(':')[0] + "','" + S.AcceptSocket.RemoteEndPoint.ToString().Split(':')[1] + "','" + u.LoginTime + "','',convert(char(8),getdate(),112))";
                    //_SaveDB.PutData2Queue(arrPutIPLoginCmd);

                    SendDataToAP(S, ret);
                }
                else
                {
                    WriteLog("DataAgentLog", "ParseConnecting:" + "無此帳號:" + Userid);
                    _SAEA.CloseClientSocket(S);
                }
            }
            catch (Exception ex)
            {
                WriteLog("DataAgentLog", "ParseConnecting:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
                throw ex;
            }
        }

        private void CombineErrorGeneralTrade(SockClientParserFunction.Order Order, string ErrorCode, string ORDERSTATUS)
        {
            try
            {

                string BROKERID;
                string INVESTORACNO;
                string NETWORKID;

                BROKERID = ASCIIEncoding.ASCII.GetString(Order.BROKERID).Trim();
                INVESTORACNO = ASCIIEncoding.ASCII.GetString(Order.INVESTORACNO).Trim();
                NETWORKID = ASCIIEncoding.ASCII.GetString(Order.CLORDID).Trim(); ;

                string SUBACT = "";//ASCIIEncoding.ASCII.GetString(Order.SUBACT).Trim();

                byte[] buffer = DbServerProvider.ResponseOrderToError(ref Order, ErrorCode, ORDERSTATUS);
                buffer = SendOrderDataToAP(BROKERID + INVESTORACNO + SUBACT, SockClientParserFunction.DDSCSocketHead.Reply, NETWORKID, buffer);



            }
            catch (Exception ex)
            {
                WriteLog("DataAgentLog", "CombineErrorGeneralTrade:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }


        private string ParseGeneralTrade(bool Sync, ref AccountItem item, SocketAsyncEventArgs S, byte[] source_buffer, string ID, string Data, string CA)
        {
            string System = "";

            string Clordid = ""; //order +networkid;
            string OriClordid = "";
            string KeepOriClordid = ""; //for patsystem
            string NetworkId = ""; //termid(2)+networkid(8)
            string webcode = "";
            string OrderID = "";//上手書號
            string Orderno = "";
            string TargetID = "";//上手代號
            string Account = "";//上手交易帳號
            byte[] buffer = null;
            try
            {
                SockClientParserFunction.DDSCOrder DDSCOrder = new SockClientParserFunction.DDSCOrder();
                com.ddsc.BI.F.ParserStruct<SockClientParserFunction.DDSCOrder>.ByteArrayToStructure(source_buffer, ref DDSCOrder);

                string KeepData = ASCIIEncoding.Default.GetString(source_buffer, 50 + Marshal.SizeOf(DDSCOrder.Order)
               , source_buffer.Length - 50 - Marshal.SizeOf(DDSCOrder.Order) - 1);
                //OrderKind=P^OrderTag=^AE=^AD=^
                string OrderKind = "";
                string OrderTag = "";
                string AE = "";
                string AD = "";
                string pseq = "";

                foreach (string f in KeepData.Split('^'))
                {
                    if (f.IndexOf("OrderKind") > -1)
                    {
                        OrderKind = f.Split('=')[1];
                    }
                    if (f.IndexOf("AD") > -1)
                    {
                        AD = f.Split('=')[1];
                    }
                    if (f.IndexOf("pseq") > -1)
                    {
                        pseq = f.Split('=')[1];
                    }
                    if (f.IndexOf("OrderTag") > -1)
                    {
                        OrderTag = f.Split('=')[1];
                    }
                    if (f.IndexOf("AE") > -1)
                    {
                        AE = f.Split('=')[1];
                    }

                }

                string Seq = ASCIIEncoding.ASCII.GetString(DDSCOrder.Head.OLDSEQ);
                string NewSeq = ASCIIEncoding.ASCII.GetString(DDSCOrder.Head.NEWSEQ);


                string ip = S.AcceptSocket.RemoteEndPoint.ToString();
                item.OrderItem.IP = ip;


                string Exectype = ASCIIEncoding.ASCII.GetString(DDSCOrder.Order.EXECTYPE);//0:新增, 4:取消, 5: 減量, M:改價
                if (Sync) //如果為同步資料時，取CLORDID，如果不是則新NEW一筆
                    NetworkId = ASCIIEncoding.Default.GetString(DDSCOrder.Order.CLORDID).Trim();
                else
                    NetworkId = getNetworkId();

                OriClordid = NetworkId;


                switch (Exectype)
                {
                    case "0"://0:新增
                        if (Sync)
                            Orderno = ASCIIEncoding.Default.GetString(DDSCOrder.Order.ORDERNO).Trim();
                        else
                            Orderno = getOrderNo();
                       
                        item.NETWORKID = NetworkId;
                        DDSCOrder.Order.CLORDID = ASCIIEncoding.Default.GetBytes(NetworkId.PadRight(25, ' '));
                        DDSCOrder.Order.ORDERNO = ASCIIEncoding.Default.GetBytes(Orderno.PadRight(7, ' '));

                        DDSCOrder.Order.IP = ASCIIEncoding.ASCII.GetBytes(ip.PadRight(30));


                        byte[] body = SockClientParserFunction.StructureToByteArray(DDSCOrder.Order);

                        Array.Copy(body, 0, source_buffer, 50, body.Length);
                        //source_buffer = SockClientParserFunction.StructureToByteArray(DDSCOrder);
                        _AccountCore.AddNetWorkIdItem(S, NetworkId, Seq, "", KeepData);


                        //    AS400Order = GetAS400Order(DDSCOrder, NetworkId, ip);

                        break;
                    case "4":// 4:取消, 5: 減量, M:改價
                    case "5":
                    case "M":
                        Orderno = ASCIIEncoding.Default.GetString(DDSCOrder.Order.ORDERNO).Trim();
                        item.NETWORKID = NetworkId;
                        OriClordid = ASCIIEncoding.Default.GetString(DDSCOrder.Order.CLORDID).Trim();
                        FOrderItem Fitem = _AccountItemProvider.GetReplyData(OriClordid);
                        if (Fitem != null)
                        {
                            OrderID = Fitem.ORDERID;//取得上手書號
                            KeepOriClordid = Fitem.KEEPORICLORDID;
                        }
                        _AccountCore.UpdSeqItem(OriClordid, NewSeq);

                        break;

                }

                if (!Sync)
                {


                    byte[] SyncBuffer = new byte[source_buffer.Length];

                    Array.Copy(source_buffer, SyncBuffer, SyncBuffer.Length);
                    SyncBuffer[0] = 0xF1;

                    SendDataToSync(SyncBuffer);

                }
                SendDataToDBServer(source_buffer);



                //檢核此交易帳號對應哪個上手、上手帳號
                Targetitem titem = chkTargetData(GetString(DDSCOrder.Order.BROKERID), GetString(DDSCOrder.Order.INVESTORACNO)
                    , GetString(DDSCOrder.Order.SECURITYEXCHANGE), GetString(DDSCOrder.Order.SECURITYTYPE1)
                    , GetString(DDSCOrder.Order.SYMBOL1), GetString(DDSCOrder.Order.MATURITYMONTHYEAR1));
                if (titem == null)
                {
                    DDSCOrder.Order.CLORDID = ASCIIEncoding.ASCII.GetBytes(OriClordid.PadRight(25, ' '));
                    CombineErrorGeneralTrade(DDSCOrder.Order, "ERR1", "");
                    item.T5 = Date.NowTime().ToString("HH:mm:ss.fff");
                    VIPProvider.OrderTo(ref item, ref DDSCOrder.Order, Exectype, Orderno, OriClordid, OrderID
                                    , "ERR1", "", TargetID, Account, "", "");
                    _SaveDB[0].PutData2QueueDetail(item);

                    return "";
                }
                else
                {
                    TargetID = titem.TargetID;//上手代號
                    Account = titem.Account;//上手交易帳號
                    System = titem.System;//上手交易帳號
                }

                //檢核是否有連線
                string TargetServer = null;
                _DataAgent.TargetServer.TryGetValue(TargetID, out TargetServer);
                if (TargetServer == null)
                {
                    DDSCOrder.Order.CLORDID = ASCIIEncoding.ASCII.GetBytes(OriClordid.PadRight(25, ' '));
                    CombineErrorGeneralTrade(DDSCOrder.Order, "ERR1", "");
                    item.T5 = Date.NowTime().ToString("HH:mm:ss.fff");
                    VIPProvider.OrderTo(ref item, ref DDSCOrder.Order, Exectype, Orderno, OriClordid, OrderID
                                    , "ERR1", "", TargetID, Account, "", "");
                    _SaveDB[0].PutData2QueueDetail(item);

                    return "";
                }






                VIPProvider.OrderTo(ref item, ref DDSCOrder.Order, Exectype, Orderno, NetworkId, OrderID
, "", "", TargetID, Account, Data, CA);

                if (Exectype == "0")//FOrderItem 資料由回報運算，新單為初始值
                    _AccountItemProvider.SetReplyDataForNew(NetworkId, item.FOrderItem);
                item.FOrderItem.SYSTEM = System;
                item.FOrderItem.KEEPORICLORDID = KeepOriClordid;






                _OrderCore.AddSAEA(NetworkId, item);

                item.T3 = Date.NowTime().ToString("HH:mm:ss.fff");

                if (Sync) return NetworkId;//同不資料不用出單




                if (Exectype == "0")
                {
                    NewOrderSingleMessage message = FIXProvider.FItem2NewOrderSingleMessage(item.FOrderItem, ref  _SymbolProvider);

                    _DataAgent.FIXServerQ.PutData2Queue(new FIXObject(TargetID, message));

                }
                else if (Exectype == "5")
                {
                    OrderCancelReplaceMessage message = FIXProvider.FItem2OrderCancelReplaceMessage(item.FOrderItem, ref  _SymbolProvider);
                    //Speedy沒有改量 只有減量，所以要運算出減量口數
                    Orderno = ASCIIEncoding.Default.GetString(DDSCOrder.Order.ORDERNO).Trim();
                    item.NETWORKID = NetworkId;
                    OriClordid = ASCIIEncoding.Default.GetString(DDSCOrder.Order.CLORDID).Trim();
                    FOrderItem Fitem = _AccountItemProvider.GetReplyData(OriClordid);
                    if (Fitem != null)
                    {
                        OrderID = Fitem.ORDERID;//取得上手書號
                        KeepOriClordid = Fitem.KEEPORICLORDID;
                        message.LeaveQty = Fitem.LEAVESQTY;
                    }



                    // if (titem.System == "PATS")//上手系統若為PATS 原單單號為上一次成功的新單單號
                    message.OrigClOrdID = KeepOriClordid;
                    _DataAgent.FIXServerQ.PutData2Queue(new FIXObject(TargetID, message));
                }
                else if (Exectype == "4")
                {
                    OrderCancelMessage message = FIXProvider.FItem2OrderCancelMessage(item.FOrderItem, ref  _SymbolProvider);
                    //  if (titem.System == "PATS")//上手系統若為PATS 原單單號為上一次成功的新單單號
                    message.OrigClOrdID = KeepOriClordid;
                    _DataAgent.FIXServerQ.PutData2Queue(new FIXObject(TargetID, message));
                }


            }
            catch (Exception ex)
            {
                WriteLog("DataAgentLog", "ParseGeneralTrade:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
                throw ex;
            }
            return NetworkId;
        }




        private string ParseProgramTrade(bool Sync, ref AccountItem item, SocketAsyncEventArgs S, byte[] source_buffer, string ID, string Data, string CA)
        {
            string System = "";

            string Clordid = ""; //order +networkid;
            string OriClordid = "";
            string KeepOriClordid = ""; //for patsystem
            string NetworkId = ""; //termid(2)+networkid(8)
            string webcode = "";
            string OrderID = "";//上手書號
            string Orderno = "";
            string TargetID = "";//上手代號
            string Account = "";//上手交易帳號
            byte[] buffer = null;
            try
            {
                SockClientParserFunction.DDSCOrder DDSCOrder = new SockClientParserFunction.DDSCOrder();
                com.ddsc.BI.F.ParserStruct<SockClientParserFunction.DDSCOrder>.ByteArrayToStructure(source_buffer, ref DDSCOrder);
                ;
                string KeepData = ASCIIEncoding.Default.GetString(source_buffer, 50 + Marshal.SizeOf(DDSCOrder.Order)
                    , source_buffer.Length - 50 - Marshal.SizeOf(DDSCOrder.Order) - 1);
                string OrderKind = "";
                string OrderTag = "";
                string AE = "";
                string AD = "";
                string pseq = "";
                //KeepData

                ////OrderKind=P^OrderTag=^AE=^AD=Time Slice|2|500|20161004172843726|20161004182843000|35000|5|0^



                foreach (string f in KeepData.Split('^'))
                {
                    if (f.IndexOf("OrderKind") > -1)
                    {
                        OrderKind = f.Split('=')[1];
                    }
                    if (f.IndexOf("AD") > -1)
                    {
                        AD = f.Split('=')[1];
                    }
                    if (f.IndexOf("pseq") > -1)
                    {
                        pseq = f.Split('=')[1];
                    }
                    if (f.IndexOf("OrderTag") > -1)
                    {
                        OrderTag = f.Split('=')[1];
                    }
                    if (f.IndexOf("AE") > -1)
                    {
                        AE = f.Split('=')[1];
                    }

                }


                string Seq = ASCIIEncoding.ASCII.GetString(DDSCOrder.Head.OLDSEQ);
                string NewSeq = ASCIIEncoding.ASCII.GetString(DDSCOrder.Head.NEWSEQ);


                string ip = S.AcceptSocket.RemoteEndPoint.ToString();
                item.OrderItem.IP = ip;


                DDSCOrder.Order.IP = ASCIIEncoding.ASCII.GetBytes(ip.PadRight(30));


                string Exectype = ASCIIEncoding.ASCII.GetString(DDSCOrder.Order.EXECTYPE);//0:新增, 4:取消, 5: 減量, M:改價
                if (Sync) //如果為同步資料時，取CLORDID，如果不是則新NEW一筆
                    NetworkId = ASCIIEncoding.Default.GetString(DDSCOrder.Order.CLORDID).Trim();
                else
                    NetworkId = getNetworkId();


                OriClordid = NetworkId;

                switch (Exectype)
                {
                    case "0"://0:新增


                        item.NETWORKID = NetworkId;
                        DDSCOrder.Order.CLORDID = ASCIIEncoding.Default.GetBytes(NetworkId.PadRight(25, ' '));


                        byte[] body = SockClientParserFunction.StructureToByteArray(DDSCOrder.Order);

                        Array.Copy(body, 0, source_buffer, 50, body.Length);


                        _AccountCore.AddNetWorkIdItem(S, NetworkId, Seq, "", KeepData);
                        //    AS400Order = GetAS400Order(DDSCOrder, NetworkId, ip);

                        break;
                    case "4":// 4:取消, 5: 減量, M:改價
                    case "5":
                    case "M":
                        Orderno = ASCIIEncoding.Default.GetString(DDSCOrder.Order.ORDERNO).Trim();
                        item.NETWORKID = NetworkId;
                        OriClordid = ASCIIEncoding.Default.GetString(DDSCOrder.Order.CLORDID).Trim();
                        FOrderItem Fitem = _AccountItemProvider.GetReplyData(OriClordid);
                        if (Fitem != null)
                            OrderID = Fitem.ORDERID;//取得上手書號
                        _AccountCore.UpdSeqItem(ASCIIEncoding.ASCII.GetString(DDSCOrder.Order.CLORDID), NewSeq);

                        break;

                }

                //  string TargetServer = null;
                //_DataAgent.TargetServer.TryGetValue(TargetID,out TargetServer) ;


                if (!Sync)
                {
 


                    byte[] SyncBuffer = new byte[source_buffer.Length];

                    Array.Copy(source_buffer, SyncBuffer, SyncBuffer.Length);
                    SyncBuffer[0] = 0xF2;

                    SendDataToSync(SyncBuffer);
                }

                //  檢核此交易帳號對應哪個上手、上手帳號
                Targetitem titem = chkTargetData(GetString(DDSCOrder.Order.BROKERID), GetString(DDSCOrder.Order.INVESTORACNO)
                    , GetString(DDSCOrder.Order.SECURITYEXCHANGE), GetString(DDSCOrder.Order.SECURITYTYPE1)
                    , GetString(DDSCOrder.Order.SYMBOL1), GetString(DDSCOrder.Order.MATURITYMONTHYEAR1));
                if (titem == null)
                {
                    DDSCOrder.Order.CLORDID = ASCIIEncoding.ASCII.GetBytes(OriClordid.PadRight(25, ' '));
                    CombineErrorGeneralTrade(DDSCOrder.Order, "ERR1", "");

                    return "";
                }
                else
                {
                    TargetID = titem.TargetID;//上手代號
                    Account = titem.Account;//上手交易帳號
                    System = titem.System;//上手交易帳號
                }

                string TargetServer = null;
                _DataAgent.TargetServer.TryGetValue(TargetID, out TargetServer);
                if (TargetServer == null)
                {
                    DDSCOrder.Order.CLORDID = ASCIIEncoding.ASCII.GetBytes(OriClordid.PadRight(25, ' '));
                    CombineErrorGeneralTrade(DDSCOrder.Order, "ERR1", "");

                    return "";
                }


                StrategyDataProvider.OrderTo(ref item, ref DDSCOrder.Order, Exectype, Orderno, NetworkId, OrderID
, "", "", TargetID, Account, Data, CA);

                // if (Exectype == "0")//FOrderItem 資料由回報運算，新單為初始值
                _StrategyDataProvider.SetReplyData(OriClordid, item.FOrderItem, AD);

                WriteLog("OrderTrigger", Sync ? "Sync" : "" + "Trigger: Exectype:" + item.FOrderItem.EXECTYPE + " AD:" + AD + " pseq:" + Seq + " " + DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss.fff") + " " + item.FOrderItem.ToString());

                if (!Sync)
                {
                    _StrategyDataProvider.SetReplyDataTrigger(OriClordid, item.FOrderItem, AD);
                }

                item.FOrderItem.SYSTEM = System;
                item.FOrderItem.KEEPORICLORDID = KeepOriClordid;
                item.Data = KeepData;
                _OrderCore.AddSAEA(NetworkId, item);

                buffer = StrategyDataProvider.ToReply(item.FOrderItem, AD);

                string BROKERID;
                string INVESTORACNO;
                string NETWORKID;

                BROKERID = ASCIIEncoding.ASCII.GetString(DDSCOrder.Order.BROKERID).Trim();
                INVESTORACNO = ASCIIEncoding.ASCII.GetString(DDSCOrder.Order.INVESTORACNO).Trim();
                NETWORKID = ASCIIEncoding.ASCII.GetString(DDSCOrder.Order.CLORDID).Trim(); ;
                string SUBACT = "";// ASCIIEncoding.ASCII.GetString(DDSCOrder.Order.SUBACT).Trim();


                byte[] ret = SendOrderDataToAP(BROKERID + INVESTORACNO + SUBACT, SockClientParserFunction.DDSCSocketHead.ProgramTradeReply, NETWORKID, buffer);


            }
            catch (Exception ex)
            {
                WriteLog("DataAgentLog", "ParseGeneralTrade:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
                throw ex;
            }
            return NetworkId;
        }





        void _StrategyDataProvider_OrderTrigger(FOrderItem obj, DateTime TIME, string QTY)
        {
            try
            {

                string Orderno = getOrderNo();
                obj.ORDERQTY = int.Parse(QTY);
                string NetworkId = getNetworkId();
                obj.CLORDID = NetworkId;
                obj.ORDERNO = Orderno;


                NetWorkIdItem item = _AccountCore.FindNetWorkIdItem(obj.ORICLORDID);
                string KeepData = item.Data;
                //OrderKind=P^OrderTag=^AE=^AD=^
                string OrderKind = "";
                string OrderTag = "";
                string AE = "";
                string AD = "";
                string pseq = "";

                foreach (string f in KeepData.Split('^'))
                {
                    if (f.IndexOf("OrderKind") > -1)
                    {
                        OrderKind = f.Split('=')[1];
                    }
                    if (f.IndexOf("AD") > -1)
                    {
                        AD = f.Split('=')[1];
                    }
                    if (f.IndexOf("pseq") > -1)
                    {
                        pseq = f.Split('=')[1];
                    }
                    if (f.IndexOf("OrderTag") > -1)
                    {
                        OrderTag = f.Split('=')[1];
                    }
                    if (f.IndexOf("AE") > -1)
                    {
                        AE = f.Split('=')[1];
                    }

                }

                string keepData = "";
                keepData = string.Format("OrderKind=1^OrderTag={0}^AE={1}^AD={2}^pseq={3}^"
                    , OrderTag, AE, AD, item.OldSeq);


                obj.ORICLORDID = NetworkId;
                _AccountCore.AddNetWorkIdItem(null, NetworkId, "", "", keepData);


                _AccountItemProvider.SetReplyDataForNew(NetworkId, obj);


                byte[] source_buffer = null;
                source_buffer = VIPProvider.ToOrder(obj, keepData);
                source_buffer[0] = 0xF1;
                SendDataToSync(source_buffer);


                NewOrderSingleMessage message = FIXProvider.FItem2NewOrderSingleMessage(obj, ref  _SymbolProvider);

                _DataAgent.FIXServerQ.PutData2Queue(new FIXObject(obj.TARGETID, message));

                WriteLog("OrderTrigger", "Trigger:" + "pseq:" + item.OldSeq + " " + TIME.ToString("yyyy/MM/dd HH:mm:ss.fff") + " " + obj.ToString());
            }

            catch (Exception ex)
            {

                WriteLog("DataAgentLog", "_StrategyDataProvider_OrderTrigger:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }

        }





        //private void ParseCATrade(ref AccountItem item, SocketAsyncEventArgs S, byte[] buffer)
        //{

        //    try
        //    {


        //        SockClientParserFunction.DDSCCAOrder DDSCCAOrder = new SockClientParserFunction.DDSCCAOrder();

        //        com.ddsc.BI.F.ParserStruct<SockClientParserFunction.DDSCCAOrder>.ByteArrayToStructure(buffer, 0, ref DDSCCAOrder);
        //        SockClientParserFunction.Order Order = new SockClientParserFunction.Order();
        //        com.ddsc.BI.F.ParserStruct<SockClientParserFunction.Order>.ByteArrayToStructure(buffer, 50, ref Order);
        //        int orderlen = Marshal.SizeOf(Order);
        //        string starttime = Date.NowTime().ToString("HHmmssfff");
        //        string signature = Encoding.ASCII.GetString(buffer, 50 + orderlen + 15 + 8, buffer.Length - (50 + orderlen + 15 + 8) - 1);
        //        string data = ASCIIEncoding.ASCII.GetString(SockClientParserFunction.StructureToByteArray(DDSCCAOrder.Order));
        //        string id = ASCIIEncoding.ASCII.GetString(DDSCCAOrder.ID).Trim();
        //        string cano = ASCIIEncoding.ASCII.GetString(DDSCCAOrder.CertSerial);
        //        item.OrderItem.CA = signature;
        //        item.OrderItem.DATA = data;
        //        item.OrderItem.ID = id;
        //        DDSCCAOrder.Head.HEAD = new byte[1] { SockClientParserFunction.DDSCSocketHead.GeneralTrade };

        //        int rtn = 0;
        //        if (_VerifyFlag)
        //        {
        //            UserInfo u = _AccountCore.FindUserInfo(S);
        //            if (u.CANO != cano)
        //            {
        //                u.CANO = cano;
        //                rtn = SignVerify("", data, signature, cano, id, S.AcceptSocket.RemoteEndPoint.ToString()); //Verify(signature, data, cano);
        //                if (rtn != 0)
        //                    u.CANO = "";


        //            }
        //            else
        //            {
        //                rtn = 0;
        //                SignVerifyExcute.BeginInvoke("", data, signature, cano, id, S.AcceptSocket.RemoteEndPoint.ToString(), null, null);
        //            }
        //        }
        //        if (rtn == 0)
        //        {
        //            SockClientParserFunction.DDSCOrder DDSCOrder = new SockClientParserFunction.DDSCOrder();
        //            DDSCOrder.Head = DDSCCAOrder.Head;
        //            DDSCOrder.Head.LENGTH = BitConverter.GetBytes(Convert.ToInt16(Marshal.SizeOf(Order)));
        //            if (BitConverter.IsLittleEndian)
        //                Array.Reverse(DDSCOrder.Head.LENGTH);
        //            DDSCOrder.Order = Order;
        //            DDSCOrder.End = new byte[1] { SockClientParserFunction.DDSCSocketHead.End };
        //            string networkidb = ParseGeneralTrade(ref item, S, SockClientParserFunction.StructureToByteArray(DDSCOrder), id, data, signature);

        //            WriteLog("CALOG", string.Format("[starttime][{0}][network][{1}][returnCode][{2}][CADATA][{3}][DATA][{4}][CANO][{5}]"
        //                , starttime, networkidb, rtn, signature, data, cano));
        //        }
        //        else
        //        {

        //            string Seq = ASCIIEncoding.ASCII.GetString(DDSCCAOrder.Head.OLDSEQ);
        //            string NewSeq = ASCIIEncoding.ASCII.GetString(DDSCCAOrder.Head.NEWSEQ);
        //            string NetworkId = getNetworkId();
        //            string EXECTYPE = ASCIIEncoding.ASCII.GetString(Order.EXECTYPE);//0:新增, 4:取消, 5: 減量, M:改價
        //            string oldwebcode = "";
        //            string oldnetworkid = "";

        //            switch (EXECTYPE)
        //            {
        //                case "0"://0:新增

        //                    // Order.ORDERNO = NetworkId;
        //                    Order.CLORDID = ASCIIEncoding.ASCII.GetBytes(NetworkId.PadRight(10, ' '));
        //                    _AccountCore.AddNetWorkIdItem(S, _WebCode + NetworkId, Seq, "", "");

        //                    break;
        //                case "4":// 4:取消, 5: 減量, M:改價
        //                case "5":
        //                case "M":

        //                    oldnetworkid = ASCIIEncoding.ASCII.GetString(Order.CLORDID).Trim();
        //                    _AccountCore.UpdSeqItem(oldwebcode + oldnetworkid, NewSeq);

        //                    break;

        //            }

        //            WriteLog("CALOG", string.Format("[starttime][{0}][network][{1}][returnCode][{2}][CADATA][{3}][DATA][{4}][CANO][{5}][{6}]"
        //                , starttime, NetworkId, rtn, signature, data, cano, ""));

        //            CombineErrorGeneralTrade(Order, "ERR3", "");

        //            // save 交易 明細
        //            TransDDSCOrder2AccountItem(ref item, S, Order, NetworkId, "ERR3", id, signature, data);

        //            _SaveDB[0].PutData2QueueDetail(item);
        //        }

        //    }

        //    catch (Exception ex)
        //    {
        //        WriteLog("DataAgentLog", "ParseCATrade:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
        //        throw ex;
        //    }

        //}

        //private void TransDDSCOrder2AccountItem(ref  AccountItem item, SocketAsyncEventArgs S, SockClientParserFunction.Order Order
        //     , string NetworkId, string errorcode, string id, string signature, string data)
        //{
        //    string EXECTYPE = ASCIIEncoding.ASCII.GetString(Order.EXECTYPE);//0:新增, 4:取消, 5: 減量, M:改價

        //    string oldwebcode = "";
        //    string oldnetworkid = "";

        //    switch (EXECTYPE)
        //    {
        //        case "0"://0:新增


        //            break;
        //        case "4":// 4:取消, 5: 減量, M:改價
        //        case "5":
        //        case "M":

        //            oldnetworkid = ASCIIEncoding.ASCII.GetString(Order.CLORDID);

        //            break;

        //    }

        //    item.OrderKind = OrderKind.TRADE;
        //    item.OrderItem.ORDERKIND = "1";
        //    item.OrderItem.BROKERID = ASCIIEncoding.ASCII.GetString(Order.BROKERID);
        //    item.OrderItem.INVESTORACNO = ASCIIEncoding.ASCII.GetString(Order.INVESTORACNO);
        //    //   item.OrderItem.COMMODITYID = ASCIIEncoding.ASCII.GetString(Order.COMMODITYID);
        //    item.OrderItem.PRODUCTKIND = ASCIIEncoding.ASCII.GetString(Order.PRODUCTKIND);
        //    item.OrderItem.ORDERNO = ASCIIEncoding.ASCII.GetString(Order.ORDERNO);
        //    item.OrderItem.BS = ASCIIEncoding.ASCII.GetString(Order.BS);
        //    item.OrderItem.ORDERTYPE = ASCIIEncoding.ASCII.GetString(Order.ORDERTYPE);
        //    //item.OrderItem.ORDERPRICE = ASCIIEncoding.ASCII.GetString(Order.ORDERPRICE);
        //    //item.OrderItem.ORDERQUANTITY = ASCIIEncoding.ASCII.GetString(Order.ORDERQUANTITY);


        //    //item.OrderItem.ORDERCONDITION = ASCIIEncoding.ASCII.GetString(Order.ORDERCONDITION);
        //    //item.OrderItem.OPENOFFSETFLAG = ASCIIEncoding.ASCII.GetString(Order.OPENOFFSETFLAG);
        //    item.OrderItem.EXECTYPE = EXECTYPE;
        //    item.OrderItem.TRADEDATE = DateTime.Now.ToString("yyyyMMdd");
        //    item.OrderItem.STATUSCODE = errorcode;
        //    item.OrderItem.IP = S.AcceptSocket.RemoteEndPoint.ToString();


        //    item.OrderItem.ORDERTIME = DateTime.Now.ToString("HHmmss");
        //    //   item.OrderItem.SUBACT = ASCIIEncoding.ASCII.GetString(Order.OPENOFFSETFLAG);
        //    item.OrderItem.SOURCECODE = ASCIIEncoding.ASCII.GetString(Order.SOURCECODE);
        //    item.OrderItem.WEBCODE = oldwebcode;
        //    item.OrderItem.NETWORKID = oldnetworkid;
        //    item.OrderItem.NEWWEBCODE = _WebCode;
        //    item.OrderItem.NEWNETWORKID = NetworkId;
        //    if (id != "")
        //        item.OrderItem.ID = id;
        //    if (signature != "")
        //        item.OrderItem.CA = signature;
        //    if (data != "")
        //        item.OrderItem.DATA = data;


        //}


        private void SendDataToDBServer(byte[] buffer)
        {
            try
            {
                _DBServerQ.PutData2Queue(buffer);

            }
            catch (Exception ex)
            {
                WriteLog("DataAgentLog", "SendDataToDBServer:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }

        private void SendDataToSync(byte[] buffer)
        {
            try
            {

                if (_SyncQ != null)
                    _SyncQ.PutData2Queue(buffer);

            }
            catch (Exception ex)
            {
                WriteLog("DataAgentLog", "SendDataToSync:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }

        //public void parseFixReport(string SenderCompID, string TargetCompID, TT.ExecutionReport obj)
        //{
        //    SocketAsyncEventArgs[] Sockets;
        //    try
        //    {
        //        byte[] sendbuffer = null; ;
        //        byte[] sentbuffer = null; ;
        //        obj = _ReportProvider.Combine(obj);
        //        if (obj == null) return;



        //        string T4 = Date.NowTime().ToString("HH:mm:ss.fff");
        //        string BROKERID = "";
        //        string INVESTORACNO = "";
        //        string SUBACT = "";
        //        string ClOrdID = "";
        //        AccountItem itemdetail;


        //        FOrderItem Fitem = _AccountItemProvider.SetReplyData(obj.OrigClOrdID, obj);//更新委託資料
        //        string data = AS400Provider.toAS400FUN201("", "", Fitem, obj);
        //        _DataAgent.OrderDataQWriterQ.PutData2Queue(data);

        //        BROKERID = Fitem.BROKERID;
        //        INVESTORACNO = Fitem.INVESTORACNO;
        //        SUBACT = Fitem.SUBACT;

        //        ClOrdID = obj.ClOrdID;



        //        itemdetail = _OrderCore.FindSAEA( ClOrdID);//中台送出
        //        AccountItemProvider.SetReplyDataDetail(itemdetail.FOrderItem, Fitem);

        //        if (itemdetail.S != null)
        //        {
        //        }
        //        itemdetail.T4 = T4;


        //        sendbuffer = VIPProvider.ToReply(obj, Fitem);
        //        SendOrderDataToAP(BROKERID + INVESTORACNO + SUBACT, SockClientParserFunction.DDSCSocketHead.Reply
        //                                                          , ClOrdID, sendbuffer);


        //        int DGWReplyCount = _SeqDataProvider.Count + 1;
        //        sendbuffer = FDGWProvider.ToResponse112((DGWReplyCount).ToString().PadLeft(10, '0'), obj, Fitem);

        //        if (!_SeqDataProvider.check((DGWReplyCount).ToString()))
        //            _SeqDataProvider.Add((DGWReplyCount).ToString(), itemdetail.SYSTEMCODE + itemdetail.SEQ + ASCIIEncoding.Default.GetString(sendbuffer));

        //        Sockets = _ActiveReplyCore.FindSAEA("112");//主動回報
        //        if (Sockets != null)
        //        {
        //            //DGW主動回報
        //            for (int i = 0; i < Sockets.Length; i++)
        //            {
        //                itemdetail.S = Sockets[i];
        //                itemdetail.FUNCTION = "112";

        //                sentbuffer = SendDGWToAP(ref itemdetail, itemdetail.SYSTEMCODE + itemdetail.SEQ + FDGWProtocols.ReturnCode.R1120000, sendbuffer);
        //                WriteLog("FUN112SendLog", itemdetail.SYSTEMCODE + itemdetail.SEQ + ASCIIEncoding.Default.GetString(sentbuffer));
        //            }
        //        }
        //        if (obj.ExecType == "0" || obj.ExecType == "4" || obj.ExecType == "5" || obj.ExecType == "8")
        //        {
        //            itemdetail.T5 = Date.NowTime().ToString("HH:mm:ss.fff");
        //            _SaveDB[0].PutData2QueueDetail(itemdetail);
        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //    }
        //}

        public void parseTTFixReport(string system, string SenderCompID, string TargetCompID, TT.ExecutionReport obj)
        {
            ExecutionReport TT = FIXProvider.TT2EXCHForExecutionReport(obj, ref _SymbolProvider);
            parseFixReport(system, SenderCompID, TargetCompID, TT);
        }

        public void parseFixReport(string system, string SenderCompID, string TargetCompID, ExecutionReport obj)
        {

            SocketAsyncEventArgs[] Sockets;
            try
            {


                byte[] sendbuffer = null; ;
                byte[] sentbuffer = null; ;
                obj = _ReportProvider.Combine(obj);
                if (obj == null) return;



                string T4 = Date.NowTime().ToString("HH:mm:ss.fff");
                string BROKERID = "";
                string INVESTORACNO = "";
                string SUBACT = "";

                AccountItem itemdetail;



                FOrderItem Fitem = null;


                Fitem = _AccountItemProvider.SetReplyData(obj.OrigClOrdID, obj);//更新委託資料


                BROKERID = Fitem.BROKERID;
                INVESTORACNO = Fitem.INVESTORACNO;
                SUBACT = "";//ASCIIEncoding.ASCII.GetString(Order.SUBACT).Trim();
                //不等於複式單拆程單式單走正常流程
                if (obj.MultiLegReportingType != "2")
                    sendbuffer = VIPProvider.ToReply(obj, Fitem);
                else
                    sendbuffer = VIPProvider.ToReplyMLegToSingleLeg(obj, Fitem);
                SendOrderDataToAP(BROKERID + INVESTORACNO + SUBACT, SockClientParserFunction.DDSCSocketHead.Reply
                                                                  , obj.OrigClOrdID, sendbuffer);



                itemdetail = _OrderCore.FindSAEA(obj.ClOrdID);//中台送出
                AccountItemProvider.SetReplyDataDetail(itemdetail.FOrderItem, Fitem);

                if (itemdetail.S != null)
                {
                }
                itemdetail.T4 = T4;


                if (obj.ExecType == "0" || obj.ExecType == "4" || obj.ExecType == "5" || obj.ExecType == "8")
                {
                    itemdetail.T5 = Date.NowTime().ToString("HH:mm:ss.fff");
                    _SaveDB[0].PutData2QueueDetail(itemdetail);
                }

            }
            catch (Exception ex)
            {
                WriteLog("DataAgentLog", "parseFixReport:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());

            }
        }



        private DateTime StampToDateTime(string timeStamp)
        {

            DateTime dateTimeStart = TimeZone.CurrentTimeZone.ToLocalTime(new DateTime(1970, 1, 1, 8, 0, 0));// +8 TW
            long lTime = long.Parse(timeStamp + "0000000");
            TimeSpan toNow = new TimeSpan(lTime);

            return dateTimeStart.Add(toNow);
        }

        private Targetitem chkTargetData(string BROKERID, string INVESTORACNO
                            , string SECURITYEXCHANGE, string SECURITYTYPE, string SYMBOL, string MATURITYMONTHYEAR)
        {
            Targetitem item = null;

            BROKERID = BROKERID.Trim();
            INVESTORACNO = INVESTORACNO.Trim();
            SECURITYEXCHANGE = SECURITYEXCHANGE.Trim();
            SECURITYTYPE = SECURITYTYPE.Trim();
            SYMBOL = SYMBOL.Trim();
            MATURITYMONTHYEAR = MATURITYMONTHYEAR.Trim();
            if (_DataAgent.TargetData.TryGetValue(BROKERID + INVESTORACNO + SECURITYEXCHANGE + SECURITYTYPE + SYMBOL + MATURITYMONTHYEAR, out item))
                return item;
            if (_DataAgent.TargetData.TryGetValue(BROKERID + INVESTORACNO + SECURITYEXCHANGE + SECURITYTYPE + SYMBOL, out item))
                return item;
            if (_DataAgent.TargetData.TryGetValue(BROKERID + INVESTORACNO + SECURITYEXCHANGE + SECURITYTYPE, out item))
                return item;
            if (_DataAgent.TargetData.TryGetValue(BROKERID + INVESTORACNO + SECURITYEXCHANGE, out item))
                return item;
            if (_DataAgent.TargetData.TryGetValue(BROKERID + INVESTORACNO, out item))
                return item;
            if (_DataAgent.TargetData.TryGetValue(BROKERID, out item))
                return item;
            return item;
        }


        private void VipReplayAddSeq(string oldseq, string newseq, ref byte[] buffer)
        {

            int ReplyCount = _SeqVipDataProvider.Count + 1;
            byte[] Countbyte = ASCIIEncoding.Default.GetBytes(ReplyCount.ToString().PadLeft(10, '0'));
            Array.Copy(Countbyte, 0, buffer, 0, 10);
            if (!_SeqVipDataProvider.check((ReplyCount).ToString()))
                _SeqVipDataProvider.Add((ReplyCount).ToString(), oldseq.PadRight(10, ' ') + newseq.PadRight(10, ' ') + ASCIIEncoding.Default.GetString(buffer));



        }

        /// <summary>
        /// 新增單回AP
        /// </summary>
        /// <param name="Account"></param>
        /// <param name="buffer"></param>
        private byte[] SendOrderDataToAP(string Account, byte head, string NetWorkID, byte[] buffer)
        {
            byte[] retBuffer = null;
            try
            {




                Dictionary<int, SocketAsyncEventArgs> Sockets = this._AccountCore.FindSAEA(Account);


                SockClientParserFunction.DDSCHead DDSCHead = new SockClientParserFunction.DDSCHead();
                DDSCHead.HEAD = new byte[1] { head };
                DDSCHead.MESSAGETIME = ASCIIEncoding.ASCII.GetBytes(DateTime.Now.ToString("HHmmssfff"));



                byte[] headbyte;





                byte[] netoworkid = ASCIIEncoding.ASCII.GetBytes(NetWorkID);


                //取seq
                NetWorkIdItem item = _AccountCore.FindNetWorkIdItem(netoworkid);



                if (item != null)
                {
                    DDSCHead.OLDSEQ = ASCIIEncoding.ASCII.GetBytes(item.OldSeq.PadRight(9, ' '));
                    DDSCHead.NEWSEQ = ASCIIEncoding.ASCII.GetBytes(item.NewSeq.PadRight(9, ' '));
                    DDSCHead.USERID = ASCIIEncoding.ASCII.GetBytes(item.UserId.PadRight(20, ' '));


                    byte[] Data = Encoding.Default.GetBytes(item.Data);
                    byte[] byteReply = buffer;
                    var list = new List<byte>();
                    list.AddRange(byteReply);
                    list.AddRange(Data);
                    buffer = list.ToArray();
                    VipReplayAddSeq(item.OldSeq, item.NewSeq, ref buffer);
                }

                else
                {
                    DDSCHead.OLDSEQ = ASCIIEncoding.ASCII.GetBytes("".PadRight(9, ' '));
                    DDSCHead.NEWSEQ = ASCIIEncoding.ASCII.GetBytes("".PadRight(9, ' '));
                    DDSCHead.USERID = ASCIIEncoding.ASCII.GetBytes("".PadRight(20, ' '));
                    VipReplayAddSeq("", "", ref buffer);
                }
                DDSCHead.LENGTH = BitConverter.GetBytes(UInt16.Parse(buffer.Length.ToString()));
                if (BitConverter.IsLittleEndian)
                    Array.Reverse(DDSCHead.LENGTH);

                retBuffer = new byte[50 + buffer.Length + 1];
                headbyte = SockClientParserFunction.StructureToByteArray(DDSCHead);
                Array.Copy(headbyte, 0, retBuffer, 0, headbyte.Length);
                Array.Copy(buffer, 0, retBuffer, headbyte.Length, buffer.Length);
                retBuffer[retBuffer.Length - 1] = SockClientParserFunction.DDSCSocketHead.End;
                if (Sockets != null)
                {
                    int[] arr = Sockets.Keys.ToArray();
                    try
                    {//有可能在取得socket 物件後 斷線
                        //foreach (int key in Sockets.Keys.ToArray())
                        for (int i = 0; i < arr.Length; i++)
                        {

                            try
                            {

                                this._SAEA.SendData(Sockets[arr[i]], _DataEncode ? SockClientParserFunction.EncodeData(retBuffer) : retBuffer);
                                // WriteLog("SAEAServerLogSend" + Sockets[arr[i]].AcceptSocket.RemoteEndPoint.ToString().Replace(":", ";"), retBuffer);

                                string RemoteIP = ((System.Net.IPEndPoint)Sockets[arr[i]].AcceptSocket.RemoteEndPoint).Address.ToString();
                                WriteLog("SAEAServerLogSend" + RemoteIP, retBuffer);
                            }
                            catch (Exception ex)
                            {
                                WriteLog("DataAgentLog", "Socket is null:" + Account + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
                            }

                        }
                    }
                    catch (Exception ex)
                    {
                        WriteLog("DataAgentLog", "Sockets is null:" + Account + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
                    }
                }




                SendDataToDBServer(retBuffer);
            }
            catch (Exception ex)
            {
                WriteLog("DataAgentLog", "SendOrderDataToAP:" + Account + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
            finally
            {

            }
            return retBuffer;
        }

        private string getOrderNo()
        {
            try
            {
                int orderno = _OrderNo.getSeq();


                return _SrcID + ((int)DateTime.Now.DayOfWeek).ToString() + Int2String(orderno).PadLeft(4, '0');
            }
            catch (Exception ex)
            {
            }
            return "";

        }

        private string getNetworkId()
        {

            try
            {
                int networkid = _OrderNoSeq.getSeq();

                return _SrcID + ((int)DateTime.Now.DayOfWeek).ToString()
                    + (Int2String(int.Parse(DateTime.Now.ToString("yyyyMMdd"))) + networkid.ToString()).PadLeft(12, '0');
            }
            catch (Exception ex)
            {
            }
            return "";

        }



        private byte[] getSeq()
        {
            byte[] Seq;

            int seq = _Seq.getSeq();
            seq = 1000000 * (int)DateTime.Now.DayOfWeek + seq;

            Seq = ASCIIEncoding.ASCII.GetBytes((_SrcID + Int2String(seq).PadLeft(4, '0')).PadRight(9, ' '));


            return Seq;
        }



        private void SendDataToAP(SocketAsyncEventArgs S, byte[] buffer)
        {
            Array.Copy(ASCIIEncoding.ASCII.GetBytes(DateTime.Now.ToString("HHmmssfff")), 0, buffer, 1, 9);
            string RemoteIP = ((System.Net.IPEndPoint)S.AcceptSocket.RemoteEndPoint).Address.ToString();
            this._SAEA.SendData(S, _DataEncode ? SockClientParserFunction.EncodeData(buffer) : buffer);
            // WriteLog("SAEAServerLogSend" + S.AcceptSocket.RemoteEndPoint.ToString().Replace(":", ";"), buffer);
            WriteLog("SAEAServerLogSend" + RemoteIP, buffer);


        }





        private void WriteLog(string key, byte[] data)
        {

            DataAgent._LM.WriteLog(key, data);
        }
        private void WriteLog(string key, string data)
        {
            DataAgent._LM.WriteLog(key, data);
        }



        private int SignVerify(string networkid, string data, string Signature, string CertSN, string idno, string IP)
        {

            int intResult = 9999;
            try
            {
                string signature = "";

                bool verify = true;
                if (verify) intResult = 0;
                //intResult = _VA.VA_STOCK_P1VerifySignEx(Signature, data, "", 0, 0, idno, CertSN
                //  , Settings.Default.SrcCode
                //  , Settings.Default.BizId
                //  , "default", IP);


                return intResult;

            }
            catch (Exception ex)
            {
                return 9999;
            }
        }



        void _SaveDBEvent(string networkid, DataTable dt)
        {

        }


        public static String Int2String(Int64 intValue)
        {
            String strValue = String.Empty;
            String strArr = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
            while (intValue != 0)
            {
                int intRem = 0;
                intRem = (int)(intValue % strArr.Length);
                strValue = strArr.Substring(intRem, 1) + strValue;
                intValue /= strArr.Length;
            }
            return strValue;
        }
        private string GetString(byte[] b)
        {
            try
            {
                return ASCIIEncoding.Default.GetString(b).Trim();
            }
            catch (Exception ex)
            {

            }
            return "";
        }
    }
}
