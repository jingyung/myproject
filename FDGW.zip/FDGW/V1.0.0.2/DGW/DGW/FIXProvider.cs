﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using com.ddsc.BI.F;
namespace com.ddsc.TradeSocketServer
{
    public class FIXObject
    {
        public FIXObject(string pTargetID, object pMessage)
        {

            TargetID = pTargetID;
            Message = pMessage;
        }
        public string System;
        public string TargetID;
        public object Message;
    }
    public class NewOrderSingleMessage
    {
        public FOrderItem FOrderItem;
        public NewOrderSingleMessage()
        {
            ClOrdID = "";
            ClientID = "";
            Account = "";
            SecurityExchange = "";
            SecurityType1 = "";
            Symbol1 = "";
            MaturityMonthYear1 = "";
            PutOrCall1 = "";
            StrikePrice1 = 0;
            Side1 = "";
            SecurityType2 = "";
            Symbol2 = "";
            MaturityMonthYear2 = "";
            PutOrCall2 = "";
            StrikePrice2 = 0;
            Side2 = "";
            Side = "";
            OrderQty = 0;
            OrderType = "";
            Price = 0;
            StopPx = 0;
            TimeInForce = "";
            ExpireDate = "";
            PositionEffect = "";
        }
        public string ClOrdID { get; set; }
        public string ClientID { get; set; }
        public string Account { get; set; }
        public string SecurityExchange { get; set; }
        public string SecurityType1 { get; set; }
        public string Symbol1 { get; set; }
        public string MaturityMonthYear1 { get; set; }
        public string PutOrCall1 { get; set; }
        public decimal StrikePrice1 { get; set; }
        public string Side1 { get; set; }
        public string SecurityType2 { get; set; }
        public string Symbol2 { get; set; }
        public string MaturityMonthYear2 { get; set; }
        public string PutOrCall2 { get; set; }
        public decimal StrikePrice2 { get; set; }
        public string Side2 { get; set; }
        public string Side { get; set; }
        public int OrderQty { get; set; }
        public string OrderType { get; set; }
        public decimal Price { get; set; }
        public decimal StopPx { get; set; }
        public string TimeInForce { get; set; }
        public string ExpireDate { get; set; }
        public string PositionEffect { get; set; }
    }

    public class OrderCancelReplaceMessage
    {
        public FOrderItem FOrderItem;
        public OrderCancelReplaceMessage()
        {
            OrderID = "";
            OrigClOrdID = "";
            ClOrdID = "";
            ClientID = "";
            Account = "";
            SecurityExchange = "";
            SecurityType1 = "";
            Symbol1 = "";
            MaturityMonthYear1 = "";
            PutOrCall1 = "";
            StrikePrice1 = 0;
            Side1 = "";
            SecurityType2 = "";
            Symbol2 = "";
            MaturityMonthYear2 = "";
            PutOrCall2 = "";
            StrikePrice2 = 0;
            Side2 = "";
            Side = "";
            OrderQty = 0;
            OrderType = "";
            Price = 0;
            StopPx = 0;
            TimeInForce = "";
            ExpireDate = "";
            PositionEffect = "";
            LeaveQty = 0;
        }
        public string OrderID { get; set; }
        public string OrigClOrdID { get; set; }
        public string ClOrdID { get; set; }
        public string ClientID { get; set; }
        public string Account { get; set; }
        public string SecurityExchange { get; set; }
        public string SecurityType1 { get; set; }
        public string Symbol1 { get; set; }
        public string MaturityMonthYear1 { get; set; }
        public string PutOrCall1 { get; set; }
        public decimal StrikePrice1 { get; set; }
        public string Side1 { get; set; }
        public string SecurityType2 { get; set; }
        public string Symbol2 { get; set; }
        public string MaturityMonthYear2 { get; set; }
        public string PutOrCall2 { get; set; }
        public decimal StrikePrice2 { get; set; }
        public string Side2 { get; set; }
        public string Side { get; set; }
        public int OrderQty { get; set; }
        public string OrderType { get; set; }
        public decimal Price { get; set; }
        public decimal StopPx { get; set; }
        public string TimeInForce { get; set; }
        public string ExpireDate { get; set; }
        public string PositionEffect { get; set; }

        public int LeaveQty { get; set; }
     
    }

    public class OrderCancelMessage
    {
        public FOrderItem FOrderItem;
        public OrderCancelMessage()
        {
            OrderID = "";
            OrigClOrdID = "";
            ClOrdID = "";
            Account = "";
            Symbol = "";
            SecurityType = "";
            MaturityMonthYear = "";
            Side = "";
            SecurityExchange = "";
        }
        public string OrderID { get; set; }
        public string OrigClOrdID { get; set; }
        public string ClOrdID { get; set; }
        public string ClientID { get; set; }
        public string Account { get; set; }
        public string Symbol { get; set; }
        public string SecurityType { get; set; }
        public string MaturityMonthYear { get; set; }
        public string Side { get; set; }
        public string SecurityExchange { get; set; }
    }



    public class ExecutionReport
    {
        public ExecutionReport()
        {
            Brokerid = "";
            Account = "";
            AvgPx = 0;
            ClearingAccount = "";
            ClientID = "";
            ClOrdID = "";
            ClRefID = "";
            CumQty = 0;
            CxlRejReason = "";
            CxlRejResponseTo = "";
            ESAReference = "";
            ExecID = "";
            ExecRefID = "";
            ExecRestatementReason = "";
            ExecTransType = "";
            ExecType = "";
            ExpireDate = "";
            LastPx = 0;
            LastShares = 0;
            LeavesQty = 0;
            Legflag1 = false;
            Legflag2 = false;
            LocalTransactTime = "";
            MaturityDay1 = "";
            MaturityDay2 = "";
            MaturityMonthYear1 = "";
            MaturityMonthYear2 = "";
            MultiLegReportingType = "";
            Openclose = "";
            OrderID = "";
            OrderLegNum = "";
            OrderQty = 0;
            OrdStatus = "";
            OrdType = "";
            OrigClOrdID = "";
            OrigExecID = "";
            Price = 0;
            Price1 = 0;
            Price2 = 0;
            PutOrCall1 = "";
            PutOrCall2 = "";
            RawLastPx = 0;
            RawPrice = 0;
            RawStopPx = 0;
            SecondaryOrderID = "";
            SecurityExchange = "";
            SecurityType = "";
            SecurityType1 = "";
            SecurityType2 = "";
            Side = "";
            Side1 = "";
            Side2 = "";
            StopPx = 0;
            StrikePrice1 = 0;
            StrikePrice2 = 0;
            Symbol1 = "";
            Symbol2 = "";
            Text = "";
            TimeInForce = "";
            TransactTime = "";
            Data = "";

        }
        public string Brokerid { get; set; }
        public string Account { get; set; }
        public decimal AvgPx { get; set; }
        public string ClearingAccount { get; set; }
        public string ClientID { get; set; }
        public string ClOrdID { get; set; }
        public string ClRefID { get; set; }
        public decimal CumQty { get; set; }
        public string CxlRejReason { get; set; }
        public string CxlRejResponseTo { get; set; }
        public string ESAReference { get; set; }
        public string ExecID { get; set; }
        public string ExecRefID { get; set; }
        public string ExecRestatementReason { get; set; }
        public string ExecTransType { get; set; }
        public string ExecType { get; set; }
        public string ExpireDate { get; set; }
        public decimal LastPx { get; set; }
        public decimal LastShares { get; set; }
        public decimal LeavesQty { get; set; }
        public bool Legflag1 { get; set; }
        public bool Legflag2 { get; set; }
        public string LocalTransactTime { get; set; }
        public string MaturityDay1 { get; set; }
        public string MaturityDay2 { get; set; }
        public string MaturityMonthYear1 { get; set; }
        public string MaturityMonthYear2 { get; set; }
        public string MultiLegReportingType { get; set; }
        public string Openclose { get; set; }
        public string OrderID { get; set; }
        public string OrderLegNum { get; set; }
        public decimal OrderQty { get; set; }
        public string OrdStatus { get; set; }
        public string OrdType { get; set; }
        public string OrigClOrdID { get; set; }
        public string OrigExecID { get; set; }
        public decimal Price { get; set; }
        public decimal Price1 { get; set; }
        public decimal Price2 { get; set; }
        public string PutOrCall1 { get; set; }
        public string PutOrCall2 { get; set; }
        public decimal RawLastPx { get; set; }
        public decimal RawPrice { get; set; }
        public decimal RawStopPx { get; set; }
        public string SecondaryOrderID { get; set; }
        public string SecurityExchange { get; set; }
        public string SecurityType { get; set; }
        public string SecurityType1 { get; set; }
        public string SecurityType2 { get; set; }
        public string Side { get; set; }
        public string Side1 { get; set; }
        public string Side2 { get; set; }
        public decimal StopPx { get; set; }
        public decimal StrikePrice1 { get; set; }
        public decimal StrikePrice2 { get; set; }
        public string Symbol1 { get; set; }
        public string Symbol2 { get; set; }
        public string Text { get; set; }
        public string TimeInForce { get; set; }
        public string TransactTime { get; set; }
        public string Data { get; set; }
    }

    public class FIXProvider
    {
        public FIXProvider()
        {
        }
        public static NewOrderSingleMessage FItem2NewOrderSingleMessage(FOrderItem item, ref SymbolProvider SymbolProvider)
        {
            NewOrderSingleMessage obj = new NewOrderSingleMessage();

            obj.FOrderItem = item.Copy();
            //  SymbolData SymbolData = SymbolProvider.GetSymbolDataForSymbol(item.SECURITYEXCHANGE, item.SECURITYTYPE1, item.SYMBOL1);

            decimal Price = item.PRICE;
            decimal StopPrice = item.STOPPRICE;

            string ExChange = item.SECURITYEXCHANGE;
            string Symbol1 = item.SYMBOL1;
            string Symbol2 = item.SYMBOL2;
            //if (item.SYSTEM == "PATS")
            //{
            //    Price = SymbolProvider.Price2fractionPrice(item.PRICE, SymbolData.PDENOMIN, SymbolData.PRATIO);
            //    StopPrice = SymbolProvider.Price2fractionPrice(item.STOPPRICE, SymbolData.PDENOMIN, SymbolData.PRATIO);
            //    Price = Price * SymbolData.PRATIO;
            //    ExChange = SymbolData.PEXCH;
            //    Symbol1 = SymbolData.PSYMBOL;
            //    if (item.PRODUCTKIND == "3" || item.PRODUCTKIND == "4")
            //        Symbol2 = SymbolData.PSYMBOL;
            //}
            //else if (item.SYSTEM == "TT")
            //{
            //    Price = SymbolProvider.Price2fractionPrice(item.PRICE, SymbolData.TDENOMIN, SymbolData.TRATIO);
            //    StopPrice = SymbolProvider.Price2fractionPrice(item.STOPPRICE, SymbolData.TDENOMIN, SymbolData.TRATIO);
            //}

            obj.ClOrdID = item.CLORDID;
            obj.ClientID = item.BROKERID + item.INVESTORACNO;
            obj.Account = item.ACCOUNT;
            obj.SecurityExchange = ExChange;
            obj.SecurityType1 = item.SECURITYTYPE1;
            obj.Symbol1 = Symbol1;
            obj.MaturityMonthYear1 = item.MATURITYMONTHYEAR1;
            obj.PutOrCall1 = ParserForTarget.DDSC2TargetForCP(item.PUTORCALL1);
            obj.StrikePrice1 = item.STRIKEPRICE1;
            obj.Side1 = ParserForTarget.DDSC2TargetForBS(item.SIDE1);
            obj.SecurityType2 = item.SECURITYTYPE2;
            obj.Symbol2 = Symbol2;
            obj.MaturityMonthYear2 = item.MATURITYMONTHYEAR2;
            obj.PutOrCall2 = ParserForTarget.DDSC2TargetForCP(item.PUTORCALL2); ;
            obj.StrikePrice2 = item.STRIKEPRICE2;
            obj.Side2 = ParserForTarget.DDSC2TargetForBS(item.SIDE2);
            obj.Side = ParserForTarget.DDSC2TargetForBS(item.BS);
            obj.OrderQty = item.ORDERQTY;
            obj.OrderType = item.ORDERTYPE;
            obj.Price = Price;
            obj.StopPx = StopPrice;
            obj.TimeInForce = item.TIMEINFORCE;
            obj.ExpireDate = item.EXPIREDATE;
            obj.PositionEffect = item.OPENCLOSE;


            return obj;
        }

        public static OrderCancelReplaceMessage FItem2OrderCancelReplaceMessage(FOrderItem item, ref SymbolProvider SymbolProvider)
        {

            // SymbolData SymbolData = SymbolProvider.GetSymbolDataForSymbol(item.SECURITYEXCHANGE, item.SECURITYTYPE1, item.SYMBOL1);

            decimal Price = item.PRICE;
            decimal StopPrice = item.STOPPRICE;

            string ExChange = item.SECURITYEXCHANGE;
            string Symbol1 = item.SYMBOL1;
            string Symbol2 = item.SYMBOL2;
            //if (item.SYSTEM == "PATS")
            //{
            //    Price = SymbolProvider.Price2fractionPrice(item.PRICE, SymbolData.PDENOMIN, SymbolData.PRATIO);
            //    StopPrice = SymbolProvider.Price2fractionPrice(item.STOPPRICE, SymbolData.PDENOMIN, SymbolData.PRATIO);
            //    ExChange = SymbolData.PEXCH;
            //    Symbol1 = SymbolData.PSYMBOL;
            //    if (item.PRODUCTKIND == "3" || item.PRODUCTKIND == "4")
            //        Symbol2 = SymbolData.PSYMBOL;
            //}
            //else if (item.SYSTEM == "TT")
            //{
            //    Price = SymbolProvider.Price2fractionPrice(item.PRICE, SymbolData.TDENOMIN, SymbolData.TRATIO);
            //    StopPrice = SymbolProvider.Price2fractionPrice(item.STOPPRICE, SymbolData.TDENOMIN, SymbolData.TRATIO);

            //}






            OrderCancelReplaceMessage obj = new OrderCancelReplaceMessage();
            obj.FOrderItem = item.Copy();
            obj.OrigClOrdID = item.ORICLORDID;
            obj.OrderID = item.ORDERID;
            obj.ClOrdID = item.CLORDID;
            obj.ClientID = item.BROKERID + item.INVESTORACNO;
            obj.Account = item.ACCOUNT;
            obj.SecurityExchange = ExChange;
            obj.SecurityType1 = item.SECURITYTYPE1;
            obj.Symbol1 = Symbol1;
            obj.MaturityMonthYear1 = item.MATURITYMONTHYEAR1;
            obj.PutOrCall1 = ParserForTarget.DDSC2TargetForCP(item.PUTORCALL1);
            obj.StrikePrice1 = item.STRIKEPRICE1;
            obj.Side1 = ParserForTarget.DDSC2TargetForBS(item.SIDE1);
            obj.SecurityType2 = item.SECURITYTYPE2;
            obj.Symbol2 = Symbol2;
            obj.MaturityMonthYear2 = item.MATURITYMONTHYEAR2;
            obj.PutOrCall2 = ParserForTarget.DDSC2TargetForCP(item.PUTORCALL2);
            obj.StrikePrice2 = item.STRIKEPRICE2;
            obj.Side2 = ParserForTarget.DDSC2TargetForBS(item.SIDE2);
            obj.Side = ParserForTarget.DDSC2TargetForBS(item.BS);
            obj.OrderQty = item.ORDERQTY;
            obj.OrderType = item.ORDERTYPE;
            obj.Price = Price;
            obj.StopPx = StopPrice;
            obj.TimeInForce = item.TIMEINFORCE;
            obj.ExpireDate = item.EXPIREDATE;
            obj.PositionEffect = item.OPENCLOSE;


            return obj;
        }



        public static OrderCancelMessage FItem2OrderCancelMessage(FOrderItem item, ref SymbolProvider SymbolProvider)
        {

            // SymbolData SymbolData = SymbolProvider.GetSymbolDataForSymbol(item.SECURITYEXCHANGE, item.SECURITYTYPE1, item.SYMBOL1);

            decimal Price = item.PRICE;
            decimal StopPrice = item.STOPPRICE;

            string ExChange = item.SECURITYEXCHANGE;
            string Symbol1 = item.SYMBOL1;
            string Symbol2 = item.SYMBOL2;
            //if (item.SYSTEM == "PATS")
            //{
            //    Price = SymbolProvider.Price2fractionPrice(item.PRICE, SymbolData.PDENOMIN, SymbolData.PRATIO);
            //    StopPrice = SymbolProvider.Price2fractionPrice(item.STOPPRICE, SymbolData.PDENOMIN, SymbolData.PRATIO);
            //    ExChange = SymbolData.PEXCH;
            //    Symbol1 = SymbolData.PSYMBOL;
            //    if (item.PRODUCTKIND == "3" || item.PRODUCTKIND == "4")
            //        Symbol2 = SymbolData.PSYMBOL;
            //}
            //else if (item.SYSTEM == "TT")
            //{
            //    Price = SymbolProvider.Price2fractionPrice(item.PRICE, SymbolData.TDENOMIN, SymbolData.TRATIO);
            //    StopPrice = SymbolProvider.Price2fractionPrice(item.STOPPRICE, SymbolData.TDENOMIN, SymbolData.TRATIO);

            //}



            OrderCancelMessage obj = new OrderCancelMessage();
            obj.FOrderItem = item.Copy();
            obj.OrigClOrdID = item.ORICLORDID;
            obj.OrderID = item.ORDERID;
            obj.ClOrdID = item.CLORDID;
            obj.ClientID = item.BROKERID + item.INVESTORACNO;
            obj.Account = item.ACCOUNT;
            obj.Symbol = Symbol1;
            obj.SecurityType = item.SECURITYTYPE1;
            obj.MaturityMonthYear = item.MATURITYMONTHYEAR1;
            obj.Side = ParserForTarget.DDSC2TargetForBS(item.BS);
            obj.SecurityExchange = ExChange;

            return obj;
        }




        public static ExecutionReport TT2EXCHForExecutionReport(TT.ExecutionReport obj, ref SymbolProvider _SymbolProvider)
        {
            string SecurityType = obj.SecurityType;
            if (obj.SecurityType == "MLEG")
            {
                SecurityType = obj.SecurityType1;
            }

            //SymbolData SymbolData = _SymbolProvider.GetSymbolDataForSymbol(obj.SecurityExchange, SecurityType, obj.Symbol1);

            decimal Price = obj.Price;
            decimal StopPrice = obj.StopPx;
            decimal Price1 = obj.Price1;
            decimal Price2 = obj.Price2;
            decimal LastPx = obj.LastPx;
            decimal AvgPx = obj.AvgPx;
            string ExChange = obj.SecurityExchange; ;
            string Symbol1 = obj.Symbol1;
            string Symbol2 = obj.Symbol2;

            //Price = SymbolProvider.fractionPrice2Price(obj.Price, SymbolData.TDENOMIN, SymbolData.TRATIO);
            //StopPrice = SymbolProvider.fractionPrice2Price(obj.StopPx, SymbolData.TDENOMIN, SymbolData.TRATIO);

            //decimal Price1 = SymbolProvider.fractionPrice2Price(obj.Price1, SymbolData.TDENOMIN, SymbolData.TRATIO);
            //decimal Price2 = SymbolProvider.fractionPrice2Price(obj.Price2, SymbolData.TDENOMIN, SymbolData.TRATIO);
            //decimal LastPx = SymbolProvider.fractionPrice2Price(obj.LastPx, SymbolData.TDENOMIN, SymbolData.TRATIO);
            //decimal AvgPx = SymbolProvider.fractionPrice2Price(obj.AvgPx, SymbolData.TDENOMIN, SymbolData.TRATIO);
            if (obj.SecurityType == "MLEG")
            {
                // Symbol2 = SymbolData.SYMBOL;
            }

            ExecutionReport TT = new ExecutionReport();
            TT.OrderID = obj.OrderID;
            TT.SecondaryOrderID = obj.SecondaryOrderID;
            TT.ClOrdID = obj.ClOrdID;
            TT.OrigClOrdID = obj.OrigClOrdID;
            TT.ClientID = obj.ClientID;
            TT.ExecID = obj.ExecID;
            TT.OrigExecID = obj.OrigExecID;
            TT.ExecTransType = obj.ExecTransType;
            TT.ExecRefID = obj.ExecRefID;
            TT.ExecType = obj.ExecType;
            TT.OrdStatus = obj.OrdStatus;
            TT.ExecRestatementReason = obj.ExecRestatementReason;
            TT.Account = obj.Account;
            TT.SecurityExchange = ExChange;
            TT.Symbol1 = Symbol1;
            TT.SecurityType1 = obj.SecurityType1;
            TT.MaturityMonthYear1 = obj.MaturityMonthYear1;
            TT.MaturityDay1 = obj.MaturityDay1;
            TT.PutOrCall1 = obj.PutOrCall1;
            TT.StrikePrice1 = obj.StrikePrice1;
            TT.Side1 = obj.Side1;
            TT.Price1 = Price1;
            TT.Symbol2 = Symbol2;
            TT.SecurityType2 = obj.SecurityType2;
            TT.MaturityMonthYear2 = obj.MaturityMonthYear2;
            TT.MaturityDay2 = obj.MaturityDay2;
            TT.PutOrCall2 = obj.PutOrCall2;
            TT.StrikePrice2 = obj.StrikePrice2;
            TT.Side2 = obj.Side2;
            TT.Price2 = Price2;
            TT.Side = obj.Side;
            TT.OrderQty = obj.OrderQty;
            TT.OrdType = obj.OrdType;
            TT.Openclose = obj.Openclose;
            TT.Price = Price;
            TT.StopPx = StopPrice;
            TT.RawPrice = obj.RawPrice;
            TT.RawStopPx = obj.RawStopPx;
            TT.TimeInForce = obj.TimeInForce;
            TT.ExpireDate = obj.ExpireDate;
            TT.LastShares = obj.LastShares;
            TT.LastPx = LastPx;
            TT.RawLastPx = obj.RawLastPx;
            TT.LeavesQty = obj.LeavesQty;
            TT.CumQty = obj.CumQty;
            TT.AvgPx = AvgPx;
            TT.TransactTime = obj.TransactTime;
            TT.LocalTransactTime = obj.LocalTransactTime;
            TT.Text = obj.Text;
            TT.ClRefID = obj.ClRefID;
            TT.ESAReference = obj.ESAReference;
            TT.OrderLegNum = obj.OrderLegNum;
            TT.ClearingAccount = obj.ClearingAccount;
            TT.CxlRejResponseTo = obj.CxlRejResponseTo;
            TT.CxlRejReason = obj.CxlRejReason;
            TT.MultiLegReportingType = obj.MultiLegReportingType;
            TT.Legflag1 = obj.Legflag1;
            TT.Legflag2 = obj.Legflag2;
            return TT;
        }

    }





}
