﻿using System;
using System.IO;
using System.Text;
using System.Diagnostics;

namespace com.ddsc.TradeSocketServer
{
    public class Date
    {
        static DateTime now = DateTime.Now;
        static Stopwatch SW;
        private DateTime _Time;

        public DateTime Time
        {
            get
            {
                return _Time;
            }
        }
        private long _MS;

        public long MS
        {
            get { return _MS; }

        }


        public Date()
        {
            _Time = NowTime();
            _MS = NowMS();
        }



        public static long NowMS()
        {
            if (SW == null)
            {
                SW = new Stopwatch();
            }


            if (!SW.IsRunning)
            {
                now = DateTime.Now;
                SW.Reset();
                SW.Start();
            }

            return SW.ElapsedMilliseconds;
        }

        public static long ElapsedMicroSeconds()
        {
            if (SW == null)
            {
                SW = new Stopwatch();
            }


            if (!SW.IsRunning)
            {
                now = DateTime.Now;
                SW.Reset();
                SW.Start();
            }
            return SW.ElapsedTicks * 1000000 / Stopwatch.Frequency;
        }
        public static DateTime NowTime()
        {
            if (SW == null)
            {
                SW = new Stopwatch();
            }


            if (!SW.IsRunning)
            {
                now = DateTime.Now;
                SW.Reset();
                SW.Start();
            }

            DateTime boot = now + SW.Elapsed;
            return boot;
        }
    }


    /// <summary>
    /// WriterLOG 的摘要描述。
    /// </summary>
    public class WriterLOG
    {
        DateTime now = DateTime.Now;
        StreamWriter sw_Log;
        BinaryWriter writer;
        public string ASTR_FileName = null;
        public string ASTR_FolderName = null;



        public WriterLOG(string STR_FileName, bool OpenFileEnable)
        {

            initWriter("", STR_FileName, "", OpenFileEnable, false);

        }

        public WriterLOG(string BasePath, string STR_FileName, bool OpenFileEnable)
        {

            initWriter(BasePath, STR_FileName, "", OpenFileEnable, false);

        }

        public WriterLOG(string BasePath, string STR_FileName, string Dir, bool OpenFileEnable)
        {

            initWriter(BasePath, STR_FileName, Dir, OpenFileEnable, false);

        }
        public WriterLOG(string BasePath, string STR_FileName, string Dir, bool OpenFileEnable, bool overwite)
        {

            initWriter(BasePath, STR_FileName, Dir, OpenFileEnable, overwite);

        }
        private void initWriter(string BasePath, string STR_FileName, string Dir, bool OpenFileEnable, bool overwite)
        {
            try
            {
                ASTR_FileName = STR_FileName;


                if (BasePath.Trim().Length > 0)
                {
                    if (Dir.Trim().Length > 0)
                        ASTR_FolderName = BasePath.TrimEnd() + "\\Log\\" + DateTime.Now.ToString("yyyyMMdd") + "\\" + Dir;
                    else
                        ASTR_FolderName = BasePath.TrimEnd() + "\\Log\\" + DateTime.Now.ToString("yyyyMMdd");
                }
                else
                {
                    if (Dir.Trim().Length > 0)
                        ASTR_FolderName = AppDomain.CurrentDomain.BaseDirectory.ToString().TrimEnd() + "\\Log\\" + DateTime.Now.ToString("yyyyMMdd") + "\\" + Dir;
                    else
                        ASTR_FolderName = AppDomain.CurrentDomain.BaseDirectory.ToString().TrimEnd() + "\\Log\\" + DateTime.Now.ToString("yyyyMMdd");
                }

                if (!Directory.Exists(ASTR_FolderName))
                {
                    Directory.CreateDirectory(ASTR_FolderName);
                }
                string str_path = ASTR_FolderName + "\\" + ASTR_FileName + ".txt";
                if (File.Exists(str_path))
                {
                    if (!overwite)
                        sw_Log = File.AppendText(str_path);
                    else
                        sw_Log = File.CreateText(str_path);
                } 
                else
                {
                    sw_Log = File.CreateText(str_path);
                }
                sw_Log = new StreamWriter(sw_Log.BaseStream, Encoding.Default);
                writer = new BinaryWriter(sw_Log.BaseStream,Encoding.Default);
                if (OpenFileEnable)
                {
                    sw_Log.WriteLine(DateTime.Now.ToString("yyyyMMdd HH:mm:ss.ffffff") + " -->:" + "Open Log File");
                    sw_Log.Flush();
                }
            }
            catch (Exception ex)
            {
                string test = ex.ToString();
            }
        }
        ~WriterLOG()
        {
            Close();
        }
        public void Close()
        {
            try
            {
                if (sw_Log != null)
                {
                    sw_Log.Close();
                }
            }
            catch (Exception ex)
            {
            }
        }
        public void WriteLine(byte[] lineToWrite)
        {


            try
            {
                if (sw_Log.BaseStream != null)
                {

                    writer.Write(lineToWrite);
                    writer.Flush();

                }
            }
            catch
            {
            }
        }
        public void WriteEntryData(string l_strLogData)
        {
            //			sw_Log.WriteLine(DateTime.Now.ToString("yyyyMMdd HH:mm:ss -->:" + l_strLogData.Replace("'"," ")));
            try
            {
                sw_Log.WriteLine(DateTime.Now.ToString("yyyyMMdd HH:mm:ss.ffffff") + " -->:" + l_strLogData);
                sw_Log.Flush();
            }
            catch
            {
            }
        }

        public void WriteData(string l_strLogData)
        {
            //			sw_Log.WriteLine(DateTime.Now.ToString("yyyyMMdd HH:mm:ss -->:" + l_strLogData.Replace("'"," ")));
            try
            {
                sw_Log.WriteLine(l_strLogData);
                sw_Log.Flush();
            }
            catch
            {
            }
        }
    }
    public class FileALLReader
    {
        private object lockerForLog = new object();


        StreamReader sr;
        private string ASTR_FileName = null;
        private string ASTR_FolderName = null;
        public FileALLReader(string STR_FileName)
        {
            initWriter("", STR_FileName, "");
        }
        public FileALLReader(string BasePath, string STR_FileName)
        {

            initWriter(BasePath, STR_FileName, "");

        }

        public FileALLReader(string BasePath, string STR_FileName, string Dir)
        {

            initWriter(BasePath, STR_FileName, Dir);

        }

        public void initWriter(string BasePath, string STR_FileName, string Dir)
        {

            try
            {
                ASTR_FileName = STR_FileName;
                if (BasePath.Trim().Length > 0)
                {
                    if (Dir.Trim().Length > 0)
                        ASTR_FolderName = BasePath.TrimEnd() + "\\Log\\" + DateTime.Now.ToString("yyyyMMdd") + "\\" + Dir;
                    else
                        ASTR_FolderName = BasePath.TrimEnd() + "\\Log\\" + DateTime.Now.ToString("yyyyMMdd");
                }
                else
                {
                    if (Dir.Trim().Length > 0)
                        ASTR_FolderName = AppDomain.CurrentDomain.BaseDirectory.ToString().TrimEnd() + "\\Log\\" + DateTime.Now.ToString("yyyyMMdd") + "\\" + Dir;
                    else
                        ASTR_FolderName = AppDomain.CurrentDomain.BaseDirectory.ToString().TrimEnd() + "\\Log\\" + DateTime.Now.ToString("yyyyMMdd");
                }
                if (!Directory.Exists(ASTR_FolderName))
                {
                    Directory.CreateDirectory(ASTR_FolderName);
                }



                string str_path = ASTR_FolderName + "\\" + ASTR_FileName + ".txt";
                if (File.Exists(str_path))
                {
                    sr = new StreamReader(str_path,Encoding.Default);
                }


            }
            catch (Exception ex)
            {
                throw ex;
            }


        }

        public string readln()
        {
            if (sr != null)
            {
                if (sr.BaseStream != null)
                {

                    return sr.ReadLine();
                }
                else
                    return "";
            }
            return "";



        }
        public string read()
        {
            if (sr != null)
            {
                if (sr.BaseStream != null)
                {

                    return sr.ReadToEnd();
                }
                else
                    return "";
            }
            return "";



        }

        public void Close()
        {
            if (sr != null)
            {
                if (sr.BaseStream != null)
                    sr.Close();
            }

        }
    }
    public class FileDate
    {
        public void delfile(int FileDate)
        {
            if (!Directory.Exists(AppDomain.CurrentDomain.BaseDirectory.ToString().TrimEnd() + "\\Log"))
            {
                Directory.CreateDirectory(AppDomain.CurrentDomain.BaseDirectory.ToString().TrimEnd() + "\\Log");
            }
            string[] dir = Directory.GetDirectories(AppDomain.CurrentDomain.BaseDirectory.ToString().Trim() + "Log");
            string[] dt = new string[dir.Length];
            int chk_day = int.Parse((DateTime.Now.AddDays(-(FileDate - 1))).ToString("yyyyMMdd"));

            for (int i = 0; i < dir.Length; i++)
            {
                dt[i] = (Directory.GetLastWriteTime(dir[i])).ToString("yyyyMMdd");
                if (int.Parse(dt[i]) < chk_day)
                {
                    Directory.Delete(dir[i], true);
                }
            }
        }
    }
}
