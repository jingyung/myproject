﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using com.ddsc.core;
using System.Threading;


namespace com.ddsc.TradeSocketServer
{
    public class TimerOrder
    {

        private QueuePoolByLock<TimeItem> _QEvent;
        public class TimeItem
        {
            public void init()
            {
                ID = "";
                NO = "";
                QTY = "";
                sended = false;
            }
            public string ID;
            public string NO;
            public DateTime TIME;
            public string QTY;
            public bool sended;
        }
        public class TimeOrder
        {
            public void init()
            {
            }
            public Dictionary<int, TimeItem> OrderList = new Dictionary<int, TimeItem>();
            public DateTime BeginTime = new DateTime();
            public DateTime EndTime = new DateTime();
            public bool Enabled = false;
            public int TotalQty = 0;
            public int Qty = 0;
            public int TotalTimes = 0;
            public int Times = 0;
            public int CurrentNo = 0;//index
            public int Interval = 0;

            public void start()
            {
                Enabled = true;
            }
            public void stop()
            {
                Enabled = false;
            }
        }
        public event FinishHandler FinishEvent;
        public delegate void FinishHandler(string ID);
        public event TickHandler TickEvent;
        public delegate void TickHandler(string ID, string NO, DateTime TIME, string QTY);
        public void onTickEvent(string ID, string NO, DateTime TIME, string QTY)
        {
            if (TickEvent != null)
                TickEvent(ID, NO, TIME, QTY);
        }
        public void onFinishEvent(string ID)
        {
            if (FinishEvent != null)
                FinishEvent(ID);
        }


        public TimeOrder GetTimeOrder(string key)
        {
            TimeOrder obj = null;
            lock (TimeOrderCollection)
            {
                TimeOrderCollection.TryGetValue(key, out obj);
            }

            return obj;
        }

        public void StopTimeOrder(string key)
        {
            TimeOrder obj = null;
            lock (TimeOrderCollection)
            {
                if (TimeOrderCollection.TryGetValue(key, out obj))
                {
                    obj.stop();
                }
            }


        }
        private Dictionary<string, TimeOrder> TimeOrderCollection = new Dictionary<string, TimeOrder>();

        //System.Timers.Timer timer; //= new System.Timers.Timer();
        System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
        public TimerOrder()
        {

            _QEvent = new QueuePoolByLock<TimeItem>(1);
            _QEvent.ParameterExcute += new QueuePoolByLock<TimeItem>.ParameterHandler(_QEvent_ParameterExcute);
            _QEvent.Go();
            timer.Interval = 100;
            timer.Tick += new EventHandler(timer_Tick);
            timer.Start();
            //  timer.Elapsed += new System.Timers.ElapsedEventHandler(timer_Elapsed);
        }


        /// <summary>
        ///   設定變數 
        /// </summary>
        /// <param name="totalqty">ID</param>
        /// <param name="totalqty">總口數</param>
        /// <param name="qty">每次送單口數</param>
        /// <param name="ratio">比率</param>
        /// <param name="interval">間隔時間(毫秒)</param> 
        /// <param name="BeginTime">開始時間</param>
        /// <param name="EndTime">結束時間</param>
        public void setParam(string id, int p_totalqty, int p_qty, decimal p_ratio, int p_interval, DateTime p_BeginTime, DateTime p_EndTime)
        {
            TimeOrder t = new TimeOrder();
            //設定送出次數
            if (p_ratio == 0)//判斷是不是依照比率
            {
                t.TotalTimes = p_totalqty / p_qty;
                if (p_totalqty % p_qty > 0)
                    t.TotalTimes = t.TotalTimes + 1;
            }
            else
            {
                t.TotalTimes = Convert.ToInt16(Math.Ceiling(1 / p_ratio));//無條件進位
                p_qty = p_totalqty / t.TotalTimes;
            }
            //設定間隔時間
            if (p_BeginTime < DateTime.Now)//如果時間超過,起始時間用當下時間
                p_BeginTime = DateTime.Now;

            t.Interval = p_interval;
            if (t.Interval == 0)//判斷是不是定時分單.總秒數/次數
            {
                if ((p_EndTime - p_BeginTime).TotalMilliseconds < 0)
                    return;
                t.Interval = Convert.ToInt32((p_EndTime - p_BeginTime).TotalMilliseconds) / t.TotalTimes;
            }
            t.TotalQty = p_totalqty;
            t.Qty = p_qty;
            t.BeginTime = p_BeginTime;
            t.EndTime = p_EndTime;
            t.OrderList.Clear();
            t.CurrentNo = 0;

            for (int i = 0; i < t.TotalTimes; i++)
            {
                TimeItem TimeItem = new TimeItem();
                TimeItem.init();
                TimeItem.ID = id;
                TimeItem.NO = i.ToString();
                if (i < (t.TotalTimes - 1))
                    TimeItem.QTY = t.Qty.ToString();
                else
                {
                    TimeItem.QTY = (t.TotalQty - i * t.Qty).ToString();//最後一次用剩餘口數送出
                }

                TimeItem.TIME = t.BeginTime.AddMilliseconds(timer.Interval + t.Interval * (i));
                t.OrderList.Add(i, TimeItem);
            }
            TimeOrderCollection[id] = t;
            t.start();
        }
        public void start()
        {
            timer.Start();
        }
        public void stop()
        {
            timer.Stop();
        }
        public void dispose()
        {
            if (_QEvent != null)
            {

                _QEvent.ParameterExcute -= new QueuePoolByLock<TimeItem>.ParameterHandler(_QEvent_ParameterExcute);
                _QEvent.Dispose();
            }
            GC.SuppressFinalize(this);
        }

        //private void timer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        void timer_Tick(object sender, EventArgs e)
        {
            
            foreach (TimeOrder t in TimeOrderCollection.Values)
            {
                if (t.Enabled && t.BeginTime <= DateTime.Now)
                {
                    //if (t.CurrentNo < t.TotalTimes)
                    //{
                    //    bool tmp =false;
                    //    for (int i = t.CurrentNo; i < t.TotalTimes; i++)
                    //    {
                    //        if (t.OrderList[i].TIME <= DateTime.Now)
                    //        {
                    //            tmp = true;
                    //            break;
                    //        }
                    //        else
                    //        {
                    //            tmp = false;
                    //        }
                    //    }
                    //    if (tmp)
                    //    {

                    //        if (!t.OrderList[t.CurrentNo].sended)
                    //        {
                    //            t.Times++;
                    //            Console.WriteLine(t.CurrentNo);
                    //            Console.WriteLine(t.Times);
                    //            t.OrderList[t.CurrentNo].sended = true;
                    //            _QEvent.PutData2Queue(t.OrderList[t.CurrentNo]);
                    //            t.CurrentNo++;
                    //        }
                    //    }

                    //}

                   // if (t.CurrentNo < t.TotalTimes-1)
                    if (t.CurrentNo < t.TotalTimes )//當一筆的時候也要出單
                    {
                        for (int i = t.CurrentNo; i < t.TotalTimes; i++)
                        {
                            if (t.OrderList[i].TIME <= DateTime.Now)
                            {
                                if (!t.OrderList[i].sended)
                                {
                                    t.OrderList[i].sended = true;
                                    _QEvent.PutData2Queue(t.OrderList[i]);
                                    t.CurrentNo = i;
                                    break;
                                }
                            }
                        }
                    }
                }

            }
        }
        private void _QEvent_ParameterExcute(TimeItem ff)
        {
            try
            {
                if (TimeOrderCollection.ContainsKey(ff.ID))
                {
                    onTickEvent(ff.ID, ff.NO, ff.TIME, ff.QTY);

                    if (TimeOrderCollection[ff.ID].Times == TimeOrderCollection[ff.ID].TotalTimes)
                        onFinishEvent(ff.ID);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }


    //public class TimerOrder
    //{
    //    public string Seq { get; set; }
    //    public event TickHandler TickEvent;
    //    public delegate void TickHandler(TimerOrder obj,DateTime TIME, string QTY);
    //    private QueuePoolByLock<TimeItem> _QEvent;
    //    public struct TimeItem
    //    {
    //        public void init()
    //        {
    //            NO = "";
    //            QTY = "";
    //        }
    //        public string NO;
    //        public DateTime TIME;
    //        public string QTY;
    //    }
    //    int TotalQty = 0;
    //    int Qty = 0;
    //    int Times = 0;
    //    int Interval = 0;
    //    int Count = 0;
    //    DateTime BeginTime = new DateTime();
    //    DateTime EndTime = new DateTime();
    //    public Dictionary<int, TimeItem> OrderList = new Dictionary<int, TimeItem>();
    //    System.Timers.Timer timer = new System.Timers.Timer();

    //    public TimerOrder()
    //    {
    //        Seq = "";

    //        _QEvent = new QueuePoolByLock<TimeItem>(1);
    //        _QEvent.ParameterExcute += new QueuePoolByLock<TimeItem>.ParameterHandler(_QEvent_ParameterExcute);
    //        _QEvent.Go();
    //        timer.Elapsed += new System.Timers.ElapsedEventHandler(timer_Elapsed);
    //    }
    //    /// <summary>
    //    ///   設定變數 
    //    /// </summary>
    //    /// <param name="totalqty">總口數</param>
    //    /// <param name="qty">每次送單口數</param>
    //    /// <param name="ratio">比率</param>
    //    /// <param name="interval">間隔時間(毫秒)</param> 
    //    /// <param name="BeginTime">開始時間</param>
    //    /// <param name="EndTime">結束時間</param>
    //    public void setParam(int p_totalqty, int p_qty, decimal p_ratio, ref int p_interval, DateTime p_BeginTime, DateTime p_EndTime)
    //    {
    //        //設定送出次數
    //        if (p_ratio == 0)//判斷是不是依照比率
    //        {
    //            Times = p_totalqty / p_qty;
    //            if (p_totalqty % p_qty > 0)
    //                Times = Times + 1;
    //        }
    //        else
    //        {
    //            Times = Convert.ToInt16(Math.Ceiling(1 / p_ratio));//無條件進位
    //            p_qty = p_totalqty / Times;
    //        }
    //        //設定間隔時間
    //        if (p_BeginTime < DateTime.Now)//如果時間超過,起始時間用當下時間
    //            p_BeginTime = DateTime.Now;

    //        Interval = p_interval;
    //        if (Interval == 0)//判斷是不是定時分單.總秒數/次數
    //        {
    //            if ((p_EndTime - p_BeginTime).TotalSeconds < 0)
    //                return;
    //            Interval = Convert.ToInt16((p_EndTime - p_BeginTime).TotalSeconds) / Times * 1000;
    //        }
    //        p_interval = Interval;
    //        timer.Interval = Interval;
    //        TotalQty = p_totalqty;
    //        Qty = p_qty;
    //        BeginTime = p_BeginTime;
    //        EndTime = p_EndTime;
    //        OrderList.Clear();
    //        Count = 0;

    //        for (int i = 0; i < Times; i++)
    //        {
    //            TimeItem TimeItem = new TimeItem();
    //            TimeItem.init();
    //            TimeItem.NO = i.ToString();
    //            if (i < (Times - 1))
    //                TimeItem.QTY = Qty.ToString();
    //            else
    //            {
    //                TimeItem.QTY = (TotalQty - i * Qty).ToString();//最後一次用剩餘口數送出
    //            }
    //            TimeItem.TIME = BeginTime.AddMilliseconds(Interval * (i + 1));
    //            OrderList.Add(i, TimeItem);
    //        }

    //    }
    //    public void start()
    //    {
    //        timer.Start();
    //    }
    //    public void stop()
    //    {
    //        timer.Stop();
    //    }
    //    public void dispose()
    //    {
    //        if (_QEvent != null)
    //        {

    //            _QEvent.ParameterExcute -= new QueuePoolByLock<TimeItem>.ParameterHandler(_QEvent_ParameterExcute);
    //            _QEvent.Dispose();
    //        }
    //        GC.SuppressFinalize(this);
    //    }
    //    private void timer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
    //    {
    //        if (BeginTime <= DateTime.Now)
    //        {
    //            if (Count < Times)
    //            {
    //                _QEvent.PutData2Queue(OrderList[Count]);
    //                Count++;
    //            }
    //            else
    //            {
    //                timer.Stop();
    //            }
    //        }
    //    }
    //    private void _QEvent_ParameterExcute(TimeItem ff)
    //    {
    //        try
    //        {
    //            onTickEvent(ff.TIME, ff.QTY);
    //        }
    //        catch (Exception ex)
    //        {

    //        }
    //    }
    //    private void onTickEvent(DateTime TIME, string QTY)
    //    {
    //        if (TickEvent != null)
    //            TickEvent(this,TIME, QTY);
    //    }
    //}
}
