﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using com.ddsc.BI.F;
namespace com.ddsc.TradeSocketServer
{
    public class DbServerProvider
    {
 

        public static byte[] ResponseOrderToError(ref SockClientParserFunction.Order Order  
                           
                           , string STATUSCODE
                           , string ORDERSTATUS
                             )
        {
            byte[] buffer = null;
            try
            {
                SockClientParserFunction.Reply Reply = new SockClientParserFunction.Reply();
                Reply.REPLYSEQ = GetByte("", 10);
                Reply.TRADEDATE = GetByte(DateTime.Now.ToString("yyyyMMdd"), 8);
                Reply.ORDERTIME = GetByte(Date.NowTime().ToString("HHmmssfff"), 9);
                Reply.EXECTYPE = GetByte(8, 1);
                Reply.BROKERID = Order.BROKERID;
                Reply.ORDERNO = Order.ORDERNO;
                Reply.INVESTORACNO = Order.INVESTORACNO;
                Reply.SUBACT = Order.SUBACT;
                Reply.PRODUCTKIND = Order.PRODUCTKIND;
                Reply.SECURITYEXCHANGE = Order.SECURITYEXCHANGE;
                Reply.SECURITYTYPE1 = Order.SECURITYTYPE1;
                Reply.SYMBOL1 = Order.SYMBOL1;
                Reply.MATURITYMONTHYEAR1 = Order.MATURITYMONTHYEAR1;
                Reply.PUTORCALL1 = Order.PUTORCALL1;
                Reply.STRIKEPRICE1 = Order.STRIKEPRICE1;
                Reply.SIDE1 = Order.SIDE1;
                Reply.PRICE1 = GetByte(0, 22);
                Reply.SECURITYTYPE2 = Order.SECURITYTYPE2;
                Reply.SYMBOL2 = Order.SYMBOL2;
                Reply.MATURITYMONTHYEAR2 = Order.MATURITYMONTHYEAR2;
                Reply.PUTORCALL2 = Order.PUTORCALL2;
                Reply.STRIKEPRICE2 = Order.STRIKEPRICE2;
                Reply.SIDE2 = Order.SIDE2;
                Reply.PRICE2 = GetByte(0, 22);
                Reply.BS = Order.BS;
                Reply.ORDERTYPE = Order.ORDERTYPE;
                Reply.PRICE = Order.PRICE;
                Reply.STOPPRICE = Order.STOPPRICE;
                Reply.ORDERQTY = Order.ORDERQTY;
                Reply.TIMEINFORCE = Order.TIMEINFORCE;
                Reply.OPENCLOSE = Order.OPENCLOSE;
                Reply.EXPIREDATE = Order.EXPIREDATE;
                Reply.LASTSHARES = GetByte(0, 5);
                Reply.LASTPX = GetByte(0, 22);
                Reply.LEAVESQTY = GetByte(0, 5);
                Reply.CUMQTY = GetByte(0, 5);
                Reply.AVGPX = GetByte(0, 22);
                Reply.CLORDID = Order.CLORDID;
                Reply.SOURCECODE = Order.SOURCECODE;
                Reply.STATUSCODE = GetByte(STATUSCODE, 7);
                Reply.ORDERSTATUS = GetByte(ORDERSTATUS, 70);
                Reply.EXECID = GetByte("", 75);
                Reply.EXECTRANSTYPE = GetByte("0", 1);
                Reply.EXECREFID = GetByte("", 75);
                Reply.ORDERID = Order.ORDERID;
                Reply.TARGETID = Order.TARGETID;

                Reply.ACCOUNT = Order.ACCOUNT;

                buffer = SockClientParserFunction.StructureToByteArray(Reply);
            }
            catch (Exception ex)
            {
            }
            return buffer;
        }


        private static byte[] GetByte(string b, int width)
        {
            try
            {
                return ASCIIEncoding.Default.GetBytes(b.PadRight(width, ' '));
            }
            catch (Exception ex)
            {

            }
            return null;
        }
        private static byte[] GetByte(Decimal b, int width)
        {
            try
            {
                return ASCIIEncoding.Default.GetBytes(b.ToString().PadLeft(width, ' '));
            }
            catch (Exception ex)
            {

            }
            return null;
        }

    }
}
