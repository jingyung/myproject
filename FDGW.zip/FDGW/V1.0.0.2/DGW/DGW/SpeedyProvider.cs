﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace com.ddsc.TradeSocketServer
{
    public class SpeedyProvider
    {

        //        國外期貨中台複式下單格式經討論如下，如有疑問，請盡速詢問，謝謝!!

        //商品代碼欄位中，輸入以Pipe(‘|’)符號分隔的多個複式單商品，例如：
        //AJ|BRF

        //在商品年月欄位輸入以Pipe(‘|’)符號分隔的多個複式單商品日期，
        //第一欄買賣別：長度為1，S:Sell B:Buy
        //第二欄商品年月：長度為6，格式YYYYMM
        //第三欄買賣權：長度為1，C:Call P:Put，限選擇權
        //第四欄履約價：長度不定，限選擇權
        //例如：
        //期貨：第一隻腳：買進 2017年1月，第二隻腳：賣出 2017年2月
        //B201701|S201702

        //選擇權：第一隻腳：買進 2017年1月履約價5000買權，第二隻腳：賣出 2017年2月履約價6000賣權
        //B201701C5000|S201702P6000

        //若只有一個商品代碼，商品年月為複式格式，則以同商品複式單下單。

        public static string Parse2NewOrderMessage(ref SpeedyAPI.OrderConnection SpeedyConn, ref NewOrderSingleMessage src, ref SpeedyAPI.NewOrderMessage desc)
        {

            string ret = "";
            desc.ExchangeCode = src.SecurityExchange;
            desc.BrokerID = src.FOrderItem.BROKERID; ;
            desc.Market = (src.FOrderItem.PRODUCTKIND == "1" || src.FOrderItem.PRODUCTKIND == "4") ? SpeedyAPI.MarketEnum.mPATSFutures : SpeedyAPI.MarketEnum.mPATSOptions;
            desc.Account = src.FOrderItem.INVESTORACNO;
            desc.AccountFlag = "0";
            desc.Symbol = src.FOrderItem.SYMBOL1;
            if (src.FOrderItem.PRODUCTKIND == "3" || src.FOrderItem.PRODUCTKIND == "4")//複式單
            {
                if (src.FOrderItem.SECURITYTYPE1 == "FUT")
                {
                    desc.MaturityMonthYear = src.FOrderItem.SIDE1 + src.FOrderItem.MATURITYMONTHYEAR1.Trim()
                                     + "|" + src.FOrderItem.SIDE2 + src.FOrderItem.MATURITYMONTHYEAR2.Trim();
                }
                else
                {
                    desc.MaturityMonthYear = src.FOrderItem.SIDE1 + src.FOrderItem.MATURITYMONTHYEAR1.Trim() + src.FOrderItem.PUTORCALL1 + src.FOrderItem.STRIKEPRICE1.ToString("#.########")
                                     + "|" + src.FOrderItem.SIDE2 + src.FOrderItem.MATURITYMONTHYEAR2.Trim() + src.FOrderItem.PUTORCALL2 + src.FOrderItem.STRIKEPRICE2.ToString("#.########");
                }
            }
            else
                desc.MaturityMonthYear = src.FOrderItem.MATURITYMONTHYEAR1;


            desc.EventType = Fix2SpeedyForCP(src.FOrderItem.PUTORCALL1);


            desc.StrikePrice = (double)src.FOrderItem.STRIKEPRICE1;


            desc.OrderType = Fix2ForSpeedyOrderType(src.OrderType);

            desc.Price = (double)src.Price;
            desc.OrderQty = src.OrderQty;

            desc.Data = "ClOrdID=" + src.ClOrdID + "^OriClOrdID=" + src.ClOrdID;


            desc.TimeInForce = Fix2ForSpeedyTimeInForce(src.TimeInForce);

            desc.PositionEffect = Fix2SpeedyForPositionEffect(src.PositionEffect);


            desc.Side = Fix2SpeedyForBS(src.Side);
            desc.ClOrdID = src.FOrderItem.CLORDID;
            desc.NID = SpeedyConn.GenerateUniqueID(desc.Market, SpeedyAPI.MessageTypeEnum.mtNew);


            ret = string.Format(@"new BrokerID[{0}]Market[{1}]Account[{2}]AccountFlag[{3}]Symbol[{4}]MaturityMonthYear[{5}]EventType[{6}]StrikePrice[{7}]OrderType[{8}]Price[{9}]OrderQty[{10}]Side[{11}]TimeInForce[{12}]PositionEffect[{13}]ClOrdID[{14}]NID[{15}]ExchangeCode[{16}]Data[{17}]", desc.BrokerID, desc.Market.ToString()
                                                   , desc.Account, desc.AccountFlag, desc.Symbol
                                                   , desc.MaturityMonthYear, desc.EventType.ToString()
                                                   , desc.StrikePrice.ToString()
                                                   , desc.OrderType.ToString()
                                                   , desc.Price.ToString()
                                                   , desc.OrderQty.ToString()
                                                   , desc.Side.ToString()
                                                   , desc.TimeInForce.ToString()
                                                   , desc.PositionEffect.ToString()
                                                   , desc.ClOrdID, desc.NID, desc.ExchangeCode, desc.Data
                                                   );

            return ret;
        }



        public static string Parse2ReplaceOrderMessage(ref SpeedyAPI.OrderConnection SpeedyConn, ref OrderCancelReplaceMessage src, ref SpeedyAPI.ReplaceOrderMessage desc)
        {

            string ret = "";
            desc.ExchangeCode = src.SecurityExchange;
            desc.BrokerID = src.FOrderItem.BROKERID; ;
            desc.Market = (src.FOrderItem.PRODUCTKIND == "1" || src.FOrderItem.PRODUCTKIND == "4") ? SpeedyAPI.MarketEnum.mPATSFutures : SpeedyAPI.MarketEnum.mPATSOptions;
            desc.Account = src.FOrderItem.INVESTORACNO;
            desc.AccountFlag = "0";
            desc.Symbol = src.FOrderItem.SYMBOL1;
            if (src.FOrderItem.PRODUCTKIND == "3" || src.FOrderItem.PRODUCTKIND == "4")//複式單
            {
                if (src.FOrderItem.SECURITYTYPE1 == "FUT")
                {
                    desc.MaturityMonthYear = src.FOrderItem.SIDE1 + src.FOrderItem.MATURITYMONTHYEAR1.Trim()
                                     + "|" + src.FOrderItem.SIDE2 + src.FOrderItem.MATURITYMONTHYEAR2.Trim();
                }
                else
                {
                    desc.MaturityMonthYear = src.FOrderItem.SIDE1 + src.FOrderItem.MATURITYMONTHYEAR1.Trim() + src.FOrderItem.PUTORCALL1 + src.FOrderItem.STRIKEPRICE1.ToString("#.########")
                                     + "|" + src.FOrderItem.SIDE2 + src.FOrderItem.MATURITYMONTHYEAR2.Trim() + src.FOrderItem.PUTORCALL2 + src.FOrderItem.STRIKEPRICE2.ToString("#.########");
                }
            }
            else
                desc.MaturityMonthYear = src.FOrderItem.MATURITYMONTHYEAR1;

            desc.EventType = Fix2SpeedyForCP(src.FOrderItem.PUTORCALL1);


            desc.StrikePrice = (double)src.FOrderItem.STRIKEPRICE1;


            desc.OrderType = Fix2ForSpeedyOrderType(src.OrderType);

            desc.Price = (double)src.Price;

            if (src.OrderQty >= src.LeaveQty)
            {
                desc.OrderQty = 0;
            }
            else if (src.OrderQty < src.LeaveQty)
            {
                desc.OrderQty = (src.LeaveQty - src.OrderQty);
            }
            else if (src.OrderQty == 0)
            {
                desc.OrderQty = src.LeaveQty;
            }



            desc.Side = Fix2SpeedyForBS(src.Side);
            desc.TimeInForce = Fix2ForSpeedyTimeInForce(src.TimeInForce);


            desc.PositionEffect = Fix2SpeedyForPositionEffect(src.PositionEffect);



            desc.OrderID = src.FOrderItem.ORDERID;
            desc.ClOrdID = src.FOrderItem.CLORDID;
            desc.OrigClOrdID = src.FOrderItem.ORICLORDID;
            desc.NID = SpeedyConn.GenerateUniqueID(desc.Market, SpeedyAPI.MessageTypeEnum.mtReplace);


            desc.Data = "ClOrdID=" + src.FOrderItem.CLORDID + "^OriClOrdID=" + src.FOrderItem.ORICLORDID;


            ret = string.Format(@"Replace BrokerID[{0}]Market[{1}]Account[{2}]AccountFlag[{3}]Symbol[{4}]MaturityMonthYear[{5}]EventType[{6}]StrikePrice[{7}]OrderType[{8}]Price[{9}]OrderQty[{10}]Side[{11}]TimeInForce[{12}]PositionEffect[{13}]ClOrdID[{14}]OrigClOrdID[{15}]OrderID[{16}]NID[{17}]ExchangeCode[{18}]Data[{19}]", desc.BrokerID, desc.Market.ToString(), desc.Account, desc.AccountFlag, desc.Symbol
                                                   , desc.MaturityMonthYear, desc.EventType.ToString()
                                                   , desc.StrikePrice.ToString()
                                                   , desc.OrderType.ToString()
                                                   , desc.Price.ToString()
                                                   , desc.OrderQty.ToString()
                                                   , desc.Side.ToString()
                                                   , desc.TimeInForce.ToString()
                                                   , desc.PositionEffect.ToString()
                                                   , desc.ClOrdID
                                                    , desc.OrigClOrdID
                                                     , desc.OrderID, desc.NID, desc.ExchangeCode, desc.Data
                                                   );

            return ret;

        }


        public static string Parse2OrderCancelMessage(ref SpeedyAPI.OrderConnection SpeedyConn, ref OrderCancelMessage src, ref SpeedyAPI.CancelOrderMessage desc)
        {

            string ret = "";
            desc.ExchangeCode = src.SecurityExchange;
            desc.BrokerID = src.FOrderItem.BROKERID; ;
            desc.Market = (src.FOrderItem.PRODUCTKIND == "1" || src.FOrderItem.PRODUCTKIND == "4") ? SpeedyAPI.MarketEnum.mPATSFutures : SpeedyAPI.MarketEnum.mPATSOptions;
            desc.Account = src.FOrderItem.INVESTORACNO;
            desc.AccountFlag = "0";
            desc.Symbol = src.FOrderItem.SYMBOL1;

            if (src.FOrderItem.PRODUCTKIND == "3" || src.FOrderItem.PRODUCTKIND == "4")//複式單
            {
                if (src.FOrderItem.SECURITYTYPE1 == "FUT")
                {
                    desc.MaturityMonthYear = src.FOrderItem.SIDE1 + src.FOrderItem.MATURITYMONTHYEAR1.Trim()
                                     + "|" + src.FOrderItem.SIDE2 + src.FOrderItem.MATURITYMONTHYEAR2.Trim();
                }
                else
                {
                    desc.MaturityMonthYear = src.FOrderItem.SIDE1 + src.FOrderItem.MATURITYMONTHYEAR1.Trim() + src.FOrderItem.PUTORCALL1 + src.FOrderItem.STRIKEPRICE1.ToString("#.########")
                                     + "|" + src.FOrderItem.SIDE2 + src.FOrderItem.MATURITYMONTHYEAR2.Trim() + src.FOrderItem.PUTORCALL2 + src.FOrderItem.STRIKEPRICE2.ToString("#.########");
                }
            }
            else
                desc.MaturityMonthYear = src.FOrderItem.MATURITYMONTHYEAR1;

            desc.EventType = Fix2SpeedyForCP(src.FOrderItem.PUTORCALL1);

            desc.StrikePrice = (double)src.FOrderItem.STRIKEPRICE1;


            desc.OrderType = Fix2ForSpeedyOrderType(src.FOrderItem.ORDERTYPE); ;

            desc.Side = Fix2SpeedyForBS(src.Side);

            desc.OrderID = src.FOrderItem.ORDERID;
            desc.ClOrdID = src.FOrderItem.CLORDID;
            desc.OrigClOrdID = src.FOrderItem.ORICLORDID;
            desc.NID = SpeedyConn.GenerateUniqueID(desc.Market, SpeedyAPI.MessageTypeEnum.mtCancel);
            desc.Data = "ClOrdID=" + src.FOrderItem.CLORDID + "^OriClOrdID=" + src.FOrderItem.ORICLORDID;


            ret = string.Format(@"Cancel BrokerID[{0}]Market[{1}]Account[{2}]AccountFlag[{3}]Symbol[{4}]MaturityMonthYear[{5}]EventType[{6}]StrikePrice[{7}]OrderType[{8}]Price[{9}]OrderQty[{10}]Side[{11}]TimeInForce[{12}]PositionEffect[{13}]ClOrdID[{14}]OrigClOrdID[{15}]OrderID[{16}]NID[{17}]ExchangeCode[{18}]Data[{19}]", desc.BrokerID, desc.Market.ToString()
                                                   , desc.Account, desc.AccountFlag, desc.Symbol
                                                   , desc.MaturityMonthYear, desc.EventType.ToString()
                                                   , desc.StrikePrice.ToString()
                                                   , desc.OrderType.ToString()
                                                   , desc.Price.ToString()
                                                   , ""
                                                   , desc.Side.ToString()
                                                   , desc.TimeInForce.ToString()
                                                   , ""
                                                   , desc.ClOrdID
                                                    , desc.OrigClOrdID
                                                     , desc.OrderID, desc.NID, desc.ExchangeCode, desc.Data
                                                   );

            return ret;

        }




        public static string Parse2ExecutionReport(ref com.ddsc.tool.LogManager _LM, ref SpeedyAPI.ExecutionReportMessage src, ref ExecutionReport desc)
        {

            string ret = "";
            string ClOrdID = "";
            string ORICLORDID = "";
            try
            {


                ret = string.Format(@"ExchangeCode[{0}]Symbol[{1}]Side[{2}]LegSide1[{3}]LegSide2[{4}]Market[{5}]MaturityMonthYear[{6}]EventType[{7}]StrikePrice[{8}]Account[{9}]ClOrdID[{10}]OrigClOrdID[{11}]ExecType[{12}]OrderQty[{13}]LeavesQty[{14}]LastPx[{15}]LastQty[{16}]CumQty[{17}]LegPrice1[{18}]LegPrice2[{19}]Price[{20}]StopPx[{21}]PositionEffect[{22}]TimeInForce[{23}]OrderID[{24}]OrderStatus[{25}]OrderType[{26}]ExecTransType[{27}]Text[{28}]CxlRejResponseTo[{29}]ExecRestatementReason[{30}]TransactTime[{31}]NID[{32}]Data[{33}]OrigTransactTime [{34}]ExecID[{35}]ExecRefID[{36}]  "
                    , src.ExchangeCode
    , src.Symbol, src.Side.ToString(), src.LegSide1.ToString(), src.LegSide2.ToString(), src.Market.ToString()
    , src.MaturityMonthYear, src.EventType.ToString(), src.StrikePrice.ToString(), src.Account, src.ClOrdID
    , src.OrigClOrdID
    , src.ExecType.ToString(), src.OrderQty.ToString(), src.LeavesQty.ToString(), src.LastPx.ToString()
    , src.LastQty.ToString()
    , src.CumQty.ToString(), src.LegPrice1.ToString(), src.LegPrice2.ToString()
    , src.Price
    , src.StopPx
    , src.PositionEffect.ToString()
    , src.TimeInForce.ToString()
    , src.OrderID.ToString()
    , src.OrderStatus.ToString()
    , src.OrderType.ToString()
    , src.ExecTransType.ToString()
    , src.Text
    , src.CxlRejResponseTo.ToString()
    , src.ExecRestatementReason.ToString()
    , src.TransactTime
    , src.NID, src.Data != null ? src.Data : "", src.OrigTransactTime, src.ExecID, src.ExecRefID
    );

                if (src.Data != null)
                    foreach (string f in src.Data.Split('^'))
                    {
                        if (f.IndexOf("ClOrdID") > -1)
                        {
                            ClOrdID = f.Split('=')[1];
                        }
                        if (f.IndexOf("OriClOrdID") > -1)
                        {
                            ORICLORDID = f.Split('=')[1];
                        }


                    }
                if (src.MaturityMonthYear != null)
                {
                    if (src.MaturityMonthYear.Split('|').Length > 1)
                    {
                        //B201701C5000|S201702P6000
                        string data1 = src.MaturityMonthYear.Split('|')[0];
                        string data2 = src.MaturityMonthYear.Split('|')[1];

                        string MaturityMonthYear1 = data1.Substring(1, 6);
                        string MaturityMonthYear2 = data2.Substring(1, 6);
                        string BS1 = data1.Substring(0, 1);
                        string BS2 = data2.Substring(0, 1);
                        string CP1;
                        string CP2;
                        decimal STRIKE1;
                        decimal STRIKE2;
                        desc.SecurityType = "MLEG";

                        if (src.Market == SpeedyAPI.MarketEnum.mPATSFutures)
                            desc.SecurityType1 = desc.SecurityType2 = "FUT";
                        else if (src.Market == SpeedyAPI.MarketEnum.mPATSOptions)
                            desc.SecurityType1 = desc.SecurityType2 = "OPT";
                        desc.Symbol2 = desc.Symbol1 = src.Symbol;
                        desc.MaturityMonthYear1 = MaturityMonthYear1;
                        desc.MaturityMonthYear2 = MaturityMonthYear2;


                        desc.Side1 = Speedy2FixForBS(src.LegSide1);
                        desc.Side2 = Speedy2FixForBS(src.LegSide2);

                        if (desc.SecurityType1 == "OPT")
                        {
                            CP1 = data1.Substring(7, 1);
                            CP2 = data2.Substring(7, 1);
                            desc.PutOrCall1 = CP1 == "C" ? "1" : "0";
                            desc.PutOrCall2 = CP2 == "C" ? "1" : "0";
                            STRIKE1 = decimal.Parse(data1.Substring(8));
                            STRIKE2 = decimal.Parse(data2.Substring(8));
                            desc.StrikePrice1 = STRIKE1;
                            desc.StrikePrice2 = STRIKE2;
                        }
                        else
                        {
                            desc.PutOrCall1 = "";
                            desc.PutOrCall2 = "";
                            desc.StrikePrice1 = 0;
                            desc.StrikePrice2 = 0;
                        }


                    }
                    else
                    {

                        if (src.Market == SpeedyAPI.MarketEnum.mPATSFutures)
                            desc.SecurityType = desc.SecurityType1 = "FUT";
                        else if (src.Market == SpeedyAPI.MarketEnum.mPATSOptions)
                            desc.SecurityType = desc.SecurityType1 = "OPT";
                        desc.SecurityType2 = "";
                        desc.Symbol1 = src.Symbol;
                        desc.Symbol2 = "";
                        desc.MaturityMonthYear1 = src.MaturityMonthYear;
                        desc.MaturityMonthYear2 = "";

                        if (desc.SecurityType1 == "OPT")
                        {
                            desc.PutOrCall1 = Speedy2FixForCP(src.EventType);
                            desc.PutOrCall2 = "";
                            desc.StrikePrice1 = (decimal)src.StrikePrice;
                            desc.StrikePrice2 = 0;
                        }
                        else
                        {
                            desc.PutOrCall1 = "";
                            desc.PutOrCall2 = "";
                            desc.StrikePrice1 = 0;
                            desc.StrikePrice2 = 0;
                        }
                    }
                }

                desc.SecondaryOrderID = "";
                desc.SecurityExchange = src.ExchangeCode;

                desc.Side = Speedy2FixForBS(src.Side);
                //   desc.MultiLegReportingType = src.mu;
                desc.Brokerid = src.BrokerID;
                desc.Data = src.Data;
                desc.Account = src.Account;
                desc.AvgPx = 0;
                desc.ClearingAccount = "";
                desc.ClientID = "";
                desc.ClOrdID = ClOrdID;//src.ClOrdID;
                desc.ClRefID = "";
                desc.CumQty = src.CumQty;
                //desc.CxlRejReason              =        
                desc.CxlRejResponseTo = "";// src.CxlRejResponseTo.ToString();
                //desc.ESAReference              =        
                desc.ExecID = src.ExecID;
                desc.ExecRefID = src.ExecRefID;
                desc.ExecRestatementReason = "";// src.ExecRestatementReason.ToString();
                desc.ExecTransType = Speedy2FixForExecTransType(src.ExecTransType);


                desc.ExecType = Speedy2FixForExecType(src.ExecType);
                desc.ExpireDate = "";
                desc.LastPx = (decimal)src.LastPx;
                desc.LastShares = src.LastQty;
                desc.LeavesQty = src.LeavesQty;
                desc.LocalTransactTime = src.TransactTime;
                //desc.MaturityDay1              =        
                //desc.MaturityDay2              =       

                desc.Openclose = Speedy2FixForPositionEffect(src.PositionEffect);
                desc.OrderID = src.OrderID;
                desc.OrderLegNum = "";
                desc.OrderQty = src.OrderQty;
                desc.OrdStatus = Speedy2FixForOrdStatus(src.OrderStatus);
                desc.OrdType = Speedy2FixForOrderType(src.OrderType);
                desc.OrigClOrdID = ORICLORDID;//src.OrigClOrdID;
                // desc.OrigExecID = src.
                desc.Price = (decimal)src.Price;
                desc.Price1 = (decimal)src.LegPrice1;
                desc.Price2 = (decimal)src.LegPrice2;

                //desc.RawLastPx                 =       
                //desc.RawPrice                  =       
                //desc.RawStopPx                 =       

                desc.StopPx = (decimal)src.StopPx;

                if (src.Text != null)
                {

                    string[] rr = src.Text.Split(new string[] { "'" }, StringSplitOptions.RemoveEmptyEntries);

                    desc.Text = rr[0].Replace("[", " ").Replace("]", " ");

                }


                desc.TimeInForce = Speedy2FixForTimeInForce(src.TimeInForce);
                if (desc.OrdStatus == "1" || desc.OrdStatus == "2")
                {
                    //Summary、 Leg
                    if (desc.Text.IndexOf("Summary") > -1)
                        desc.MultiLegReportingType = "3";
                    else if (desc.Text.IndexOf("Leg") > -1)
                        desc.MultiLegReportingType = "2";
                    else
                        desc.MultiLegReportingType = "1";
                }
                try
                {
                    string[] DATE_TIME_FORMATS = { "yyyyMMdd-HH:mm:ss.fff", "yyyyMMdd-HH:mm:ss", "HHmmss" };
                    System.Globalization.DateTimeStyles DATE_TIME_STYLES = System.Globalization.DateTimeStyles.AssumeUniversal | System.Globalization.DateTimeStyles.AdjustToUniversal;
                    System.Globalization.CultureInfo DATE_TIME_CULTURE_INFO = System.Globalization.CultureInfo.InvariantCulture;
                    DateTime wwww = System.DateTime.ParseExact(src.TransactTime, DATE_TIME_FORMATS, DATE_TIME_CULTURE_INFO, DATE_TIME_STYLES);
                    string datetime = wwww.ToLocalTime().ToString("yyyyMMddHHmmssfff");
                    desc.TransactTime = datetime;

                }
                catch (Exception ex)
                {
                    desc.TransactTime = DateTime.Now.ToString("yyyyMMddHHmmssfff");
                }

            }
            catch (Exception ex)
            {
                return ret += ex.Message;
            }
            return ret;


        }
        public static SpeedyAPI.SideEnum Fix2SpeedyForBS(string src)
        {

            //ExecType fix 4.2
            //"1: Buy
            //2: Sell"

            SpeedyAPI.SideEnum side = SpeedyAPI.SideEnum.sNone;
            switch (src)
            {
                case "1":
                    side = SpeedyAPI.SideEnum.sBuy;
                    break;
                case "2":
                    side = SpeedyAPI.SideEnum.sSell;
                    break;


            }



            return side;
        }

        public static string Speedy2FixForBS(SpeedyAPI.SideEnum src)
        {

            //ExecType fix 4.2
            //"1: Buy
            //2: Sell"

            string side = "";
            switch (src)
            {
                case SpeedyAPI.SideEnum.sBuy:
                    side = "1";
                    break;
                case SpeedyAPI.SideEnum.sSell:
                    side = "2";
                    break;


            }



            return side;
        }


        public static SpeedyAPI.EventTypeEnum Fix2SpeedyForCP(string src)
        {

            //ExecType fix 4.2
            //1 for Call, 0 for put
            //"

            SpeedyAPI.EventTypeEnum cp = SpeedyAPI.EventTypeEnum.evtNone;
            switch (src)
            {
                case "1":
                    cp = SpeedyAPI.EventTypeEnum.evtCall;
                    break;
                case "0":
                    cp = SpeedyAPI.EventTypeEnum.evtPut;
                    break;


            }



            return cp;
        }

        public static string Speedy2FixForCP(SpeedyAPI.EventTypeEnum src)
        {

            //ExecType fix 4.2
            //1 for Call, 0 for put
            //"

            string cp = "";
            switch (src)
            {
                case SpeedyAPI.EventTypeEnum.evtCall:
                    cp = "1";
                    break;
                case SpeedyAPI.EventTypeEnum.evtPut:
                    cp = "0";
                    break;


            }



            return cp;
        }




        public static SpeedyAPI.OrderTypeEnum Fix2ForSpeedyOrderType(string src)
        {

            //ExecType fix 4.2
            //           1:Market
            //2:Limit
            //3:Stop
            //4:Stop Limit
            SpeedyAPI.OrderTypeEnum OrderType = SpeedyAPI.OrderTypeEnum.otNone;
            switch (src)
            {
                case "1":
                    OrderType = SpeedyAPI.OrderTypeEnum.otMarket;
                    break;
                case "2":
                    OrderType = SpeedyAPI.OrderTypeEnum.otLimit;
                    break;
                case "3":
                    OrderType = SpeedyAPI.OrderTypeEnum.otStop;
                    break;
                case "4": //Canceled
                    OrderType = SpeedyAPI.OrderTypeEnum.otStopLimit;
                    break;

            }



            return OrderType;
        }


        public static SpeedyAPI.TimeInForceEnum Fix2ForSpeedyTimeInForce(string src)
        {
            //ExecType fix 4.2
            //預設0
            //0: Day
            //1: Good Till Cancel (GTC)
            //2: At The Opening (OPG)
            //3: Immediate or Cancel (IOC)
            //4: Fill Or Kill (FOK)
            //6: Good Till Date
            //8: Good in Session (GIS)
            //Z: At The Auction
            SpeedyAPI.TimeInForceEnum TimeInForce = SpeedyAPI.TimeInForceEnum.tifNone;
            switch (src)
            {
                case "0": //Exchange accept new order
                    TimeInForce = SpeedyAPI.TimeInForceEnum.tifROD;
                    break;
                case "3": //Exchange accept new order
                    TimeInForce = SpeedyAPI.TimeInForceEnum.tifIOC;
                    break;
                case "4": //Replaced
                    TimeInForce = SpeedyAPI.TimeInForceEnum.tifFOK;
                    break;


            }



            return TimeInForce;
        }


        public static string Speedy2FixForOrderType(SpeedyAPI.OrderTypeEnum src)
        {
            //ExecType fix 4.2
            //           1:Market
            //2:Limit
            //3:Stop
            //4:Stop Limit
            string OrderType = "";
            switch (src)
            {
                case SpeedyAPI.OrderTypeEnum.otMarket: //Exchange accept new order
                    OrderType = "1";
                    break;
                case SpeedyAPI.OrderTypeEnum.otLimit: //Exchange accept new order
                    OrderType = "2";
                    break;
                case SpeedyAPI.OrderTypeEnum.otStop: //Replaced
                    OrderType = "3";
                    break;
                case SpeedyAPI.OrderTypeEnum.otStopLimit: //Canceled
                    OrderType = "4";
                    break;

            }



            return OrderType;
        }

        public static string Speedy2FixForTimeInForce(SpeedyAPI.TimeInForceEnum src)
        {
            //ExecType fix 4.2
            //預設0
            //0: Day
            //1: Good Till Cancel (GTC)
            //2: At The Opening (OPG)
            //3: Immediate or Cancel (IOC)
            //4: Fill Or Kill (FOK)
            //6: Good Till Date
            //8: Good in Session (GIS)
            //Z: At The Auction
            string TimeInForce = "";
            switch (src)
            {
                case SpeedyAPI.TimeInForceEnum.tifROD: //Exchange accept new order
                    TimeInForce = "0";
                    break;
                case SpeedyAPI.TimeInForceEnum.tifIOC: //Exchange accept new order
                    TimeInForce = "3";
                    break;
                case SpeedyAPI.TimeInForceEnum.tifFOK: //Replaced
                    TimeInForce = "4";
                    break;


            }



            return TimeInForce;
        }


        public static string Speedy2FixForExecType(SpeedyAPI.ExecTypeEnum src)
        {
            //ExecType fix 4.2
            //   0: New
            //1: Partial Fill
            //2: Fill
            //4: Cancel
            //5: Replace
            //6: Pending Cancel
            //8: Rejected
            //C: Expired
            //D: Restated
            string ExecType = "";
            switch (src)
            {
                case SpeedyAPI.ExecTypeEnum.etNone: //Unknown
                    break;
                case SpeedyAPI.ExecTypeEnum.etNew: //Exchange accept new order
                    ExecType = "0";
                    break;
                case SpeedyAPI.ExecTypeEnum.etReplaced: //Replaced
                    ExecType = "5";
                    break;
                case SpeedyAPI.ExecTypeEnum.etCanceled: //Canceled
                    ExecType = "4";
                    break;
                case SpeedyAPI.ExecTypeEnum.etPartiallyFilled: //Partial fill
                    ExecType = "1";
                    break;
                case SpeedyAPI.ExecTypeEnum.etFilled: //filled
                    ExecType = "2";
                    break;
                case SpeedyAPI.ExecTypeEnum.etRejected: //Rejected
                    ExecType = "8";
                    break;
            }



            return ExecType;
        }

        public static string Speedy2FixForExecTransType(SpeedyAPI.ExecTransTypeEnum src)
        {
            //ExecTransType fix 4.2
            //0:New
            //2:Correct (when the FIX Adapter configuration enables
            //Send Fill Updates in the FIX Session settings and when
            //either X_TRADER confirms a fill or when an OM Gateway
            //sends a fill update.)
            //3:Status (in response to an Order Status Request (H)
            //message)
            string ExecTransType = "0";
            switch (src)
            {
                case SpeedyAPI.ExecTransTypeEnum.ettNew: //New
                    ExecTransType = "0";
                    break;

                case SpeedyAPI.ExecTransTypeEnum.ettCancel: //ettCancel
                    ExecTransType = "1";
                    break;

                case SpeedyAPI.ExecTransTypeEnum.ettCorrect: //Correct
                    ExecTransType = "2";
                    break;



            }



            return ExecTransType;
        }



        public static string Speedy2FixForOrdStatus(SpeedyAPI.OrderStatusEnum src)
        {
            //ExecTransType fix 4.2
            //     0: New
            //1: Partially filled
            //2: Filled
            //4: Canceled
            //5: Replaced
            //6: Cancel pending
            //8: Rejected
            //9: Suspended (Held)
            //A: Pending new
            //C: Expired
            //E: Pending replace
            //U: Order in an unknown state due to a TT Gateway or
            string OrdStatus = "";
            switch (src)
            {
                case SpeedyAPI.OrderStatusEnum.osNew: //New
                    OrdStatus = "0";
                    break;
                case SpeedyAPI.OrderStatusEnum.osReplaced: //Replaced 
                    OrdStatus = "5";
                    break;
                case SpeedyAPI.OrderStatusEnum.osCanceled: //Canceled  
                    OrdStatus = "4";
                    break;
                case SpeedyAPI.OrderStatusEnum.osPartiallyFilled: //Partial fill status  
                    OrdStatus = "1";
                    break;
                case SpeedyAPI.OrderStatusEnum.osFilled: //Filled status  
                    OrdStatus = "2";
                    break;
                case SpeedyAPI.OrderStatusEnum.osRejected: //Rejected  status  
                    OrdStatus = "8";
                    break;

            }



            return OrdStatus;
        }


        public static SpeedyAPI.PositionEffectEnum Fix2SpeedyForPositionEffect(string src)
        {
            //ExecTransType fix 4.2
            //0:New
            //2:Correct (when the FIX Adapter configuration enables
            //Send Fill Updates in the FIX Session settings and when
            //either X_TRADER confirms a fill or when an OM Gateway
            //sends a fill update.)
            //3:Status (in response to an Order Status Request (H)
            //message)
            SpeedyAPI.PositionEffectEnum PositionEffect = SpeedyAPI.PositionEffectEnum.peOpen;
            switch (src)
            {
                case "O": //Open 
                    PositionEffect = SpeedyAPI.PositionEffectEnum.peOpen;
                    break;

                case "C": //Close 
                    PositionEffect = SpeedyAPI.PositionEffectEnum.peClose;
                    break;
            }
            return PositionEffect;
        }


        public static string Speedy2FixForPositionEffect(SpeedyAPI.PositionEffectEnum src)
        {
            //ExecTransType fix 4.2
            //0:New
            //2:Correct (when the FIX Adapter configuration enables
            //Send Fill Updates in the FIX Session settings and when
            //either X_TRADER confirms a fill or when an OM Gateway
            //sends a fill update.)
            //3:Status (in response to an Order Status Request (H)
            //message)
            string PositionEffect = "";
            switch (src)
            {
                case SpeedyAPI.PositionEffectEnum.peOpen: //Open 
                    PositionEffect = "O";
                    break;

                case SpeedyAPI.PositionEffectEnum.peClose: //Close 
                    PositionEffect = "C";
                    break;
            }
            return PositionEffect;
        }

    }



}
