﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using com.ddsc.BI.F;
namespace com.ddsc.TradeSocketServer
{
    public class StrategyDataProvider
    {
        public event OrderTriggerHandler OrderTrigger;
        public delegate void OrderTriggerHandler(FOrderItem obj, DateTime TIME, string QTY);
        TimerOrder T;

        object RILocker = new object();
        Dictionary<string, FOrderItem> _RI;
        public StrategyDataProvider()
        {

            _RI = new Dictionary<string, FOrderItem>();

              T = new TimerOrder();
            T.TickEvent += new TimerOrder.TickHandler(T_TickEvent);
            T.FinishEvent += new TimerOrder.FinishHandler(T_FinishEvent);
            T.start();

        }
        ~StrategyDataProvider()
        {
             Dispose();
        }
        public void Dispose()
        {
            if (T != null)
            {
                T.stop();
                
                T.TickEvent -= new TimerOrder.TickHandler(T_TickEvent);
                T.FinishEvent -= new TimerOrder.FinishHandler(T_FinishEvent);
                T.dispose();
            }
        }


        public FOrderItem SetReplyData(string Clorid, FOrderItem item, string AD)
        {
            FOrderItem ret;
            lock (RILocker)
            {
                if (_RI.ContainsKey(Clorid))
                {

                    FOrderItem obj = _RI[Clorid];
                    obj.PRICE = item.PRICE;
                    obj.LEAVESQTY = item.LEAVESQTY;
                    obj.CUMQTY = item.CUMQTY;

                    obj.STATUSCODE = item.STATUSCODE;
                    obj.ORDERSTATUS = item.ORDERSTATUS;
                    obj.ORDERID = item.ORDERID;
                    _RI[Clorid] = obj;
                    ret = obj;

                }
                else
                {
                    _RI[Clorid] = item;
                    ret = item;


                }
            

            }
            return ret;
        }



        public FOrderItem SetReplyDataTrigger(string Clorid, FOrderItem item, string AD)
        {
            FOrderItem ret=null;
            lock (RILocker)
            {
                 
                //AD =Time Slice,2,500,20161003180440000,20161003190440000,36000,5,0
                int TotalQty = int.Parse(AD.Split('|')[2]);
                int Interval = int.Parse(AD.Split('|')[5]);
                int Qty = int.Parse(AD.Split('|')[6]);
                decimal Ratio = decimal.Parse(AD.Split('|')[7]);
                IFormatProvider culture = new System.Globalization.CultureInfo("zh-TW", true);
                string begin = AD.Split('|')[3];
                string end = AD.Split('|')[4];

                DateTime beginTime = DateTime.ParseExact(begin, "yyyyMMddHHmmssfff", culture);
                DateTime endTime = DateTime.ParseExact(end, "yyyyMMddHHmmssfff", culture);

                if (item.EXECTYPE == "0")
                {
                    T.setParam(Clorid, TotalQty, Qty, Ratio, Interval, beginTime, endTime);

                }
                else if (item.EXECTYPE == "4")
                {
                    T.StopTimeOrder(Clorid);
                }

            }
            return ret;
        }




        void T_FinishEvent(string ID)
        {

        }

        void T_TickEvent(string ID, string NO, DateTime TIME, string QTY)
        {
            lock (RILocker)
            {
                FOrderItem source = null;
                if (_RI.TryGetValue(ID, out source))
                {
                    FOrderItem item = source.Copy();
                    if (OrderTrigger != null)
                        OrderTrigger(item, TIME, QTY);
                }
            }
        }


        public static void OrderTo(ref AccountItem Item
                      , ref SockClientParserFunction.Order Request
                        , string EXECTYPE
                        , string ORDERNO
                        , string CLORDID
                        , string ORDERID
                        , string STATUSCODE
                        , string ORDERSTATUS
                        , string TARGETID
                        , string ACCOUNT
                        , string DATA
                        , string CADATA)
        {
            byte[] buffer = null;
            try
            {

                Item.OrderKind = OrderKind.TRADE;


                Item.FOrderItem.TRADEDATE = GetString(Request.TRADEDATE);
                Item.FOrderItem.ORDERTIME = GetString(Request.ORDERTIME);
                Item.FOrderItem.EXECTYPE = GetString(Request.EXECTYPE);
                Item.FOrderItem.BROKERID = GetString(Request.BROKERID);
                Item.FOrderItem.ORDERNO = ORDERNO;
                Item.FOrderItem.INVESTORACNO = GetString(Request.INVESTORACNO);
                Item.FOrderItem.SUBACT = GetString(Request.SUBACT);
                Item.FOrderItem.PRODUCTKIND = GetString(Request.PRODUCTKIND);
                Item.FOrderItem.SECURITYEXCHANGE = GetString(Request.SECURITYEXCHANGE);
                Item.FOrderItem.SECURITYTYPE1 = GetString(Request.SECURITYTYPE1);
                Item.FOrderItem.SYMBOL1 = GetString(Request.SYMBOL1);
                Item.FOrderItem.MATURITYMONTHYEAR1 = GetString(Request.MATURITYMONTHYEAR1);
                Item.FOrderItem.PUTORCALL1 = GetString(Request.PUTORCALL1);
                Item.FOrderItem.STRIKEPRICE1 = GetDecimal(Request.STRIKEPRICE1);
                Item.FOrderItem.SIDE1 = GetString(Request.SIDE1);
                Item.FOrderItem.PRICE1 = 0;
                Item.FOrderItem.SECURITYTYPE2 = GetString(Request.SECURITYTYPE2);
                Item.FOrderItem.SYMBOL2 = GetString(Request.SYMBOL2);
                Item.FOrderItem.MATURITYMONTHYEAR2 = GetString(Request.MATURITYMONTHYEAR2);
                Item.FOrderItem.PUTORCALL2 = GetString(Request.PUTORCALL2);
                Item.FOrderItem.STRIKEPRICE2 = GetDecimal(Request.STRIKEPRICE2);
                Item.FOrderItem.SIDE2 = GetString(Request.SIDE2);
                Item.FOrderItem.PRICE2 = 0;
                Item.FOrderItem.BS = GetString(Request.BS);
                Item.FOrderItem.ORDERTYPE = GetString(Request.ORDERTYPE);
                Item.FOrderItem.PRICE = GetDecimal(Request.PRICE);
                Item.FOrderItem.STOPPRICE = GetDecimal(Request.STOPPRICE);
                Item.FOrderItem.ORDERQTY = GetInt(Request.ORDERQTY);
                Item.FOrderItem.TIMEINFORCE = GetString(Request.TIMEINFORCE);
                Item.FOrderItem.OPENCLOSE = GetString(Request.OPENCLOSE);
                Item.FOrderItem.EXPIREDATE = GetString(Request.EXPIREDATE);
                Item.FOrderItem.LASTSHARES = 0;
                Item.FOrderItem.LASTPX = 0;
                Item.FOrderItem.LEAVESQTY = GetInt(Request.ORDERQTY);
                Item.FOrderItem.CUMQTY = 0;
                Item.FOrderItem.AVGPX = 0;
                if (EXECTYPE == "0")
                {
                    Item.FOrderItem.ORICLORDID = CLORDID;
                    Item.FOrderItem.CLORDID = CLORDID;
                }
                else
                {
                    Item.FOrderItem.ORICLORDID = GetString(Request.CLORDID);
                    Item.FOrderItem.CLORDID = CLORDID;
                }


                Item.FOrderItem.DTRADE = GetString(Request.DTRADE);
                Item.FOrderItem.SOURCECODE = GetString(Request.SOURCECODE);
                Item.FOrderItem.STATUSCODE = STATUSCODE;
                Item.FOrderItem.ORDERSTATUS = ORDERSTATUS;
                Item.FOrderItem.EXECID = "";
                Item.FOrderItem.EXECREFID = "";
                Item.FOrderItem.ORDERID = ORDERID;
                Item.FOrderItem.TARGETID = TARGETID;
                Item.FOrderItem.ACCOUNT = ACCOUNT;

                Item.FOrderItem.IP = GetString(Request.IP);
                Item.FOrderItem.ID = "";
                Item.FOrderItem.CADATA = CADATA;
                Item.FOrderItem.DATA = DATA;

            }
            catch (Exception ex)
            {
            }

        }





        public static byte[] ToReply(FOrderItem Fitem, string AD)
        {
            SockClientParserFunction.Reply Reply = new SockClientParserFunction.Reply();
            Reply.REPLYSEQ = GetByte("", 10);
            Reply.TRADEDATE = GetByte(DateTime.Now.ToString("yyyyMMdd"), 8);
            Reply.ORDERTIME = GetByte(DateTime.Now.ToString("HHmmssfff"), 9);
            Reply.EXECTYPE = GetByte(Fitem.EXECTYPE, 1);
            Reply.BROKERID = GetByte(Fitem.BROKERID, 7);
            Reply.ORDERNO = GetByte(Fitem.ORDERNO, 7);
            Reply.INVESTORACNO = GetByte(Fitem.INVESTORACNO, 7);
            Reply.SUBACT = GetByte(Fitem.SUBACT, 7);
            Reply.PRODUCTKIND = GetByte(Fitem.PRODUCTKIND, 7);
            Reply.SECURITYEXCHANGE = GetByte(Fitem.SECURITYEXCHANGE, 10);
            Reply.SECURITYTYPE1 = GetByte(Fitem.SECURITYTYPE1, 5);
            Reply.SYMBOL1 = GetByte(Fitem.SYMBOL1, 10);
            Reply.MATURITYMONTHYEAR1 = GetByte(Fitem.MATURITYMONTHYEAR1, 6);
            Reply.PUTORCALL1 = GetByte(Fitem.PUTORCALL1, 1);
            Reply.STRIKEPRICE1 = GetByte(Fitem.STRIKEPRICE1, 22);
            Reply.SIDE1 = GetByte(Fitem.SIDE1, 1);
            Reply.PRICE1 = GetByte(Fitem.PRICE1, 22);
            Reply.SECURITYTYPE2 = GetByte(Fitem.SECURITYTYPE2, 5);
            Reply.SYMBOL2 = GetByte(Fitem.SYMBOL2, 10);
            Reply.MATURITYMONTHYEAR2 = GetByte(Fitem.MATURITYMONTHYEAR2, 6);
            Reply.PUTORCALL2 = GetByte(Fitem.PUTORCALL2, 1);
            Reply.STRIKEPRICE2 = GetByte(Fitem.STRIKEPRICE2, 22);
            Reply.SIDE2 = GetByte(Fitem.SIDE2, 1);
            Reply.PRICE2 = GetByte(Fitem.PRICE2, 22);
            Reply.BS = GetByte(Fitem.BS, 1);
            Reply.ORDERTYPE = GetByte(Fitem.ORDERTYPE, 1);
            Reply.PRICE = GetByte(Fitem.PRICE, 22);
            Reply.STOPPRICE = GetByte(Fitem.STOPPRICE, 22);

            Reply.TIMEINFORCE = GetByte(Fitem.TIMEINFORCE, 1);
            Reply.OPENCLOSE = GetByte(Fitem.OPENCLOSE, 1);
            Reply.EXPIREDATE = GetByte(Fitem.EXPIREDATE, 8);
            Reply.LASTSHARES = GetByte("0", 5);
            Reply.LASTPX = GetByte("0", 22);
            Reply.LEAVESQTY = GetByte("0", 5);
            Reply.CUMQTY = GetByte("0", 5);
            Reply.AVGPX = GetByte("0", 22);
            Reply.CLORDID = GetByte(Fitem.ORICLORDID, 25);
            Reply.SOURCECODE = GetByte(Fitem.SOURCECODE, 1);

            if (Fitem.EXECTYPE == "0")
            {
                Reply.ORDERQTY = GetByte(Fitem.ORDERQTY, 5);
                Reply.STATUSCODE = GetByte(FReplyIntegration.ORDERED_CODE, 7);
                Reply.ORDERSTATUS = GetByte(FReplyIntegration.ORDERED, 70);
                Reply.LEAVESQTY = GetByte(Fitem.ORDERQTY, 5);
            }
            else if (Fitem.EXECTYPE == "5")
            {
                Reply.ORDERQTY = GetByte(Fitem.ORDERQTY, 5);
                Reply.STATUSCODE = GetByte(FReplyIntegration.REPLACEED_CODE, 7);
                Reply.ORDERSTATUS = GetByte(FReplyIntegration.REPLACEED, 70);
                Reply.LEAVESQTY = GetByte(Fitem.ORDERQTY, 5);
            }
            else if (Fitem.EXECTYPE == "4")
            {
                Reply.ORDERQTY = GetByte(Fitem.ORDERQTY, 5);
                Reply.STATUSCODE = GetByte(FReplyIntegration.ORDEREDCANCEL_CODE, 7);
                Reply.ORDERSTATUS = GetByte(FReplyIntegration.ORDEREDCANCEL, 70);
                Reply.LEAVESQTY = GetByte(0, 5);
            }
            Reply.EXECID = GetByte("", 75);
            Reply.EXECTRANSTYPE = GetByte("0", 1);
            Reply.EXECREFID = GetByte("", 75);
            Reply.ORDERID = GetByte(Fitem.ORDERID, 10);
            Reply.TARGETID = GetByte(Fitem.TARGETID, 10);
            Reply.ACCOUNT = GetByte(Fitem.ACCOUNT, 20);


            return SockClientParserFunction.StructureToByteArray(Reply);
        }


        private static byte[] GetByte(string b, int width)
        {
            try
            {
                return ASCIIEncoding.Default.GetBytes(b.PadRight(width, ' '));
            }
            catch (Exception ex)
            {

            }
            return null;
        }
        private static byte[] GetByte(Decimal b, int width)
        {
            try
            {
                return ASCIIEncoding.Default.GetBytes(b.ToString().PadLeft(width, ' '));
            }
            catch (Exception ex)
            {

            }
            return null;
        }
        private static string GetString(byte[] b)
        {
            try
            {
                return ASCIIEncoding.Default.GetString(b).Trim();
            }
            catch (Exception ex)
            {

            }
            return "";
        }
        private static decimal GetDecimal(byte[] b)
        {
            try
            {
                return Decimal.Parse(ASCIIEncoding.Default.GetString(b).Trim());
            }
            catch (Exception ex)
            {

            }
            return 0;
        }
        private static int GetInt(byte[] b)
        {
            try
            {
                return int.Parse(ASCIIEncoding.Default.GetString(b).Trim());
            }
            catch (Exception ex)
            {

            }
            return 0;
        }
    }
}
