﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using com.ddsc.BI.F;
namespace com.ddsc.TradeSocketServer
{
    public class VIPProvider
    {
        public static void OrderTo(ref AccountItem Item
                              , ref SockClientParserFunction.Order Request
                                , string EXECTYPE
                                , string ORDERNO
                                , string CLORDID
                                , string ORDERID
                                , string STATUSCODE
                                , string ORDERSTATUS
                                , string TARGETID
                                , string ACCOUNT
                                , string DATA
                                , string CADATA)
        {
            byte[] buffer = null;
            try
            {

                Item.OrderKind = OrderKind.TRADE;


                Item.FOrderItem.TRADEDATE = GetString(Request.TRADEDATE);
                Item.FOrderItem.ORDERTIME = GetString(Request.ORDERTIME);
                Item.FOrderItem.EXECTYPE = GetString(Request.EXECTYPE);
                Item.FOrderItem.BROKERID = GetString(Request.BROKERID);
                Item.FOrderItem.ORDERNO = ORDERNO;
                Item.FOrderItem.INVESTORACNO = GetString(Request.INVESTORACNO);
                Item.FOrderItem.SUBACT = GetString(Request.SUBACT);
                Item.FOrderItem.PRODUCTKIND = GetString(Request.PRODUCTKIND);
                Item.FOrderItem.SECURITYEXCHANGE = GetString(Request.SECURITYEXCHANGE);
                Item.FOrderItem.SECURITYTYPE1 = GetString(Request.SECURITYTYPE1);
                Item.FOrderItem.SYMBOL1 = GetString(Request.SYMBOL1);
                Item.FOrderItem.MATURITYMONTHYEAR1 = GetString(Request.MATURITYMONTHYEAR1);
                Item.FOrderItem.PUTORCALL1 = GetString(Request.PUTORCALL1);
                Item.FOrderItem.STRIKEPRICE1 = GetDecimal(Request.STRIKEPRICE1);
                Item.FOrderItem.SIDE1 = GetString(Request.SIDE1);
                Item.FOrderItem.PRICE1 = 0;
                Item.FOrderItem.SECURITYTYPE2 = GetString(Request.SECURITYTYPE2);
                Item.FOrderItem.SYMBOL2 = GetString(Request.SYMBOL2);
                Item.FOrderItem.MATURITYMONTHYEAR2 = GetString(Request.MATURITYMONTHYEAR2);
                Item.FOrderItem.PUTORCALL2 = GetString(Request.PUTORCALL2);
                Item.FOrderItem.STRIKEPRICE2 = GetDecimal(Request.STRIKEPRICE2);
                Item.FOrderItem.SIDE2 = GetString(Request.SIDE2);
                Item.FOrderItem.PRICE2 = 0;
                Item.FOrderItem.BS = GetString(Request.BS);
                Item.FOrderItem.ORDERTYPE = GetString(Request.ORDERTYPE);
                Item.FOrderItem.PRICE = GetDecimal(Request.PRICE);
                Item.FOrderItem.STOPPRICE = GetDecimal(Request.STOPPRICE);
                Item.FOrderItem.ORDERQTY = GetInt(Request.ORDERQTY);
                Item.FOrderItem.TIMEINFORCE = GetString(Request.TIMEINFORCE);
                Item.FOrderItem.OPENCLOSE = GetString(Request.OPENCLOSE);
                Item.FOrderItem.EXPIREDATE = GetString(Request.EXPIREDATE);
                Item.FOrderItem.LASTSHARES = 0;
                Item.FOrderItem.LASTPX = 0;
                Item.FOrderItem.LEAVESQTY = 0;
                Item.FOrderItem.CUMQTY = 0;
                Item.FOrderItem.AVGPX = 0;
                if (EXECTYPE == "0")
                {
                    Item.FOrderItem.ORICLORDID = CLORDID;
                    Item.FOrderItem.CLORDID = CLORDID;
                }
                else
                {
                    Item.FOrderItem.ORICLORDID = GetString(Request.CLORDID);
                    Item.FOrderItem.CLORDID = CLORDID;
                }


                Item.FOrderItem.DTRADE = GetString(Request.DTRADE);
                Item.FOrderItem.SOURCECODE = GetString(Request.SOURCECODE);
                Item.FOrderItem.STATUSCODE = STATUSCODE;
                Item.FOrderItem.ORDERSTATUS = ORDERSTATUS;
                Item.FOrderItem.EXECID = "";
                Item.FOrderItem.EXECREFID = "";
                Item.FOrderItem.ORDERID = ORDERID;
                Item.FOrderItem.TARGETID = TARGETID;
                Item.FOrderItem.ACCOUNT = ACCOUNT;

                Item.FOrderItem.IP = GetString(Request.IP);
                Item.FOrderItem.ID = "";
                Item.FOrderItem.CADATA = CADATA;
                Item.FOrderItem.DATA = DATA;

            }
            catch (Exception ex)
            {
            }

        }




        public static byte[] ToReply(ExecutionReport obj, FOrderItem Fitem)
        {
            SockClientParserFunction.Reply Reply = new SockClientParserFunction.Reply();
            Reply.REPLYSEQ = GetByte("", 10);
            if (obj.TransactTime.Length < 17)
            {
                Reply.TRADEDATE = GetByte(DateTime.Now.ToString("yyyyMMdd"), 8);
                Reply.ORDERTIME = GetByte(DateTime.Now.ToString("HHmmssfff"), 9);
            }
            else
            {
                Reply.TRADEDATE = GetByte(obj.TransactTime.Substring(0, 8), 8);
                Reply.ORDERTIME = GetByte(obj.TransactTime.Substring(8, 9), 9);
            }
            Reply.EXECTYPE = GetByte(obj.ExecType, 1);
            Reply.BROKERID = GetByte(Fitem.BROKERID, 7);
            Reply.ORDERNO = GetByte(Fitem.ORDERNO, 7);
            Reply.INVESTORACNO = GetByte(Fitem.INVESTORACNO, 7);
            Reply.SUBACT = GetByte(Fitem.SUBACT, 7);
            Reply.PRODUCTKIND = GetByte(Fitem.PRODUCTKIND, 7);
            Reply.SECURITYEXCHANGE = GetByte(Fitem.SECURITYEXCHANGE, 10);
            Reply.SECURITYTYPE1 = GetByte(Fitem.SECURITYTYPE1, 5);
            Reply.SYMBOL1 = GetByte(Fitem.SYMBOL1, 10);
            Reply.MATURITYMONTHYEAR1 = GetByte(Fitem.MATURITYMONTHYEAR1, 6);
            Reply.PUTORCALL1 = GetByte(Fitem.PUTORCALL1, 1);
            Reply.STRIKEPRICE1 = GetByte(Fitem.STRIKEPRICE1, 22);
            Reply.SIDE1 = GetByte(Fitem.SIDE1, 1);
            Reply.PRICE1 = GetByte(obj.Price1, 22);
            Reply.SECURITYTYPE2 = GetByte(Fitem.SECURITYTYPE2, 5);
            Reply.SYMBOL2 = GetByte(Fitem.SYMBOL2, 10);
            Reply.MATURITYMONTHYEAR2 = GetByte(Fitem.MATURITYMONTHYEAR2, 6);
            Reply.PUTORCALL2 = GetByte(Fitem.PUTORCALL2, 1);
            Reply.STRIKEPRICE2 = GetByte(Fitem.STRIKEPRICE2, 22);
            Reply.SIDE2 = GetByte(Fitem.SIDE2, 1);
            Reply.PRICE2 = GetByte(obj.Price2, 22);
            Reply.BS = GetByte(Fitem.BS, 1);
            Reply.ORDERTYPE = GetByte(obj.OrdType, 1);
            Reply.PRICE = GetByte(obj.Price, 22);
            Reply.STOPPRICE = GetByte(obj.StopPx, 22);
            Reply.ORDERQTY = GetByte(obj.OrderQty, 5);
            Reply.TIMEINFORCE = GetByte(obj.TimeInForce, 1);
            Reply.OPENCLOSE = GetByte(obj.Openclose, 1);
            Reply.EXPIREDATE = GetByte(obj.ExpireDate, 8);
            Reply.LASTSHARES = GetByte(obj.LastShares, 5);
            Reply.LASTPX = GetByte(obj.LastPx, 22);
            Reply.LEAVESQTY = GetByte(obj.LeavesQty, 5);
            Reply.CUMQTY = GetByte(obj.CumQty, 5);
            Reply.AVGPX = GetByte(obj.AvgPx, 22);
            Reply.CLORDID = GetByte(obj.OrigClOrdID, 25);
            Reply.SOURCECODE = GetByte(Fitem.SOURCECODE, 1);
            Reply.STATUSCODE = GetByte(Fitem.STATUSCODE, 7);
            Reply.ORDERSTATUS = GetByte(Fitem.ORDERSTATUS, 70);
            Reply.EXECID = GetByte(obj.ExecID, 75);
            Reply.EXECTRANSTYPE = GetByte(obj.ExecTransType, 1);
            Reply.EXECREFID = GetByte(obj.ExecRefID, 75);
            Reply.ORDERID = GetByte(obj.OrderID, 10);
            Reply.TARGETID = GetByte(Fitem.TARGETID, 10);
            Reply.ACCOUNT = GetByte(Fitem.ACCOUNT, 20);

            return SockClientParserFunction.StructureToByteArray(Reply);
        }


        public static byte[] ToReplyMLegToSingleLeg(ExecutionReport obj, FOrderItem Fitem)
        {
            SockClientParserFunction.Reply Reply = new SockClientParserFunction.Reply();
            Reply.REPLYSEQ = GetByte("", 10);
            if (obj.TransactTime.Length < 17)
            {
                Reply.TRADEDATE = GetByte(DateTime.Now.ToString("yyyyMMdd"), 8);
                Reply.ORDERTIME = GetByte(DateTime.Now.ToString("HHmmssfff"), 9);
            }
            else
            {
                Reply.TRADEDATE = GetByte(obj.TransactTime.Substring(0, 8), 8);
                Reply.ORDERTIME = GetByte(obj.TransactTime.Substring(8, 9), 9);
            }
            Reply.EXECTYPE = GetByte(obj.ExecType, 1);
            Reply.BROKERID = GetByte(Fitem.BROKERID, 7);
            Reply.ORDERNO = GetByte(Fitem.ORDERNO, 7);
            Reply.INVESTORACNO = GetByte(Fitem.INVESTORACNO, 7);
            Reply.SUBACT = GetByte(Fitem.SUBACT, 7);
            if (Fitem.SECURITYTYPE1 == "FUT")
                Reply.PRODUCTKIND = GetByte("1", 1);
            else
                Reply.PRODUCTKIND = GetByte("2", 1);
            Reply.SECURITYEXCHANGE = GetByte(Fitem.SECURITYEXCHANGE, 10);
            Reply.SECURITYTYPE1 = GetByte(Fitem.SECURITYTYPE1, 5);
            Reply.SYMBOL1 = GetByte(Fitem.SYMBOL1, 10);
            Reply.MATURITYMONTHYEAR1 = GetByte(obj.MaturityMonthYear1, 6);
            if (Fitem.SECURITYTYPE1 == "OPT")
                Reply.PUTORCALL1 = GetByte(obj.PutOrCall1 == "0" ? "P" : "C", 1);
            else
                Reply.PUTORCALL1 = GetByte("", 1);
            Reply.STRIKEPRICE1 = GetByte(obj.StrikePrice1, 22);
            Reply.SIDE1 = GetByte("", 1);
            Reply.PRICE1 = GetByte(obj.Price1, 22);
            Reply.SECURITYTYPE2 = GetByte("", 5);
            Reply.SYMBOL2 = GetByte("", 10);
            Reply.MATURITYMONTHYEAR2 = GetByte("", 6);
            Reply.PUTORCALL2 = GetByte("", 1);
            Reply.STRIKEPRICE2 = GetByte("0", 22);
            Reply.SIDE2 = GetByte("", 1);
            Reply.PRICE2 = GetByte(obj.Price2, 22);
            Reply.BS = GetByte(obj.Side == "1" ? "B" : "S", 1);
            Reply.ORDERTYPE = GetByte(obj.OrdType, 1);
            Reply.PRICE = GetByte(obj.Price, 22);
            Reply.STOPPRICE = GetByte(obj.StopPx, 22);
            Reply.ORDERQTY = GetByte(obj.OrderQty, 5);
            Reply.TIMEINFORCE = GetByte(obj.TimeInForce, 1);
            Reply.OPENCLOSE = GetByte(obj.Openclose, 1);
            Reply.EXPIREDATE = GetByte(obj.ExpireDate, 8);
            Reply.LASTSHARES = GetByte(obj.LastShares, 5);
            Reply.LASTPX = GetByte(obj.LastPx, 22);
            Reply.LEAVESQTY = GetByte(obj.LeavesQty, 5);
            Reply.CUMQTY = GetByte(obj.CumQty, 5);
            Reply.AVGPX = GetByte(obj.AvgPx, 22);
            Reply.CLORDID = GetByte(obj.OrigClOrdID, 25);
            Reply.SOURCECODE = GetByte(Fitem.SOURCECODE, 1);
            Reply.STATUSCODE = GetByte(Fitem.STATUSCODE, 7);
            Reply.ORDERSTATUS = GetByte(Fitem.ORDERSTATUS, 70);
            Reply.EXECID = GetByte(obj.ExecID, 75);
            Reply.EXECTRANSTYPE = GetByte(obj.ExecTransType, 1);
            Reply.EXECREFID = GetByte(obj.ExecRefID, 75);
            Reply.ORDERID = GetByte(obj.OrderID, 10);
            Reply.TARGETID = GetByte(Fitem.TARGETID, 10);
            Reply.ACCOUNT = GetByte(Fitem.ACCOUNT, 20);

            return SockClientParserFunction.StructureToByteArray(Reply);
        }


        public static byte[] ToReply(FOrderItem Fitem)
        {
            SockClientParserFunction.Reply Reply = new SockClientParserFunction.Reply();
            Reply.REPLYSEQ = GetByte("", 10);
            Reply.TRADEDATE = GetByte(DateTime.Now.ToString("yyyyMMdd"), 8);
            Reply.ORDERTIME = GetByte(DateTime.Now.ToString("HHmmssfff"), 9);
            Reply.EXECTYPE = GetByte(Fitem.EXECTYPE, 1);
            Reply.BROKERID = GetByte(Fitem.BROKERID, 7);
            Reply.ORDERNO = GetByte(Fitem.ORDERNO, 7);
            Reply.INVESTORACNO = GetByte(Fitem.INVESTORACNO, 7);
            Reply.SUBACT = GetByte(Fitem.SUBACT, 7);
            Reply.PRODUCTKIND = GetByte(Fitem.PRODUCTKIND, 7);
            Reply.SECURITYEXCHANGE = GetByte(Fitem.SECURITYEXCHANGE, 10);
            Reply.SECURITYTYPE1 = GetByte(Fitem.SECURITYTYPE1, 5);
            Reply.SYMBOL1 = GetByte(Fitem.SYMBOL1, 10);
            Reply.MATURITYMONTHYEAR1 = GetByte(Fitem.MATURITYMONTHYEAR1, 6);
            Reply.PUTORCALL1 = GetByte(Fitem.PUTORCALL1, 1);
            Reply.STRIKEPRICE1 = GetByte(Fitem.STRIKEPRICE1, 22);
            Reply.SIDE1 = GetByte(Fitem.SIDE1, 1);
            Reply.PRICE1 = GetByte(Fitem.PRICE1, 22);
            Reply.SECURITYTYPE2 = GetByte(Fitem.SECURITYTYPE2, 5);
            Reply.SYMBOL2 = GetByte(Fitem.SYMBOL2, 10);
            Reply.MATURITYMONTHYEAR2 = GetByte(Fitem.MATURITYMONTHYEAR2, 6);
            Reply.PUTORCALL2 = GetByte(Fitem.PUTORCALL2, 1);
            Reply.STRIKEPRICE2 = GetByte(Fitem.STRIKEPRICE2, 22);
            Reply.SIDE2 = GetByte(Fitem.SIDE2, 1);
            Reply.PRICE2 = GetByte(Fitem.PRICE2, 22);
            Reply.BS = GetByte(Fitem.BS, 1);
            Reply.ORDERTYPE = GetByte(Fitem.ORDERTYPE, 1);
            Reply.PRICE = GetByte(Fitem.PRICE, 22);
            Reply.STOPPRICE = GetByte(Fitem.STOPPRICE, 22);
            Reply.ORDERQTY = GetByte(Fitem.ORDERQTY, 5);
            Reply.TIMEINFORCE = GetByte(Fitem.TIMEINFORCE, 1);
            Reply.OPENCLOSE = GetByte(Fitem.OPENCLOSE, 1);
            Reply.EXPIREDATE = GetByte(Fitem.EXPIREDATE, 8);
            Reply.LASTSHARES = GetByte("0", 5);
            Reply.LASTPX = GetByte("0", 22);
            Reply.LEAVESQTY = GetByte("0", 5);
            Reply.CUMQTY = GetByte("0", 5);
            Reply.AVGPX = GetByte("0", 22);
            Reply.CLORDID = GetByte(Fitem.ORICLORDID, 25);
            Reply.SOURCECODE = GetByte(Fitem.SOURCECODE, 1);
            Reply.STATUSCODE = GetByte(Fitem.STATUSCODE, 7);
            Reply.ORDERSTATUS = GetByte(Fitem.ORDERSTATUS, 70);
            Reply.EXECID = GetByte("", 75);
            Reply.EXECTRANSTYPE = GetByte("0", 1);
            Reply.EXECREFID = GetByte("", 75);
            Reply.ORDERID = GetByte(Fitem.ORDERID, 10);
            Reply.TARGETID = GetByte(Fitem.TARGETID, 10);
            Reply.ACCOUNT = GetByte(Fitem.ACCOUNT, 20);

            return SockClientParserFunction.StructureToByteArray(Reply);
        }


        public static byte[] ToOrder(FOrderItem Fitem,string KeepData)
        {
            SockClientParserFunction.Order Order = new SockClientParserFunction.Order();
            Order.TRADEDATE = GetByte(DateTime.Now.ToString("yyyyMMdd"), 8);
            Order.ORDERTIME = GetByte(DateTime.Now.ToString("HHmmssfff"), 9);
            Order.PRODUCTKIND = GetByte(Fitem.PRODUCTKIND, 7);
            Order.EXECTYPE = GetByte(Fitem.EXECTYPE, 1);
            Order.BROKERID = GetByte(Fitem.BROKERID, 7);
            Order.ORDERNO = GetByte(Fitem.ORDERNO, 7);
            Order.INVESTORACNO = GetByte(Fitem.INVESTORACNO, 7);
            Order.SUBACT = GetByte(Fitem.SUBACT, 7);
            Order.SECURITYEXCHANGE = GetByte(Fitem.SECURITYEXCHANGE, 10);
            Order.SECURITYTYPE1 = GetByte(Fitem.SECURITYTYPE1, 5);
            Order.SYMBOL1 = GetByte(Fitem.SYMBOL1, 10);
            Order.MATURITYMONTHYEAR1 = GetByte(Fitem.MATURITYMONTHYEAR1, 6);
            Order.PUTORCALL1 = GetByte(Fitem.PUTORCALL1, 1);
            Order.STRIKEPRICE1 = GetByte(Fitem.STRIKEPRICE1, 22);
            Order.SIDE1 = GetByte(Fitem.SIDE1, 1);
            Order.SECURITYTYPE2 = GetByte(Fitem.SECURITYTYPE2, 5);
            Order.SYMBOL2 = GetByte(Fitem.SYMBOL2, 10);
            Order.MATURITYMONTHYEAR2 = GetByte(Fitem.MATURITYMONTHYEAR2, 6);
            Order.PUTORCALL2 = GetByte(Fitem.PUTORCALL2, 1);
            Order.STRIKEPRICE2 = GetByte(Fitem.STRIKEPRICE2, 22);
            Order.SIDE2 = GetByte(Fitem.SIDE2, 1);
            Order.BS = GetByte(Fitem.BS, 1);
            Order.PRICE = GetByte(Fitem.PRICE, 22);
            Order.STOPPRICE = GetByte(Fitem.STOPPRICE, 22);
            Order.ORDERQTY = GetByte(Fitem.ORDERQTY, 5);
            Order.TIMEINFORCE = GetByte(Fitem.TIMEINFORCE, 1);
            Order.OPENCLOSE = GetByte(Fitem.OPENCLOSE, 1);
            Order.ORDERTYPE = GetByte(Fitem.ORDERTYPE, 1);
            Order.DTRADE = GetByte(Fitem.DTRADE, 1);
            Order.EXPIREDATE =  GetByte(Fitem.EXPIREDATE, 8);

            Order.SOURCECODE = GetByte(Fitem.SOURCECODE, 1);
            Order.CLORDID = GetByte(Fitem.ORICLORDID, 25);

            Order.IP = ASCIIEncoding.ASCII.GetBytes("".PadRight(30, ' '));
            Order.ORDERID = ASCIIEncoding.ASCII.GetBytes("".PadRight(10, ' '));
            Order.ACCOUNT = ASCIIEncoding.ASCII.GetBytes("".PadRight(20, ' '));
            Order.TARGETID = ASCIIEncoding.ASCII.GetBytes("".PadRight(10, ' '));
            byte[] body = SockClientParserFunction.StructureToByteArray(Order);

            byte[] KEEP = Encoding.Default.GetBytes(KeepData);

         

            SockClientParserFunction.DDSCOrder raw = new SockClientParserFunction.DDSCOrder();

            SockClientParserFunction.DDSCHead Head = new SockClientParserFunction.DDSCHead();
            Head.HEAD = new byte[] { SockClientParserFunction.DDSCSocketHead.GeneralTrade };
            Head.MESSAGETIME = ASCIIEncoding.ASCII.GetBytes(DateTime.Now.ToString("HHmmssfff"));
            Head.OLDSEQ = ASCIIEncoding.ASCII.GetBytes("".PadRight(9, ' '));
            Head.NEWSEQ = ASCIIEncoding.ASCII.GetBytes("".PadRight(9, ' '));


            Head.USERID = ASCIIEncoding.ASCII.GetBytes("".PadRight(20, ' '));
            int len = body.Length + KEEP.Length;
            Head.LENGTH = BitConverter.GetBytes(Convert.ToInt16(len));

            if (BitConverter.IsLittleEndian)// 統一指定使用bigendian
                Array.Reverse(Head.LENGTH, 0, 2);
            byte[] head = SockClientParserFunction.StructureToByteArray(Head);

            var list = new List<byte>();

            list.AddRange(head);
            list.AddRange(body);
            list.AddRange(KEEP);
            list.AddRange(new byte[1] { SockClientParserFunction.DDSCSocketHead.End });

            return list.ToArray();
        }


        private static byte[] GetByte(string b, int width)
        {
            try
            {
                return ASCIIEncoding.Default.GetBytes(b.PadRight(width, ' '));
            }
            catch (Exception ex)
            {

            }
            return null;
        }
        private static byte[] GetByte(Decimal b, int width)
        {
            try
            {
                return ASCIIEncoding.Default.GetBytes(b.ToString().PadLeft(width, ' '));
            }
            catch (Exception ex)
            {

            }
            return null;
        }
        private static string GetString(byte[] b)
        {
            try
            {
                return ASCIIEncoding.Default.GetString(b).Trim();
            }
            catch (Exception ex)
            {

            }
            return "";
        }
        private static decimal GetDecimal(byte[] b)
        {
            try
            {
                return Decimal.Parse(ASCIIEncoding.Default.GetString(b).Trim());
            }
            catch (Exception ex)
            {

            }
            return 0;
        }
        private static int GetInt(byte[] b)
        {
            try
            {
                return int.Parse(ASCIIEncoding.Default.GetString(b).Trim());
            }
            catch (Exception ex)
            {

            }
            return 0;
        }
    }
}
