﻿namespace com.ddsc.TradeSocketServer
{
    partial class MainForm
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改這個方法的內容。
        ///
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.btnStart = new System.Windows.Forms.Button();
            this.lblStart = new System.Windows.Forms.Label();
            this.lblCount = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnTest = new System.Windows.Forms.Button();
            this.lblStop = new System.Windows.Forms.Label();
            this.btnStop = new System.Windows.Forms.Button();
            this.dgvStatus = new System.Windows.Forms.DataGridView();
            this.tabControl_Status = new System.Windows.Forms.TabControl();
            this.tabPage_status = new System.Windows.Forms.TabPage();
            this.lstSysMsg = new System.Windows.Forms.ListBox();
            this.tabPage_connections = new System.Windows.Forms.TabPage();
            this.lstConnections = new System.Windows.Forms.ListBox();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStatus)).BeginInit();
            this.tabControl_Status.SuspendLayout();
            this.tabPage_status.SuspendLayout();
            this.tabPage_connections.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Margin = new System.Windows.Forms.Padding(4);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.splitContainer2);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.tabControl_Status);
            this.splitContainer1.Size = new System.Drawing.Size(968, 470);
            this.splitContainer1.SplitterDistance = 291;
            this.splitContainer1.SplitterWidth = 5;
            this.splitContainer1.TabIndex = 0;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.btnStart);
            this.splitContainer2.Panel1.Controls.Add(this.lblStart);
            this.splitContainer2.Panel1.Controls.Add(this.lblCount);
            this.splitContainer2.Panel1.Controls.Add(this.label1);
            this.splitContainer2.Panel1.Controls.Add(this.btnTest);
            this.splitContainer2.Panel1.Controls.Add(this.lblStop);
            this.splitContainer2.Panel1.Controls.Add(this.btnStop);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.dgvStatus);
            this.splitContainer2.Size = new System.Drawing.Size(968, 291);
            this.splitContainer2.SplitterDistance = 116;
            this.splitContainer2.TabIndex = 75;
            // 
            // btnStart
            // 
            this.btnStart.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnStart.Image = ((System.Drawing.Image)(resources.GetObject("btnStart.Image")));
            this.btnStart.Location = new System.Drawing.Point(4, 4);
            this.btnStart.Margin = new System.Windows.Forms.Padding(4);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(48, 45);
            this.btnStart.TabIndex = 36;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // lblStart
            // 
            this.lblStart.Location = new System.Drawing.Point(60, 18);
            this.lblStart.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblStart.Name = "lblStart";
            this.lblStart.Size = new System.Drawing.Size(48, 29);
            this.lblStart.TabIndex = 38;
            this.lblStart.Text = "啟動";
            // 
            // lblCount
            // 
            this.lblCount.AutoSize = true;
            this.lblCount.Location = new System.Drawing.Point(65, 150);
            this.lblCount.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCount.Name = "lblCount";
            this.lblCount.Size = new System.Drawing.Size(0, 15);
            this.lblCount.TabIndex = 73;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(1, 150);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 15);
            this.label1.TabIndex = 72;
            this.label1.Text = "連線數:";
            // 
            // btnTest
            // 
            this.btnTest.Location = new System.Drawing.Point(4, 117);
            this.btnTest.Margin = new System.Windows.Forms.Padding(4);
            this.btnTest.Name = "btnTest";
            this.btnTest.Size = new System.Drawing.Size(48, 29);
            this.btnTest.TabIndex = 74;
            this.btnTest.Text = "Test";
            this.btnTest.UseVisualStyleBackColor = true;
            this.btnTest.Visible = false;
            this.btnTest.Click += new System.EventHandler(this.btnTest_Click);
            // 
            // lblStop
            // 
            this.lblStop.Location = new System.Drawing.Point(60, 78);
            this.lblStop.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblStop.Name = "lblStop";
            this.lblStop.Size = new System.Drawing.Size(48, 29);
            this.lblStop.TabIndex = 39;
            this.lblStop.Text = "中止";
            // 
            // btnStop
            // 
            this.btnStop.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnStop.Image = ((System.Drawing.Image)(resources.GetObject("btnStop.Image")));
            this.btnStop.Location = new System.Drawing.Point(4, 64);
            this.btnStop.Margin = new System.Windows.Forms.Padding(4);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(48, 45);
            this.btnStop.TabIndex = 37;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // dgvStatus
            // 
            this.dgvStatus.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvStatus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvStatus.Location = new System.Drawing.Point(0, 0);
            this.dgvStatus.Name = "dgvStatus";
            this.dgvStatus.RowTemplate.Height = 27;
            this.dgvStatus.Size = new System.Drawing.Size(848, 291);
            this.dgvStatus.TabIndex = 0;
            // 
            // tabControl_Status
            // 
            this.tabControl_Status.Controls.Add(this.tabPage_status);
            this.tabControl_Status.Controls.Add(this.tabPage_connections);
            this.tabControl_Status.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl_Status.Location = new System.Drawing.Point(0, 0);
            this.tabControl_Status.Margin = new System.Windows.Forms.Padding(4);
            this.tabControl_Status.Name = "tabControl_Status";
            this.tabControl_Status.SelectedIndex = 0;
            this.tabControl_Status.Size = new System.Drawing.Size(968, 174);
            this.tabControl_Status.TabIndex = 39;
            this.tabControl_Status.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tabControl_Status_KeyDown);
            // 
            // tabPage_status
            // 
            this.tabPage_status.Controls.Add(this.lstSysMsg);
            this.tabPage_status.Location = new System.Drawing.Point(4, 25);
            this.tabPage_status.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage_status.Name = "tabPage_status";
            this.tabPage_status.Size = new System.Drawing.Size(960, 145);
            this.tabPage_status.TabIndex = 2;
            this.tabPage_status.Text = "系統訊息";
            this.tabPage_status.UseVisualStyleBackColor = true;
            // 
            // lstSysMsg
            // 
            this.lstSysMsg.BackColor = System.Drawing.Color.Pink;
            this.lstSysMsg.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lstSysMsg.ItemHeight = 15;
            this.lstSysMsg.Location = new System.Drawing.Point(0, 0);
            this.lstSysMsg.Margin = new System.Windows.Forms.Padding(4);
            this.lstSysMsg.Name = "lstSysMsg";
            this.lstSysMsg.Size = new System.Drawing.Size(960, 145);
            this.lstSysMsg.TabIndex = 2;
            this.lstSysMsg.TabStop = false;
            // 
            // tabPage_connections
            // 
            this.tabPage_connections.Controls.Add(this.lstConnections);
            this.tabPage_connections.Location = new System.Drawing.Point(4, 25);
            this.tabPage_connections.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage_connections.Name = "tabPage_connections";
            this.tabPage_connections.Size = new System.Drawing.Size(960, 145);
            this.tabPage_connections.TabIndex = 1;
            this.tabPage_connections.Text = "已連線資訊";
            this.tabPage_connections.UseVisualStyleBackColor = true;
            // 
            // lstConnections
            // 
            this.lstConnections.BackColor = System.Drawing.Color.LightSteelBlue;
            this.lstConnections.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lstConnections.ItemHeight = 15;
            this.lstConnections.Location = new System.Drawing.Point(0, 0);
            this.lstConnections.Margin = new System.Windows.Forms.Padding(4);
            this.lstConnections.Name = "lstConnections";
            this.lstConnections.Size = new System.Drawing.Size(960, 145);
            this.lstConnections.TabIndex = 1;
            this.lstConnections.TabStop = false;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(968, 470);
            this.Controls.Add(this.splitContainer1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MinimumSize = new System.Drawing.Size(986, 517);
            this.Name = "MainForm";
            this.Text = "FTDGW";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
       
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel1.PerformLayout();
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvStatus)).EndInit();
            this.tabControl_Status.ResumeLayout(false);
            this.tabPage_status.ResumeLayout(false);
            this.tabPage_connections.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Label lblStart;
        private System.Windows.Forms.Label lblStop;
        private System.Windows.Forms.TabControl tabControl_Status;
        private System.Windows.Forms.TabPage tabPage_status;
        internal System.Windows.Forms.ListBox lstSysMsg;
        private System.Windows.Forms.TabPage tabPage_connections;
        internal System.Windows.Forms.ListBox lstConnections;
        private System.Windows.Forms.Label lblCount;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnTest;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.DataGridView dgvStatus;
    }
}

