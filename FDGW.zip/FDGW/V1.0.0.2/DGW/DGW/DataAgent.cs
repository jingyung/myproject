﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Threading;
using System.Data;
using MySql.Data.MySqlClient;
using com.ddsc.nets.server;

using com.ddsc.tool;
using com.ddsc.core;
using System.Xml;
namespace com.ddsc.TradeSocketServer
{
    public class Targetitem
    {
        public Targetitem(string pTargetID, string pAccount, string pSystem)
        { TargetID = pTargetID; Account = pAccount; System = pSystem; }
        public string TargetID = "";
        public string Account = "";
        public string System = "";
    }


    public class DataAgent
    {
        com.ddsc.net.TcpClient _TcpClient;

        private System.Threading.Thread _SpeedyT = null;
        public SpeedyAPI.OrderConnection SpeedyConn = null;

        readonly object _locker = new object();
        Queue<FIXObject> _itemQ = new Queue<FIXObject>();
        private bool _connect = false;
        private bool _SpeedyEnable = true;
        public bool Connect
        {


            get { lock (_locker) { return _connect; } }
            set { lock (_locker) { _connect = value; } }
        }

        Dictionary<string, Targetitem> _TargetData;

        public Dictionary<string, Targetitem> TargetData
        {
            get { lock (_TargetData)return _TargetData; }
            set { lock (_TargetData)_TargetData = value; }
        }
        Dictionary<string, string> _TargetServer;

        public Dictionary<string, string> TargetServer
        {
            get { lock (_TargetServer) return _TargetServer; }

        }
        Dictionary<string, string> _TargetSystem;

        private QueuePoolByLock<FIXObject> _FIXServerQ;

        public QueuePoolByLock<FIXObject> FIXServerQ
        {
            get { return _FIXServerQ; }
            set { _FIXServerQ = value; }
        }
        static SettingProvider _SettingProvider;

        internal static SettingProvider SettingProvider
        {
            get { return _SettingProvider; }
            set { _SettingProvider = value; }
        }
        private static Dictionary _DEFAULTProvider;

        public static Dictionary DEFAULTProvider
        {
            get { return _DEFAULTProvider; }
            set { _DEFAULTProvider = value; }
        }
        private System.Windows.Forms.Timer _TransferTimer;
        bool _TransferData = false;

        public bool TransferData
        {
            get { return _TransferData; }
            set { _TransferData = value; }
        }

        /// <summary>
        /// 國內交易日Flag 
        /// </summary>
        private bool _WorkDayForDomestic = false;

        public bool WorkDayForDomestic
        {
            get { return _WorkDayForDomestic; }
            set { _WorkDayForDomestic = value; }
        }
        /// <summary>
        /// 國外交易日Flag
        /// </summary>
        private bool _WorkDayForForeign = false;

        public bool WorkDayForForeign
        {
            get { return _WorkDayForForeign; }
            set { _WorkDayForForeign = value; }
        }

        private string _NextWorkDay = "";

        public string NextWorkDay
        {
            get { return _NextWorkDay; }
            set { _NextWorkDay = value; }
        }

        private string _WorkDay = "";

        public string WorkDay
        {
            get { return _WorkDay; }
            set { _WorkDay = value; }
        }

        private Dictionary<string, int> _DecimalPlace = new Dictionary<string, int>();

        public Dictionary<string, int> DecimalPlace
        {
            get { lock (_DecimalPlace) return _DecimalPlace; }
            set { lock (_DecimalPlace) _DecimalPlace = value; }
        }

        DDSCFIX4TT.Client _Client;





        private QueuePoolByLock<string> _OrderDataQWriterQ;

        public QueuePoolByLock<string> OrderDataQWriterQ
        {
            get { return _OrderDataQWriterQ; }
            set { _OrderDataQWriterQ = value; }
        }
        private QueuePoolByLock<string> _RepleDataQReadersQ;


        private QueuePoolByLock<string> _AccountOrderDataQWriterQ;

        public QueuePoolByLock<string> AccountOrderDataQWriterQ
        {
            get { return _AccountOrderDataQWriterQ; }
            set { _AccountOrderDataQWriterQ = value; }
        }
        private QueuePoolByLock<string> _AccountRepleDataQReadersQ;


        private QueuePoolByLock<byte[]> _DBServerQ;



        private QueuePoolByLock<byte[]> _SyncQ;


        public static LogManager _LM;
        private AccountCore _AccountCore;

        public AccountCore AccountCore
        {
            get { return _AccountCore; }
            set { _AccountCore = value; }
        }

        private DisplayItem _DisplayItem;


        private DBTcpClient _DBClient;



        private SAEAServer _SAEAServer;

        private TradeStringHandler _t;


        public TradeStringHandler T
        {
            get { return _t; }
            set { _t = value; }
        }

        SeqDataProvider _TransferDate = null;


        public static string BASEPATH = "";
        public static string CURRENTPATH = "";

        int begin = 0700;
        int end = 0600; //跨日 0700~0600
        public DataAgent(DisplayItem DisplayItem)
        {
            _DisplayItem = DisplayItem;

        }
        public void Dispose()
        {


        }
        ~DataAgent()
        {
            Dispose();
        }

        void _TransferTimer_Tick(object sender, EventArgs e)
        {

        }
        string Execpath = AppDomain.CurrentDomain.BaseDirectory.ToString().TrimEnd();
        public void init()
        {

            _LM = new LogManager();
            DataAgent.BASEPATH = AppDomain.CurrentDomain.BaseDirectory.ToString().TrimEnd();
            CURRENTPATH = "current";
            _SettingProvider = new SettingProvider(Execpath + "FTDGW.cfg");
            _DEFAULTProvider = _SettingProvider.Get("DEFAULT").First.Value;
            begin = _DEFAULTProvider.GetInt("ClearDataTime");
            _TransferDate = new SeqDataProvider("TransferDate", Execpath + "log\\current");

            string data = _TransferDate.Get(DateTime.Now.ToString("yyyyMMdd"));
            _TransferDate.close(); //為了要COPY所以要先CLOSE
            if (data != "Y")
            {
                int now = int.Parse(DateTime.Now.ToString("HHmm"));

                if (now > begin)//跨日
                {
                    string ParentDirectory = DateTime.Now.AddDays(-1).ToString("yyyyMMdd");
                    string path = "";
                    string descpath = "";
                    if (DataAgent.BASEPATH.Trim().Length == 0)
                    {
                        descpath = AppDomain.CurrentDomain.BaseDirectory.ToString().TrimEnd() + "Log\\" + ParentDirectory;
                        path = AppDomain.CurrentDomain.BaseDirectory.ToString().TrimEnd() + "Log\\" + CURRENTPATH;
                    }
                    else
                    {
                        descpath = DataAgent.BASEPATH.Trim() + "Log\\" + ParentDirectory;
                        path = DataAgent.BASEPATH.TrimEnd() + "Log\\" + CURRENTPATH;
                    }
                    if (!System.IO.Directory.Exists(descpath))//如果昨日目錄(昨日開盤日期)不存在，把昨天到今天的CURRENT名稱改成昨日日期
                    {
                        if (System.IO.Directory.Exists(path))
                        {
                            System.IO.Directory.Move(path, descpath);
                        }
                    }
                    _TransferDate = new SeqDataProvider("TransferDate", Execpath + "log\\current");
                    _TransferDate.Add(DateTime.Now.ToString("yyyyMMdd"), "Y");
                    _TransferDate.close();
                    _LM.AddFileWriter("DataAgentLog", new FileWriter(DataAgent.BASEPATH, CURRENTPATH, "DataAgentLog", ""));
                    ClearData();

                }

            }




            //判斷是否有開過檔有則不開
            if (!_LM.checkFileWriter("DataAgentLog"))
                _LM.AddFileWriter("DataAgentLog", new FileWriter(DataAgent.BASEPATH, CURRENTPATH, "DataAgentLog", ""));




            _TransferTimer = new System.Windows.Forms.Timer();

            _TransferTimer.Interval = 1000;
            _TransferTimer.Tick += new EventHandler(_TransferTimer_Tick);
        }




        public static void MsgAlert(string msg)
        {
            try
            {

                //   Concord.SDK.Logging.ConcordLogger.Alert("9999", msg);

            }
            catch (Exception ex)
            {
            }
        }


        public DateTime GetDate(string time)
        {


            DateTime date = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day
                , int.Parse(time.PadRight(8, '0').Substring(0, 2))
                , int.Parse(time.PadRight(8, '0').Substring(2, 2))
                , int.Parse(time.PadRight(8, '0').Substring(4, 2)));
            return date;
        }


        public void Start()
        {
            try
            {

                init();
                _TargetSystem = new Dictionary<string, string>();
                _TargetData = new Dictionary<string, Targetitem>();
                _TargetServer = new Dictionary<string, string>();
                _TransferTimer.Start();
                getTargetData();
                _FIXServerQ = new QueuePoolByLock<FIXObject>();
                _FIXServerQ.ParameterExcute += new QueuePoolByLock<FIXObject>.ParameterHandler(_FIXServerQ_ParameterExcute);

                //  getWorkDay();

                _AccountCore = new AccountCore();



                _DBServerQ = new QueuePoolByLock<byte[]>(1);
                _DBServerQ.ParameterExcute += new QueuePoolByLock<byte[]>.ParameterHandler(_DBServerQ_ParameterExcute);

                _LM.AddFileWriter("DBClientLogSend", new FileWriter(DataAgent.BASEPATH, DataAgent.CURRENTPATH, "DBClientLogSend", ""));
                _LM.AddFileWriter("DBClientLogRcv", new FileWriter(DataAgent.BASEPATH, DataAgent.CURRENTPATH, "DBClientLogRcv", ""));
                _LM.AddFileWriter("DBClientLogError", new FileWriter(DataAgent.BASEPATH, DataAgent.CURRENTPATH, "DBClientLogError", ""));

                _LM.AddFileWriter("CALOG", new FileWriter(DataAgent.BASEPATH, CURRENTPATH, "CALOG", ""));
                _LM.AddFileWriter("OrderTrigger", new FileWriter(DataAgent.BASEPATH, CURRENTPATH, "OrderTrigger", ""));

                _LM.AddFileWriter("Speedy", new FileWriter(DataAgent.BASEPATH, CURRENTPATH, "Speedy", ""));
                _LM.AddFileWriter("SpeedyWriter", new FileWriter(DataAgent.BASEPATH, CURRENTPATH, "SpeedyWriter", ""));
                _LM.AddFileWriter("SpeedyReader", new FileWriter(DataAgent.BASEPATH, CURRENTPATH, "SpeedyReader", ""));
                _t = new TradeStringHandler(_AccountCore);
                Dictionary DBSERVER = _SettingProvider.Get("DBSERVER").Last.Value;
                _DisplayItem.AddConn("DBClient"
                                        , DBSERVER.GetString("DBClientIP")
                                        , DBSERVER.GetString("DBClientPort"));
                _DBClient = new DBTcpClient();

                _DBClient.connected += new DBTcpClient.connectedHandler(_DBClient_connected);
                _DBClient.Disconnected += new DBTcpClient.disconnectedHandler(_DBClient_Disconnected);
                _DBClient.Error += new DBTcpClient.ErrorHandler(_DBClient_Error);
                _DBClient.Received += new DBTcpClient.ReceivedHandler(_DBClient_Received);
                _DBClient.Sended += new DBTcpClient.SendedHandler(_DBClient_Sended);

                _DBClient.Connect(DBSERVER.GetString("DBClientIP")
                                        , DBSERVER.GetInt("DBClientPort"));


                bool TTFlag = false;
                LinkedList<Dictionary> FixSessions = _SettingProvider.Get("FIXSESSION");
                if (FixSessions.Count > 0)
                {
                    foreach (Dictionary obj in FixSessions)
                    {
                        string system = obj.GetString("System").ToString().Trim();
                        string name = obj.GetString("TargetCompID").ToString().Trim();
                        _LM.AddFileWriter(name, new FileWriter(DataAgent.BASEPATH, CURRENTPATH, name, ""));
                        _DisplayItem.AddConn(name, obj.GetString("SocketConnectHost").ToString().Trim(), obj.GetString("SocketConnectPort").ToString().Trim());

                        if (system == "TT") TTFlag = true;
                    }
                }
                try
                {
                    _DisplayItem.AddConn("SAEAServer"
                                         , _DEFAULTProvider.GetString("SAEAServerIP")
                                         , _DEFAULTProvider.GetString("SAEAServerPort"));
                    _SAEAServer = new SAEAServer(4096, 4096, 1000);

                    _SAEAServer.backlog = 1000;
                    _SAEAServer.Actived += new ActivedEventHandler(_SAEAServer_Actived);
                    _SAEAServer.Disconnected += new DisconnectedEventHandler(_SAEAServer_Disconnected);
                    _SAEAServer.Connected += new ConnectedEventHandler(_SAEAServer_Connected);
                    _SAEAServer.Received += new ReceiveEventHandler(_SAEAServer_Received);
                    _SAEAServer.Error += new SAEAServer.ErrorHandler(_SAEAServer_Error);

                    _SAEAServer.Listen(_DEFAULTProvider.GetString("SAEAServerIP")
                                     , _DEFAULTProvider.GetInt("SAEAServerPort"));
                    _DisplayItem.displayChangeCount(_SAEAServer.NumberOfConnectedSockets);

                }
                catch (Exception ex)
                {
                    _LM.WriteLog("DataAgentLog", "SAEAServer:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
                    MsgAlert("SAEAServer:" + ex.Message);
                }
                _t.DataEncode = true;
                _t.DBClient = _DBClient;
                _t.SAEA = _SAEAServer;

                _t.DBServerQ = _DBServerQ;
                _t.OrderDataQWriterQ = _OrderDataQWriterQ;
                _t.RepleDataQReadersQ = _RepleDataQReadersQ;
                _t.DataAgent = this;

                _DBServerQ.Go();

                _FIXServerQ.Go();
                _t.load();
                if (TTFlag)
                {
                    _Client = new DDSCFIX4TT.Client();
                    _Client.Logon += new DDSCFIX4TT.Client.LogonEventHandler(_Client_Logon);
                    _Client.Logout += new DDSCFIX4TT.Client.LogoutEventHandler(_Client_Logout);
                    _Client.ExecutionReport += new DDSCFIX4TT.Client.ExecutionReportEventHandler(_Client_ExecutionReport);
                    _Client.Start();
                }
                _SpeedyEnable = true;
                _SpeedyT = new Thread(new ThreadStart(IniSpeedy));
                _SpeedyT.IsBackground = true;
                _SpeedyT.Start();





                _LM.AddFileWriter("SyncClientSend", new FileWriter(DataAgent.BASEPATH, DataAgent.CURRENTPATH, "SyncClientSend", ""));
                _LM.AddFileWriter("SyncClientRcv", new FileWriter(DataAgent.BASEPATH, DataAgent.CURRENTPATH, "SyncClientRcv", ""));
                _LM.AddFileWriter("SyncClientError", new FileWriter(DataAgent.BASEPATH, DataAgent.CURRENTPATH, "SyncClientError", ""));

                if (_SettingProvider.Get("Sync").Count > 0)
                {

                    Dictionary Sync = _SettingProvider.Get("Sync").Last.Value;

                    _DisplayItem.AddConn("SyncClient"
                                            , Sync.GetString("SyncIp")
                                            , Sync.GetString("SyncPort"));
                    _TcpClient = new net.TcpClient();

                    _TcpClient.connected += new net.TcpClient.connectedHandler(_TcpClient_connected);
                    _TcpClient.Disconnected += new net.TcpClient.disconnectedHandler(_TcpClient_Disconnected);
                    _TcpClient.Error += new net.TcpClient.ErrorHandler(_TcpClient_Error);
                    _TcpClient.Received += new net.TcpClient.ReceivedHandler(_TcpClient_Received);
                    _TcpClient.Sended += new net.TcpClient.SendedHandler(_TcpClient_Sended);
                    _TcpClient.Connect(Sync.GetString("SyncIp"), Sync.GetInt("SyncPort"));

                    _SyncQ = new QueuePoolByLock<byte[]>(1);
                    _SyncQ.ParameterExcute += new QueuePoolByLock<byte[]>.ParameterHandler(_SyncQ_ParameterExcute);
                    _t.SyncQ = _SyncQ;
                    _SyncQ.Go();
                }

            }
            catch (Exception ex)
            {
                _LM.WriteLog("DataAgentLog", "DataAgent:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }

        }

        void _SyncQ_ParameterExcute(byte[] ff)
        {
            try
            {
                if (_TcpClient.Socket.Connected)
                {
                    _LM.WriteLog("SyncClientSend", ff);
                    _TcpClient.Send(_t.DataEncode ? com.ddsc.BI.F.SockClientParserFunction.EncodeData(ff) : ff);
                }
                else
                {
                    _SyncQ.PutData2Queue(ff);
                }

            }
            catch (Exception ex)
            {
                _LM.WriteLog("DataAgentLog", "SyncQ:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }

        byte[] _TcpClient_Sended(net.TcpClient s, byte[] buffer)
        {


            return null;
        }

        void _TcpClient_Received(net.TcpClient s, byte[] buffer)
        {
            try
            {

                _LM.WriteLog("SyncClientRcv", buffer);

            }
            catch (Exception ex)
            {

            }
        }

        void _TcpClient_Error(net.TcpClient s, string msg)
        {
            _DisplayItem.ChangeConn("SyncClient", "disconnected", msg);
            _LM.WriteLog("SyncClientError", msg);
            _DisplayItem.displayStatusMsg("SyncClient " + msg);
        }

        void _TcpClient_Disconnected(net.TcpClient Tcp)
        {
            _DisplayItem.ChangeConn("SyncClient", "disconnected", "");
            _LM.WriteLog("SyncClientSend", "Client disconnected");
            _DisplayItem.displayStatusMsg("SyncClient disconnected");
        }

        void _TcpClient_connected(net.TcpClient s)
        {
            _DisplayItem.ChangeConn("SyncClient", "Connected", "");
            _TcpClient.HandShakeBuffer = new byte[51];
            _TcpClient.HandShakeBuffer[0] = 0x13;
            _TcpClient.HandShakeBuffer[48] = 0x00;
            _TcpClient.HandShakeBuffer[49] = 0x00;
            _TcpClient.HandShakeBuffer[50] = 0x0a;

            _LM.WriteLog("SyncClientSend", "Client connected");
            _DisplayItem.displayStatusMsg("SyncClient connected");


        }


        void _FIXServerQ_ParameterExcute(FIXObject obj)
        {
            try
            {
                string TargetCompID = null;
                string System = null;
                lock (_TargetServer)
                {
                    if (_TargetServer.TryGetValue(obj.TargetID, out TargetCompID))
                    {
                    }
                }
                if (_TargetSystem.TryGetValue(obj.TargetID, out System))
                {
                }
                if (System == "TT")
                {
                    #region TT

                    if (TargetCompID != null)
                    {
                        if (obj.Message is NewOrderSingleMessage)
                        {
                            NewOrderSingleMessage order = (NewOrderSingleMessage)obj.Message;
                            _Client.NewOrderSingle(TargetCompID, order.ClOrdID
        , order.ClientID
        , order.Account
        , order.SecurityExchange
        , order.SecurityType1
        , order.Symbol1
        , order.MaturityMonthYear1
        , order.PutOrCall1
        , order.StrikePrice1
        , order.Side1
        , order.SecurityType2
        , order.Symbol2
        , order.MaturityMonthYear2
        , order.PutOrCall2
        , order.StrikePrice2
        , order.Side2
        , order.Side
        , order.OrderQty
        , order.OrderType
        , order.Price
        , order.StopPx
        , order.TimeInForce
        , order.ExpireDate
        , order.PositionEffect);
                        }
                        else if (obj.Message is OrderCancelReplaceMessage)
                        {
                            OrderCancelReplaceMessage order = (OrderCancelReplaceMessage)obj.Message;
                            _Client.OrderCancelReplace(TargetCompID, order.OrderID
            , order.OrigClOrdID
            , order.ClOrdID
            , order.ClientID
            , order.Account
            , order.SecurityExchange
            , order.SecurityType1
            , order.Symbol1
            , order.MaturityMonthYear1
            , order.PutOrCall1
            , order.StrikePrice1
            , order.Side1
            , order.SecurityType2
            , order.Symbol2
            , order.MaturityMonthYear2
            , order.PutOrCall2
            , order.StrikePrice2
            , order.Side2
            , order.Side
            , order.OrderQty
            , order.OrderType
            , order.Price
            , order.StopPx
            , order.TimeInForce
            , order.ExpireDate
            , order.PositionEffect);
                        }
                        else if (obj.Message is OrderCancelMessage)
                        {
                            OrderCancelMessage order = (OrderCancelMessage)obj.Message;
                            _Client.OrderCancel(TargetCompID, order.OrderID
        , order.OrigClOrdID
        , order.ClOrdID
        );
                        }
                    }
                    #endregion
                }
                else if (System == "Speedy")
                {
                    PutData2Queue(obj);
                }

            }
            catch (Exception ex)
            {
                _LM.WriteLog("DataAgentLog", "_FIXServerQ_ParameterExcute" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }


        void _Client_ExecutionReport(string SenderCompID, string TargetCompID, TT.ExecutionReport obj)
        {
            try
            {
                _t.parseTTFixReport("TT", SenderCompID, TargetCompID, obj);
            }
            catch (Exception ex)
            {
            }
        }

        void _Client_Logout(string SenderCompID, string TargetCompID)
        {
            try
            {
                lock (_TargetServer)
                {
                    _TargetServer.Remove(TargetCompID);//[sessionID.TargetCompID] = sessionID;
                }
                _DisplayItem.displayStatusMsg(TargetCompID + " disconnected!");
                _DisplayItem.ChangeConn(TargetCompID, "disconnected", "");

                _LM.WriteLog(TargetCompID, "disconnected");
            }
            catch (Exception ex)
            {
            }
        }

        void _Client_Logon(string SenderCompID, string TargetCompID)
        {
            try
            {
                lock (_TargetServer)
                    _TargetServer[TargetCompID] = TargetCompID;
                _DisplayItem.displayStatusMsg(TargetCompID + " connected!");
                _DisplayItem.ChangeConn(TargetCompID, "connected", "");
                _LM.WriteLog(TargetCompID, "connected");


            }
            catch (Exception ex)
            {
            }
        }


        void _DBServerQ_ParameterExcute(byte[] ff)
        {
            try
            {
                if (_DBClient.Socket.Connected)
                    _DBClient.Send(ff);
                else
                {
                    _DBServerQ.PutData2Queue(ff);
                }

            }
            catch (Exception ex)
            {
                _LM.WriteLog("DataAgentLog", "DBServerQ:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }

        byte[] _DBClient_Sended(DBTcpClient s, byte[] buffer)
        {
            _LM.WriteLog("DBClientLogSend", buffer);

            return buffer;
        }

        byte[] _DBClient_Received(DBTcpClient s)
        {
            try
            {

                byte[] buffer = new byte[50];
                Parts.ReceiveRawBuffer(buffer, 0, buffer.Length, s.Socket);

                _LM.WriteLog("DBClientLogRcv", buffer);
                return buffer;
            }
            catch (Exception ex)
            {
                return null;
            }
            // _DBClientLog.WriteLine(buffer);
        }

        void _DBClient_Error(DBTcpClient s, string msg)
        {
            _DisplayItem.ChangeConn("DBClient", "disconnected", msg);
            _LM.WriteLog("DBClientLogError", msg);
            _DisplayItem.displayStatusMsg("DBClient " + msg);
            //_DBClientLog.WriteLine(msg);


            MsgAlert("DBClient disconnected " + msg);
        }

        void _DBClient_Disconnected(DBTcpClient s)
        {
            _DisplayItem.ChangeConn("DBClient", "disconnected", "");
            _LM.WriteLog("DBClientLogSend", "Client disconnected");
            _DisplayItem.displayStatusMsg("DBClient   Client disconnected");
            // _DBClientLog.WriteLine("Client disconnected");


        }

        void _DBClient_connected(DBTcpClient s)
        {
            _DisplayItem.ChangeConn("DBClient", "Connected", "");

            _LM.WriteLog("DBClientLogSend", "Client connected");
            _DisplayItem.displayStatusMsg("DBClient   Client connected");


        }





        //===================SAEA===================
        void _SAEAServer_Actived()
        {
            if (_SAEAServer.Active)
            {
                _DisplayItem.ChangeConn("SAEAServer", "listen", "");

            }
            else
            {
                _DisplayItem.ChangeConn("SAEAServer", "Error", "");
            }
        }
        void _SAEAServer_Error(string msg)
        {

            _LM.WriteLog("DataAgentLog", "SAEAServer_Error_" + msg);

        }
        void _SAEAServer_Disconnected(DisconnectedEventArgs Saea)
        {
            try
            {
                //UserInfo u = _t.AccountCore.FindUserInfo(Saea.SocketAsyncEventArgs);
                //if (u != null)
                //{
                //    string[] arrPutIPLogoutCmd = new string[1];
                //    arrPutIPLogoutCmd[0] = "UPDATE  [dbo].[TRADEIPLOG]"
                //      + "SET [LOGOUTTIME] ='" + DateTime.Now.ToString("HH:mm:ss") + "',[STATUS] = ''  "
                //    + "WHERE USERID='" + u.UserId + "' and IP='" + Saea.SocketAsyncEventArgs.AcceptSocket.RemoteEndPoint.ToString().Split(':')[0] + "' and PORT='" + Saea.SocketAsyncEventArgs.AcceptSocket.RemoteEndPoint.ToString().Split(':')[1] + "' and  LOGINTIME ='" + u.LoginTime + "'";
                //    _t.SaveDB.PutData2Queue(arrPutIPLogoutCmd);
                //}
                this._AccountCore.RemoveSAEA(Saea.SocketAsyncEventArgs);
                DataToken Token = Saea.SocketAsyncEventArgs.UserToken as DataToken;

                string RemoteEndPoint = Token.RemoteEndPoint;//(((System.Net.IPEndPoint)Saea.Socket.RemoteEndPoint).Address.ToString());
                string RemoteIP = RemoteEndPoint.Split(':')[0];
                this.T._ActiveReplyCore.RemoveSAEA(Saea.SocketAsyncEventArgs);

                _DisplayItem.displayStatusMsg(RemoteIP + " 離開!");
                _DisplayItem.displayRemoveConnections(RemoteEndPoint);
                //_LM.CloseWriteLog("SAEAServerLogRCV" + Saea.Socket.RemoteEndPoint.ToString().Replace(":", ";"));
                //_LM.CloseWriteLog("SAEAServerLogSend" + Saea.Socket.RemoteEndPoint.ToString().Replace(":", ";"));


                _DisplayItem.displayChangeCount(_SAEAServer.NumberOfConnectedSockets);

                _LM.WriteLog("SAEAServerLogRCV" + RemoteIP, RemoteEndPoint + " disconnected");
                _LM.WriteLog("SAEAServerLogSend" + RemoteIP, RemoteEndPoint + " disconnected");

            }

            catch (Exception ex)
            {
                _LM.WriteLog("DataAgentLog", "_SAEAServer_Disconnected" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        void _SAEAServer_Connected(ConnectedEventArgs Saea)
        {
            try
            {


                //_LM.AddFileWriter("SAEAServerLogRCV" + Saea.Socket.RemoteEndPoint.ToString().Replace(":", ";"), new FileWriter(DataAgent.BASEPATH, "SAEAServerLogRCV" + Saea.Socket.RemoteEndPoint.ToString().Replace(":", ";"), @"\connections"));
                //_LM.AddFileWriter("SAEAServerLogSend" + Saea.Socket.RemoteEndPoint.ToString().Replace(":", ";"), new FileWriter(DataAgent.BASEPATH, "SAEAServerLogSend" + Saea.Socket.RemoteEndPoint.ToString().Replace(":", ";"), @"\connections"));
                DataToken Token = Saea.SocketAsyncEventArgs.UserToken as DataToken;

                string RemoteEndPoint = Token.RemoteEndPoint;//(((System.Net.IPEndPoint)Saea.Socket.RemoteEndPoint).Address.ToString());
                string RemoteIP = RemoteEndPoint.Split(':')[0];
                _DisplayItem.displayAddConnections(RemoteEndPoint);
                _DisplayItem.displayChangeCount(_SAEAServer.NumberOfConnectedSockets);
                if (!_LM.checkFileWriter("SAEAServerLogRCV" + RemoteIP))
                {


                    _LM.AddFileWriter("SAEAServerLogRCV" + RemoteIP, new FileWriter(DataAgent.BASEPATH, DataAgent.CURRENTPATH, "SAEAServerLogRCV" + RemoteIP, @"\connections"));
                    _LM.AddFileWriter("SAEAServerLogSend" + RemoteIP, new FileWriter(DataAgent.BASEPATH, DataAgent.CURRENTPATH, "SAEAServerLogSend" + RemoteIP, @"\connections"));
                }
                _DisplayItem.displayStatusMsg(RemoteEndPoint + " 登入!");
                _LM.WriteLog("SAEAServerLogRCV" + RemoteIP, RemoteEndPoint + " connected");
                _LM.WriteLog("SAEAServerLogSend" + RemoteIP, RemoteEndPoint + " connected");


            }
            catch (Exception ex)
            {
                _LM.WriteLog("DataAgentLog", "_SAEAServer_Connected_" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        void _SAEAServer_Received(ReceiveEventArgs Saea)
        {

            try
            {
                _t.ParseDDSCData(Saea.SocketAsyncEventArgs, Saea.ReceiveBytes);
            }
            catch (Exception ex)
            {
                _LM.WriteLog("DataAgentLog", "_SAEAServer_Received:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
            // _SAEAServerLog.WriteLine(Saea.ReceiveBytes);
        }



        public void Stop()
        {
            _DisplayItem.ClearData();
            PutData2Queue(null);
            _SpeedyEnable = false;
            this.Connect = false;
            if (SpeedyConn != null)
            {
                SpeedyConn.OnConnected -= new SpeedyAPI.IOrderConnectionEvents_OnConnectedEventHandler(SpeedyConn_OnConnected);
                SpeedyConn.OnDisconnected -= new SpeedyAPI.IOrderConnectionEvents_OnDisconnectedEventHandler(SpeedyConn_OnDisconnected);

                SpeedyConn.OnLogonReply -= new SpeedyAPI.IOrderConnectionEvents_OnLogonReplyEventHandler(SpeedyConn_OnLogonReply);

                SpeedyConn.OnExecutionReport -= new SpeedyAPI.IOrderConnectionEvents_OnExecutionReportEventHandler(SpeedyConn_OnExecutionReport);

                SpeedyConn.Disconnect();
                SpeedyConn.Destroy();
                SpeedyConn.SetDebugLog("");
                SpeedyConn = null;
            }



            if (_TargetServer != null)
                _TargetServer.Clear();
            if (_TargetData != null)
                _TargetData.Clear();
            if (_TargetSystem != null)
                _TargetSystem.Clear();
            if (_TransferTimer != null)
                _TransferTimer.Stop();
            if (_Client != null)
            {
                _Client.Logon -= new DDSCFIX4TT.Client.LogonEventHandler(_Client_Logon);
                _Client.Logout -= new DDSCFIX4TT.Client.LogoutEventHandler(_Client_Logout);
                _Client.ExecutionReport -= new DDSCFIX4TT.Client.ExecutionReportEventHandler(_Client_ExecutionReport);
                _Client.Stop();
            }

            if (_SAEAServer != null)
            {
                _SAEAServer.Actived -= new ActivedEventHandler(_SAEAServer_Actived);
                _SAEAServer.Disconnected -= new DisconnectedEventHandler(_SAEAServer_Disconnected);
                _SAEAServer.Connected -= new ConnectedEventHandler(_SAEAServer_Connected);
                _SAEAServer.Received -= new ReceiveEventHandler(_SAEAServer_Received);
                _SAEAServer.Error -= new SAEAServer.ErrorHandler(_SAEAServer_Error);
                _SAEAServer.close();
            }

            if (_DBClient != null)
            {

                _DBClient.connected -= new DBTcpClient.connectedHandler(_DBClient_connected);
                _DBClient.Disconnected -= new DBTcpClient.disconnectedHandler(_DBClient_Disconnected);
                _DBClient.Error -= new DBTcpClient.ErrorHandler(_DBClient_Error);
                _DBClient.Received -= new DBTcpClient.ReceivedHandler(_DBClient_Received);
                _DBClient.Sended -= new DBTcpClient.SendedHandler(_DBClient_Sended);

                _DBClient.Close();
            }


            if (_DBServerQ != null)
            {
                _DBServerQ.ParameterExcute -= new QueuePoolByLock<byte[]>.ParameterHandler(_DBServerQ_ParameterExcute);
                _DBServerQ.Dispose();
            }


            if (_SyncQ != null)
            {
                _SyncQ.ParameterExcute -= new QueuePoolByLock<byte[]>.ParameterHandler(_SyncQ_ParameterExcute);
                _SyncQ.Dispose();
            }



            if (_TcpClient != null)
            {
                _TcpClient.connected -= new net.TcpClient.connectedHandler(_TcpClient_connected);
                _TcpClient.Disconnected -= new net.TcpClient.disconnectedHandler(_TcpClient_Disconnected);
                _TcpClient.Error -= new net.TcpClient.ErrorHandler(_TcpClient_Error);
                _TcpClient.Received -= new net.TcpClient.ReceivedHandler(_TcpClient_Received);
                _TcpClient.Sended -= new net.TcpClient.SendedHandler(_TcpClient_Sended);
                _TcpClient.Close();


            }

            if (_LM != null)
            {
                _LM.CloseWriteLog("TradeDataQWriter");
                _LM.CloseWriteLog("TradeDataQWriterError");





                _LM.CloseWriteLog("AccountDataQWriter");
                _LM.CloseWriteLog("AccountDataQWriterError");

                _LM.CloseWriteLog("DBClientLogSend");
                _LM.CloseWriteLog("DBClientLogRcv");
                _LM.CloseWriteLog("DBClientLogError");

                _LM.CloseWriteLog("CALOG");
                _LM.CloseWriteLog("OrderTrigger");
                _LM.CloseWriteLog("DataAgentLog"); ;
            }
            if (_t != null)
                _t.Dispose();

            if (_AccountCore != null)
                _AccountCore.Close();
            if (_LM != null)
                _LM.Dispose();

        }




        //        public void getWorkDay()
        //        {
        //            try
        //            {


        //                _WorkDay = "";
        //                _NextWorkDay = "";
        //                _WorkDayForDomestic = false;
        //                _WorkDayForForeign = false;
        //                DataTable dtData = new DataTable();


        //                string strSqlCmd = "";
        //                SqlDataAdapter sql;

        //                //判斷大於等於今天的營業日都要帶出來，判斷今天和下個營業日期 
        //                strSqlCmd = @" 
        //select * from [dbo].[WORKDAY] where [DATE] >=CONVERT(CHAR(8),GETDATE(),112) order by  CAST(DATE as int) asc";
        //                sql = new SqlDataAdapter(strSqlCmd, Settings.Default.ConfigSqlConnectionString);
        //                sql.Fill(dtData);

        //                //workday 資料 平日只有兩筆  今天營業日和下個營業日
        //                //遇假日 六日 或假期 ，每天資料  只會有一筆 下個營業日
        //                if (dtData.Rows.Count > 0)
        //                {
        //                    for (int i = 0; i < dtData.Rows.Count; i++)
        //                    {
        //                        if (dtData.Rows[i]["DATE"].ToString() == DateTime.Now.ToString("yyyyMMdd"))
        //                        {
        //                            _WorkDay = dtData.Rows[i]["DATE"].ToString();
        //                            if (dtData.Rows[i]["DOMESTICFLAG"].ToString() == "Y")
        //                            {
        //                                _WorkDayForDomestic = true;
        //                            }
        //                            else
        //                            {
        //                                _WorkDayForDomestic = false;
        //                            }

        //                            if (dtData.Rows[i]["FOREIGNFLAG"].ToString() == "Y")
        //                            {
        //                                _WorkDayForForeign = true;
        //                            }
        //                            else
        //                            {
        //                                _WorkDayForForeign = false;
        //                            }
        //                        }
        //                        else
        //                        {
        //                            //if (i < 2) //不管資料內容多少，只會取資料的前兩筆 一筆當日營業日 第二筆下一個營業日或 下一個營業日(假日轉檔)
        //                            //{
        //                            if (_NextWorkDay == "")//避免有資料為次日  和次次日
        //                                _NextWorkDay = dtData.Rows[i]["DATE"].ToString();
        //                            //}
        //                        }
        //                        if (i > 1) break;//只跑兩筆
        //                    }


        //                }
        //                else
        //                {
        //                    _WorkDayForDomestic = false;
        //                    _WorkDayForForeign = false;
        //                }



        //                _LM.WriteLog("DataAgentLog", "getWorkDay count:" + dtData.Rows.Count.ToString() + " WorkDay" + _WorkDay + " NextWorkDay" + _NextWorkDay);
        //            }
        //            catch (Exception ex)
        //            {
        //                _LM.WriteLog("DataAgentLog", "getWorkDay:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
        //                MsgAlert("getWorkDay " + ex.Message);

        //            }
        //        }

        public void getTargetData()
        {
            try
            {


                DataTable dtData = new DataTable();


                string strSqlCmd = "";
                MySqlDataAdapter sql;

                strSqlCmd = @" select * from TARGETMAP";
                sql = new MySqlDataAdapter(strSqlCmd, DEFAULTProvider.GetString("ConfigSqlConnectionString"));
                sql.Fill(dtData);

                if (dtData.Rows.Count > 0)
                {
                    for (int i = 0; i < dtData.Rows.Count; i++)
                    {
                        DataRow dr = dtData.Rows[i];
                        string key = dr["BROKERID"].ToString().Trim() + dr["INVESTORACNO"].ToString().Trim()
                            + dr["SECURITYEXCHANGE"].ToString().Trim()
                              + dr["SECURITYTYPE"].ToString().Trim() + dr["SYMBOL"].ToString().Trim()
                              + dr["MATURITYMONTHYEAR"].ToString().Trim()

                            ;
                        string targetid = dr["TARGETID"].ToString().Trim();
                        string account = dr["ACCOUNT"].ToString().Trim();
                        string System = dr["SYSTEM"].ToString().Trim();
                        if (!_TargetData.ContainsKey(key))
                        {
                            _TargetData[key] = new Targetitem(targetid, account, System);
                        }
                        _TargetSystem[targetid] = System;
                    }


                }



                _LM.WriteLog("DataAgentLog", "getTargetData count:" + dtData.Rows.Count.ToString());
            }
            catch (Exception ex)
            {
                _LM.WriteLog("DataAgentLog", "getTargetData:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
                MsgAlert("getTargetData " + ex.Message);

            }
        }




        void IniSpeedy()
        {
            try
            {
                string gg = "";
                Dictionary Speedy = _SettingProvider.Get("Speedy").Last.Value;
                string SpeedyConnIP = Speedy.GetString("SpeedyConnIP");
                string SpeedyConnPort = Speedy.GetString("SpeedyConnPort");
                string SpeedyName = Speedy.GetString("CreateName");


                _DisplayItem.AddConn("Speedy", SpeedyConnIP, SpeedyConnPort);



                SpeedyConn = new SpeedyAPI.OrderConnection();
                SpeedyConn.OnConnected += new SpeedyAPI.IOrderConnectionEvents_OnConnectedEventHandler(SpeedyConn_OnConnected);
                SpeedyConn.OnDisconnected += new SpeedyAPI.IOrderConnectionEvents_OnDisconnectedEventHandler(SpeedyConn_OnDisconnected);

                SpeedyConn.OnLogonReply += new SpeedyAPI.IOrderConnectionEvents_OnLogonReplyEventHandler(SpeedyConn_OnLogonReply);

                SpeedyConn.OnExecutionReport += new SpeedyAPI.IOrderConnectionEvents_OnExecutionReportEventHandler(SpeedyConn_OnExecutionReport);

                SpeedyConn.Create2(SpeedyName + "@" + System.Net.Dns.GetHostName());

                SpeedyConn.UseNewFuturesSymbol = true;
                SpeedyConn.EnableFilledStatus = false;
                SpeedyConn.SendFillZeroQty = true;
                SpeedyConn.AddSellSide(SpeedyAPI.SellSideTypeEnum.ssPATS);
                SpeedyConn.SetBrokerID(SpeedyAPI.MarketEnum.mFutures, "F008000");
                SpeedyConn.ClearMemberID = "F008";
                SpeedyConn.SetLanguage(SpeedyAPI.MessageLanguageEnum.mlChinese);
                //開啟會SPEEDY無法正常關閉LOG檔
                //SpeedyConn.SetDebugLog(AppDomain.CurrentDomain.BaseDirectory.ToString().TrimEnd() + "\\Log\\" + DataAgent.CURRENTPATH + "\\"+DateTime.Now.ToString("yyyyMMdd")+"SpeedyLog.txt");
                SpeedyAPI.NewOrderMessage NewOrderMessage = new SpeedyAPI.NewOrderMessage();
                SpeedyAPI.ReplaceOrderMessage ReplaceOrderMessage = new SpeedyAPI.ReplaceOrderMessage();
                SpeedyAPI.CancelOrderMessage CancelOrderMessage = new SpeedyAPI.CancelOrderMessage();
                while (_SpeedyEnable)
                {
                    if (!Connect)
                    { ConnSpeedy(); }
                    while (Connect)
                    {
                        FIXObject item;
                        lock (_locker)
                        {
                            while (_itemQ.Count == 0)
                            {

                                Monitor.Wait(_locker);
                            }
                            item = _itemQ.Dequeue();
                        }

                        if (item != null)
                        {
                            try
                            {
                                if (item.Message is NewOrderSingleMessage)
                                {
                                    NewOrderSingleMessage Message = (NewOrderSingleMessage)item.Message;

                                    gg = SpeedyProvider.Parse2NewOrderMessage(ref SpeedyConn, ref  Message, ref NewOrderMessage);
                                    _LM.WriteLog("SpeedyWriter", gg);
                                    SpeedyConn.NewOrder(NewOrderMessage);

                                }
                                else if (item.Message is OrderCancelReplaceMessage)
                                {
                                    OrderCancelReplaceMessage Message = (OrderCancelReplaceMessage)item.Message;

                                    gg = SpeedyProvider.Parse2ReplaceOrderMessage(ref SpeedyConn, ref Message, ref ReplaceOrderMessage);
                                    _LM.WriteLog("SpeedyWriter", gg);
                                    SpeedyConn.ReplaceOrder(ReplaceOrderMessage);


                                }
                                else if (item.Message is OrderCancelMessage)
                                {
                                    OrderCancelMessage Message = (OrderCancelMessage)item.Message;

                                    gg = SpeedyProvider.Parse2OrderCancelMessage(ref SpeedyConn, ref Message, ref CancelOrderMessage);
                                    _LM.WriteLog("SpeedyWriter", gg);
                                    SpeedyConn.CancelOrder(CancelOrderMessage);

                                }
                            }
                            catch (Exception ex)
                            {
                                _LM.WriteLog("DataAgentLog", "Order:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());

                            }
                        }
                        else
                        {

                            break;
                        }

                    }
                    _LM.WriteLog("Speedy", "Speedy on Reconnect!");

                }


            }
            catch (Exception ex)
            {
                _LM.WriteLog("DataAgentLog", "IniSpeedy:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());

            }
        }
        void ConnSpeedy()
        {
            try
            {
                if (!Connect)
                {
                    Dictionary Speedy = _SettingProvider.Get("Speedy").Last.Value;
                    string SpeedyConnIP = Speedy.GetString("SpeedyConnIP");
                    string SpeedyConnPort = Speedy.GetString("SpeedyConnPort");
                    string SpeedyName = Speedy.GetString("CreateName");

                    SpeedyConn.Connect(SpeedyConnIP, int.Parse(SpeedyConnPort));
                    Thread.Sleep(2000);
                }
            }
            catch (Exception ex)
            {
                _LM.WriteLog("DataAgentLog", "ConnSpeedy:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }

        void LogonSpeedy()
        {
            try
            {
                Dictionary Speedy = _SettingProvider.Get("Speedy").Last.Value;
                string SpeedyLogonID = Speedy.GetString("SpeedyLogonID");
                string SpeedyLogonPassword = Speedy.GetString("SpeedyLogonPassword");
                string SpeedyLogonAccount = Speedy.GetString("SpeedyLogonAccount");
                SpeedyConn.Logon(SpeedyLogonID, SpeedyLogonPassword, SpeedyLogonAccount, SpeedyAPI.ConnectionTypeEnum.ctBoth);
            }
            catch (Exception ex)
            {
                _LM.WriteLog("DataAgentLog", "LogonSpeedy:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());

            }
        }
        void SpeedyConn_OnExecutionReport(SpeedyAPI.ExecutionReportMessage Msg, SpeedyAPI.ExecDupEnum PossDup)
        {
            try
            {
                if (PossDup == SpeedyAPI.ExecDupEnum.edPossibleDuplicate || PossDup == SpeedyAPI.ExecDupEnum.edSpeedyGenerate)
                {

                }
                else
                {

                }
                if (Msg.ExecType == SpeedyAPI.ExecTypeEnum.etOrderStatus)
                {

                    return;
                }

                ExecutionReport obj = new ExecutionReport();
                string gg = SpeedyProvider.Parse2ExecutionReport(ref _LM, ref Msg, ref obj);
                _LM.WriteLog("SpeedyReader", gg);
                _t.parseFixReport("Speedy", "", "", obj);


            }
            catch (System.Exception e)
            {
                _LM.WriteLog("DataAgentLog", "SpeedyConn_OnExecutionReport" + e.Message);
            }
        }

        void SpeedyConn_OnLogonReply(string Message, SpeedyAPI.LogonResultEnum Result, int ConnectionID)
        {
            try
            {
                _LM.WriteLog("Speedy", "Speedy Logon  !");
                if (Result == SpeedyAPI.LogonResultEnum.lrOK)
                {
                    lock (_TargetServer)
                        _TargetServer["Speedy"] = "Speedy";
                    _DisplayItem.ChangeConn("Speedy", "Connected", "");
                    _LM.WriteLog("Speedy", "Speedy Logon successfully!");
                }
                else
                {
                    lock (_TargetServer)
                        _TargetServer.Remove("Speedy");
                    _DisplayItem.ChangeConn("Speedy", "disconnected", "");
                    _DisplayItem.displayStatusMsg("Speedy is Fail!\n" + ConnectionID + ":" + Message);
                    _LM.WriteLog("Speedy", "Speedy is Fail!\n" + ConnectionID + ":" + Message);
                }

            }
            catch (Exception ex)
            {
                _LM.WriteLog("DataAgentLog", "SpeedyConn_OnLogonReply:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        public void PutData2Queue(FIXObject item)
        {
            lock (_locker)
            {

                _itemQ.Enqueue(item);
                Monitor.Pulse(_locker);
            }
        }
        void SpeedyConn_OnDisconnected()
        {
            try
            {
                _DisplayItem.ChangeConn("Speedy", "Disconnect", "");
                _LM.WriteLog("Speedy", "Speedy on Disconnect!");
                this.Connect = false;
                PutData2Queue(null);
            }
            catch (Exception ex)
            {
                _LM.WriteLog("DataAgentLog", "SpeedyConn_OnDisconnected:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());

            }
        }

        void SpeedyConn_OnConnected()
        {
            try
            {

                _LM.WriteLog("Speedy", "Speedy Connect!");
                this.Connect = true;
                LogonSpeedy();

            }
            catch (Exception ex)
            {
                _LM.WriteLog("DataAgentLog", "SpeedyConn_OnConnected:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }


        public void ClearData()
        {
            try
            {

                _LM.WriteLog("DataAgentLog", "ClearData:start");

                DataTable dtData = new DataTable();
                MySql.Data.MySqlClient.MySqlConnection MySqlConnection = new MySql.Data.MySqlClient.MySqlConnection(DEFAULTProvider.GetString("TradeSqlConnectionString"));
                MySqlCommand MySqlCommand = new MySql.Data.MySqlClient.MySqlCommand();
                MySqlCommand.CommandTimeout = 600;
                MySqlCommand.CommandType = CommandType.StoredProcedure;
                MySqlCommand.Connection = MySqlConnection;
                MySqlCommand.Connection.Open();
                MySqlCommand.CommandText = "ClearData";
                int ret = MySqlCommand.ExecuteNonQuery();


                _LM.WriteLog("DataAgentLog", "ClearData:end");

            }
            catch (Exception ex)
            {
                _LM.WriteLog("DataAgentLog", "ClearData:error" + ex.Message);
            }
        }
    }
}
