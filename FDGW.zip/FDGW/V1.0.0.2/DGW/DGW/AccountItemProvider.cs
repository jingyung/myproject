﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using com.ddsc.nets.server;
using System.Net.Sockets;
using com.ddsc.BI.F;

using System.Runtime.InteropServices;
using com.ddsc.tool;
using MySql.Data.MySqlClient;
namespace com.ddsc.TradeSocketServer
{

    public enum DDSCProtocol
    {
        DDSC, DGW
    }
    public enum OrderKind
    {
        TRADE, ACCOUNT
    }

    public class OrderItem
    {
        public void init()
        {
            ORDERKIND = "";
            BROKERID = "";
            INVESTORACNO = "";
            COMMODITYID = "";
            PRODUCTKIND = "";
            ORDERNO = "";
            BS = "";
            ORDERTYPE = "";
            ORDERPRICE = "0";
            ORDERQUANTITY = "0";
            BEFOREQUANTITY = "0";
            AFTERQUANTITY = "0";
            ORDERCONDITION = "";
            OPENOFFSETFLAG = "";
            EXECTYPE = "";
            STATUSCODE = "";
            TRADEDATE = "";
            DATA = "";
            CA = "";
            IP = "";
            ID = "";
            ORDERTIME = "";
            SUBACT = "";
            SOURCECODE = "";
            WEBCODE = "";
            NETWORKID = "";
            NEWWEBCODE = "";
            NEWNETWORKID = "";
        }
        public string ORDERKIND;
        public string BROKERID;
        public string INVESTORACNO;
        public string COMMODITYID;
        public string PRODUCTKIND;
        public string ORDERNO;
        public string BS;
        public string ORDERTYPE;
        public string ORDERPRICE;
        public string ORDERQUANTITY;
        public string BEFOREQUANTITY;
        public string AFTERQUANTITY;
        public string ORDERCONDITION;
        public string OPENOFFSETFLAG;
        public string EXECTYPE;
        public string STATUSCODE;
        public string TRADEDATE;

        public string ORDERTIME;
        public string SUBACT;
        public string SOURCECODE;
        public string WEBCODE;
        public string NETWORKID;
        public string NEWWEBCODE;
        public string NEWNETWORKID;
        public string DATA;
        public string CA;
        public string IP;
        public string ID;
    }

    public class FOrderItem
    {

        public void init()
        {
            TRADEDATE = "";
            ORDERTIME = "";
            EXECTYPE = "";
            BROKERID = "";
            ORDERNO = "";
            INVESTORACNO = "";
            SUBACT = "";
            PRODUCTKIND = "";
            SECURITYEXCHANGE = "";
            SECURITYTYPE1 = "";
            SYMBOL1 = "";
            MATURITYMONTHYEAR1 = "";
            PUTORCALL1 = "";
            STRIKEPRICE1 = 0;
            SIDE1 = "";
            PRICE1 = 0;
            SECURITYTYPE2 = "";
            SYMBOL2 = "";
            MATURITYMONTHYEAR2 = "";
            PUTORCALL2 = "";
            STRIKEPRICE2 = 0;
            SIDE2 = "";
            PRICE2 = 0;
            BS = "";
            ORDERTYPE = "";
            PRICE = 0;
            STOPPRICE = 0;
            ORDERQTY = 0;
            TIMEINFORCE = "";
            OPENCLOSE = "";
            EXPIREDATE = "";
            LASTSHARES = 0;
            LASTPX = 0;
            LEAVESQTY = 0;
            CUMQTY = 0;
            AVGPX = 0;
            CLORDID = "";
            ORICLORDID = "";
            SOURCECODE = "";
            STATUSCODE = "";
            ORDERSTATUS = "";
            EXECID = "";
            EXECTRANSTYPE = "0"; //預設 NEW
            EXECREFID = "";
            ORDERID = "";
            TARGETID = "";
            ACCOUNT = "";
            DTRADE = "";
            DATA = "";
            CADATA = "";
            IP = "";
            ID = "";
            KEEPORICLORDID = "";
            SYSTEM = "";
        }

        public string TRADEDATE { get; set; }
        public string ORDERTIME { get; set; }
        public string EXECTYPE { get; set; }
        public string BROKERID { get; set; }
        public string ORDERNO { get; set; }
        public string INVESTORACNO { get; set; }
        public string SUBACT { get; set; }

        public string PRODUCTKIND { get; set; }
        public string SECURITYEXCHANGE { get; set; }
        public string SECURITYTYPE1 { get; set; }
        public string SYMBOL1 { get; set; }
        public string MATURITYMONTHYEAR1 { get; set; }
        public string PUTORCALL1 { get; set; }
        public decimal STRIKEPRICE1 { get; set; }
        public string SIDE1 { get; set; }
        public decimal PRICE1 { get; set; }
        public string SECURITYTYPE2 { get; set; }
        public string SYMBOL2 { get; set; }
        public string MATURITYMONTHYEAR2 { get; set; }
        public string PUTORCALL2 { get; set; }
        public decimal STRIKEPRICE2 { get; set; }
        public string SIDE2 { get; set; }
        public decimal PRICE2 { get; set; }
        public string BS { get; set; }
        public string ORDERTYPE { get; set; }
        public decimal PRICE { get; set; }
        public decimal STOPPRICE { get; set; }
        public int ORDERQTY { get; set; }
        public string TIMEINFORCE { get; set; }
        public string OPENCLOSE { get; set; }
        public string EXPIREDATE { get; set; }
        public int LASTSHARES { get; set; }
        public decimal LASTPX { get; set; }
        public int LEAVESQTY { get; set; }
        public int CUMQTY { get; set; }
        public decimal AVGPX { get; set; }
        public string DTRADE { get; set; }
        public string CLORDID { get; set; }
        public string ORICLORDID { get; set; }

        public string SOURCECODE { get; set; }
        public string STATUSCODE { get; set; }
        public string ORDERSTATUS { get; set; }
        public string EXECID { get; set; }
        public string EXECTRANSTYPE { get; set; }
        public string EXECREFID { get; set; }
        public string ORDERID { get; set; }
        public string TARGETID { get; set; }
        public string ACCOUNT { get; set; }



        public string KEEPORICLORDID { get; set; }
        public string SYSTEM { get; set; }
        public string DATA; //明文
        public string CADATA;//密文
        public string IP;
        public string ID;

        public FOrderItem Copy()
        {
            FOrderItem item = new FOrderItem();
            item.TRADEDATE = TRADEDATE;
            item.ORDERTIME = ORDERTIME;
            item.EXECTYPE = EXECTYPE;
            item.BROKERID = BROKERID;
            item.ORDERNO = ORDERNO;
            item.INVESTORACNO = INVESTORACNO;
            item.SUBACT = SUBACT;
            item.PRODUCTKIND = PRODUCTKIND;
            item.SECURITYEXCHANGE = SECURITYEXCHANGE;
            item.SECURITYTYPE1 = SECURITYTYPE1;
            item.SYMBOL1 = SYMBOL1;
            item.MATURITYMONTHYEAR1 = MATURITYMONTHYEAR1;
            item.PUTORCALL1 = PUTORCALL1;
            item.STRIKEPRICE1 = STRIKEPRICE1;
            item.SIDE1 = SIDE1;
            item.PRICE1 = PRICE1;
            item.SECURITYTYPE2 = SECURITYTYPE2;
            item.SYMBOL2 = SYMBOL2;
            item.MATURITYMONTHYEAR2 = MATURITYMONTHYEAR2;
            item.PUTORCALL2 = PUTORCALL2;
            item.STRIKEPRICE2 = STRIKEPRICE2;
            item.SIDE2 = SIDE2;
            item.PRICE2 = PRICE2;
            item.BS = BS;
            item.ORDERTYPE = ORDERTYPE;
            item.PRICE = PRICE;
            item.STOPPRICE = STOPPRICE;
            item.ORDERQTY = ORDERQTY;
            item.TIMEINFORCE = TIMEINFORCE;
            item.OPENCLOSE = OPENCLOSE;
            item.EXPIREDATE = EXPIREDATE;
            item.LASTSHARES = LASTSHARES;
            item.LASTPX = LASTPX;
            item.LEAVESQTY = LEAVESQTY;
            item.CUMQTY = CUMQTY;
            item.AVGPX = AVGPX;
            item.DTRADE = DTRADE;
            item.CLORDID = CLORDID;
            item.ORICLORDID = ORICLORDID;
            item.SOURCECODE = SOURCECODE;
            item.STATUSCODE = STATUSCODE;
            item.ORDERSTATUS = ORDERSTATUS;
            item.EXECID = EXECID;
            item.EXECTRANSTYPE = EXECTRANSTYPE;
            item.EXECREFID = EXECREFID;
            item.ORDERID = ORDERID;
            item.TARGETID = TARGETID;
            item.ACCOUNT = ACCOUNT;
            item.KEEPORICLORDID = KEEPORICLORDID;
            item.SYSTEM = SYSTEM;
            item.DATA = DATA;
            item.CADATA = CADATA;
            item.IP = IP;
            item.ID = ID;
            return item;
        }

        public string ToString()
        {
            string ggg = "";
            ggg = string.Format(@"TRADEDATE[{0}]ORDERTIME[{1}]EXECTYPE[{2}]BROKERID[{3}]ORDERNO[{4}]INVESTORACNO[{5}]SUBACT[{6}]PRODUCTKIND[{7}]SECURITYEXCHANGE[{8}]SECURITYTYPE1[{9}]SYMBOL1[{10}]MATURITYMONTHYEAR1[{11}]PUTORCALL1[{12}]STRIKEPRICE1[{13}]SIDE1[{14}]PRICE1[{15}]SECURITYTYPE2[{16}]SYMBOL2[{17}]MATURITYMONTHYEAR2[{18}]PUTORCALL2[{19}]STRIKEPRICE2[{20}]SIDE2[{21}]PRICE2[{22}]BS[{23}]ORDERTYPE[{24}]PRICE[{25}]STOPPRICE[{26}]ORDERQTY[{27}]TIMEINFORCE[{28}]OPENCLOSE[{29}]EXPIREDATE[{30}]LASTSHARES[{31}]LASTPX[{32}]LEAVESQTY[{33}]CUMQTY[{34}]AVGPX[{35}]DTRADE[{36}]CLORDID[{37}]ORICLORDID[{38}]SOURCECODE[{39}]STATUSCODE[{40}]ORDERSTATUS[{41}]EXECID[{42}]EXECTRANSTYPE[{43}]EXECREFID[{44}]ORDERID[{45}]TARGETID[{46}]ACCOUNT[{47}]KEEPORICLORDID[{48}]SYSTEM[{49}]DATA[{50}]CADATA[{51}]IP[{52}]ID[{53}]
", TRADEDATE
, ORDERTIME
, EXECTYPE
, BROKERID
, ORDERNO
, INVESTORACNO
, SUBACT
, PRODUCTKIND
, SECURITYEXCHANGE
, SECURITYTYPE1
, SYMBOL1
, MATURITYMONTHYEAR1
, PUTORCALL1
, STRIKEPRICE1
, SIDE1
, PRICE1
, SECURITYTYPE2
, SYMBOL2
, MATURITYMONTHYEAR2
, PUTORCALL2
, STRIKEPRICE2
, SIDE2
, PRICE2
, BS
, ORDERTYPE
, PRICE
, STOPPRICE
, ORDERQTY
, TIMEINFORCE
, OPENCLOSE
, EXPIREDATE
, LASTSHARES
, LASTPX
, LEAVESQTY
, CUMQTY
, AVGPX
, DTRADE
, CLORDID
, ORICLORDID
, SOURCECODE
, STATUSCODE
, ORDERSTATUS
, EXECID
, EXECTRANSTYPE
, EXECREFID
, ORDERID
, TARGETID
, ACCOUNT
, KEEPORICLORDID
, SYSTEM
, DATA
, CADATA
, IP
, ID);

            return ggg;
        }

    }
    public class CashItem
    {
        public void init()
        {
            COMPANY = "";
            INVESTORACNO = "";
            TRDDT = "";
            TYPE = "";
            SLIPNO = "";
            BANK = "";
            AMT = 0;
            BANKACTNO = "";
            TOBANK = "";
            TOBANKACTNO = "";
            TOBANKACTNM = "";
            CDTYPE = "";
            CURRENCY = "";
            WEBCODE = "";
            NETWORKID = "";
            NEWWEBCODE = "";
            NEWNETWORKID = "";
            STATUS = "";
            DATA = "";
            CA = "";
            IP = "";
            ID = "";
        }

        public string TRDDT;
        public string TYPE;
        public string SLIPNO;
        public string COMPANY;
        public string INVESTORACNO;
        public string BANK;
        public string BANKACTNO;
        public string TOBANK;
        public string TOBANKACTNO;
        public string TOBANKACTNM;
        public decimal AMT;
        public string CDTYPE;
        public string STATUS;
        public string CURRENCY;
        public string WEBCODE;
        public string NETWORKID;
        public string NEWWEBCODE;
        public string NEWNETWORKID;
        public string DATA;
        public string CA;
        public string IP;
        public string ID;
    }

    public class NETMONEYItem
    {
        public string IDATE;
        public string BHNO;
        public string CUSTNO;
        public string CURRENCY;
        public string AMT;
        public string IBANKCODE;
        public string IBANKACCT;
        public string TDATE;
        public string CODE;
        public string CA;
        public string IP;
        public string OWEBID;
        public string ONMVSEQ;
        public string CANCEL_WEBID;
        public string CANCEL_NMVSEQ;
        public string ID;
        public string SLIPNO;
        public string CHGTIME;
        public string RSTATUS;
        public string REMARK;
        public string SIGNDATA;
        public string DATA;
        public string T3;
        public string T4;
        public void init()
        {
            IDATE = "";
            BHNO = "";
            CUSTNO = "";
            CURRENCY = "";
            AMT = "";
            IBANKCODE = "";
            IBANKACCT = "";
            TDATE = "";
            CODE = "";
            CA = "";
            IP = "";
            OWEBID = "";
            ONMVSEQ = "";
            CANCEL_WEBID = "";
            CANCEL_NMVSEQ = "";
            ID = "";
            SLIPNO = "";
            CHGTIME = "";
            RSTATUS = "";
            REMARK = "";
            SIGNDATA = "";
            DATA = "";
            T3 = "";
            T4 = "";
        }
    }
    public class COINTRNItem
    {
        public string IDATE;
        public string BHNO;
        public string CUSTNO;
        public string AMT;
        public string INCUR;
        public string OUTCUR;
        public string CA;
        public string IP;
        public string WEBID;
        public string NMVSEQ;
        public string ID;
        public string CHGTIME;
        public string RSTATUS;
        public string REMARK;
        public string SIGNDATA;
        public string DATA;
        public string T3;
        public string T4;
        public void init()
        {
            IDATE = "";
            BHNO = "";
            CUSTNO = "";
            AMT = "";
            INCUR = "";
            OUTCUR = "";
            CA = "";
            IP = "";
            WEBID = "";
            NMVSEQ = "";
            ID = "";
            CHGTIME = "";
            RSTATUS = "";
            REMARK = "";
            SIGNDATA = "";
            DATA = "";
            T3 = "";
            T4 = "";
        }
    }
    public class TWDNTDTRItem
    {
        public string IDATE;
        public string BHNO;
        public string CUSTNO;
        public string CODE;
        public string AMT;
        public string CA;
        public string IP;
        public string WEBID;
        public string NMVSEQ;
        public string ID;
        public string CHGTIME;
        public string RSTATUS;
        public string REMARK;
        public string SIGNDATA;
        public string DATA;
        public string T3;
        public string T4;
        public void init()
        {
            IDATE = "";
            BHNO = "";
            CUSTNO = "";
            CODE = "";
            AMT = "";
            CA = "";
            IP = "";
            WEBID = "";
            NMVSEQ = "";
            ID = "";
            CHGTIME = "";
            RSTATUS = "";
            REMARK = "";
            SIGNDATA = "";
            DATA = "";
            T3 = "";
            T4 = "";
        }
    }
    public class AccountItem
    {
        public void init()
        {
            S = null;
            Data = "";
            T2 = "";
            T3 = "";
            T4 = "";
            T5 = "";
            NETWORKID = "";
            FUNCTION = "";
            SYSTEMCODE = "".PadRight(3, ' ');
            SEQ = "".PadRight(10, ' ');
            OrderItem = new OrderItem(); //國內
            OrderItem.init();
            FOrderItem = new FOrderItem();//國外
            FOrderItem.init();
            CashItem = new CashItem();//出入金
            CashItem.init();
            NETMONEYItem = new NETMONEYItem();//網路出金申請
            NETMONEYItem.init();

            COINTRNItem = new COINTRNItem();//國外換匯作業
            COINTRNItem.init();

            TWDNTDTRItem = new TWDNTDTRItem();//國內外幣別互轉
            TWDNTDTRItem.init();
        }
        public OrderKind OrderKind;
        public DDSCProtocol Protocol;
        public SocketAsyncEventArgs S;

        public string Data;
        public bool Encode;
        public string T2;
        public string T3;
        public string T4;
        public string T5;
        public string NETWORKID;
        public string FUNCTION;
        public string SYSTEMCODE;
        public string SEQ;
        public FOrderItem FOrderItem;
        public OrderItem OrderItem;
        public CashItem CashItem;
        public NETMONEYItem NETMONEYItem;
        public COINTRNItem COINTRNItem;
        public TWDNTDTRItem TWDNTDTRItem;
    }

    public class AccountItemProvider
    {
        SeqDataProvider _KeepClordid;
        object RILocker = new object();
        Dictionary<string, FOrderItem> _RI;
        public AccountItemProvider()
        {
            _RI = new Dictionary<string, FOrderItem>();
            //keep上一次委回成功的網路單號
            _KeepClordid = new SeqDataProvider("KeepClordid", DataAgent.BASEPATH + "log\\current");
            _KeepClordid.RealKeepFile = false;
            try
            {
                string ConnectionString = DataAgent.DEFAULTProvider.GetString("TradeSqlConnectionString");
                DataTable dt = new DataTable();
                DataSet ds = new DataSet();

                string strSqlCommand = "select * from  ORDERREPLY";
                MySqlDataAdapter adp = new MySqlDataAdapter(strSqlCommand, ConnectionString);
                adp.Fill(dt);
                if (dt.Rows.Count > 0)
                {

                    foreach (DataRow dr in dt.Rows)
                    {
                        FOrderItem item = new FOrderItem();
                        item.TRADEDATE = dr["TRADEDATE"].ToString().Trim();
                        item.ORDERNO = dr["ORDERNO"].ToString().Trim();
                        item.ORDERTIME = dr["ORDERTIME"].ToString().Trim();
                        item.BROKERID = dr["BROKERID"].ToString().Trim();
                        item.INVESTORACNO = dr["INVESTORACNO"].ToString().Trim();
                        item.SUBACT = dr["SUBACT"].ToString().Trim();
                        item.BS = dr["BS"].ToString().Trim();
                        item.PRODUCTKIND = dr["PRODUCTKIND"].ToString().Trim();
                        item.SECURITYEXCHANGE = dr["SECURITYEXCHANGE"].ToString().Trim();
                        item.SECURITYTYPE1 = dr["SECURITYTYPE1"].ToString().Trim();
                        item.SYMBOL1 = dr["SYMBOL1"].ToString().Trim();
                        item.MATURITYMONTHYEAR1 = dr["MATURITYMONTHYEAR1"].ToString().Trim();
                        item.PUTORCALL1 = dr["PUTORCALL1"].ToString().Trim();
                        item.STRIKEPRICE1 = decimal.Parse(dr["STRIKEPRICE1"].ToString());
                        item.SIDE1 = dr["SIDE1"].ToString().Trim();
                        item.SECURITYTYPE2 = dr["SECURITYTYPE2"].ToString().Trim();
                        item.SYMBOL2 = dr["SYMBOL2"].ToString().Trim();
                        item.MATURITYMONTHYEAR2 = dr["MATURITYMONTHYEAR2"].ToString().Trim();
                        item.PUTORCALL2 = dr["PUTORCALL2"].ToString().Trim();
                        item.STRIKEPRICE2 = decimal.Parse(dr["STRIKEPRICE2"].ToString());
                        item.SIDE2 = dr["SIDE2"].ToString().Trim();
                        item.PRICE = decimal.Parse(dr["PRICE"].ToString());
                        item.STOPPRICE = decimal.Parse(dr["STOPPRICE"].ToString());
                        item.ORDERQTY = int.Parse(dr["ORDERQTY"].ToString());
                        item.CUMQTY = int.Parse(dr["MATCHQTY"].ToString());
                        item.LEAVESQTY = int.Parse(dr["NOMATCHQTY"].ToString());

                        item.STATUSCODE = dr["STATUSCODE"].ToString().Trim();
                        item.ORDERSTATUS = dr["ORDERSTATUS"].ToString().Trim();
                        item.ORICLORDID = dr["CLORDID"].ToString().Trim();
                        item.OPENCLOSE = dr["OPENCLOSE"].ToString().Trim();
                        item.TIMEINFORCE = dr["TIMEINFORCE"].ToString().Trim();
                        item.ORDERTYPE = dr["ORDERTYPE"].ToString().Trim();
                        item.EXPIREDATE = dr["EXPIREDATE"].ToString().Trim();
                        item.DTRADE = dr["DTRADE"].ToString().Trim();

                        item.SOURCECODE = dr["SOURCECODE"].ToString().Trim();
                        item.IP = dr["IP"].ToString().Trim();
                        item.ORDERID = dr["ORDERID"].ToString().Trim();
                        item.TARGETID = dr["TARGETID"].ToString().Trim();
                        item.ACCOUNT = dr["ACCOUNT"].ToString().Trim();
                        item.KEEPORICLORDID = _KeepClordid.Get(item.ORDERID);
                        _RI[item.ORICLORDID] = item;
                    }
                }

            }
            catch (Exception ex)
            {
            }


        }
        ~AccountItemProvider()
        {
            Dispose();
        }
        public void Dispose()
        {
            try
            {

                if (_KeepClordid != null)
                {
                    _KeepClordid.close();
                }
                _RI.Clear();
            }
            catch (Exception ex)
            {
            }
        }

        public FOrderItem SetReplyDataForNew(string Clorid, FOrderItem item)
        {
            FOrderItem ret;
            lock (RILocker)
            {
                if (_RI.ContainsKey(Clorid))
                {

                    FOrderItem obj = _RI[Clorid];
                    obj.PRICE = item.PRICE;
                    obj.LEAVESQTY = item.LEAVESQTY;
                    obj.CUMQTY = item.CUMQTY;

                    obj.STATUSCODE = item.STATUSCODE;
                    obj.ORDERSTATUS = item.ORDERSTATUS;
                    obj.ORDERID = item.ORDERID;
                    _RI[Clorid] = obj;
                    ret = obj;

                }
                else
                {
                    _RI[Clorid] = item;
                    ret = item;

                }
            }
            return ret;
        }

        public static void SetReplyDataDetail(FOrderItem obj, FOrderItem item)
        {



            obj.ORDERQTY = item.ORDERQTY;

            obj.PRICE = item.PRICE;
            obj.LEAVESQTY = Convert.ToInt16(item.LEAVESQTY);
            obj.CUMQTY = Convert.ToInt16(item.CUMQTY);

            obj.STATUSCODE = item.STATUSCODE;
            obj.ORDERSTATUS = item.ORDERSTATUS;
            obj.ORDERID = item.ORDERID;


        }

        public FOrderItem SetReplyData(string Clorid, ExecutionReport item)
        {
            FOrderItem ret;
            lock (RILocker)
            {
                if (_RI.ContainsKey(Clorid))
                {

                    FOrderItem obj = _RI[Clorid];

                    //obj.PUTORCALL1 = ParserForTarget.Target2DDSCForCP(item.PutOrCall1);
                    //obj.PUTORCALL2 = ParserForTarget.Target2DDSCForCP(item.PutOrCall2);
                    //obj.BS = ParserForTarget.Target2DDSCForBS(item.Side);
                    //obj.SIDE1 = ParserForTarget.Target2DDSCForBS(item.Side1);
                    //obj.SIDE2 = ParserForTarget.Target2DDSCForBS(item.Side2);
                    if (item.OrdStatus == "0") { obj.STATUSCODE = "0000"; obj.ORDERSTATUS = "委託成功"; }
                    if (item.OrdStatus == "4") { obj.STATUSCODE = "0002"; obj.ORDERSTATUS = "刪單成功"; }
                    if (item.OrdStatus == "5") { obj.STATUSCODE = "0007"; obj.ORDERSTATUS = "改單成功"; }
                    if (item.OrdStatus == "1") { obj.STATUSCODE = "0003"; obj.ORDERSTATUS = "部分成交"; }
                    if (item.OrdStatus == "2") { obj.STATUSCODE = "0004"; obj.ORDERSTATUS = "完全成交"; }
                    if (item.OrdStatus == "8") { obj.STATUSCODE = "ERROR"; obj.ORDERSTATUS = item.Text; }

                    if (item.OrdStatus == "5")
                    {
                        obj.PRICE = item.Price;
                        obj.STOPPRICE = item.StopPx;
                        obj.TIMEINFORCE = item.TimeInForce;
                        obj.ORDERTYPE = item.OrdType;
                        obj.OPENCLOSE = item.Openclose;
                    }
                    obj.LEAVESQTY = Convert.ToInt16(item.LeavesQty);
                    obj.CUMQTY = Convert.ToInt16(item.CumQty);


                    if (item.OrdStatus != "8")
                    {
                        obj.KEEPORICLORDID = item.ClOrdID; //pats 原單單號是抓上一次成功的clordid
                        _KeepClordid.Add(obj.ORDERID, item.ClOrdID);
                    }
                    //obj.STATUSCODE = item.OrdStatus;
                    //obj.ORDERSTATUS = item.Text;
                    obj.ORDERID = item.OrderID;


                    _RI[Clorid] = obj;
                    ret = obj;
                }
                else
                {

                    FOrderItem obj = new FOrderItem();
                    obj.TRADEDATE = item.TransactTime.Substring(0, 8);
                    obj.ORDERTIME = item.TransactTime.Substring(8, 9);
                    obj.EXECTYPE = item.ExecType;
                    obj.BROKERID = "";
                    obj.ORDERNO = "";
                    obj.INVESTORACNO = item.Account;
                    obj.SUBACT = "";
                    if (item.SecurityType == "MLEG")
                    {
                        if (item.SecurityType1 == "FUT")
                            obj.PRODUCTKIND = "4";
                        else
                            obj.PRODUCTKIND = "3";
                    }
                    else
                    {
                        if (item.SecurityType1 == "FUT")
                            obj.PRODUCTKIND = "1";
                        else
                            obj.PRODUCTKIND = "2";
                    }
                    obj.SECURITYEXCHANGE = item.SecurityExchange;
                    obj.SECURITYTYPE1 = item.SecurityType1;
                    obj.SYMBOL1 = item.Symbol1;
                    obj.MATURITYMONTHYEAR1 = item.MaturityMonthYear1;
                    obj.PUTORCALL1 = item.PutOrCall1;
                    obj.STRIKEPRICE1 = item.StrikePrice1;
                    obj.SIDE1 = item.Side1;
                    obj.PRICE1 = item.Price1;
                    obj.SECURITYTYPE2 = item.SecurityType2;
                    obj.SYMBOL2 = item.Symbol2;
                    obj.MATURITYMONTHYEAR2 = item.MaturityMonthYear2;
                    obj.PUTORCALL2 = item.PutOrCall2;
                    obj.STRIKEPRICE2 = item.StrikePrice2;
                    obj.SIDE2 = item.Side2;
                    obj.PRICE2 = item.Price2;
                    obj.BS = item.Side;
                    obj.ORDERTYPE = item.OrdType;
                    obj.PRICE = item.Price;
                    obj.STOPPRICE = item.StopPx;
                    obj.ORDERQTY = int.Parse(item.OrderQty.ToString());
                    obj.TIMEINFORCE = item.TimeInForce;
                    obj.OPENCLOSE = item.Openclose;
                    obj.EXPIREDATE = item.ExpireDate;
                    obj.LASTSHARES = int.Parse(item.LastShares.ToString());
                    obj.LASTPX = item.RawLastPx;
                    obj.LEAVESQTY = Convert.ToInt16(item.LeavesQty);
                    obj.CUMQTY = Convert.ToInt16(item.CumQty);
                    obj.AVGPX = item.AvgPx;
                    obj.CLORDID = item.ClOrdID;
                    obj.ORICLORDID = item.OrigClOrdID;
                    obj.SOURCECODE = "";
                    obj.STATUSCODE = item.OrdStatus;
                    obj.ORDERSTATUS = item.Text;
                    obj.EXECID = item.ExecID;
                    obj.EXECREFID = item.ExecRefID;
                    obj.ORDERID = item.OrderID;
                    obj.TARGETID = "";
                    obj.ACCOUNT = item.Account;
                    obj.DTRADE = "";
                    obj.DATA = "";
                    obj.CADATA = "";
                    obj.IP = "";
                    obj.ID = "";


                    obj.PUTORCALL1 = ParserForTarget.Target2DDSCForCP(item.PutOrCall1);
                    obj.PUTORCALL2 = ParserForTarget.Target2DDSCForCP(item.PutOrCall2);
                    obj.BS = ParserForTarget.Target2DDSCForBS(item.Side);
                    obj.SIDE1 = ParserForTarget.Target2DDSCForBS(item.Side1);
                    obj.SIDE2 = ParserForTarget.Target2DDSCForBS(item.Side2);
                    if (item.OrdStatus == "0") { obj.STATUSCODE = "0000"; obj.ORDERSTATUS = "委託成功"; }
                    if (item.OrdStatus == "4") { obj.STATUSCODE = "0002"; obj.ORDERSTATUS = "刪單成功"; }
                    if (item.OrdStatus == "5") { obj.STATUSCODE = "0007"; obj.ORDERSTATUS = "改單成功"; }
                    if (item.OrdStatus == "1") { obj.STATUSCODE = "0003"; obj.ORDERSTATUS = "部分成交"; }
                    if (item.OrdStatus == "2") { obj.STATUSCODE = "0004"; obj.ORDERSTATUS = "完全成交"; }
                    if (item.OrdStatus == "8") { obj.STATUSCODE = "FIXERROR"; obj.ORDERSTATUS = item.Text; }
                    if (item.OrdStatus != "8")
                    {
                        obj.KEEPORICLORDID = item.ClOrdID; //pats 原單單號是抓上一次成功的clordid
                        _KeepClordid.Add(obj.ORDERID, item.ClOrdID);
                    }

                    _RI[Clorid] = obj;
                    ret = obj;
                }
            }
            return ret;
        }

        public FOrderItem GetReplyData(string Clorid)
        {
            FOrderItem item = null;

            lock (RILocker)
            {
                if (_RI.TryGetValue(Clorid, out item))
                    return item;
            }
            return null;
        }



        private static string GetString(byte[] b)
        {
            try
            {
                return ASCIIEncoding.Default.GetString(b).Trim();
            }
            catch (Exception ex)
            {

            }
            return "";
        }
        private static decimal GetDecimal(byte[] b)
        {
            try
            {
                return Decimal.Parse(ASCIIEncoding.Default.GetString(b).Trim());
            }
            catch (Exception ex)
            {

            }
            return 0;
        }
        private static int GetInt(byte[] b)
        {
            try
            {
                return int.Parse(ASCIIEncoding.Default.GetString(b).Trim());
            }
            catch (Exception ex)
            {

            }
            return 0;
        }
    }
}
