﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using com.ddsc.BI;
namespace com.ddsc.TradeSocketServer
{
    public enum OrderKindEnum
    {
        reserve=0,ontime
    }
    public struct ReplyItem
    {
        public void init()
        {
            ORDERKIND = "";
            BROKERID = "";
            INVESTORACNO = "";
            COMMODITYID = "";
            PRODUCTKIND = "";
            ORDERNO = "";
            BS = "";
            ORDERTYPE = "";
            ORDERPRICE = 0;
            ORDERQUANTITY = 0;
            BEFOREQUANTITY = 0;
            AFTERQUANTITY = 0;
            ORDERCONDITION = "";
            OPENOFFSETFLAG = "";
            EXECTYPE = "";
            STATUSCODE = "";
            TRADEDATE = "";

            ORDERTIME = "";
            SUBACT = "";
            SOURCECODE = "";

            TOTALMATCHQTY = 0;
            AFTERQUANTITY = 0;
            WEBCODE = "";
            NETWORKID = "";
        }
        public string ORDERKIND;
        public string BROKERID;
        public string INVESTORACNO;
        public string COMMODITYID;
        public string PRODUCTKIND;
        public string ORDERNO;
        public string BS;
        public string ORDERTYPE;
        public decimal ORDERPRICE;
        public int ORDERQUANTITY;
        public int BEFOREQUANTITY;
        public int AFTERQUANTITY;
        public string ORDERCONDITION;
        public string OPENOFFSETFLAG;
        public string EXECTYPE;
        public string STATUSCODE;
        public string TRADEDATE;

        public string ORDERTIME;
        public string SUBACT;
        public string SOURCECODE;
        public string WEBCODE;
        public string NETWORKID;
        public int TOTALMATCHQTY;
        public decimal BEFOREPRICE;
    }

    public class RI
    {
        object RILocker = new object();
        Dictionary<string, ReplyItem> _RI;
        public RI()
        {
            //key =brokerid+orderno 
            _RI = new Dictionary<string, ReplyItem>();
        }
        ~RI()
        {
            Dispose();
        }
        public void Dispose()
        {


            GC.SuppressFinalize(this);
        }

        public ReplyItem SetReplyData(OrderKindEnum OrderKind, string BrokerID, string OrderNO, decimal OrderPrice, int OrderQty
            , int BeforeQty, int AferQty)
        {
            ReplyItem item;
            string key = BrokerID + OrderNO;
            lock (RILocker)
            {
                if (_RI.ContainsKey(key))
                {

                    item = _RI[key];



                    //當下成交 IOC、FOK發生機率最高,R單也有可能
                    //剩餘口數為零，就不異動，因為這筆成交為最後一筆
                    if (item.BEFOREQUANTITY == 0 && item.TOTALMATCHQTY > 0)
                    {

                    }
                    else
                    {
                        item.BEFOREPRICE = item.ORDERPRICE;
                        item.ORDERPRICE = OrderPrice;
                        item.BEFOREQUANTITY = BeforeQty;
                        item.AFTERQUANTITY = AferQty;
                    }
                    _RI[key] = item;
                }
                else
                {
                    item = new ReplyItem();
                    item.init();
                    item.BROKERID = BrokerID;
                    item.ORDERNO = OrderNO;
                    item.ORDERPRICE = OrderPrice;
                    item.BEFOREPRICE = OrderPrice;
                    item.ORDERQUANTITY = OrderQty;
                    item.BEFOREQUANTITY = BeforeQty;
                    item.AFTERQUANTITY = AferQty;
                    _RI[key] = item;

                }


            }
            return item;
        }
        public ReplyItem SetMatchReplyData(string BrokerID, string OrderNO, int BeforeQty, int AferQty, int TotalMatchQty)
        {
            ReplyItem item;
            string key = BrokerID + OrderNO;
            lock (RILocker)
            {
                if (_RI.ContainsKey(key))
                {

                    item = _RI[key];

                    //當下成交 IOC、FOK發生機率最高,R單也有可能
                    //剩餘口數為零，就不異動，因為這筆成交為最後一筆
                    if (item.BEFOREQUANTITY == 0 && item.TOTALMATCHQTY > 0)
                    {

                    }
                    else
                    {
                        item.BEFOREQUANTITY = BeforeQty;
                        item.AFTERQUANTITY = AferQty;
                        item.TOTALMATCHQTY = TotalMatchQty;
                    }
                    _RI[key] = item;
                }
                else
                {
                    item = new ReplyItem();
                    item.init();
                    item.BROKERID = BrokerID;
                    item.ORDERNO = OrderNO;
                    item.BEFOREQUANTITY = BeforeQty;
                    item.AFTERQUANTITY = AferQty;
                    item.TOTALMATCHQTY = TotalMatchQty;
                    _RI[key] = item;

                }


            }
            return item;
        }



    }
}
