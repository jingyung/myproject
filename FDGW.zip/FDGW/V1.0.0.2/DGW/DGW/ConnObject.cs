﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace com.ddsc.TradeSocketServer
{
    public class ConnCore
    {
    }
    public class ConnObject
    {
        System.Net.Sockets.SocketAsyncEventArgs m_SAEA;
        string m_Account;
        public string Account
        {
            set { m_Account = value; }
            get { return m_Account; }
        }

        public System.Net.Sockets.SocketAsyncEventArgs SAEA
        {
            set { m_SAEA = value; }
            get { return m_SAEA; }
        }
       
    }
}
