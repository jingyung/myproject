﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using com.ddsc.tool;
using com.ddsc.BI.F;
namespace com.ddsc.TradeSocketServer
{
    public class ReportProvider
    {
        SeqProvider _OrderNo = null;
        SeqProvider _OrderNoSeq = null;
        SeqDataProvider _NetWorkidData = null;
        string _SrcID = "";
        private Dictionary<string, ExecutionReport> _MLEGDATA = new Dictionary<string,  ExecutionReport>();
        private Dictionary<string, string> _OrderID2NetWorkidData;

        public Dictionary<string, string> OrderID2NetWorkidData
        {
            get { return _OrderID2NetWorkidData; }
            set { _OrderID2NetWorkidData = value; }
        }
        private Dictionary<string, string> _NetWorkid2OrderIDData;

        public Dictionary<string, string> NetWorkid2OrderIDData
        {
            get { return _NetWorkid2OrderIDData; }
            set { _NetWorkid2OrderIDData = value; }
        }


        public ReportProvider()
        {
            _OrderID2NetWorkidData = new Dictionary<string, string>();
            _NetWorkid2OrderIDData = new Dictionary<string, string>();
            _MLEGDATA = new Dictionary<string, ExecutionReport>();
            _OrderNo = new SeqProvider("OrderNoForLiv", DataAgent.BASEPATH + "log\\current");
            _OrderNoSeq = new SeqProvider("NetWorkIDForLiv", DataAgent.BASEPATH + "log\\current");
            _NetWorkidData = new SeqDataProvider("NetWorkIDForReport", DataAgent.BASEPATH + "log\\current");
           
            _SrcID = DataAgent.DEFAULTProvider.GetString("SrcIDLiv");
        }
        ~ReportProvider()
        {
            Dispose();
        }
        public void Dispose()
        {
            if (_NetWorkidData != null)
                _NetWorkidData.close();
            if (_OrderNo != null)
                _OrderNo.Dispose();
            if (_OrderNoSeq != null)
                _OrderNoSeq.Dispose();
            if (_OrderID2NetWorkidData != null)
                _OrderID2NetWorkidData.Clear();

            if (_NetWorkid2OrderIDData != null)
                _NetWorkid2OrderIDData.Clear();
            if (_MLEGDATA != null)
                _MLEGDATA.Clear();
        }
        public void AddMlegData(string OrderID,  ExecutionReport obj)
        {
            lock (_MLEGDATA)
                if (OrderID.Trim().Length > 0)
                {
                    _MLEGDATA[OrderID] = obj;
                }
        }
        public  ExecutionReport FindMlegData(string OrderID)
        {
             ExecutionReport obj = null;
            lock (_MLEGDATA)
                if (OrderID.Trim().Length > 0)
                {
                    obj = _MLEGDATA[OrderID];
                }
            return obj;
        }


        public void AddOriCLORDIDForOrderID(string OrderID, string OriCLORDID)
        {
            lock (_OrderID2NetWorkidData)
                if (OrderID.Trim().Length > 0 && OriCLORDID.Trim().Length > 0)
                {

                    _NetWorkidData.Add(OrderID, OriCLORDID);
                }
        }
        public void AddOrderIDForOriCLORDID(string OriCLORDID, string OrderID)
        {
            lock (_NetWorkid2OrderIDData)
                if (OrderID.Trim().Length > 0 && OriCLORDID.Trim().Length > 0)
                {

                    _NetWorkidData.Add(OriCLORDID, OrderID);
                }
        }

        public string FindOrderIDForOriCLORDID(string OriCLORDID)
        {
            string id = "";
            lock (_NetWorkid2OrderIDData)
            {
                id = _NetWorkidData.Get(OriCLORDID);

            }
            return id;
        }

        public string FindOriCLORDIDForOrderID(string OrderID)
        {
            string id = "";
            lock (_OrderID2NetWorkidData)
            {
                id = _NetWorkidData.Get(OrderID);
            }
            return id;
        }


        public ExecutionReport Combine(ExecutionReport obj)
        {
            string OrigClOrdID = "";
            //if (obj.ExecTransType != "0" && obj.ExecType != "D") return null; //restat 狀態不揭示
            //if (obj.ExecTransType != "0") return null;//不揭示STATUS 、correct

            if (obj.ClOrdID == "") return null;//原單由上手下的不揭示
            if (obj.OrderID == "0") obj.OrderID = "";
            obj.OrderID = obj.OrderID.Replace("NONE", "").Replace("00000", "");
            if (obj.ExecType == "0")
            {
                if (obj.ClOrdID == "")//判斷上手AP 下單沒有回傳 網路單號 自動滾單號與書號
                {
                    //string orderno = getOrderNo();
                    //string networkid = getNetworkId();
                    //obj.OrigClOrdID = OrigClOrdID = obj.ClOrdID = orderno + networkid;
                }
                else
                {
                    obj.OrigClOrdID = OrigClOrdID = obj.ClOrdID;
                }
                AddOriCLORDIDForOrderID(obj.OrderID, obj.ClOrdID);
                AddOrderIDForOriCLORDID(obj.ClOrdID, obj.OrderID);
                //if (obj.SecurityType == "MLEG")
                //{
                //    AddMlegData(obj.OrderID, obj);
                //}
            }
            else
            {
                OrigClOrdID = FindOriCLORDIDForOrderID(obj.OrderID);
                if (OrigClOrdID.Length > 0)
                    obj.OrigClOrdID = OrigClOrdID;
                else obj.OrigClOrdID = obj.ClOrdID;
            }
            return obj;
            //下面不用跑 回報全部以SPEEDY為主，所以不用管合併或分兩隻腳
            if ((obj.OrdStatus == "1" || obj.OrdStatus == "2") && obj.MultiLegReportingType == "3")
            {
                //TT.ExecutionReport ret = FindMlegData(obj.OrderID);
                //ret.LastPx = obj.LastPx;
                //AddMlegData(obj.OrderID, ret);
                //if (ret.Legflag2 && ret.Legflag1)
                //{
                //    obj = ret;
                //}
                //else
                    return null;
            }

            if ((obj.OrdStatus == "1" || obj.OrdStatus == "2") && obj.MultiLegReportingType == "2")
            {
                ExecutionReport ret = FindMlegData(obj.OrderID);
                ret.CumQty = obj.CumQty;
                ret.LastShares = obj.LastShares;
                ret.LeavesQty = obj.LeavesQty;
                ret.ExecID  = obj.ExecID  ;
                //價差算法 1buy 1sell contract 當 buy spread ,第一隻腳在市場上為買方，成交價差為 腳一 減腳二
                //                             當 sell spread ,第一隻腳在市場上為賣方，成交價差為 腳一減腳二
                //  1sell 1buy contract  當 buy spread ,第一隻腳在市場上為賣方，成交價差為 腳二 減腳一
                //                        當 sell spread ,第一隻腳在市場上為買方，成交價差為 腳二 減腳一
                if (ret.MaturityMonthYear1 == obj.MaturityMonthYear1)//不計算成真正的買賣別，而用合約的買賣別  
                {

                    ret.Price1 = obj.LastPx;
                    ret.Legflag1 = true;
                }
                else
                {
                    ret.Price2 = obj.LastPx;
                    ret.Legflag2 = true;
                }
                ret.ExecType = obj.ExecType;
                ret.OrdStatus = obj.OrdStatus;
                AddMlegData(obj.OrderID, ret);

                if (ret.Legflag2 && ret.Legflag1)
                {
                    decimal price = 0;
                    decimal leg = ret.Side == "1" ? 1 : -1;
                    decimal leg1 = ret.Side1 == "1" ? 1 : -1;
                    decimal leg2 = ret.Side2 == "1" ? 1 : -1;
                    if (ret.Side == "1")
                    {
                        price = leg * (leg1 * ret.Price1 + leg2 * ret.Price2);
                    }
                    else
                    {
                        price = leg * (leg1 * ret.Price1 + leg2 * ret.Price2);
                        price = price * -1;
                    }
                    ret.LastPx = price;
                    obj = ret;
                    ret.Legflag2 = false;
                    ret.Legflag1 = false;
                    AddMlegData(obj.OrderID, ret);
                }
                else
                    return null;
            }
            return obj;

        }

        public static FOrderItem ToFOrderItem(TT.ExecutionReport obj)
        {
            FOrderItem item = new FOrderItem();



            return item;
        }

        private string getOrderNo()
        {
            try
            {
                int orderno = _OrderNo.getSeq();


                return ((int)DateTime.Now.DayOfWeek).ToString() + _SrcID + TradeStringHandler.Int2String(orderno).PadLeft(4, '0');
            }
            catch (Exception ex)
            {
            }
            return "";

        }

        private string getNetworkId()
        {

            try
            {
                int networkid = _OrderNoSeq.getSeq();

                return ((int)DateTime.Now.DayOfWeek).ToString() + _SrcID + networkid.ToString().PadLeft(12, '0');
            }
            catch (Exception ex)
            {
            }
            return "";

        }



    }
}
