﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using com.ddsc.tool;
namespace com.ddsc.TradeSocketServer
{
    public partial class MainForm : Form
    {
        private DataAgent _DataAgent;


        private Timer _StartRunning;
        private Timer _CloseRunning;
        private bool _ServerRunning;
        bool f;
        private string _SysCloseTime;
        public MainForm()
        {
            try
            {

                InitializeComponent();
                this.Text += "(V" + Application.ProductVersion + ")";
                DisplayItem DI = new DisplayItem();

                DI.frmMainForm = this;

                DI.lstSysMsg = this.lstSysMsg;
                DI.lstConnections = this.lstConnections;
                DI.DgvStatus = this.dgvStatus;
                DI.lblCount = this.lblCount;
                this._DataAgent = new DataAgent(DI);

                DataTable dt = new DataTable();
                dt.Columns.Add("ConnectionName");
                dt.Columns.Add("ConnectionIp");
                dt.Columns.Add("ConnectionPort");
                dt.Columns.Add("ConnectionStatus");
                dt.Columns.Add("ConnectionRemark");

                dt.PrimaryKey = new DataColumn[] { dt.Columns["ConnectionName"] };
                this.dgvStatus.DataSource = dt;
                this.dgvStatus.Columns["ConnectionName"].Width = 200;
                this.dgvStatus.Columns["ConnectionName"].HeaderText = "連線主機";
                this.dgvStatus.Columns["ConnectionIp"].Width = 100;
                this.dgvStatus.Columns["ConnectionIp"].HeaderText = "主機IP";
                this.dgvStatus.Columns["ConnectionPort"].Width = 100;
                this.dgvStatus.Columns["ConnectionPort"].HeaderText = "主機PORT";
                this.dgvStatus.Columns["ConnectionStatus"].Width = 150;
                this.dgvStatus.Columns["ConnectionStatus"].HeaderText = "連線狀態";
                this.dgvStatus.Columns["ConnectionRemark"].Width = 500;
                this.dgvStatus.Columns["ConnectionRemark"].HeaderText = "說明";
                this.dgvStatus.ReadOnly = true;
                this.dgvStatus.AllowUserToAddRows = false;
                this._StartRunning = new Timer();
                this._StartRunning.Interval = 10000;
                this._StartRunning.Tick += new EventHandler(_StartRunning_Tick);
                this._StartRunning.Start();
                this._ServerRunning = false;

                this._CloseRunning = new Timer();
                this._CloseRunning.Tick += new EventHandler(_CloseRunning_Tick);
                this._CloseRunning.Interval = 1000;
                this._CloseRunning.Start();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        void _CloseRunning_Tick(object sender, EventArgs e)
        {
            try
            {

                //int LINT_Year = DateTime.Now.Year;
                //int LINT_Month = DateTime.Now.Month;
                //int LINT_Day = DateTime.Now.Day;
                //int LDTM_SysCloseDataHH = int.Parse(this._SysCloseTime.PadRight(8, '0').Substring(0, 2));
                //int LDTM_SysCloseDatamm = int.Parse(this._SysCloseTime.PadRight(8, '0').Substring(3, 2));
                //int LDTM_SysCloseDatass = int.Parse(this._SysCloseTime.PadRight(8, '0').Substring(6, 2));
                //DateTime LDTM_SysCloseTime = new DateTime(LINT_Year, LINT_Month, LINT_Day, LDTM_SysCloseDataHH, LDTM_SysCloseDatamm, LDTM_SysCloseDatass);
                //if (DateTime.Now > LDTM_SysCloseTime)
                //{
                //    this._DataAgent.Stop();
                //    this.Close();
                //}



            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\r\n" + ex.Source + "\r\n" + ex.StackTrace);
            }
        }
        string Execpath = AppDomain.CurrentDomain.BaseDirectory.ToString().TrimEnd();
        private void _StartRunning_Tick(object sender, EventArgs e)
        {
            if (!this._ServerRunning)
            {
                setDataAgent(false);
                setDataAgent(true);
            }


            SettingProvider _SettingProvider = new SettingProvider(Execpath+"FTDGW.cfg");
            Dictionary _DEFAULTProvider = _SettingProvider.Get("DEFAULT").First.Value;
            int closeweek = _DEFAULTProvider.GetInt("CloseTimeByWeek");
            int begin = _DEFAULTProvider.GetInt("ClearDataTime");
            int now = int.Parse(DateTime.Now.ToString("HHmm"));
 


            SeqDataProvider _TransferDate = new SeqDataProvider("TransferDate", Execpath+"log\\current");

            string data = _TransferDate.Get(DateTime.Now.ToString("yyyyMMdd"));
            _TransferDate.close(); //為了要COPY所以要先CLOSE
            if (data != "Y")
            {
                if (now > begin)//跨日
                {

                    if (closeweek == -1 || (int)DateTime.Now.DayOfWeek == closeweek)
                    {
                  
                        this.Close();
                    }
                    else
                    {
                        setDataAgent(false);


                        setDataAgent(true);
                    }
                }
            }
        }


        private void btnStart_Click(object sender, EventArgs e)
        {
            setDataAgent(true);
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            setDataAgent(false);
        }

        private void setDataAgent(bool flag)
        {
            if (flag)
            {

                //   this._StartRunning.Stop();
                this._ServerRunning = true;

                btnStart.Enabled = false;
                btnStop.Enabled = true;

                this._DataAgent.Start();


            }
            else
            {
                this._ServerRunning = false;

                this._StartRunning.Start();

                btnStart.Enabled = true;
                btnStop.Enabled = false;


                this._DataAgent.Stop();
            }


        }

        private void button1_Click(object sender, EventArgs e)
        {



            string test = "12";
            byte[] bb = Encoding.ASCII.GetBytes(test);



        }

        private void tabControl_Status_KeyDown(object sender, KeyEventArgs e)
        {
            if (_DataAgent == null) return;
            if (e.Alt && e.KeyCode == Keys.F1)
            {
                ShowThings th = new ShowThings(_DataAgent.AccountCore);
                th.ShowDialog();

            }
        }



        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {

            this._DataAgent.Stop();
            this._DataAgent.Dispose();
        }

        private void btnTest_Click(object sender, EventArgs e)
        {
        }








    }
}
