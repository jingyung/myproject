﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace com.ddsc.tool
{
    public class Dictionary
        {
            private string _Name;

            public string Name
            {
                get { return _Name; }
                set { _Name = value; }
            }
            private System.Collections.Generic.Dictionary<string, string> _data = new System.Collections.Generic.Dictionary<string, string>();

            public Dictionary(string name)
            {
                _Name = name;
            }
            public void SetString(string key, string val)
            {
                _data[key] = val;
            }
            public string GetString(string key)
            {
                string val = "";
                if (!_data.TryGetValue(key, out val))
                    return "";
                return val;
            }
            public bool GetBool(string key)
            {
                string val = "true";
                if (!_data.TryGetValue(key, out val))
                    return true;
                return bool.Parse(val);
            }


            public int GetInt(string key)
            {
                string val = "";
                if (!_data.TryGetValue(key, out val))
                    return 0;
                return int.Parse(val);
            }
        }

    class SettingProvider
    {
        

        private LinkedList<Dictionary> _sections = new LinkedList<Dictionary>();

        public SettingProvider(string file)
        {
            FileStream fs = File.Open(file, FileMode.Open, FileAccess.Read);
            TextReader conf = new StreamReader(fs);

            Dictionary currentSection = null;

            string line = null;
            while ((line = conf.ReadLine()) != null)
            {

                line = line.Trim();
                if (IsComment(line))
                {
                    continue;
                }
                else if (IsSection(line))
                {
                    currentSection = Add(new Dictionary(SplitSection(line)));
                }
                else if (IsKeyValue(line) && currentSection != null)
                {
                    string[] kv = line.Split(new char[] { '=' }, 2);
                    currentSection.SetString(kv[0].Trim(), kv[1].Trim());
                }
            }
            conf.Close();
        }

        /// <summary>
        /// Strip the outer '[' and ']' from the section name, e.g. '[DEFAULT]' becomes 'DEFAULT'
        /// </summary>
        /// <param name="s">the section name</param>
        /// <returns></returns>
        public static string SplitSection(string s)
        {
            return s.Trim('[', ']').Trim();
        }

        public static bool IsComment(string s)
        {
            if (s.Length < 1)
                return false;
            return '#' == s[0];
        }

        public static bool IsKeyValue(string s)
        {
            return s.IndexOf('=') != -1;
        }

        public static bool IsSection(string s)
        {
            if (s.Length < 2)
                return false;
            return s[0] == '[' && s[s.Length - 1] == ']';
        }

        public Dictionary Add(Dictionary section)
        {
            _sections.AddLast(section);
            return section;
        }


        public LinkedList<Dictionary> Get(string sectionName)
        {
            LinkedList<Dictionary> result = new LinkedList<Dictionary>();
            foreach (Dictionary dict in _sections)
                if (sectionName.ToUpperInvariant() == dict.Name.ToUpperInvariant())
                    result.AddLast(dict);
            return result;
        }
    }
}
