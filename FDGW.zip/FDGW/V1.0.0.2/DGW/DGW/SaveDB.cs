﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Collections;
using System.Data;
 
using com.ddsc.tool;
using com.ddsc.core;
using System.Security.Cryptography;


using MySql.Data.MySqlClient;
namespace com.ddsc.TradeSocketServer
{
    public enum SaveDBItemEnum
    {
        checkUserPassword, CustomerData, EditPassword, OrderReplyData, MatchReplyData, INCOME_DETAIL, CASH, CASH_DETAIL, INCOME
    }
    public class SaveDBItem
    {
        public SaveDBItemEnum DBItemEnum;
        public string NetWorkID;
        public string[] item;

    }


    public class SaveDB
    {
        public event SaveDBHandler SaveDBEvent;
        public delegate void SaveDBHandler(string networkid, DataTable dt);
        private QueuePoolByLock<AccountItem> _QDetail;
        private QueuePoolByLock<SaveDBItem> _Q;
        int _ConnectCount = 0;
        const int MAXCONNECTCOUNT = 999;

        MySqlConnection sqlFutureDBConn; //
        MySqlConnection sqlFutureDBConnExcute; //

        MySqlConnection sqlConn;
        MySqlConnection sqlConnDBConnExcute; //


        MySqlCommand sqlcmdInsertOrderReplyDetail;
    
        
        string _decodeSqlstring = "";
        string _saveConfigSqlstring = "";
        int _count = 0;
        /// <summary>
        /// 物件初始化

        /// </summary>
        public SaveDB(int count, string SaveDBConnectionString)
        {
            _count = count;
            DataAgent._LM.AddFileWriter("SaveDBError" + _count, new FileWriter(DataAgent.BASEPATH, DataAgent.CURRENTPATH, "SaveDBError" + _count, ""));

            DataAgent._LM.AddFileWriter("SaveDBInfo" + _count, new FileWriter(DataAgent.BASEPATH, DataAgent.CURRENTPATH, "SaveDBInfo" + _count, ""));

            _Q = new QueuePoolByLock<SaveDBItem>(1);

            _Q.ParameterExcute += new QueuePoolByLock<SaveDBItem>.ParameterHandler(_Q_ParameterExcute);


            _Q.Go();

            _QDetail = new QueuePoolByLock<AccountItem>(1);
            _QDetail.ParameterExcute += new QueuePoolByLock<AccountItem>.ParameterHandler(_QDetail_ParameterExcute);
            _QDetail.Go();

            this.initInsertOrderReplyDetail();
           
            //string[] sqlsplit = Properties.Settings.Default.TradeSqlConnectionString.Split(';');

            //for (int i = 0; i < sqlsplit.Length; i++)
            //{
            //    if (sqlsplit[i].Contains("Password"))//Password大小寫必須一樣 ，讓編碼的密碼解成明文
            //    {
            //        sqlsplit[i] = "Password=" + Encoding.Unicode.GetString(
            //            Convert.FromBase64String(sqlsplit[i].Replace("Password=", ""))
            //            );
            //    }
            //    _decodeSqlstring += sqlsplit[i] + ";";
            //}

            _decodeSqlstring = SaveDBConnectionString;  //0交易 1基本資料
        

            _decodeSqlstring = "Connection Timeout=30;" + _decodeSqlstring;
        




 
            sqlConn = new  MySqlConnection(_decodeSqlstring);
            sqlConnDBConnExcute = new MySqlConnection(_decodeSqlstring);

            sqlcmdInsertOrderReplyDetail.CommandTimeout = 120;
            sqlcmdInsertOrderReplyDetail.CommandText = getSqlcmdInsertOrderReplyDetail();
            sqlcmdInsertOrderReplyDetail.Connection = new MySqlConnection(_decodeSqlstring);// sqlConnDBConnExcute;



 
            
        }

        void _QDetail_ParameterExcute(AccountItem ff)
        {
            try
            {
                if (ff.CashItem.TYPE == "")  //委託明細
                {
                    execDBInsertOrderReplyDetail(ff);

                }
                else
                {
                   

                }
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("SaveDBInfo", "_QDetail_ParameterExcute" + ex.Message);

            }
        }

        void _Q_ParameterExcute(SaveDBItem ff)
        {
            try
            {

              
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("SaveDBInfo", "_Q_ParameterExcute" + ex.Message);

            }

        }
 
        private string getSqlcmdInsertOrderReplyDetail()
        {
            string sql = "";
            sql = @"INSERT INTO  ORDERREPLYDETAIL
           (TRADEDATE
           ,ORDERNO
           ,ORDERTIME
           ,BROKERID
           ,INVESTORACNO
           ,SUBACT
            ,EXECTYPE
           ,BS
           ,PRODUCTKIND
           ,SECURITYEXCHANGE
           ,SECURITYTYPE1
           ,SYMBOL1
           ,MATURITYMONTHYEAR1
           ,PUTORCALL1
           ,STRIKEPRICE1
           ,SIDE1
           ,SECURITYTYPE2
           ,SYMBOL2
           ,MATURITYMONTHYEAR2
           ,PUTORCALL2
           ,STRIKEPRICE2
           ,SIDE2
           ,PRICE
           ,STOPPRICE
           ,ORDERQTY
           ,AFTERQTY
           ,STATUSCODE
           ,ORDERSTATUS
           ,CLORDID
           ,ORICLORDID
           ,OPENCLOSE
           ,TIMEINFORCE
           ,ORDERTYPE
           ,EXPIREDATE
           ,DTRADE
           ,MDATE
           ,SEQ
           ,SOURCECODE
           ,IP
           ,ORDERID
           ,TARGETID
           ,ACCOUNT
           ,T2
           ,T3
           ,T4
           ,T5
           ,DATA
           ,CADATA
           ,ID)
     VALUES
           (DATE_FORMAT(NOW(),'%Y%m%d')
           ,@ORDERNO
,@ORDERTIME
,@BROKERID
,@INVESTORACNO
,@SUBACT
,@EXECTYPE
,@BS
,@PRODUCTKIND
,@SECURITYEXCHANGE
,@SECURITYTYPE1
,@SYMBOL1
,@MATURITYMONTHYEAR1
,@PUTORCALL1
,@STRIKEPRICE1
,@SIDE1
,@SECURITYTYPE2
,@SYMBOL2
,@MATURITYMONTHYEAR2
,@PUTORCALL2
,@STRIKEPRICE2
,@SIDE2
,@PRICE
,@STOPPRICE
,@ORDERQTY
,@AFTERQTY
,@STATUSCODE
,@ORDERSTATUS
,@CLORDID
,@ORICLORDID
,@OPENCLOSE
,@TIMEINFORCE
,@ORDERTYPE
,@EXPIREDATE
,@DTRADE
,now()    
,@SEQ
,@SOURCECODE
,@IP
,@ORDERID
,@TARGETID
,@ACCOUNT
,@T2
,@T3
,@T4
,@T5
,@DATA
,@CADATA
,@ID)";
            return sql;
        }
 
        private void initInsertOrderReplyDetail()
        {

            sqlcmdInsertOrderReplyDetail = new MySqlCommand();

            sqlcmdInsertOrderReplyDetail.Parameters.Add("@TRADEDATE",MySqlDbType.VarChar);
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@ORDERNO", MySqlDbType.VarChar);
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@ORDERTIME", MySqlDbType.VarChar);
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@BROKERID", MySqlDbType.VarChar);
            
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@INVESTORACNO", MySqlDbType.VarChar);
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@SUBACT", MySqlDbType.VarChar);
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@EXECTYPE", MySqlDbType.VarChar);
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@BS", MySqlDbType.VarChar);
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@PRODUCTKIND", MySqlDbType.VarChar);
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@SECURITYEXCHANGE", MySqlDbType.VarChar);
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@SECURITYTYPE1", MySqlDbType.VarChar);
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@SYMBOL1", MySqlDbType.VarChar);
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@MATURITYMONTHYEAR1", MySqlDbType.VarChar);
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@PUTORCALL1", MySqlDbType.VarChar);
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@STRIKEPRICE1", MySqlDbType.Decimal);
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@SIDE1", MySqlDbType.VarChar);
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@SECURITYTYPE2", MySqlDbType.VarChar);
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@SYMBOL2", MySqlDbType.VarChar);
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@MATURITYMONTHYEAR2", MySqlDbType.VarChar);
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@PUTORCALL2", MySqlDbType.VarChar);
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@STRIKEPRICE2", MySqlDbType.Decimal);
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@SIDE2", MySqlDbType.VarChar);
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@PRICE", MySqlDbType.Decimal);
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@STOPPRICE", MySqlDbType.Decimal);
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@ORDERQTY", MySqlDbType.Int16);
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@AFTERQTY", MySqlDbType.Int16);
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@STATUSCODE", MySqlDbType.VarChar);
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@ORDERSTATUS", MySqlDbType.VarChar);
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@CLORDID", MySqlDbType.VarChar);
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@ORICLORDID", MySqlDbType.VarChar);
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@OPENCLOSE", MySqlDbType.VarChar);
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@TIMEINFORCE", MySqlDbType.VarChar);
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@ORDERTYPE", MySqlDbType.VarChar);
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@EXPIREDATE", MySqlDbType.VarChar);
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@DTRADE", MySqlDbType.VarChar);
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@SEQ", MySqlDbType.VarChar);
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@SOURCECODE", MySqlDbType.VarChar);
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@IP", MySqlDbType.VarChar);
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@ORDERID", MySqlDbType.VarChar);
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@TARGETID", MySqlDbType.VarChar);
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@ACCOUNT", MySqlDbType.VarChar);
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@T2", MySqlDbType.VarChar);
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@T3", MySqlDbType.VarChar);
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@T4", MySqlDbType.VarChar);
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@T5", MySqlDbType.VarChar);
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@DATA", MySqlDbType.VarChar);
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@CADATA", MySqlDbType.VarChar);
            sqlcmdInsertOrderReplyDetail.Parameters.Add("@ID", MySqlDbType.VarChar);
 

        }
 
        public bool execDBInsertOrderReplyDetail(AccountItem item)
        {
            bool blnSuccess = false;
            long startTime = Date.NowMS();

            try
            {

                //OpenConnectionExcute();
                OpenConnection(sqlcmdInsertOrderReplyDetail.Connection);
                

                sqlcmdInsertOrderReplyDetail.Parameters["@TRADEDATE"].Value = item.FOrderItem.TRADEDATE;
                sqlcmdInsertOrderReplyDetail.Parameters["@ORDERNO"].Value = item.FOrderItem.ORDERNO;
                sqlcmdInsertOrderReplyDetail.Parameters["@ORDERTIME"].Value = item.FOrderItem.ORDERTIME;
                sqlcmdInsertOrderReplyDetail.Parameters["@BROKERID"].Value = item.FOrderItem.BROKERID;
                sqlcmdInsertOrderReplyDetail.Parameters["@INVESTORACNO"].Value = item.FOrderItem.INVESTORACNO;
                sqlcmdInsertOrderReplyDetail.Parameters["@SUBACT"].Value = item.FOrderItem.SUBACT;
                sqlcmdInsertOrderReplyDetail.Parameters["@EXECTYPE"].Value = item.FOrderItem.EXECTYPE;
                sqlcmdInsertOrderReplyDetail.Parameters["@BS"].Value = item.FOrderItem.BS;
                sqlcmdInsertOrderReplyDetail.Parameters["@PRODUCTKIND"].Value = item.FOrderItem.PRODUCTKIND;
                sqlcmdInsertOrderReplyDetail.Parameters["@SECURITYEXCHANGE"].Value = item.FOrderItem.SECURITYEXCHANGE;
                sqlcmdInsertOrderReplyDetail.Parameters["@SECURITYTYPE1"].Value = item.FOrderItem.SECURITYTYPE1;
                sqlcmdInsertOrderReplyDetail.Parameters["@SYMBOL1"].Value = item.FOrderItem.SYMBOL1;
                sqlcmdInsertOrderReplyDetail.Parameters["@MATURITYMONTHYEAR1"].Value = item.FOrderItem.MATURITYMONTHYEAR1;
                sqlcmdInsertOrderReplyDetail.Parameters["@PUTORCALL1"].Value = item.FOrderItem.PUTORCALL1;
                sqlcmdInsertOrderReplyDetail.Parameters["@STRIKEPRICE1"].Value = item.FOrderItem.STRIKEPRICE1;
                sqlcmdInsertOrderReplyDetail.Parameters["@SIDE1"].Value = item.FOrderItem.SIDE1;
                sqlcmdInsertOrderReplyDetail.Parameters["@SECURITYTYPE2"].Value = item.FOrderItem.SECURITYTYPE2;
                sqlcmdInsertOrderReplyDetail.Parameters["@SYMBOL2"].Value = item.FOrderItem.SYMBOL2;
                sqlcmdInsertOrderReplyDetail.Parameters["@MATURITYMONTHYEAR2"].Value = item.FOrderItem.MATURITYMONTHYEAR2;
                sqlcmdInsertOrderReplyDetail.Parameters["@PUTORCALL2"].Value = item.FOrderItem.PUTORCALL2;
                sqlcmdInsertOrderReplyDetail.Parameters["@STRIKEPRICE2"].Value = item.FOrderItem.STRIKEPRICE2;
                sqlcmdInsertOrderReplyDetail.Parameters["@SIDE2"].Value = item.FOrderItem.SIDE2;
                sqlcmdInsertOrderReplyDetail.Parameters["@PRICE"].Value = item.FOrderItem.PRICE;
                sqlcmdInsertOrderReplyDetail.Parameters["@STOPPRICE"].Value = item.FOrderItem.STOPPRICE;
                sqlcmdInsertOrderReplyDetail.Parameters["@ORDERQTY"].Value = item.FOrderItem.ORDERQTY;
                sqlcmdInsertOrderReplyDetail.Parameters["@AFTERQTY"].Value = item.FOrderItem.LEAVESQTY;
                sqlcmdInsertOrderReplyDetail.Parameters["@STATUSCODE"].Value = item.FOrderItem.STATUSCODE;
                sqlcmdInsertOrderReplyDetail.Parameters["@ORDERSTATUS"].Value = item.FOrderItem.ORDERSTATUS.Length > 70 ? item.FOrderItem.ORDERSTATUS.Substring(0, 70) : item.FOrderItem.ORDERSTATUS;
                sqlcmdInsertOrderReplyDetail.Parameters["@CLORDID"].Value = item.FOrderItem.CLORDID;
                sqlcmdInsertOrderReplyDetail.Parameters["@ORICLORDID"].Value = item.FOrderItem.ORICLORDID;
                sqlcmdInsertOrderReplyDetail.Parameters["@OPENCLOSE"].Value = item.FOrderItem.OPENCLOSE;
                sqlcmdInsertOrderReplyDetail.Parameters["@TIMEINFORCE"].Value = item.FOrderItem.TIMEINFORCE;
                sqlcmdInsertOrderReplyDetail.Parameters["@ORDERTYPE"].Value = item.FOrderItem.ORDERTYPE;
                sqlcmdInsertOrderReplyDetail.Parameters["@EXPIREDATE"].Value = item.FOrderItem.EXPIREDATE;
                sqlcmdInsertOrderReplyDetail.Parameters["@DTRADE"].Value = item.FOrderItem.DTRADE;
                sqlcmdInsertOrderReplyDetail.Parameters["@SEQ"].Value = item.SEQ;
                sqlcmdInsertOrderReplyDetail.Parameters["@SOURCECODE"].Value = item.FOrderItem.SOURCECODE;
                sqlcmdInsertOrderReplyDetail.Parameters["@IP"].Value = item.FOrderItem.IP;
                sqlcmdInsertOrderReplyDetail.Parameters["@ORDERID"].Value = item.FOrderItem.ORDERID;
                sqlcmdInsertOrderReplyDetail.Parameters["@TARGETID"].Value = item.FOrderItem.TARGETID;
                sqlcmdInsertOrderReplyDetail.Parameters["@ACCOUNT"].Value = item.FOrderItem.ACCOUNT;
                sqlcmdInsertOrderReplyDetail.Parameters["@T2"].Value = item.T2;
                sqlcmdInsertOrderReplyDetail.Parameters["@T3"].Value = item.T3;
                sqlcmdInsertOrderReplyDetail.Parameters["@T4"].Value = item.T4;
                sqlcmdInsertOrderReplyDetail.Parameters["@T5"].Value = item.T5;
                sqlcmdInsertOrderReplyDetail.Parameters["@DATA"].Value = item.FOrderItem.DATA;
                sqlcmdInsertOrderReplyDetail.Parameters["@CADATA"].Value = item.FOrderItem.CADATA; 
              sqlcmdInsertOrderReplyDetail.Parameters["@ID"].Value = item.FOrderItem.ID;  
                                             
                                             
                                             




                int count = sqlcmdInsertOrderReplyDetail.ExecuteNonQuery();
                if (count > 0)
                    blnSuccess = true;
                else
                    blnSuccess = false;
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("SaveDBError" + _count, string.Format("sqlcmdInsertOrderReplyDetail {0},{1},{2} ", Date.NowMS() - startTime
                    , item.OrderItem.WEBCODE + item.OrderItem.NETWORKID + item.OrderItem.NEWWEBCODE + item.OrderItem.NEWNETWORKID, ex.Message));
                blnSuccess = false;
            }
            finally
            {
                DataAgent._LM.WriteLog("SaveDBInfo" + _count, string.Format("sqlcmdInsertOrderReplyDetail {0},{1} ", Date.NowMS() - startTime
                    , item.OrderItem.WEBCODE + item.OrderItem.NETWORKID + item.OrderItem.NEWWEBCODE + item.OrderItem.NEWNETWORKID));
                sqlcmdInsertOrderReplyDetail.Connection.Close();
            }
            return blnSuccess;
        }


         
        object execDBInsertReOrderReplylocker = new object();

 
    
        public string get_md5(string inputstr)
        {
            MD5 md5Hasher = MD5.Create();
            byte[] data = md5Hasher.ComputeHash(Encoding.Default.GetBytes(inputstr));
            StringBuilder sBuilder = new StringBuilder();

            for (int i = 0; i < data.Length; i++)
            {
                sBuilder.Append(data[i].ToString("x2"));
            }

            md5Hasher = null;

            return Convert.ToString(sBuilder);
        }
        ~SaveDB()
        {
            SaveDBDispose();
        }



        public void SaveDBDispose()
        {



            DataAgent._LM.CloseWriteLog("SaveDBError" + _count);
            DataAgent._LM.CloseWriteLog("SaveDBInfo" + _count);
            if (_Q != null)
            {
                _Q.ParameterExcute -= new QueuePoolByLock<SaveDBItem>.ParameterHandler(_Q_ParameterExcute);

                _Q.Dispose();
            }
            if (_QDetail != null)
            {

                _QDetail.ParameterExcute -= new QueuePoolByLock<AccountItem>.ParameterHandler(_QDetail_ParameterExcute);
                _QDetail.Dispose();
            }

 


            GC.SuppressFinalize(this);

        }

        /// <summary>
        /// 外部資訊傳入
        /// </summary>
        public void PutData2Queue(SaveDBItem data)
        {
            try
            {
                _Q.PutData2Queue(data);
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("SaveDBError", ex.StackTrace.ToString() + "/" + ex.ToString());

            }
        }

        public void PutData2QueueDetail(AccountItem data)
        {
            try
            {
                _QDetail.PutData2Queue(data);
            }
            catch (Exception ex)
            {
                DataAgent._LM.WriteLog("SaveDBError", ex.StackTrace.ToString() + "/" + ex.ToString());

            }
        }


        private void OpenFutureConnection()
        {
        FutureConnection:
            try
            {
                if (sqlFutureDBConn.State != ConnectionState.Open)
                {
                    sqlFutureDBConn.Open();
                    _ConnectCount = 0;
                }
            }
            catch (Exception ex)
            {
                if (_ConnectCount <= MAXCONNECTCOUNT)
                {
                    _ConnectCount++;
                    goto FutureConnection;
                }
                else
                {
                    throw ex;
                }
            }
        }

        private void OpenFutureConnectionExcute()
        {
        FutureConnectionExcute:
            try
            {
                if (sqlFutureDBConnExcute.State != ConnectionState.Open)
                {
                    sqlFutureDBConnExcute.Open();
                    _ConnectCount = 0;
                }
            }
            catch (Exception ex)
            {
                if (_ConnectCount <= MAXCONNECTCOUNT)
                {
                    _ConnectCount++;
                    goto FutureConnectionExcute;
                }
                else
                {
                    throw ex;
                }
            }
        }
        private void OpenConnection()
        {
        connect:
            try
            {
                if (sqlConn.State != ConnectionState.Open)
                {
                    sqlConn.Open();
                    _ConnectCount = 0;
                }
            }
            catch (Exception ex)
            {
                if (_ConnectCount <= MAXCONNECTCOUNT)
                {
                    _ConnectCount++;
                    goto connect;
                }
                else
                {
                    throw ex;
                }
            }
        }

        private void OpenConnectionExcute()
        {
        connectExcute:
            try
            {
                if (sqlConnDBConnExcute.State != ConnectionState.Open)
                {
                    sqlConnDBConnExcute.Open();
                    _ConnectCount = 0;
                }
            }
            catch (Exception ex)
            {
                if (_ConnectCount <= MAXCONNECTCOUNT)
                {
                    _ConnectCount++;
                    goto connectExcute;
                }
                else
                {
                    throw ex;
                }
            }
        }

        private void OpenConnection(MySqlConnection pSqlconn)
        {
        connect:
            try
            {
                if (pSqlconn.State != ConnectionState.Open)
                {
                    pSqlconn.Open();
                    _ConnectCount = 0;
                }
            }
            catch (Exception ex)
            {
                if (_ConnectCount <= MAXCONNECTCOUNT)
                {
                    _ConnectCount++;
                    goto connect;
                }
                else
                {
                    throw ex;
                }
            }
        }




        private void onSaveDBEvent(string networkid, DataTable dt)
        {
            if (SaveDBEvent != null)
                SaveDBEvent(networkid, dt);
        }
    }
}
