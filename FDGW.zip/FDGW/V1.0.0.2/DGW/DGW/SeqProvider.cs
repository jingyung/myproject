﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
namespace com.ddsc.tool
{
    public class SeqProvider : IDisposable
    {
        object Locker = new object();
        int _seq = 0;
        private System.IO.FileStream _seqNumsFile;
        string _LogName = "";
        public SeqProvider(string filename, string path)
        {
            if (!System.IO.Directory.Exists(path))
                System.IO.Directory.CreateDirectory(path);

            _LogName = System.IO.Path.Combine(path, filename + ".txt");
            open();
        }
        private void open()
        {

            if (System.IO.File.Exists(_LogName))
            {
                using (System.IO.StreamReader seqNumReader = new System.IO.StreamReader(_LogName))
                {
                    string s = seqNumReader.ReadToEnd().Trim();
                    if (s.Length > 0)
                        _seq = Convert.ToInt32(s);
                    else
                        _seq = 0;
                }
            }
            _seqNumsFile = new System.IO.FileStream(_LogName, System.IO.FileMode.OpenOrCreate, System.IO.FileAccess.ReadWrite);

        }
        public int getSeq()
        {
            int s = 0;
            lock (Locker)
            {
                  s = ++_seq;
                setSeqNum();
            }
            return s;
        }
        private void setSeqNum()
        {
            _seqNumsFile.Seek(0, System.IO.SeekOrigin.Begin);
            System.IO.StreamWriter writer = new System.IO.StreamWriter(_seqNumsFile);
            string data = _seq.ToString("D20");
            _seqNumsFile.Write(ASCIIEncoding.ASCII.GetBytes(data), 0, 20);
            writer.Flush();
        }
        public void Dispose()
        {
            _seqNumsFile.Dispose();

        }
    }
}
