﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net.Sockets;
namespace com.ddsc.TradeSocketServer
{
    public partial class ShowThings : Form
    {
        public ShowThings(AccountCore ac)
        {
            InitializeComponent();



            if (ac.SI != null)
            {
                SetSI(ac.SI);
            }
            if (ac.SU != null)
            {
                SetSU(ac.SU);
            }
            if (ac.IS != null)
            {
                SetIS(ac.IS);
            }
            if (ac.US != null)
            {
                SetUS(ac.US);
            }
            if (ac.UI != null)
            {
                SetUI(ac.UI);
            }
            if (ac.NetworkIdItem != null)
            {
                SetNetworkIdItem(ac.NetworkIdItem);
            }
            tvMain.ExpandAll();
        }

        private void SetSI(Dictionary<SocketAsyncEventArgs, Dictionary<string, string>> SI)
        {
            AddMainNode("SI");
            foreach (SocketAsyncEventArgs key1 in SI.Keys)
            {
                AddNode("SI", key1.AcceptSocket.RemoteEndPoint.ToString());
                foreach (string key2 in SI[key1].Keys)
                {
                    AddNode("SI", key1.AcceptSocket.RemoteEndPoint.ToString(), key2 + "-" + SI[key1][key2]);
                }
            }

        }

        private void SetSU(Dictionary<SocketAsyncEventArgs, Dictionary<string, string>> SU)
        {
            AddMainNode("SU");
            foreach (SocketAsyncEventArgs key1 in SU.Keys)
            {
                AddNode("SU", key1.AcceptSocket.RemoteEndPoint.ToString());
                foreach (string key2 in SU[key1].Keys)
                {
                    AddNode("SU", key1.AcceptSocket.RemoteEndPoint.ToString(), key2 + "-" + SU[key1][key2]);
                }
            }

        }

        private void SetIS(Dictionary<string, Dictionary<int, SocketAsyncEventArgs>> IS)
        {
            AddMainNode("IS");
            foreach (string key1 in IS.Keys)
            {
                AddNode("IS", key1);
                foreach (int key2 in IS[key1].Keys)
                {
                    AddNode("IS", key1, key2.ToString() + "-" + IS[key1][key2].AcceptSocket.RemoteEndPoint.ToString());
                }
            }

        }

        private void SetUS(Dictionary<string, Dictionary<int, SocketAsyncEventArgs>> US)
        {
            AddMainNode("US");
            foreach (string key1 in US.Keys)
            {
                AddNode("US", key1);
                foreach (int key2 in US[key1].Keys)
                {
                   
                    AddNode("US", key1, key2.ToString() + "-" + US[key1][key2].AcceptSocket.RemoteEndPoint.ToString());
                }
            }

        }

        private void SetUI(Dictionary<string, Dictionary<string, string>> UI)
        {
            AddMainNode("UI");
            foreach (string key1 in UI.Keys)
            {
                AddNode("UI", key1);
                foreach (string key2 in UI[key1].Keys)
                {
                    AddNode("UI", key1, key2+ "-" + UI[key1][key2]);
                }
            }

        }

        private void SetNetworkIdItem(Dictionary<string, NetWorkIdItem> NetworkIdItem)
        {
            AddMainNode("NetworkIdItem");
            foreach (string key1 in NetworkIdItem.Keys)
            {
                AddNode("NetworkIdItem", key1);
                AddNode("NetworkIdItem", key1, "OldSeq:" + NetworkIdItem[key1].OldSeq + " NewSeq:" + NetworkIdItem[key1].NewSeq + " UserId:" + NetworkIdItem[key1].UserId);
            }

        }

        private void AddNode(string key, string text)
        {
            TreeNode tn = new TreeNode();
            tn.Text = text;
            tn.Name = text;
            tvMain.Nodes[key].Nodes.Add(tn);
        }
        private void AddNode(string key1, string key2, string text)
        {
            TreeNode tn = new TreeNode();
            tn.Text = text;
            tn.Name = text;
            tvMain.Nodes[key1].Nodes[key2].Nodes.Add(tn);
        }

        private void AddMainNode(string main)
        {
            TreeNode tn = new TreeNode();
            tn.Text = main;
            tn.Name = main;
            tvMain.Nodes.Add(tn);
        }
    }
}
