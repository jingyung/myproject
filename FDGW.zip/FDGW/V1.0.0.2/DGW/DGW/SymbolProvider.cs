﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
namespace com.ddsc.TradeSocketServer
{
    public class SymbolData
    {
        public SymbolData()
        {
            SECURITYEXCHANGE = "";
            SYMBOL = "";
            SECURITYTYPE = "";
            PEXCH = "";
            PSYMBOL = "";
            DDSCEXCH = "";
            DDSCSYMBOL = "";
            CHNAME = "";
            CHSNAME = "";
            FCMNO = "";
            TICKSIZE = 0;
            POINTVALUE = 0;
            TDENOMIN = 1;
            PDENOMIN = 1;
            DDENOMIN = 1;
            TRATIO = 1;
            PRATIO = 1;
            DRATIO = 1;

        }

        public SymbolData(DataRow dr)
        {
            SECURITYEXCHANGE = dr["SECURITYEXCHANGE"].ToString().Trim();
            SYMBOL = dr["SYMBOL"].ToString().Trim();
            SECURITYTYPE = dr["SECURITYTYPE"].ToString().Trim();
            PEXCH = dr["PEXCH"].ToString().Trim();
            PSYMBOL = dr["PSYMBOL"].ToString().Trim();
            DDSCEXCH = dr["DDSCEXCH"].ToString().Trim();
            DDSCSYMBOL = dr["DDSCSYMBOL"].ToString().Trim();
            CHNAME = dr["CHNAME"].ToString().Trim();
            CHSNAME = dr["CHSNAME"].ToString().Trim();
            FCMNO = dr["FCMNO"].ToString().Trim();
         //   TICKSIZE = Decimal.Parse(dr["TICKSIZE"].ToString());
         
            POINTVALUE = Decimal.Parse(dr["POINTVALUE"].ToString());
            TRATIO = Decimal.Parse(dr["TRATIO"].ToString());
            TDENOMIN = Decimal.Parse(dr["TDENOMIN"].ToString());
            PDENOMIN = Decimal.Parse(dr["PDENOMIN"].ToString());
            DDENOMIN = Decimal.Parse(dr["DDENOMIN"].ToString());
            PRATIO = Decimal.Parse(dr["PRATIO"].ToString());
            DRATIO = Decimal.Parse(dr["DRATIO"].ToString());

        }

        public string SECURITYEXCHANGE { get; set; }
        public string SYMBOL { get; set; }
        public string SECURITYTYPE { get; set; }
        public string PEXCH { get; set; }
        public string PSYMBOL { get; set; }
        public string DDSCEXCH { get; set; }
        public string DDSCSYMBOL { get; set; }
        public string CHNAME { get; set; }
        public string CHSNAME { get; set; }
        public string FCMNO { get; set; }
        public decimal TICKSIZE { get; set; }
        public decimal POINTVALUE { get; set; }
        public decimal TRATIO { get; set; }
        public decimal TDENOMIN { get; set; }
        public decimal PDENOMIN { get; set; }
        public decimal DDENOMIN { get; set; }
        public decimal PRATIO { get; set; }
        public decimal DRATIO { get; set; }
 
    }

    public class SymbolProvider
    {
        Dictionary<string, SymbolData> _Symbol2DDSC;

        Dictionary<string, SymbolData> _DDSCl2Symbol;

        Dictionary<string, SymbolData> _Pats2Symbol;


        public SymbolProvider()
        {
            _Symbol2DDSC = new Dictionary<string, SymbolData>();
            _DDSCl2Symbol = new Dictionary<string, SymbolData>();
            _Pats2Symbol = new Dictionary<string, SymbolData>();

            try
            {
                string ConnectionString = DataAgent.DEFAULTProvider.GetString("ConfigSqlConnectionString");
                DataTable dt = new DataTable();
                DataSet ds = new DataSet();

                string strSqlCommand = "select * from SYMBOLDATA";
                SqlDataAdapter adp = new SqlDataAdapter(strSqlCommand, ConnectionString);
                adp.Fill(dt);
                if (dt.Rows.Count > 0)
                {

                    foreach (DataRow dr in dt.Rows)
                    {
                        string SECURITYEXCHANGE = dr["SECURITYEXCHANGE"].ToString().Trim();
                        string SECURITYTYPE = dr["SECURITYTYPE"].ToString().Trim();
                        string SYMBOL = dr["SYMBOL"].ToString().Trim();
                        string PEXCH = dr["PEXCH"].ToString().Trim();
                        string DDSCEXCH = dr["DDSCEXCH"].ToString().Trim();
                        string DDSCSYMBOL = dr["DDSCSYMBOL"].ToString().Trim();

                        _Symbol2DDSC[SECURITYEXCHANGE + SECURITYTYPE + SYMBOL] = new SymbolData(dr);
                        _DDSCl2Symbol[DDSCEXCH + SECURITYTYPE + DDSCSYMBOL] = new SymbolData(dr);
                        _Pats2Symbol[PEXCH + SECURITYTYPE + SYMBOL] = new SymbolData(dr);

                    }
                }

            }
            catch (Exception ex)
            {
            }

        }


        public SymbolData GetSymbolDataForSymbol(string SECURITYEXCHANGE, string SECURITYTYPE, string SYMBOL)
        {
            SECURITYTYPE = SECURITYTYPE == "FUT" ? "1" : SECURITYTYPE;
            SECURITYTYPE = SECURITYTYPE == "OPT" ? "2" : SECURITYTYPE;
            string key = SECURITYEXCHANGE + SECURITYTYPE + SYMBOL;
            SymbolData data = null; ;
            if (_Symbol2DDSC.TryGetValue(key, out data))
                return data;
            else
                return null;
        }
        public SymbolData GetSymbolDataForPatsSymbol(string PSECURITYEXCHANGE, string SECURITYTYPE, string SYMBOL)
        {
            SECURITYTYPE = SECURITYTYPE == "FUT" ? "1" : SECURITYTYPE;
            SECURITYTYPE = SECURITYTYPE == "OPT" ? "2" : SECURITYTYPE;
            string key = PSECURITYEXCHANGE + SECURITYTYPE + SYMBOL;
            SymbolData data = null; ;
            if (_Pats2Symbol.TryGetValue(key, out data))
                return data;
            else
                return null;
        }
        public SymbolData GetSymbolDataForDDSCSymbol(string DDSCSECURITYEXCHANGE, string SECURITYTYPE, string DDSCSYMBOL)
        {
            SECURITYTYPE = SECURITYTYPE == "FUT" ? "1" : SECURITYTYPE;
            SECURITYTYPE = SECURITYTYPE == "OPT" ? "2" : SECURITYTYPE;
            string key = DDSCSECURITYEXCHANGE + SECURITYTYPE + DDSCSYMBOL;
            SymbolData data = null; ;
            if (_DDSCl2Symbol.TryGetValue(key, out data))
                return data;
            else
                return null;
        }


        public static decimal fractionPrice2Price(decimal fractionPrice2Price, decimal Denominator, decimal Radio)
        {
            fractionPrice2Price = fractionPrice2Price / Radio;
            if (Denominator == 1) //分母1，不用轉換
            {
                return fractionPrice2Price;
            }
            else
            {

                string strpricestr = fractionPrice2Price.ToString("0.##########");
                string[] strpricestrs = strpricestr.Split('.');

                if (strpricestrs.Length == 1) //沒有小數點
                {
                    return fractionPrice2Price;
                }
                else
                {
                    int strDenominator = Denominator.ToString().Length;
                    decimal f = (decimal)(Math.Pow(10, strDenominator));//取得分母位數
                    decimal num = decimal.Parse(strpricestrs[0]);//取得整數
                    decimal r = decimal.Parse(strpricestrs[1]) / Denominator;//運算 decimal*分母=分子
                    r = (r / f);//運算分子真實位數   例如 100 1/32   不是100.1 而是100.01
                    return num = num + r;
                }


            }
            return 0;
        }



        public static decimal Price2fractionPrice(decimal price, decimal Denominator, decimal Radio)
        {
            if (Denominator == 1) //分母1，不用轉換
            {
                return price * Radio;
            }
            else
            {

                string strpricestr = price.ToString("0.##########");
                string[] strpricestrs = strpricestr.Split('.');

                if (strpricestrs.Length == 1) //沒有小數點
                {
                    return price * Radio;
                }
                else
                {
                    int strDenominator = Denominator.ToString().Length;
                    decimal f = (decimal)(Math.Pow(10, strDenominator));//取得分母位數
                    decimal num = decimal.Parse(strpricestrs[0]);//取得整數
                    decimal r = decimal.Parse("0." + strpricestrs[1]) * Denominator;//運算 decimal*分母=分子
                    r = (r / f);//運算分子真實位數   例如 100 1/32   不是100.1 而是100.01
                      num = num + r;
                      return num * Radio;
                }


            }
            return 0;
        }
 
    }
}
