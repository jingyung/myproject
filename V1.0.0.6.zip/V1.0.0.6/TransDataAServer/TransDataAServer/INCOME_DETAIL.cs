using System;
                                        using System.Collections.Generic;
                                        using System.Linq;
                                        using System.Text;
                                        using System.Runtime.InteropServices;
                                        namespace TransDataAServer
                                        {
                                            public class INCOME_DETAIL
                                            {
                                                public static string getSql(FileInfo.INCOME_DETAIL raw)
                                                {
                                                    try
                                                    {
                                                        string sql = string.Format(@" INSERT INTO   INCOME_DETAIL(OCCDT,FIRM,IBNO,ACTNO,CUSGROUP,TRADEID,EXH,TRDDT,ORDNO,FIRMORD,DIVIDESEQ,DTRDDT,DORDNO,DFIRMORD,DDIVIDESEQ,COMNOKIND,USEOFF,NET,BS,COMNO,COMYM,STKPRC,CALLPUT,DCOMNO,QTY,DQTY,TRDPRC1,TRDPRC2,PRTLOS,CURRENCY,DTRADE,DDTRADE,FEE,TAX,SOURCE,DSOURCE,PRPDUCTKIND,SPRPDUCTKIND,SETTLEFLAG,INCOME,OFFSEQ,DFEE,DTAX,AENO,DAENO,PREMIUM,DPREMIUM,ORDERKIND1,ORDERKIND2,UPD_DATE)VALUES
('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}','{12}','{13}','{14}','{15}','{16}','{17}','{18}','{19}','{20}','{21}','{22}','{23}','{24}','{25}','{26}','{27}','{28}','{29}','{30}','{31}','{32}','{33}','{34}','{35}','{36}','{37}','{38}','{39}','{40}','{41}','{42}','{43}','{44}','{45}','{46}','{47}','{48}',convert(char(8),getdate(),112))"
, Function.getString(raw.OCCDT).Trim()
,Function.getString(raw.FIRM).Trim()
,Function.getString(raw.IBNO).Trim()
,Function.getString(raw.ACTNO).Trim()
,Function.getString(raw.CUSGROUP).Trim()
,Function.getString(raw.TRADEID).Trim()
,Function.getString(raw.EXH).Trim()
,Function.getString(raw.TRDDT).Trim()
,Function.getString(raw.ORDNO).Trim()
,Function.getString(raw.FIRMORD).Trim()
,Function.getString(raw.DIVIDESEQ).Trim()
,Function.getString(raw.DTRDDT).Trim()
,Function.getString(raw.DORDNO).Trim()
,Function.getString(raw.DFIRMORD).Trim()
,Function.getString(raw.DDIVIDESEQ).Trim()
,Function.getString(raw.COMNOKIND).Trim()
,Function.getString(raw.USEOFF).Trim()
,Function.getString(raw.NET).Trim()
,Function.getString(raw.BS).Trim()
,Function.getString(raw.COMNO).Trim()
,Function.getString(raw.COMYM).Trim()
, Function.getPrice(7, 6, Function.getString(raw.STKPRC))
,Function.getString(raw.CALLPUT).Trim()
,Function.getString(raw.DCOMNO).Trim()
,Function.getString(raw.QTY).Trim()
,Function.getString(raw.DQTY).Trim()
, Function.getSignPrice(7,6,Function.getString(raw.TRDPRC1) )
,Function.getSignPrice(7,6,Function.getString(raw.TRDPRC2) )
,Function.getSignPrice(11,2,Function.getString(raw.PRTLOS) )
,Function.getString(raw.CURRENCY).Trim()
,Function.getString(raw.DTRADE).Trim()
,Function.getString(raw.DDTRADE).Trim()
,Function.getPrice(7,2,Function.getString(raw.FEE) )
,Function.getPrice(7,2,Function.getString(raw.TAX) )
,Function.getString(raw.SOURCE).Trim()
,Function.getString(raw.DSOURCE).Trim()
,Function.getString(raw.PRPDUCTKIND).Trim()
,Function.getString(raw.SPRPDUCTKIND).Trim()
,Function.getString(raw.SETTLEFLAG).Trim()
,Function.getSignPrice(11,2,Function.getString(raw.INCOME) )
,Function.getString(raw.OFFSEQ).Trim()
,Function.getPrice(7,2,Function.getString(raw.DFEE) )
,Function.getPrice(7,2,Function.getString(raw.DTAX))
,Function.getString(raw.AENO).Trim()
,Function.getString(raw.DAENO).Trim()
, Function.getSignPrice(11, 2, Function.getString(raw.PREMIUM))
, Function.getSignPrice(11, 2, Function.getString(raw.DPREMIUM))
, Function.getString(raw.ORDERKIND1).Trim()
, Function.getString(raw.ORDERKIND2).Trim() 
  );
                                    return sql;
                                }
                                catch (Exception ex)
                                {
                                    throw ex;
                                }
                            }
                            public static FileInfo.INCOME_DETAIL getINCOME_DETAIL(Byte[] byLine )
                                {
                                    try
                                    {
                                        FileInfo.INCOME_DETAIL INCOME_DETAIL = new FileInfo.INCOME_DETAIL();

                                        int len = Marshal.SizeOf(INCOME_DETAIL);
                                        IntPtr ptr = Marshal.AllocHGlobal(len);
                                        Marshal.Copy(byLine, 0, ptr, len); ;
                                        INCOME_DETAIL = (FileInfo.INCOME_DETAIL)Marshal.PtrToStructure(ptr, typeof(FileInfo.INCOME_DETAIL));
                                        Marshal.FreeHGlobal(ptr); 
                                        return INCOME_DETAIL;

 
                                    }
                                    catch (Exception ex)
                                    {
                                        throw ex;
                                    }
                                }

                            }
                        }

                        