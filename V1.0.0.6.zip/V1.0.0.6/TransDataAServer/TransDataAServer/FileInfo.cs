using System;
                using System.Collections.Generic;

                using System.Text;
                using System.Runtime.InteropServices;
                using System.Collections;

                namespace TransDataAServer
                {
                    public class FileInfo
                    {   
                            [StructLayoutAttribute(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
                            public struct P09F
                            {
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
                                public byte[] P09_KIND_ID;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 30)]
                                public byte[] P09_NAME;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
                                public byte[] P09_STOCK_ID;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] P09_SUBTYPE;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
                                public byte[] P09_CONTRACT_SIZE;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] P09_STATUS_CODE;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] P09_CURRENCY;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] P09_STRIKE_DECIMAIL;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] P09_PRICE_DECIMAIL;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] P09_ACCEPT_QUOTE_FLAG;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
                                public byte[] P09_BEGIN_DATE;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] P09_BLOCK_TRADE_FLAG;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] P09_EXPIRY_TYPE;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] FP09_UNDERLYING_TYPE;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
                                public byte[] FP09_MARKET_CLOSE_GROUP;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 30)]
                                public byte[] FILLER;
                            }
 
                            [StructLayoutAttribute(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
                              public struct P08
                            {
                            [MarshalAs(UnmanagedType.ByValArray, SizeConst =10)]
                            public byte[] P08_COMMODITY_ID    ;
                            [MarshalAs(UnmanagedType.ByValArray, SizeConst =6)]
                            public byte[] P08_SETTLEMENT_MONTH;
                            [MarshalAs(UnmanagedType.ByValArray, SizeConst =9)]
                            public byte[] P08_STRIKE_PRICE    ;
                            [MarshalAs(UnmanagedType.ByValArray, SizeConst =1)]
                            public byte[] P08_CP_CODE         ;
                            [MarshalAs(UnmanagedType.ByValArray, SizeConst =8)]
                            public byte[] P08_BEGIN_DATE      ;
                            [MarshalAs(UnmanagedType.ByValArray, SizeConst =8)]
                            public byte[] P08_END_DATE        ;
                            [MarshalAs(UnmanagedType.ByValArray, SizeConst =9)]
                            public byte[] P08_RAISE_PRICE     ;
                            [MarshalAs(UnmanagedType.ByValArray, SizeConst =9)]
                            public byte[] P08_FALL_PRICE      ;
                            [MarshalAs(UnmanagedType.ByValArray, SizeConst =9)]
                            public byte[] P08_PREMIUM         ;
                            [MarshalAs(UnmanagedType.ByValArray, SizeConst =9)]
                            public byte[] P08_RAISE_PRICE2    ;
                            [MarshalAs(UnmanagedType.ByValArray, SizeConst =9)]
                            public byte[] P08_FALL_PRICE2     ;
                            [MarshalAs(UnmanagedType.ByValArray, SizeConst =9)]
                            public byte[] P08_RAISE_PRICE3    ;
                            [MarshalAs(UnmanagedType.ByValArray, SizeConst =9)]
                            public byte[] P08_FALL_PRICE3     ;
                            [MarshalAs(UnmanagedType.ByValArray, SizeConst =1)]
                            public byte[] P08_PROD_KIND       ;
                            [MarshalAs(UnmanagedType.ByValArray, SizeConst =1)]
                            public byte[] P08_ACCEPT_QUOTE_FLAG;
                            [MarshalAs(UnmanagedType.ByValArray, SizeConst =1)]
                            public byte[] P08_DECIMAL_LOCATOR ;
                            [MarshalAs(UnmanagedType.ByValArray, SizeConst =5)]
                            public byte[] P08_PSEQ            ;
                            [MarshalAs(UnmanagedType.ByValArray, SizeConst =2)]
                            public byte[] P08_FLOW_GROUP       ;
                            }

                            [StructLayoutAttribute(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
                            public struct P09O
                            {
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
                                public byte[] P09_KIND_ID;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 30)]
                                public byte[] P09_NAME;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
                                public byte[] P09_STOCK_ID;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] P09_SUBTYPE;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
                                public byte[] P09_CONTRACT_SIZE;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] P09_STATUS_CODE;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] P09_CURRENCY;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] P09_STRIKE_DECIMAIL;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] P09_PRICE_DECIMAIL;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] P09_ACCEPT_QUOTE_FLAG;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
                                public byte[] P09_BEGIN_DATE;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] P09_BLOCK_TRADE_FLAG;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] P09_EXPIRY_TYPE;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] FP09_UNDERLYING_TYPE;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
                                public byte[] FP09_MARKET_CLOSE_GROUP;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 30)]
                                public byte[] FILLER;
                            }
  
           
                            [StructLayoutAttribute(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
                            public struct ACPARTY
                            {
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
                                public byte[] PARTY_NMODEID;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
                                public byte[] PARTY_NCOMPID;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
                                public byte[] PARTY_NEMCUID;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
                                public byte[] PARTY_NTYPEID;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
                                public byte[] PARTY_NPACOID;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst =12)]
                                public byte[] PARTY_NPACUID; 
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
                                public byte[] PARTY_NINFOVL; 
                                
                            }
                            [StructLayoutAttribute(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
                            public struct INCOME_DETAIL
                            {
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
                                public byte[] OCCDT;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
                                public byte[] FIRM;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
                                public byte[] IBNO;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
                                public byte[] ACTNO;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
                                public byte[] CUSGROUP;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
                                public byte[] TRADEID;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
                                public byte[] EXH;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
                                public byte[] TRDDT;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
                                public byte[] ORDNO;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
                                public byte[] FIRMORD;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
                                public byte[] DIVIDESEQ;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
                                public byte[] DTRDDT;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
                                public byte[] DORDNO;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
                                public byte[] DFIRMORD;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
                                public byte[] DDIVIDESEQ;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] COMNOKIND;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] USEOFF;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] NET;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] BS;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
                                public byte[] COMNO;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
                                public byte[] COMYM;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 13)]
                                public byte[] STKPRC;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] CALLPUT;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
                                public byte[] DCOMNO;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
                                public byte[] QTY;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
                                public byte[] DQTY;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 14)]
                                public byte[] TRDPRC1;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 14)]
                                public byte[] TRDPRC2;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 14)]
                                public byte[] PRTLOS;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
                                public byte[] CURRENCY;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] DTRADE;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] DDTRADE;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
                                public byte[] FEE;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
                                public byte[] TAX;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] SOURCE;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] DSOURCE;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] PRPDUCTKIND;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] SPRPDUCTKIND;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] SETTLEFLAG;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 14)]
                                public byte[] INCOME;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 22)]
                                public byte[] OFFSEQ;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
                                public byte[] DFEE;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
                                public byte[] DTAX;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
                                public byte[] AENO;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
                                public byte[] DAENO;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 14)]
                                public byte[] PREMIUM;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 14)]
                                public byte[] DPREMIUM;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
                                public byte[] ORDERKIND1;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
                                public byte[] ORDERKIND2;
                            }
                            [StructLayoutAttribute(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
                            public struct WORKDAY
                            {
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
                                public byte[] DATE;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] DOMESTICFLAG;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] FOREIGNFLAG;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] WEEK;
                            }
                        
                            [StructLayoutAttribute(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
                              public struct CASHLOG
                            {
                            [MarshalAs(UnmanagedType.ByValArray, SizeConst =8)]
                            public byte[] TRDDT;
                            [MarshalAs(UnmanagedType.ByValArray, SizeConst =7)]
                            public byte[] FIRM;
                            [MarshalAs(UnmanagedType.ByValArray, SizeConst =3)]
                            public byte[] IBNO;
                            [MarshalAs(UnmanagedType.ByValArray, SizeConst =7)]
                            public byte[] ACTNO;
                            [MarshalAs(UnmanagedType.ByValArray, SizeConst =3)]
                            public byte[] CUSGROUP;
                            [MarshalAs(UnmanagedType.ByValArray, SizeConst =6)]
                            public byte[] TRADEID;
                            [MarshalAs(UnmanagedType.ByValArray, SizeConst =1)]
                            public byte[] CDTYPE;
                            [MarshalAs(UnmanagedType.ByValArray, SizeConst =3)]
                            public byte[] CURRENCY;
                            [MarshalAs(UnmanagedType.ByValArray, SizeConst =14)]
                            public byte[] ORIGNAMT;
                            [MarshalAs(UnmanagedType.ByValArray, SizeConst =14)]
                            public byte[] NTAMT;
                            [MarshalAs(UnmanagedType.ByValArray, SizeConst =6 )]
                            public byte[] NETWORKID;
                            [MarshalAs(UnmanagedType.ByValArray, SizeConst =7)]
                            public byte[] BANK;
                            [MarshalAs(UnmanagedType.ByValArray, SizeConst =20)]
                            public byte[] BANKACTNO;
                            [MarshalAs(UnmanagedType.ByValArray, SizeConst =7)]
                            public byte[] TOBANK;
                            [MarshalAs(UnmanagedType.ByValArray, SizeConst =20)]
                            public byte[] TOBANKACTNO;
                            [MarshalAs(UnmanagedType.ByValArray, SizeConst =10)]
                            public byte[] TOBANKNAME;
                            [MarshalAs(UnmanagedType.ByValArray, SizeConst =9)]
                            public byte[] SLIPNO;
                            [MarshalAs(UnmanagedType.ByValArray, SizeConst =1)]
                            public byte[] SOURCECODE;
                            [MarshalAs(UnmanagedType.ByValArray, SizeConst =1)]
                            public byte[] FLOPPYFLAG;
                            }

                            [StructLayoutAttribute(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
                            public struct CUSDATA
                            {
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] OCCTP;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
                                public byte[] FIRM;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
                                public byte[] ACTNO;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
                                public byte[] BROKER;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
                                public byte[] TACTNO;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
                                public byte[] IDNO;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
                                public byte[] AENO;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] SNDCHK;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
                                public byte[] APPLYDATE;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 40)]
                                public byte[] LEMAIL;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] MTYPE;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 22)]
                                public byte[] ACTNAME;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
                                public byte[] BIRTHDT;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
                                public byte[] STCRRY;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
                                public byte[] BANKNO;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
                                public byte[] BANKACNO;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
                                public byte[] BANKNO1;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
                                public byte[] BANKACNO1;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
                                public byte[] BANKNO2;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
                                public byte[] BANKACNO2;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
                                public byte[] BANKNO3;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
                                public byte[] BANKACNO3;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
                                public byte[] ODATE;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
                                public byte[] FDATE;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] DTFLAG;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
                                public byte[] SORT;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] SEX;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
                                public byte[] EDUCATION;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 42)]
                                public byte[] CONAME;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 22)]
                                public byte[] JOB;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
                                public byte[] LZIPCODE;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 82)]
                                public byte[] LADDRESS;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
                                public byte[] LTELNO;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
                                public byte[] LCELLPHONE;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
                                public byte[] LFAXNO;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
                                public byte[] CZIPCODE;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 82)]
                                public byte[] CADDRESS;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
                                public byte[] CTELNO;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] ECUST;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] MKTFLG;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
                                public byte[] PASSWORD;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] HTSFLG;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] NSKFLG;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] ITTFLG;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] ITJFLG;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] APIFLG;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
                                public byte[] BANKNOUS;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
                                public byte[] BANKACNOUS;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
                                public byte[] BANKNOUS1;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
                                public byte[] BANKACNOUS1;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
                                public byte[] BANKNOUS2;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
                                public byte[] BANKACNOUS2;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
                                public byte[] BANKNOUS3;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
                                public byte[] BANKACNOUS3; 
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
                                public byte[] BANKNOCN;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
                                public byte[] BANKACNOCN; 
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
                                public byte[] BANKNOCN1;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
                                public byte[] BANKACNOCN1;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
                                public byte[] BANKNOCN2;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
                                public byte[] BANKACNOCN2;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
                                public byte[] BANKNOCN3;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
                                public byte[] BANKACNOCN3;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] ITSFLG;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] ITPFLG;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
                                public byte[] FUSIGNCODE;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
                                public byte[] APAUTH; 
                            }

                            [StructLayoutAttribute(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
                            public struct AEDATA
                            {
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
                                public byte[] SALES_NO;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
                                public byte[] SALES;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 22)]
                                public byte[] SALS_NAME;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
                                public byte[] BRANCH_NO;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] CANCEL_FLAG;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
                                public byte[] CANCEL_DATE;
                            }

                            [StructLayoutAttribute(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
                            public struct KSCM026P
                            {
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
                                public byte[] CM026010;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
                                public byte[] CM026020;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] CM026030;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                                public byte[] CM026040;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 13)]//19
                                public byte[] CM026050;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 13)]//19
                                public byte[] CM026060;
                            }
                            [StructLayoutAttribute(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
                            public struct PWSET
                            {
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
                                public byte[] TYPE;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
                                public byte[] IDNO;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 80)]
                                public byte[] PASSWORD;
                                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
                                public byte[] PWFLAG; 

                            }
 
    }
                
                }
