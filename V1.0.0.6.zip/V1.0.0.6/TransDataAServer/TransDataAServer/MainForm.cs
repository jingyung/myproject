﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Net;
using System.Data.SqlClient;
using com.ddsc.core;
using com.ddsc.tool;
using System.Runtime.InteropServices;
using System.Xml;
using System.Xml.Linq;
namespace TransDataAServer
{
    public partial class MainForm : Form
    {
        string _TempFolder;
        private string _SysCloseTime; 
        private Timer _StartRunning;
        private string _FtpUri;
        private string _FtpAccount;
        private string _FtpPassword;
        private string _FtpUri2;
        private string _FtpAccount2;
        private string _FtpPassword2;
        private bool bolManualTime = false;
        DataTable _dtData;
        public LogManager _LM;
        List<string> lstTIMETABLE = new List<string>();
        Dictionary<string, string> dicAFTERGROUP = new Dictionary<string, string>();
        string TIMETYPE = "";
        public MainForm()
        {
            InitializeComponent();
          
            string c = string.Format("folderPath[{0}],fileName[{1}],JobName[{2}] FtpDownload Start", "qweqwe", "2", "3");
            this.Text += "(V" + Application.ProductVersion + ")";
            _LM = new LogManager();
            _LM.AddFileWriter("TransDataAServerLog", new FileWriter("TransDataAServerLog"));

            _LM.AddFileWriter("TransDataAServerErrLog", new FileWriter("TransDataAServerErrLog"));


             
            this._SysCloseTime = Properties.Settings.Default.Sys_CloseTime;
            this._TempFolder = AppDomain.CurrentDomain.BaseDirectory.ToString().TrimEnd() + "\\Log\\" + DateTime.Now.ToString("yyyyMMdd");


            this._FtpUri = Properties.Settings.Default.ftp; 
            this._FtpAccount = Properties.Settings.Default.ftpAccount;
            this._FtpPassword = Properties.Settings.Default.ftpPassword;

            this._FtpUri2 = Properties.Settings.Default.ftp2;
            this._FtpAccount2 = Properties.Settings.Default.ftpAccount2;
            this._FtpPassword2 = Properties.Settings.Default.ftpPassword2;

            lstTIMETABLE.AddRange(Properties.Settings.Default.TIMETABLE.Split('|')); 
            foreach (string str in Properties.Settings.Default.AFTERGROUP.Split('|'))
            {
                string[]  data=str.Split(':');
                if (data.Length == 2)
                    dicAFTERGROUP.Add(data[0], data[1]);
            }
            comboBox1.Items.AddRange(Properties.Settings.Default.TIMEDESC.Split('|'));
            comboBox1.SelectedIndex = 0;
            this._StartRunning = new Timer();
            this._StartRunning.Interval = 30000;
            this._StartRunning.Tick += new EventHandler(_StartRunning_Tick);
            this._StartRunning.Start();

        }

        void _StartRunning_Tick(object sender, EventArgs e)
        {
            try
            {
                //if (int.Parse(DateTime.Now.ToString("HHmmss")) >= int.Parse(this._StartTransferDataTime1.Replace(":", "")))
                //{
                    TransferData();
                //}


                if (int.Parse(DateTime.Now.ToString("HHmmss")) > int.Parse(this._SysCloseTime.Replace(":", "")))
                {

                    this.Close();
                }
            }
            catch (Exception ex)
            {
                this.ErrLog(ex.Message + ":" + ex.Source + ":" + ex.StackTrace);
            }
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            try
            {
               
                DisplaySetFileName();
                DisplaySetColumnStyle();
            }
            catch (Exception ex)
            {
                this.ErrLog(ex.Message + ":" + ex.Source + ":" + ex.StackTrace);
            }
        }
        private void DisplaySetFileName()
        {
            try
            {
                DataSet dsData = new DataSet();
                _dtData = new DataTable("MarketInfoSet");
                for (int i = lstTIMETABLE.Count - 1; i >= 0; i--)//時程降冪,找出目前屬於時程
                {
                    if (int.Parse(DateTime.Now.ToString("HHmm")) > int.Parse(lstTIMETABLE[i].Replace(":", "")))
                    {
                        TIMETYPE = (i+1).ToString();
                        break;
                    }
                }
                //判斷手動轉盤後 TIMETYPE改2
                if (bolManualTime)
                    TIMETYPE = (comboBox1.SelectedIndex+1).ToString(); 
                SqlConnection conn = new SqlConnection(Properties.Settings.Default.ConfigDB);
                string SqlCommand = "";
                SqlDataAdapter adp;
                string ftpdate = "CONVERT(CHAR(8),GETDATE(),112)";
                SqlCommand = @"select case when FTP_STATUS.STATUS='O' then 'False' when FTP_STATUS.STATUS='A' then 'False' WHEN FTP_FILES.ISDEFAULT ='1' then 'False' else 'True' end chkSel,
FTP_FILES.FILE_NAME,TABLE_NAME,isnull(FTP_STATUS.STATUS,'N')STATUS,
isnull(FTP_STATUS.STATUS_DESC,'尚未轉檔') as STATUS_DESC,FTP_FILES.SEQ,FTPSERVER,FTP_FILES.TIMETYPE from 
(select * from FTP_STATUS where FTP_DATE=" + ftpdate+@")FTP_STATUS
 right join  FTP_FILES on FTP_STATUS.FILE_NAME=FTP_FILES.FILE_NAME and FTP_STATUS.TIMETYPE=FTP_FILES.TIMETYPE  where FTP_FILES.TIMETYPE='" + TIMETYPE + "' order by SEQ ";
                adp = new SqlDataAdapter(SqlCommand, conn);
                adp.Fill(_dtData);
                this.dgvMarketInfoSet.DataSource = _dtData;
            }
            catch (Exception ex)
            {
                this.ErrLog(ex.Message.ToString() + ex.StackTrace.ToString());
            }
        }
        private void DisplaySetColumnStyle()
        {
            try
            {
                chkSelColumn.DataPropertyName = "chkSel";
                this.dgvMarketInfoSet.Columns["chkSel"].Visible = false;

                //this.dgvMarketInfoSet.Columns["filename"].HeaderText = "檔名";
                //this.dgvMarketInfoSet.Columns["filename"].Width = 80;
                //this.dgvMarketInfoSet.Columns["filename"].ReadOnly = true;

                //this.dgvMarketInfoSet.Columns["statusdesc"].HeaderText = "狀態";
                //this.dgvMarketInfoSet.Columns["statusdesc"].Width = 250;
                //this.dgvMarketInfoSet.Columns["statusdesc"].ReadOnly = true;

                //this.dgvMarketInfoSet.Columns["status"].Visible = false;
            }
            catch (Exception ex)
            {
                this.ErrLog(ex.Message.ToString() + ex.StackTrace.ToString());
            }
        }


        private void TransferData()
        {
            try
            {
            
                DataRow[] drData = _dtData.Select("chkSel = 'True'");
                foreach (DataRow dr in drData)
                {
                    if (dr["FILE_NAME"].ToString().Trim() != "STOCKCUS")
                    {
                        GetAS400(dr["FILE_NAME"].ToString().Trim(), dr["TABLE_NAME"].ToString().Trim(), dr["STATUS"].ToString().Trim(), dr["FTPSERVER"].ToString().Trim());
                    }
                    else
                    {
                        ExecSTOCKCUS(dr["TABLE_NAME"].ToString().Trim(), dr["STATUS"].ToString().Trim());
                    }
                }
                DisplaySetFileName();
                DisplaySetColumnStyle();


            }
            catch (Exception ex)
            {
                this.ErrLog(ex.Message.ToString() + ex.StackTrace.ToString());

            }
        }


        private void Log(string msg)
        {
            if( _LM["TransDataAServerLog"]!=null)
                _LM["TransDataAServerLog"].WriteLine(msg);
        }

        private void ErrLog(string msg)
        {
            if (_LM["TransDataAServerErrLog"] != null)
                _LM["TransDataAServerErrLog"].WriteLine(msg);
        }

        private void btnChange_Click(object sender, EventArgs e)
        {
            TransferData();
        }

        private void ExecSTOCKCUS(string TableName, string status)
        {
            string statuscode = "";
            string statusdesc = "";
             DataTable dtCOMP = new DataTable();
            //取得分公司資料
            try
            {
                SqlConnection conn = new SqlConnection(Properties.Settings.Default.ConfigDB); 
                string SqlCommand = "";
                SqlDataAdapter adp;
                SqlCommand = @"select COMP,NAME from COMP_SET";
                adp = new SqlDataAdapter(SqlCommand, conn);
                adp.Fill(dtCOMP);
            }
            catch (Exception ex)
            { 
                statuscode = "E";
                statusdesc = "取得分公司資料失敗!";
                this.ErrLog(TableName + " COMP Error：DB取得分公司資料失敗!"+ex.ToString());
            }
            int row =0;
            bool isOK=false ;
            if (statuscode != "E")
            {
                DataTable dtCusData = new DataTable();
                dtCusData.Columns.Add("COMP");
                dtCusData.Columns.Add("COSY");
                dtCusData.Columns.Add("CONA");
                dtCusData.Columns.Add("SETT");
                dtCusData.Columns.Add("IDNO");
                dtCusData.Columns.Add("NAME");
                dtCusData.Columns.Add("BRDT");
                dtCusData.Columns.Add("CONTRACT1");
                dtCusData.Columns.Add("CONTRACT2");
                dtCusData.Columns.Add("CONTRACTAPI");
                dtCusData.Columns.Add("CONTRACT905");
                dtCusData.Columns.Add("CONTRACT913");
                dtCusData.Columns.Add("CONTRACT914");  
                dtCusData.Columns.Add("MAIL");

                //依照分公司取得客戶資料 
                foreach (DataRow dr in dtCOMP.Rows)
                {
                    try
                    {
                        string comp = dr["COMP"].ToString();
                        int idxPage=0;
                        while (idxPage > -1)
                        {
                            string url = Properties.Settings.Default.STOCKCUS_URL + "TASBCCusMgmt.dll?mfcISAPICommand=GetCABBusin&&start=" + idxPage.ToString() + "&comp=" + comp + "&date=" + getTWDATE(DateTime.Now.AddDays(-1).ToString("yyyyMMdd")) + "&dwel=1&TARequestForm=1&tapage=xml ";
                            this.Log(TableName + ": 取得" + comp + "分公司 證券客戶資料" + url);
                            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                            Uri target = new Uri(url);
                            request.CookieContainer = new CookieContainer();
                            request.CookieContainer.Add(new Cookie("TAWork", "0eNsUTycrhWDy2HttNbBCJ5gEL2nK6xiArdhQVxBXqGDTKI4QxreTnM99ukmsv02kIp5CBebK33pK9cq+2x+C+T6c0io7D+vxY82N6wysNv4C/dvhk9pPex2WiFjqcrPH3GvcnzJFiUCSavqpgJLJu/EshRvdqbGkubQCUhx9AGOuL7qO20SupGnzsum+RkI") { Domain = target.Host });
                            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                            string content = new StreamReader(response.GetResponseStream(), Encoding.GetEncoding(950)).ReadToEnd();
                            XmlDocument xml = new XmlDocument();
                            xml.LoadXml(content);
                            this.Log(content);
                            string code = ""; 
                            if (xml.SelectSingleNode(".//TAStatus").Attributes["code"] != null)
                                code = xml.SelectSingleNode(".//TAStatus").Attributes["code"].Value; 
                            if (code != "0")
                            {
                                idxPage = -1;
                                break;
                            }
                            string xmlSBCMACUS = "<M>";
                            foreach (XmlNode cusnode in xml.SelectNodes(".//SBCMACUS"))
                            {
                                xmlSBCMACUS += cusnode.OuterXml;
                            }
                            xmlSBCMACUS += "</M>";
                            XElement rSBCMACUS = XElement.Parse(xmlSBCMACUS);
                            IEnumerable<XElement> xeSBCMACUS =
                                from el in rSBCMACUS.Elements("SBCMACUS")
                                orderby el.Attribute("time").Value
                                select el;
                            //更新異動資料
                            foreach (XElement el in xeSBCMACUS)
                            {
                                string type="";
                                string COMP = "";
                                string SETT = ""; 
                                string CUSY = "";
                                if (el.Attribute("type") != null)
                                    type = el.Attribute("type").Value;
                                if (el.Attributes("comp") != null)
                                    COMP = el.Attribute("comp").Value;
                                if (el.Attributes("emcu") != null)
                                    SETT = el.Attribute("emcu").Value;
                                if (el.Attribute("cusy") != null)
                                {
                                    CUSY = el.Attribute("cusy").Value;
                                    if (CUSY.Split(',').Length > 1)
                                    {
                                        CUSY = CUSY.Split(',')[1];
                                           DataRow[] drFinds = dtCusData.Select("COMP='" + COMP + "' and SETT='" + SETT + "'");
                                           if (drFinds.Length > 0)
                                           {
                                               drFinds[0]["NAME"] = CUSY;
                                           }
                                           else
                                           {
                                               DataRow drNew = dtCusData.NewRow();
                                               drNew["COMP"] = COMP;
                                               drNew["SETT"] = SETT;
                                               drNew["CONA"] = dr["NAME"].ToString();
                                               drNew["COSY"] = COMP;
                                               drNew["NAME"] = CUSY;
                                               dtCusData.Rows.Add(drNew);
                                           }
                                    }
                                }  
                            }
                            string xmlCACMACUS = "<M>";
                            foreach (XmlNode cusnode in xml.SelectNodes(".//CACMACUS"))
                            {
                                xmlCACMACUS += cusnode.OuterXml;
                            }
                            xmlCACMACUS += "</M>";
                            XElement rCACMACUS = XElement.Parse(xmlCACMACUS);
                            IEnumerable<XElement> xeCACMACUS =
                                from el in rCACMACUS.Elements("CACMACUS")
                                orderby el.Attribute("time").Value
                                select el;
                            foreach (XElement el in xeCACMACUS)
                            {  
                                string COMP = "";
                                string SETT = "";
                                string IDNO = "";
                                string BRDT = "";
                                if (el.Attribute("comp") != null)
                                    COMP = el.Attribute("comp").Value;
                                if (el.Attribute("emcu") != null)
                                    SETT = el.Attribute("emcu").Value;
                                if (el.Attribute("idno") != null)
                                {
                                    IDNO = el.Attribute("idno").Value;
                                    if (IDNO.Split(',').Length > 1)
                                    {
                                        IDNO = IDNO.Split(',')[1];
                                        DataRow[] drFinds = dtCusData.Select("COMP='" + COMP + "' and SETT='" + SETT + "'");
                                        if (drFinds.Length > 0)
                                        {
                                            drFinds[0]["IDNO"] = IDNO;
                                        }
                                        else
                                        {
                                            DataRow drNew = dtCusData.NewRow();
                                            drNew["COMP"] = COMP;
                                            drNew["CONA"] = dr["NAME"].ToString();
                                            drNew["COSY"] = COMP;
                                            drNew["SETT"] = SETT;
                                            drNew["IDNO"] = IDNO;
                                            dtCusData.Rows.Add(drNew);
                                        }
                                    }
                                }
                                if (el.Attribute("brdt")!= null)
                                {
                                    BRDT = el.Attribute("brdt").Value;
                                    if (BRDT.Split(',').Length > 1)
                                    {
                                        BRDT = BRDT.Split(',')[1];
                                        DataRow[] drFinds = dtCusData.Select("COMP='" + COMP + "' and SETT='" + SETT + "'");
                                        if (drFinds.Length > 0)
                                        {
                                            drFinds[0]["BRDT"] = BRDT;
                                        }
                                        else
                                        {
                                            DataRow drNew = dtCusData.NewRow();
                                            drNew["COMP"] = COMP;
                                            drNew["CONA"] = dr["NAME"].ToString();
                                            drNew["COSY"] = COMP;
                                            drNew["SETT"] = SETT;
                                            drNew["BRDT"] = BRDT;
                                            dtCusData.Rows.Add(drNew);
                                        }
                                    }
                                }  
                            }
                            string xmlCACLIAIS3= "<M>";
                            foreach (XmlNode cusnode in xml.SelectNodes(".//CACLIAIS[@lino=3]"))
                            {
                                xmlCACLIAIS3 += cusnode.OuterXml;
                            }
                            xmlCACLIAIS3 += "</M>";
                            XElement rCACLIAIS3 = XElement.Parse(xmlCACLIAIS3);
                            IEnumerable<XElement> xeCACLIAIS3 =
                                from el in rCACLIAIS3.Elements("CACLIAIS")
                                orderby el.Attribute("time").Value
                                select el;
                            foreach (XElement el in xeCACLIAIS3)
                            {
                                string MAIL = "";
                                string COMP = "";
                                string SETT = "";
                                if (el.Attribute("comp") != null)
                                    COMP = el.Attribute("comp").Value;
                                if (el.Attribute("emcu") != null)
                                    SETT = el.Attribute("emcu").Value;
                                if (el.Attribute("liad") != null)
                                {
                                    MAIL = el.Attribute("liad").Value;
                                    if (MAIL.Split(',').Length > 1)
                                    {
                                        MAIL = MAIL.Split(',')[1];
                                        DataRow[] drFinds = dtCusData.Select("COMP='" + COMP + "' and SETT='" + SETT + "'");
                                        if (drFinds.Length > 0)
                                        {
                                            drFinds[0]["MAIL"] = MAIL;
                                        }
                                        else
                                        {
                                            DataRow drNew = dtCusData.NewRow();
                                            drNew["COMP"] = COMP;
                                            drNew["CONA"] = dr["NAME"].ToString();
                                            drNew["COSY"] = COMP;
                                            drNew["SETT"] = SETT;
                                            drNew["MAIL"] = MAIL;
                                            dtCusData.Rows.Add(drNew);
                                        }
                                    }
                                }
                            }
                            string xmlCACCONTR11= "<M>";
                            foreach (XmlNode cusnode in xml.SelectNodes(".//CACCONTR[@ctno=11]"))
                            {
                                xmlCACCONTR11 += cusnode.OuterXml;
                            }
                            xmlCACCONTR11 += "</M>";
                            XElement rCACCONTR11 = XElement.Parse(xmlCACCONTR11);
                            IEnumerable<XElement> xeCACCONTR11 =
                                from el in rCACCONTR11.Elements("CACCONTR")
                                orderby el.Attribute("time").Value
                                select el;
                            foreach (XElement el in xeCACCONTR11) 
                            {
                                string CONTRACT1 = "";
                                string COMP = "";
                                string SETT = "";
                                if (el.Attribute("comp") != null)
                                    COMP = el.Attribute("comp").Value;
                                if (el.Attribute("emcu") != null)
                                    SETT = el.Attribute("emcu").Value;
                                if (el.Attribute("ctst")!= null)
                                {
                                    CONTRACT1 = el.Attribute("ctst").Value;
                                    if (CONTRACT1.Split(',').Length > 1)
                                    {
                                        CONTRACT1 = CONTRACT1.Split(',')[1];
                                        DataRow[] drFinds = dtCusData.Select("COMP='" + COMP + "' and SETT='" + SETT + "'");
                                        if (drFinds.Length > 0)
                                        {
                                            drFinds[0]["CONTRACT1"] = CONTRACT1;
                                        }
                                        else
                                        {
                                            DataRow drNew = dtCusData.NewRow();
                                            drNew["COMP"] = COMP;
                                            drNew["CONA"] = dr["NAME"].ToString();
                                            drNew["COSY"] = COMP;
                                            drNew["SETT"] = SETT;
                                            drNew["CONTRACT1"] = CONTRACT1;
                                            dtCusData.Rows.Add(drNew);
                                        }
                                    }
                                }
                            }
                            string xmlCACCONTR903= "<M>";
                            foreach (XmlNode cusnode in xml.SelectNodes(".//CACCONTR[@ctno=903]"))
                            {
                                xmlCACCONTR903 += cusnode.OuterXml;
                            }
                            xmlCACCONTR903 += "</M>";
                            XElement rCACCONTR903= XElement.Parse(xmlCACCONTR903);
                            IEnumerable<XElement> xeCACCONTR903 =
                                from el in rCACCONTR903.Elements("CACCONTR")
                                orderby el.Attribute("time").Value
                                select el;
                            foreach (XElement el in xeCACCONTR903) 
                            { 
                                string CONTRACT2 = "";
                                string COMP = "";
                                string SETT = "";
                                if (el.Attribute("comp") != null)
                                    COMP = el.Attribute("comp").Value;
                                if (el.Attribute("emcu") != null)
                                    SETT = el.Attribute("emcu").Value;
                                if (el.Attribute("ctst") != null)
                                {
                                    CONTRACT2 = el.Attribute("ctst").Value;
                                    if (CONTRACT2.Split(',').Length > 1)
                                    {
                                        CONTRACT2 = CONTRACT2.Split(',')[1];
                                        DataRow[] drFinds = dtCusData.Select("COMP='" + COMP + "' and SETT='" + SETT + "'");
                                        if (drFinds.Length > 0)
                                        {
                                            drFinds[0]["CONTRACT2"] = CONTRACT2;
                                        }
                                        else
                                        {
                                            DataRow drNew = dtCusData.NewRow();
                                            drNew["COMP"] = COMP;
                                            drNew["CONA"] = dr["NAME"].ToString();
                                            drNew["COSY"] = COMP;
                                            drNew["SETT"] = SETT;
                                            drNew["CONTRACT2"] = CONTRACT2;
                                            dtCusData.Rows.Add(drNew);
                                        }
                                    }
                                }
                            }
                            string xmlCACCONTR25 = "<M>";
                            foreach (XmlNode cusnode in xml.SelectNodes(".//CACCONTR[@ctno=25]"))
                            {
                                xmlCACCONTR25 += cusnode.OuterXml;
                            }
                            xmlCACCONTR25 += "</M>";
                            XElement rCACCONTR25 = XElement.Parse(xmlCACCONTR25);
                            IEnumerable<XElement> xeCACCONTR25 =
                                from el in rCACCONTR25.Elements("CACCONTR")
                                orderby el.Attribute("time").Value
                                select el;
                            foreach (XElement el in xeCACCONTR25)
                            { 
                                string CONTRACTAPI = "";
                                string COMP = "";
                                string SETT = "";
                                if (el.Attribute("comp") != null)
                                    COMP = el.Attribute("comp").Value;
                                if (el.Attribute("emcu") != null)
                                    SETT = el.Attribute("emcu").Value;
                                if (el.Attribute("ctst") != null)
                                {
                                    CONTRACTAPI = el.Attribute("ctst").Value;
                                    if (CONTRACTAPI.Split(',').Length > 1)
                                    {
                                        CONTRACTAPI = CONTRACTAPI.Split(',')[1];
                                        DataRow[] drFinds = dtCusData.Select("COMP='" + COMP + "' and SETT='" + SETT + "'");
                                        if (drFinds.Length > 0)
                                        {
                                            drFinds[0]["CONTRACTAPI"] = CONTRACTAPI;
                                        }
                                        else
                                        {
                                            DataRow drNew = dtCusData.NewRow();
                                            drNew["COMP"] = COMP;
                                            drNew["CONA"] = dr["NAME"].ToString();
                                            drNew["COSY"] = COMP;
                                            drNew["SETT"] = SETT;
                                            drNew["CONTRACTAPI"] = CONTRACTAPI;
                                            dtCusData.Rows.Add(drNew);
                                        }
                                    }
                                }
                            }
                            string xmlCACCONTR905 = "<M>";
                            foreach (XmlNode cusnode in xml.SelectNodes(".//CACCONTR[@ctno=905]"))
                            {
                                xmlCACCONTR905 += cusnode.OuterXml;
                            }
                            xmlCACCONTR905 += "</M>";
                            XElement rCACCONTR905 = XElement.Parse(xmlCACCONTR905);
                            IEnumerable<XElement> xeCACCONTR905 =
                                from el in rCACCONTR905.Elements("CACCONTR")
                                orderby el.Attribute("time").Value
                                select el;
                            foreach (XElement el in xeCACCONTR905)
                            {  
                                string CONTRACT905 = "";
                                string COMP = "";
                                string SETT = "";
                                if (el.Attribute("comp") != null)
                                    COMP = el.Attribute("comp").Value;
                                if (el.Attribute("emcu") != null)
                                    SETT = el.Attribute("emcu").Value;
                                if (el.Attribute("ctst") != null)
                                {
                                    CONTRACT905 = el.Attribute("ctst").Value;
                                    if (CONTRACT905.Split(',').Length > 1)
                                    {
                                        CONTRACT905 = CONTRACT905.Split(',')[1];
                                        DataRow[] drFinds = dtCusData.Select("COMP='" + COMP + "' and SETT='" + SETT + "'");
                                        if (drFinds.Length > 0)
                                        {
                                            drFinds[0]["CONTRACT905"] = CONTRACT905;
                                        }
                                        else
                                        {
                                            DataRow drNew = dtCusData.NewRow();
                                            drNew["COMP"] = COMP;
                                            drNew["CONA"] = dr["NAME"].ToString();
                                            drNew["COSY"] = COMP;
                                            drNew["SETT"] = SETT;
                                            drNew["CONTRACT905"] = CONTRACT905;
                                            dtCusData.Rows.Add(drNew);
                                        }
                                    }
                                }
                            }
                            string xmlCACCONTR913 = "<M>";
                            foreach (XmlNode cusnode in xml.SelectNodes(".//CACCONTR[@ctno=913]"))
                            {
                                xmlCACCONTR913 += cusnode.OuterXml;
                            }
                            xmlCACCONTR913 += "</M>";
                            XElement rCACCONTR913 = XElement.Parse(xmlCACCONTR913);
                            IEnumerable<XElement> xeCACCONTR913 =
                                from el in rCACCONTR913.Elements("CACCONTR")
                                orderby el.Attribute("time").Value
                                select el;
                            foreach (XElement el in xeCACCONTR913)
                            {  
                                string CONTRACT913 = "";
                                string COMP = "";
                                string SETT = "";
                                if (el.Attribute("comp") != null)
                                    COMP = el.Attribute("comp").Value;
                                if (el.Attribute("emcu") != null)
                                    SETT = el.Attribute("emcu").Value;
                                if (el.Attribute("ctst") != null)
                                {
                                    CONTRACT913 = el.Attribute("ctst").Value;
                                    if (CONTRACT913.Split(',').Length > 1)
                                    {
                                        CONTRACT913 = CONTRACT913.Split(',')[1];
                                        DataRow[] drFinds = dtCusData.Select("COMP='" + COMP + "' and SETT='" + SETT + "'");
                                        if (drFinds.Length > 0)
                                        {
                                            drFinds[0]["CONTRACT913"] = CONTRACT913;
                                        }
                                        else
                                        {
                                            DataRow drNew = dtCusData.NewRow();
                                            drNew["COMP"] = COMP;
                                            drNew["CONA"] = dr["NAME"].ToString();
                                            drNew["COSY"] = COMP;
                                            drNew["SETT"] = SETT;
                                            drNew["CONTRACT913"] = CONTRACT913;
                                            dtCusData.Rows.Add(drNew);
                                        }
                                    }
                                }
                            }
                            string xmlCACCONTR914 = "<M>";
                            foreach (XmlNode cusnode in xml.SelectNodes(".//CACCONTR[@ctno=914]"))
                            {
                                xmlCACCONTR914 += cusnode.OuterXml;
                            }
                            xmlCACCONTR914 += "</M>";
                            XElement rCACCONTR914 = XElement.Parse(xmlCACCONTR914);
                            IEnumerable<XElement> xeCACCONTR914 =
                                from el in rCACCONTR914.Elements("CACCONTR")
                                orderby el.Attribute("time").Value
                                select el;
                            foreach (XElement el in xeCACCONTR914)
                            {
                                string CONTRACT914 = "";
                                string COMP = "";
                                string SETT = "";
                                if (el.Attribute("comp") != null)
                                    COMP = el.Attribute("comp").Value;
                                if (el.Attribute("emcu") != null)
                                    SETT = el.Attribute("emcu").Value;
                                if (el.Attribute("ctst") != null)
                                {
                                    CONTRACT914 = el.Attribute("ctst").Value;
                                    if (CONTRACT914.Split(',').Length > 1)
                                    {
                                        CONTRACT914 = CONTRACT914.Split(',')[1];
                                        DataRow[] drFinds = dtCusData.Select("COMP='" + COMP + "' and SETT='" + SETT + "'");
                                        if (drFinds.Length > 0)
                                        {
                                            drFinds[0]["CONTRACT914"] = CONTRACT914;
                                        }
                                        else
                                        {
                                            DataRow drNew = dtCusData.NewRow();
                                            drNew["COMP"] = COMP;
                                            drNew["CONA"] = dr["NAME"].ToString();
                                            drNew["COSY"] = COMP;
                                            drNew["SETT"] = SETT;
                                            drNew["CONTRACT914"] = CONTRACT914;
                                            dtCusData.Rows.Add(drNew);
                                        }
                                    }
                                }
                            }
                            idxPage++;
                        }
                    }
                    catch (Exception ex)
                    {
                        statuscode = "E";
                        statusdesc = "文字處理失敗!";
                        this.ErrLog(TableName + "文字處理失敗" + ex.ToString());
                    }
                }
                if (dtCusData.Rows.Count > 0)
                {
                    foreach (DataRow dr in dtCusData.Rows)
                    {
                        string logstring = "";
                        foreach (DataColumn dc in dtCusData.Columns)
                        {
                            logstring += dr[dc.ColumnName].ToString() + "	";
                        }
                        this.Log(logstring);
                        string COMP = dr["COMP"].ToString();
                        string COSY = dr["COSY"].ToString();
                        string CONA = dr["CONA"].ToString();
                        string SETT = dr["SETT"].ToString();

                        string IDNO = dr["IDNO"].ToString();
                        string CUSY = dr["NAME"].ToString();
                        string BRDT = dr["BRDT"].ToString();
                        string CONTRACT1 = dr["CONTRACT1"].ToString();
                        string CONTRACT2 = dr["CONTRACT2"].ToString();
                        string CONTRACTAPI = dr["CONTRACTAPI"].ToString().PadLeft(1, ' ').Substring(0, 1);
                        string CONTRACT905 = dr["CONTRACT905"].ToString().PadLeft(1, ' ');
                        string CONTRACT913 = dr["CONTRACT913"].ToString().PadLeft(1, ' ');
                        string CONTRACT914 = dr["CONTRACT914"].ToString().PadLeft(1, ' ');
                        string MAIL = dr["MAIL"].ToString();
                        string APAUTH = CONTRACTAPI + CONTRACT905 + CONTRACT913 + CONTRACT914;
                        string updatecolumn = "";
                        if (IDNO != "")
                            updatecolumn += "IDNO='" + IDNO + "',";
                        if (CUSY != "")
                            updatecolumn += "NAME='" + CUSY + "',";
                        if (BRDT != "")
                            updatecolumn += "BRDT='" + BRDT + "',";
                        if (CONTRACT1 != "")
                            updatecolumn += "CONTRACT1='" + CONTRACT1 + "',";
                        if (CONTRACT2 != "")
                            updatecolumn += "CONTRACT2='" + CONTRACT2 + "',";
                        if (APAUTH.Trim() != "")
                        {
                            updatecolumn += "APAUTH=";
                            for (int i = 0; i < APAUTH.Length; i++)
                            {
                                if (APAUTH.Substring(i, 1).Trim() == "")
                                    updatecolumn += "substring(APAUTH,"+(i+1).ToString()+",1)+";
                                else
                                    updatecolumn += "'" + APAUTH.Substring(i, 1) + "'+";
                            }
                            updatecolumn = updatecolumn.TrimEnd(new char[] { '+' })+",";
                        }
                        //if (CONTRACTAPI.Trim() != "")
                        //    updatecolumn += "APAUTH='" + CONTRACTAPI + "'+substring(APAUTH,2,3),";
                        //if (CONTRACT905.Trim() != "")
                        //    updatecolumn += "APAUTH=substring(APAUTH,1,1)+'" + CONTRACT905 + "'+substring(APAUTH,3,2),";
                        //if (CONTRACT913.Trim() != "")
                        //    updatecolumn += "APAUTH=substring(APAUTH,1,2)+'" + CONTRACT913 + "'+substring(APAUTH,4,1),";
                        //if (CONTRACT914.Trim() != "")
                        //    updatecolumn += "APAUTH=substring(APAUTH,1,3)+'" + CONTRACT914 + "',";
                        if (MAIL != "")
                            updatecolumn += "EMAIL ='" + MAIL + "',";
                        if (updatecolumn != "")
                        {
                            string insertsql = "INSERT INTO STOCKCUS(COMP,COSY,CONA,SETT,IDNO,NAME,BRDT,CONTRACT1,CONTRACT2,APAUTH,EMAIL,CRT_ID,CRT_DATE)VALUES('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}','SYS',getdate())";
                            insertsql = string.Format(insertsql, COMP, COSY, CONA, SETT, IDNO, CUSY, BRDT, CONTRACT1, CONTRACT2, APAUTH,MAIL);
                            string updatesql = "UPDATE STOCKCUS SET  {2}UPD_ID='SYS',UPD_DATE=getdate()where COMP='{0}'and SETT='{1}' ";
                            updatesql = string.Format(updatesql, COMP, SETT, updatecolumn); 
                            row++;
                            this.Log(insertsql);
                            this.Log(updatesql);
                            isOK = execDB(Properties.Settings.Default.ConfigDB, updatesql, insertsql);
                            if (isOK == false)
                            {
                                statuscode = "E";
                                statusdesc = "DB轉檔指令失敗!";
                                this.ErrLog(TableName + " SaveDB Error：DB轉檔指令失敗!");

                            }
                        }
                    }
                }
            } 
            if (row <= 0 && statuscode == "")
            {
                statuscode = "E";
                statusdesc = TableName + " ：該檔案無資料!";
                this.ErrLog(TableName + " ：該檔案無資料!");

            }
            else if (row > 0 && statuscode == "")
            {
                statuscode = "O";
                statusdesc = "轉檔成功!";
                this.Log(TableName + " Success：轉檔成功!");

            }
            updateDBFileStatus(isOK, status, statuscode, statusdesc, TableName);
            
        }
        private string getTWDATE(string commDate)
        {
            if (commDate.Length < 8)
                return "";
            return (int.Parse(commDate.Substring(0, 4)) - 1911).ToString() + "/" + commDate.Substring(4, 2) + "/" + commDate.Substring(6, 2);
        }
        private void updateDBFileStatus(bool isOK, string status, string statuscode, string statusdesc, string TableName)
        {
            string ftpdate = "CONVERT(CHAR(8),GETDATE(),112)";
    
            string[] strSqlCommands1 = new string[1];
            if (status == "N")
            {

                strSqlCommands1[0] = "insert into FTP_STATUS (FTP_DATE,FILE_NAME,STATUS_DESC,STATUS,FTP_TIME,TIMETYPE )VALUES  (" + ftpdate + ",'" + TableName + "','" + statusdesc + "','" + statuscode + "',convert(char(8),GETDATE(),108),'" + TIMETYPE + "');";

            }
            else
            {

                strSqlCommands1[0] = " update FTP_STATUS set  STATUS='" + statuscode + "',STATUS_DESC='" + statusdesc + "',FTP_TIME=convert(char(8),GETDATE(),108),TIMETYPE='" + TIMETYPE + "'  where FTP_DATE = " + ftpdate + " and FILE_NAME='" + TableName + "' ;";

            }

            isOK = runExecuteNonQuery(strSqlCommands1, Properties.Settings.Default.ConfigDB);
        }
        private void GetAS400(string FileName,string TableName, string status,string ftpserver)
        {

            string statuscode = "";
            string statusdesc = "";
            bool isOK = false;

            string fileName = "";
            string folderPath = "";
            string JobName = FileName;

            //判斷手動轉或自動FTP下載
            if (chkOpenFile.Checked)
            {
                fileName = JobName;
                folderPath = lblFolder.Text; 
                
            }
            else
            {
                fileName = DateTime.Now.ToString("yyyyMMdd") + TableName;

                folderPath = this._TempFolder;

                Log(string.Format("folderPath[{0}],fileName[{1}],JobName[{2}] FtpDownload Start", folderPath, fileName, JobName));
                try
                {
                    FtpDownload(folderPath, fileName, JobName, ftpserver);
                }
                catch (Exception ex)
                {
                    statuscode = "E";
                    statusdesc = "ftp讀檔失敗!";
                    this.ErrLog(fileName + "ftp讀檔失敗 " + ex.ToString());
                }
                Log(string.Format("folderPath[{0}],fileName[{1}],JobName[{2}] FtpDownload end ", folderPath, fileName, JobName));
            }

            Hashtable hsDate = new Hashtable();

            //讀文字檔寫入
            ArrayList arlCommands = new ArrayList();

            int row = 0;
            if (statuscode != "E")
            {
                try
                {

                    switch (TableName)
                    {
                      
                        case "P08"://P08
                            saveDBP08Data(folderPath, fileName, TableName, ref isOK, ref statuscode, ref statusdesc, ref row);
                            break;
                        case "ACPARTY"://群組帳號檔   
                        case "TICKDATA"://跳動點檔 
                        case "WORKDAY"://工作日檔  
                        case "PW_SET"://密碼
                            saveDBDeleteALL(folderPath, fileName, TableName, ref isOK, ref statuscode, ref statusdesc, ref row);
                            break;
                        case "P09F"://P09期貨 
                        case "P09O"://P09選擇權 
                        case "INCOME_DETAIL"://平倉明細檔  
                        case "CASHLOG"://出入金
                        case "CUSTDATA"://客戶基本資料檔  
                            saveDBDeleteByKey(folderPath, fileName, TableName, ref isOK, ref statuscode, ref statusdesc, ref row);
                            break;
                        case "AEDATA"://營業員基本資料檔 
                            saveDBUpdateByKey(folderPath, fileName, TableName, ref isOK, ref statuscode, ref statusdesc, ref row);
                            break;
                    } 
                }
                catch (Exception ex)
                {
                    statuscode = "E";
                    statusdesc = "文字檔處理失敗!";
                    this.ErrLog(fileName + "文字檔處理失敗" + ex.ToString());

                }
            }

            if (row <= 0 && statuscode == "")
            {
                statuscode = "E";
                statusdesc = fileName + " ：該檔案無資料!";
                this.ErrLog(fileName + " ：該檔案無資料!");

            }
            else if (row >0 && statuscode == "")
            {
                statuscode = "O";
                statusdesc = "轉檔成功!";
                this.Log(fileName + " Success：轉檔成功!");
 
             }
            updateDBFileStatus(isOK, status, statuscode, statusdesc, JobName);
        }
        private void saveDBP08Data(string folderPath, string fileName, string TableName, ref bool isOK, ref string statuscode, ref string statusdesc, ref int row)
        {
            string strLine = null;
            string filepath = folderPath + "\\" + fileName;
            Log(string.Format("filepath[{0}]  file Open Start", filepath)); 
            System.IO.StreamReader file = new System.IO.StreamReader(filepath, Encoding.GetEncoding(950)); 
            List<string> lstInsertData = new List<string>();
            List<string> lstKinds = new List<string>();
            int datalen = getDataLen(TableName);
            bool flowcheck = false;
            while ((strLine = file.ReadLine()) != null)
            { 
                byte[] byLine = Encoding.GetEncoding(950).GetBytes(strLine);
                if (byLine.Length >= datalen)
                { 
                    FileInfo.P08 p08 = P08.getP08(byLine);
                    string Kind_Id = Function.getString(p08.P08_COMMODITY_ID).Trim().Substring(0, 3);
                    if(!lstKinds.Contains(Kind_Id))
                        lstKinds.Add(Kind_Id);
                    string flow_group = Function.getString(p08.P08_FLOW_GROUP).Trim() ;
                    if (dicAFTERGROUP.Keys.Contains(TIMETYPE))
                    {
                        string flow = dicAFTERGROUP[TIMETYPE];
                        if(flow==flow_group)
                            flowcheck = true;
                    }
                    lstInsertData.Add(TransDataAServer.P08.getSql(p08));  
                }
            }
            Log(string.Format("Delete [{0}] start", TableName));
            if (dicAFTERGROUP.Keys.Contains(TIMETYPE))//夜盤轉檔只刪除對應Flow 商品
            { 
                isOK = runExecuteNonQuery("delete " + TableName + "F  where  substring(COMMODITY_ID,1,3) in ('" + String.Join("','", lstKinds.ToArray()) + "') ;delete " + TableName + "O  where substring(COMMODITY_ID,1,3) in ('" + String.Join("','", lstKinds.ToArray()) + "') ", Properties.Settings.Default.ConfigDB);
            }
            else
            {
                isOK = runExecuteNonQuery("truncate table " + TableName + "F ;truncate table " + TableName + "O ", Properties.Settings.Default.ConfigDB);
            }
            if (isOK == false)
            {
                statuscode = "E";
                statusdesc = "DB轉檔指令失敗!";
                this.ErrLog(TableName + " Delete Error：DB轉檔指令失敗!");
            }
            Log(string.Format("Delete [{0}] end", TableName));
            foreach (string sql in lstInsertData)
            {
                isOK = runExecuteNonQuery(sql, Properties.Settings.Default.ConfigDB);
                if (isOK == false)
                {
                    statuscode = "E";
                    statusdesc = "DB轉檔指令失敗!";
                    this.ErrLog(fileName + " SaveDB Error：DB轉檔指令失敗!");
                }
                row += 1;
            }
            Log(string.Format("filepath[{0}]  file Open end", filepath));
            file.Close();
            //20160420判斷P08 檔案是否為最新
            //20170418判斷flowgroup 是否為最新
            System.IO.FileInfo fi = new System.IO.FileInfo(filepath); 
            if ((fi.LastWriteTime.ToString("yyyyMMdd") != DateTime.Now.ToString("yyyyMMdd"))||
                (dicAFTERGROUP.Keys.Contains(TIMETYPE) &&!flowcheck))
            {
                statuscode = "E";
                statusdesc = fileName + " ：該檔案非最新檔!";
                this.ErrLog(fileName + " ：該檔案非最新檔!");
            } 
        }
        private void saveDBDeleteALL(string folderPath, string fileName, string TableName, ref bool isOK, ref string statuscode, ref string statusdesc ,ref int row)
        {
            string strLine = null;
            string filepath = folderPath + "\\" + fileName;
            Log(string.Format("filepath[{0}]  file Open Start", filepath));
          
            System.IO.StreamReader file = new System.IO.StreamReader(filepath, Encoding.GetEncoding(950));
            string sql = ""; 
            
            int datalen = getDataLen(TableName); 
            while ((strLine = file.ReadLine()) != null)
            {
                if (row == 0)//判斷如果是第一筆先做刪除
                {
                    Log(string.Format("Delete [{0}] start", TableName));
                    isOK = runExecuteNonQuery("truncate table " + TableName, Properties.Settings.Default.ConfigDB);
                    if (isOK == false)
                    {
                        statuscode = "E";
                        statusdesc = "DB轉檔指令失敗!";
                        this.ErrLog(TableName + " Delete Error：DB轉檔指令失敗!");
                    }
                    Log(string.Format("Delete [{0}] end", TableName));
                }
                byte[] byLine = Encoding.GetEncoding(950).GetBytes(strLine);
                if (byLine.Length >= datalen)
                {
                    switch (TableName)
                    {  
                        case "ACPARTY"://群組帳號檔
                            sql = TransDataAServer.ACPARTY.getSql(ACPARTY.getCACPARTY(byLine));
                            break;   
                        case "TICKDATA"://跳動點檔
                            sql = TransDataAServer.KSCM026P.getSql(KSCM026P.getKSCM026P(byLine));
                            break;
                        case "PW_SET"://密碼
                            sql = TransDataAServer.PWSET.getSql(PWSET.getPWSET(byLine));
                            break;
                        case "WORKDAY"://工作日檔   
                            sql = TransDataAServer.WORKDAY.getSql(WORKDAY.getWORKDAY(byLine));
                            break;
                    }
                    if (sql != "")
                    {
                        isOK = runExecuteNonQuery(sql, Properties.Settings.Default.ConfigDB);
                        if (isOK == false)
                        {
                            statuscode = "E";
                            statusdesc = "DB轉檔指令失敗!";
                            this.ErrLog(fileName + " SaveDB Error：DB轉檔指令失敗!");
                        }
                    }
                    row += 1;
                }
            }
            Log(string.Format("filepath[{0}]  file Open end", filepath));
            file.Close(); 
        }
        private void saveDBDeleteByKey(string folderPath, string fileName, string TableName, ref bool isOK, ref string statuscode, ref string statusdesc, ref int row)
        {
            string strLine = null;
            string filepath = folderPath + "\\" + fileName;
            Log(string.Format("filepath[{0}]  file Open Start", filepath));
      
            System.IO.StreamReader file = new System.IO.StreamReader(filepath, Encoding.GetEncoding(950));
            string sql = "";
      
            int datalen = getDataLen(TableName);
        
          
            string deletesql = "";
            string[] keyColumn = null ;
            string[] keyValue= null;
            string[] preValue = null;
            while ((strLine = file.ReadLine()) != null)
            {
                byte[] byLine = Encoding.GetEncoding(950).GetBytes(strLine);
                if (byLine.Length >= datalen)
                {
                    switch (TableName)
                    {
                        case "P09F"://P09期貨
                            keyColumn = new string[] { "KIND_ID" };
                            FileInfo.P09F rawP09F = P09F.getP09F(byLine);
                            keyValue = new string[] { Function.getString(rawP09F.P09_KIND_ID).Trim() };
                            sql = TransDataAServer.P09F.getSql(P09F.getP09F(byLine));
                            break;
                        case "P09O"://P09選擇權
                              keyColumn = new string[] { "KIND_ID" };
                              FileInfo.P09O rawP09O = P09O.getP09O(byLine);
                              keyValue = new string[] { Function.getString(rawP09O.P09_KIND_ID).Trim() };
                            sql = TransDataAServer.P09O.getSql(P09O.getP09O(byLine));
                            break;
                        case "INCOME_DETAIL"://平倉明細檔
                            keyColumn = new string[] { "OCCDT", "FIRM","ACTNO" ,"TRDDT","ORDNO","FIRMORD","DIVIDESEQ","DTRDDT","DORDNO","DFIRMORD","DDIVIDESEQ","OFFSEQ"};
                            FileInfo.INCOME_DETAIL rawINCOME_DETAIL = INCOME_DETAIL.getINCOME_DETAIL(byLine);
                            keyValue = new string[] { Function.getString(rawINCOME_DETAIL.OCCDT).Trim(), Function.getString(rawINCOME_DETAIL.FIRM).Trim(), Function.getString(rawINCOME_DETAIL.ACTNO).Trim(), 
                                Function.getString(rawINCOME_DETAIL.TRDDT).Trim(), Function.getString(rawINCOME_DETAIL.ORDNO).Trim(), Function.getString(rawINCOME_DETAIL.FIRMORD).Trim(), 
                                Function.getString(rawINCOME_DETAIL.DIVIDESEQ).Trim(), Function.getString(rawINCOME_DETAIL.DTRDDT).Trim(), Function.getString(rawINCOME_DETAIL.DORDNO).Trim(),
                                Function.getString(rawINCOME_DETAIL.DFIRMORD).Trim() ,Function.getString(rawINCOME_DETAIL.DDIVIDESEQ).Trim() ,Function.getString(rawINCOME_DETAIL.OFFSEQ).Trim() };
                            sql = TransDataAServer.INCOME_DETAIL.getSql(rawINCOME_DETAIL); 
                            break; 
                        case "CASHLOG"://出入金 
                            keyColumn = new string[] { "TRDDT", "FIRM" ,"IBNO","ACTNO","NETWORKID","SLIPNO"};
                            FileInfo.CASHLOG rawCASHLOG=CASHLOG.getCASHLOG(byLine);
                            keyValue = new string[] { Function.getString(rawCASHLOG.TRDDT).Trim(), Function.getString(rawCASHLOG.FIRM).Trim(), Function.getString(rawCASHLOG.IBNO).Trim()
                            , Function.getString(rawCASHLOG.ACTNO).Trim(), Function.getString(rawCASHLOG.NETWORKID).Trim(), Function.getString(rawCASHLOG.SLIPNO).Trim()};
                            sql = TransDataAServer.CASHLOG.getSql(rawCASHLOG);
                            break;
                        //case "AEDATA"://營業員基本資料檔
                        //    keyColumn = new string[] { "BRANCH_NO", "SALES" };
                        //    FileInfo.AEDATA rawAEDATA = AEDATA.getAEDATA(byLine);
                        //    keyValue = new string[] { Function.getString(rawAEDATA.BRANCH_NO).Trim(), Function.getString(rawAEDATA.SALES).Trim() };
                        //    sql = TransDataAServer.AEDATA.getSql(AEDATA.getAEDATA(byLine));
                        //    break;
                        case "CUSTDATA"://客戶基本資料檔 
                            keyColumn = new string[] { "FIRM","ACTNO" };
                            FileInfo.CUSDATA rawCUSTDATA = CUSDATA.getCUSDATA(byLine);
                            keyValue = new string[] { Function.getString(rawCUSTDATA.FIRM).Trim(), Function.getString(rawCUSTDATA.ACTNO ).Trim() };
                            sql = TransDataAServer.CUSDATA.getSql(rawCUSTDATA);
                            break; 
                    }
                    if (keyValue != preValue)
                    {
                        deletesql =  "delete "+TableName+" where ";
                        for(int i=0;i<keyColumn.Length ;i++)
                        {
                            deletesql += keyColumn[i] + " ='" + keyValue[i]+"' and ";
                        }
                        deletesql = deletesql.Substring(0, deletesql.Length - 4);
                        delDayData(TableName, deletesql, keyColumn, keyValue, ref isOK, ref statuscode, ref statusdesc);
                    }
                    preValue = keyValue;
                    isOK = runExecuteNonQuery(sql, Properties.Settings.Default.ConfigDB);
                    if (isOK == false)
                    {
                        statuscode = "E";
                        statusdesc = "DB轉檔指令失敗!";
                        this.ErrLog(fileName + " SaveDB Error：DB轉檔指令失敗!");
                    }
                    row += 1;
                }
            }
            Log(string.Format("filepath[{0}]  file Open end", filepath));
            file.Close();

          
     
            //20150120判斷 P09F P09O P08F P08O 檔案是否為最新
            System.IO.FileInfo fi = new System.IO.FileInfo(filepath);
            if (TableName == "P09F" || TableName == "P09O" || TableName == "P08F" || TableName == "P08O")
            {
                if (fi.LastWriteTime.ToString("yyyyMMdd") != DateTime.Now.ToString("yyyyMMdd"))
                {
                    statuscode = "E";
                    statusdesc = fileName + " ：該檔案非最新檔!";
                    this.ErrLog(fileName + " ：該檔案非最新檔!");
                }
            }
        }
        private void saveDBUpdateByKey(string folderPath, string fileName, string TableName, ref bool isOK, ref string statuscode, ref string statusdesc, ref int row)
        {
            string strLine = null;
            string filepath = folderPath + "\\" + fileName;
            Log(string.Format("filepath[{0}]  file Open Start", filepath));

            System.IO.StreamReader file = new System.IO.StreamReader(filepath, Encoding.GetEncoding(950));
            string sql = "";

            int datalen = getDataLen(TableName); 
            while ((strLine = file.ReadLine()) != null)
            {
                byte[] byLine = Encoding.GetEncoding(950).GetBytes(strLine);
                if (byLine.Length >= datalen)
                {
                    switch (TableName)
                    { 
                        case "AEDATA"://營業員基本資料檔 
                            sql = TransDataAServer.AEDATA.getSql(AEDATA.getAEDATA(byLine));
                            break; 
                    } 
                    isOK = runExecuteNonQuery(sql, Properties.Settings.Default.ConfigDB);
                    if (isOK == false)
                    {
                        statuscode = "E";
                        statusdesc = "DB轉檔指令失敗!";
                        this.ErrLog(fileName + " SaveDB Error：DB轉檔指令失敗!");
                    }
                    row += 1;
                }
            }
            //disabled 營業員
            if (TableName == "AEDATA")
            {
                isOK = runExecuteNonQuery("update AEDATA set ENABLED_FLAG='N' where CONVERT(char(8),isnull(UPD_DATE,CRT_DATE),112)<CONVERT(char(8),getdate(),112) ", Properties.Settings.Default.ConfigDB);
                if (isOK == false)
                {
                    statuscode = "E";
                    statusdesc = "DB轉檔指令失敗!";
                    this.ErrLog(TableName + " Delete Error：DB轉檔指令失敗!");
                } 
            }
            Log(string.Format("filepath[{0}]  file Open end", filepath));
            file.Close();
            //20150120判斷 P09F P09O P08F P08O 檔案是否為最新
            System.IO.FileInfo fi = new System.IO.FileInfo(filepath);
            
        }
        private void delDayData(string TableName, string sql, string[] keyColumn, string[] keyValue, ref bool isOK, ref string statuscode, ref string statusdesc)
        {
            Log(string.Format("Delete [{0}] keycolumn [{1}] valuecolumn [{2}]  start", TableName,string.Join(" and ", keyColumn),string.Join(" and ", keyValue))); 
            isOK = runExecuteNonQuery(sql, Properties.Settings.Default.ConfigDB); 
            if (isOK == false)
            {
                statuscode = "E";
                statusdesc = "DB轉檔指令失敗!";
                this.ErrLog(TableName + " Delete Error：DB轉檔指令失敗!");

            }
            Log(string.Format("Delete [{0}]   keycolumn [{1}] valuecolumn [{2}]  end", TableName,  string.Join(" and ", keyColumn), string.Join(" and ", keyValue))); 
        }
        private int getDataLen(string TableName)
        {
            int len = 0;
            switch (TableName)
            {
                case "P09F"://P09期貨
                    FileInfo.P09F P09F = new FileInfo.P09F();
                    len = Marshal.SizeOf(P09F);
                    break;
                case "P09O"://P09選擇權
                    FileInfo.P09O P09O = new FileInfo.P09O();
                    len = Marshal.SizeOf(P09O);
                    break;
                case "P08"://P08 
                    FileInfo.P08 P08 = new FileInfo.P08();
                    len = Marshal.SizeOf(P08);
                    break; 
                case "ACPARTY"://群組帳號檔
                    FileInfo.ACPARTY ACPARTY = new FileInfo.ACPARTY();
                    len = Marshal.SizeOf(ACPARTY);
                    break;
                case "INCOME_DETAIL"://平倉明細檔
                    FileInfo.INCOME_DETAIL INCOME_DETAIL = new FileInfo.INCOME_DETAIL();
                    len = Marshal.SizeOf(INCOME_DETAIL);
                    break;
                case "WORKDAY"://工作日檔
                    FileInfo.WORKDAY WORKDAY = new FileInfo.WORKDAY();
                    len = Marshal.SizeOf(WORKDAY);
                    break;
                case "CASHLOG"://出入金
                    FileInfo.CASHLOG CASHLOG = new FileInfo.CASHLOG();
                    len = Marshal.SizeOf(CASHLOG);
                    break;
                case "CUSDATA"://客戶基本資料檔
                    FileInfo.CUSDATA CUSDATA = new FileInfo.CUSDATA();
                    len = Marshal.SizeOf(CUSDATA);
                    break;
                case "AEDATA"://營業員基本資料檔
                    FileInfo.AEDATA AEDATA = new FileInfo.AEDATA();
                    len = Marshal.SizeOf(AEDATA);
                    break;
                case "KSCM026P"://跳動點檔
                    FileInfo.KSCM026P KSCM026P = new FileInfo.KSCM026P();
                    len = Marshal.SizeOf(KSCM026P);
                    break;
                case "PW_SET"://密碼
                    FileInfo.PWSET PWSET = new FileInfo.PWSET();
                    len = Marshal.SizeOf(PWSET);
                    break;
            }
            return len;
        }


        private void FtpDownload(string filePath, string fileName, string ftp_filename,string ftpserver)
        {

            FtpWebRequest reqFTP=null;

            try
            {



                if (!Directory.Exists(filePath))
                {
                    Directory.CreateDirectory(filePath);
                }

                FileStream outputStream = new FileStream(filePath + "\\" + fileName, FileMode.Create);
                if (ftpserver == "1")
                {
                    reqFTP = (FtpWebRequest)FtpWebRequest.Create(new Uri(this._FtpUri + "//" + ftp_filename));
                    reqFTP.Credentials = new NetworkCredential(this._FtpAccount, this._FtpPassword);
                }
                else if (ftpserver == "2")
                {
                    reqFTP = (FtpWebRequest)FtpWebRequest.Create(new Uri(this._FtpUri2 + "//" + ftp_filename));
                    reqFTP.Credentials = new NetworkCredential(this._FtpAccount2, this._FtpPassword2);
                }
                reqFTP.Method = WebRequestMethods.Ftp.DownloadFile;

                reqFTP.UseBinary = true;

             

                FtpWebResponse response = (FtpWebResponse)reqFTP.GetResponse();

                Stream ftpStream = response.GetResponseStream();

                long cl = response.ContentLength;

                int bufferSize = 2048;

                int readCount;

                byte[] buffer = new byte[bufferSize];


                readCount = ftpStream.Read(buffer, 0, bufferSize);

                while (readCount > 0)
                {

                    outputStream.Write(buffer, 0, readCount);

                    readCount = ftpStream.Read(buffer, 0, bufferSize);

                }


                ftpStream.Close();
                outputStream.Close();
                response.Close();

            }

            catch (Exception ex)
            {
                throw ex;

            }
            finally
            {
              
            }

        }
        public bool runExecuteNonQuery(string sqlCommand, string db)
        {
            bool bolSuccess = true;
            SqlConnection conn = new SqlConnection(db);
            SqlTransaction trans = null;
            SqlCommand cmd = null;
            int idxCurrent = 0;
            string strerrorsql = "";
            try
            {
                // open database link
                try
                {
                    conn.Open();
                }
                catch (Exception exConnect)
                {
                    bolSuccess = false;
                    this.ErrLog("資料庫連線錯誤:" + exConnect.ToString());
                }

                // create Transaction 
                trans = conn.BeginTransaction();
                // create SqlDbCommand
                cmd = conn.CreateCommand();
                // set Connection to OracleCommand Object
                cmd.Connection = conn;
                // set CommandType to OracleCommand Object
                cmd.CommandType = CommandType.Text;
                // set CommandTimeout to OracleCommand Object
                // cmd.CommandTimeout = oleConn.getTimeout();
                // set Transaction to  OracleCommand Object
                cmd.Transaction = trans;
                cmd.CommandTimeout = 300;



                strerrorsql = sqlCommand;
                cmd.CommandText = sqlCommand;
               
                //Console.Write(i);
                // exectue (run)
                int intRecordsAffected = cmd.ExecuteNonQuery();


                trans.Commit();
                // set retrun DataTable :: info
            }
            catch (Exception ex)
            {
                this.ErrLog("資料庫寫入錯誤:" + ex.ToString() + "sql 內容" + strerrorsql);
                try
                {
                    trans.Rollback();
                }
                catch (Exception oleEx)
                {
                    bolSuccess = false;
                    this.ErrLog("資料庫錯誤rollback錯誤:" + oleEx.ToString());
                }
                bolSuccess = false;
            }
            finally
            {
                if (trans != null)
                {
                    trans = null;
                }
                if (cmd != null)
                {
                    cmd.Dispose();
                    cmd = null;
                }
                if (conn != null)
                {
                    conn.Close();
                    conn = null;
                }
            }
            return bolSuccess;
        }
        public bool runExecuteNonQuery(String[] sqlCommand, string db)
        {
            bool bolSuccess = true;
            SqlConnection conn = new SqlConnection(db);
            SqlTransaction trans = null;
            SqlCommand cmd = null;
            int idxCurrent = 0;
            string strerrorsql = "";
            try
            {
                // open database link
                try
                {
                    conn.Open();
                }
                catch (Exception exConnect)
                {
                    bolSuccess = false;
                    this.ErrLog("資料庫連線錯誤:" + exConnect.ToString());
                }

                // create Transaction 
                trans = conn.BeginTransaction();
                // create SqlDbCommand
                cmd = conn.CreateCommand();
                // set Connection to OracleCommand Object
                cmd.Connection = conn;
                // set CommandType to OracleCommand Object
                cmd.CommandType = CommandType.Text;
                // set CommandTimeout to OracleCommand Object
                // cmd.CommandTimeout = oleConn.getTimeout();
                // set Transaction to  OracleCommand Object
                cmd.Transaction = trans;
                cmd.CommandTimeout = 300;
                for (int i = 0; i < sqlCommand.Length; i++)
                {
                    idxCurrent = i;
                    //if (i > 257)
                    //{
                    //    m_temp1 = i.ToString();

                    //}

                    //      if (!sqlCommand[i].Trim().Equals(""))
                    //   {
                    // set SQL Statement to OracleCommand Object
                    if (sqlCommand[i] != null)
                    {
                        strerrorsql = sqlCommand[i];
                        cmd.CommandText = sqlCommand[i];

                        //Console.Write(i);
                        // exectue (run)
                        int intRecordsAffected = cmd.ExecuteNonQuery();
                    }
                    //  }
                }
                trans.Commit();
                // set retrun DataTable :: info
            }
            catch (Exception ex)
            {
                this.ErrLog("資料庫寫入錯誤:" + ex.ToString() + "sql 內容" + strerrorsql);
                try
                {
                    trans.Rollback();
                }
                catch (Exception oleEx)
                {
                    bolSuccess = false;
                    this.ErrLog("資料庫錯誤rollback錯誤:" + oleEx.ToString());
                }
                bolSuccess = false;
            }
            finally
            {
                if (trans != null)
                {
                    trans = null;
                }
                if (cmd != null)
                {
                    cmd.Dispose();
                    cmd = null;
                }
                if (conn != null)
                {
                    conn.Close();
                    conn = null;
                }
            }
            return bolSuccess;
        }
        private bool execDB(string str_SQLconn, string str_UpDateCmd, string str_InsertDateCmd)
        {
            bool blnSuccess = false;
            SqlConnection sqlConn;
            SqlCommand sqlcmd;
            sqlConn = new SqlConnection(str_SQLconn);
            sqlcmd = new SqlCommand();
            sqlcmd.Connection = sqlConn;
            sqlConn.Open();
            try
            {
                sqlcmd.CommandText = str_UpDateCmd;
                if (sqlcmd.ExecuteNonQuery() == 0)
                {
                    sqlcmd.CommandText = str_InsertDateCmd;
                    sqlcmd.ExecuteNonQuery();
                }
                blnSuccess = true;
            }
            catch (SqlException ex)
            {
                this.ErrLog("SQL Insert:" + str_InsertDateCmd + " Sql Update: " + str_UpDateCmd + ex.StackTrace.ToString() + "/" + ex.ToString());
                blnSuccess = false;
            }
            finally
            {
                sqlConn.Close();
            }
            return blnSuccess;
        }
        private void chkOpenFile_CheckedChanged(object sender, EventArgs e)
        {
            lblFolder.Text = "";
            if (chkOpenFile.Checked)
            {

                folderBrowserDialog1.SelectedPath  = Properties.Settings.Default.FILEPATH;
                if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
                {
                    lblFolder.Text = folderBrowserDialog1.SelectedPath;
                }
                else
                {
                    chkOpenFile.Checked = false;
                }

            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            try
            {
                _LM.CloseWriteLog("TransDataAServerLog");
                _LM.CloseWriteLog("TransDataAServerErrLog");
                _LM.Dispose();

                if (_StartRunning != null)
                    _StartRunning.Stop();
            }
            catch (Exception ex)
            { 
            }

        }

        private void btnTime2_Click(object sender, EventArgs e)
        {
            bolManualTime = true;
            DisplaySetFileName();
            bolManualTime = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ExecALLSTOCKCUS();
        }
        private void ExecALLSTOCKCUS( )
        {
            string TableName = "全轉證券客戶";
            string statuscode = "";
            string statusdesc = "";
            DataTable dtCOMP = new DataTable();
            //取得分公司資料
            try
            {
                SqlConnection conn = new SqlConnection(Properties.Settings.Default.ConfigDB);
                string SqlCommand = "";
                SqlDataAdapter adp;
                SqlCommand = @"select COMP from COMP_SET";
                adp = new SqlDataAdapter(SqlCommand, conn);
                adp.Fill(dtCOMP);
            }
            catch (Exception ex)
            {
                statuscode = "E";
                statusdesc = "取得分公司資料失敗!";
                this.ErrLog(TableName + " COMP Error：DB取得分公司資料失敗!" + ex.ToString());
            }
            int row = 0;
            bool isOK = false;
            if (statuscode != "E")
            {
                //依照分公司取得客戶資料 
                foreach (DataRow dr in dtCOMP.Rows)
                {
                    try
                    {
                        string comp = dr["COMP"].ToString();
                        int idxPage = 0;
                        while (idxPage > -1)
                        {
                            string url = Properties.Settings.Default.STOCKCUS_URL + "TASBCCusMgmt.dll?GetSBCMACus&tapage=xml&start=" + idxPage.ToString() + "&comp=" + comp;
                            this.Log(TableName + ": 取得" + comp + "分公司 證券客戶資料" + url);
                            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                            Uri target = new Uri(url);
                            request.CookieContainer = new CookieContainer();
                            request.CookieContainer.Add(new Cookie("TAWork", "0eNsUTycrhWDy2HttNbBCJ5gEL2nK6xiArdhQVxBXqGDTKI4QxreTnM99ukmsv02kIp5CBebK33pK9cq+2x+C+T6c0io7D+vxY82N6wysNv4C/dvhk9pPex2WiFjqcrPH3GvcnzJFiUCSavqpgJLJu/EshRvdqbGkubQCUhx9AGOuL7qO20SupGnzsum+RkI") { Domain = target.Host });
                            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                            string content = new StreamReader(response.GetResponseStream(), Encoding.GetEncoding(950)).ReadToEnd();
                            XmlDocument xml = new XmlDocument();
                            xml.LoadXml(content);
                            string code = "";
                            if (xml.SelectSingleNode(".//TAStatus").Attributes["code"] != null)
                                code = xml.SelectSingleNode(".//TAStatus").Attributes["code"].Value;
                            if (code != "0")
                            {
                                idxPage = -1;
                                break;
                            }
                            foreach (XmlNode cusnode in xml.SelectNodes(".//SBCMACUS"))
                            {
                                string COMP = "";
                                string COSY = "";
                                string CONA = "";
                                string SETT = "";
                                string IDNO = "";
                                string CUSY = "";
                                string BRDT = "";
                                string CONTRACT1 = "";
                                string CONTRACT2 = "";
                                string CONTRACT3 = "";
                                string CONTRACTAPI = "";
                                string CONTRACT = "";
                                string EMAIL = "";
                                if (cusnode.Attributes["comp"] != null)
                                    COMP = cusnode.Attributes["comp"].Value;
                                if (cusnode.Attributes["cosy"] != null)
                                    COSY = cusnode.Attributes["cosy"].Value;
                                if (cusnode.Attributes["cona"] != null)
                                    CONA = cusnode.Attributes["cona"].Value;
                                if (cusnode.Attributes["sett"] != null)
                                    SETT = cusnode.Attributes["sett"].Value;

                                if (cusnode.Attributes["idno"] != null)
                                    IDNO = cusnode.Attributes["idno"].Value;
                                if (cusnode.Attributes["cusy"] != null)
                                    CUSY = cusnode.Attributes["cusy"].Value;
                                if (cusnode.Attributes["brdt"] != null)
                                    BRDT = cusnode.Attributes["brdt"].Value; 

                                //if (BRDT.Length > 8)
                                //    BRDT = BRDT.Substring(BRDT.Length - 8);
                                url = Properties.Settings.Default.STOCKCUS_URL + "TASBCCusMgmt.dll?GetSBCMACus&tapage=xml&comp=" + comp + "&sett=" + SETT;
                                this.Log(TableName + ": 取得" + comp + "分公司 證券客戶資料" + SETT + url);
                                request = (HttpWebRequest)WebRequest.Create(url);

                                request.CookieContainer = new CookieContainer();
                                request.CookieContainer.Add(new Cookie("TAWork", "0eNsUTycrhWDy2HttNbBCJ5gEL2nK6xiArdhQVxBXqGDTKI4QxreTnM99ukmsv02kIp5CBebK33pK9cq+2x+C+T6c0io7D+vxY82N6wysNv4C/dvhk9pPex2WiFjqcrPH3GvcnzJFiUCSavqpgJLJu/EshRvdqbGkubQCUhx9AGOuL7qO20SupGnzsum+RkI") { Domain = target.Host });
                                response = (HttpWebResponse)request.GetResponse();
                                string contentC = new StreamReader(response.GetResponseStream(), Encoding.GetEncoding(950)).ReadToEnd();
                                XmlDocument xmlC = new XmlDocument();
                                xmlC.LoadXml(contentC);
                                this.Log(contentC);
                                XmlNode ctnonode = xmlC.SelectSingleNode(".//CACCONTRS/CACCONTR[@ctno=0]");
                                if (ctnonode != null)
                                {
                                    if (ctnonode.Attributes["ctst"] != null)
                                        CONTRACT = ctnonode.Attributes["ctst"].Value;
                                }
                                XmlNode mailnode = xmlC.SelectSingleNode(".//CACLIAIS[@lino=3]");
                                if (mailnode != null)
                                {
                                    if (mailnode.Attributes["liad"] != null)
                                        EMAIL = mailnode.Attributes["liad"].Value;
                                } 
                                if (CONTRACT != "1" && CONTRACT != "9")
                                {
                                    XmlNode ctnonode1 = xmlC.SelectSingleNode(".//CACCONTRS/CACCONTR[@ctno=11]");
                                    if (ctnonode1 != null)
                                    {
                                        if (ctnonode1.Attributes["ctst"] != null)
                                            CONTRACT1 = ctnonode1.Attributes["ctst"].Value;
                                    }
                                    XmlNode ctnonode2 = xmlC.SelectSingleNode(".//CACCONTRS/CACCONTR[@ctno=903]");
                                    if (ctnonode2 != null)
                                    {
                                        if (ctnonode2.Attributes["ctst"] != null)
                                            CONTRACT2 = ctnonode2.Attributes["ctst"].Value;
                                    }
                                    //金融家Square
                                    XmlNode ctnonode3 = xmlC.SelectSingleNode(".//CACCONTRS/CACCONTR[@ctno=905]");
                                    if (ctnonode3 != null)
                                    {
                                        if (ctnonode3.Attributes["ctst"] != null)
                                            CONTRACT3 = ctnonode3.Attributes["ctst"].Value;
                                    }
                                    //API
                                    XmlNode ctnonodeapi = xmlC.SelectSingleNode(".//CACCONTRS/CACCONTR[@ctno=25]");
                                    if (ctnonodeapi != null)
                                    {
                                        if (ctnonodeapi.Attributes["ctst"] != null)
                                            CONTRACTAPI = ctnonodeapi.Attributes["ctst"].Value;
                                    }

                                    //紳洋
                                    string CONTRACT913 = "";
                                    XmlNode ctnonode913 = xmlC.SelectSingleNode(".//CACCONTRS/CACCONTR[@ctno=913]");
                                    if (ctnonode913 != null)
                                    {
                                        if (ctnonode913.Attributes["ctst"] != null)
                                            CONTRACT913 = ctnonode913.Attributes["ctst"].Value;
                                    }
                                    //寶碩
                                    string CONTRACT914 = "";
                                    XmlNode ctnonode914 = xmlC.SelectSingleNode(".//CACCONTRS/CACCONTR[@ctno=914]");
                                    if (ctnonode914 != null)
                                    {
                                        if (ctnonode914.Attributes["ctst"] != null)
                                            CONTRACT914 = ctnonode914.Attributes["ctst"].Value;
                                    }
                                    string APAUTH = CONTRACTAPI.PadLeft(1, ' ').Substring(0, 1) + CONTRACT3.PadLeft(1, ' ') + CONTRACT913.PadLeft(1, ' ') + CONTRACT914.PadLeft(1, ' ');
                                    this.Log(APAUTH);
                                    string insertsql = "INSERT INTO STOCKCUS(COMP,COSY,CONA,SETT,IDNO,NAME,BRDT,CONTRACT1,CONTRACT2,APAUTH,EMAIL,CRT_ID,CRT_DATE)VALUES('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}','SYS',getdate())";
                                    insertsql = string.Format(insertsql, COMP, COSY, CONA, SETT, IDNO, CUSY, BRDT, CONTRACT1, CONTRACT2, APAUTH, EMAIL);
                                    string updatesql = "UPDATE STOCKCUS SET COSY='{2}',CONA='{3}',IDNO='{4}',NAME='{5}',BRDT='{6}' ,CONTRACT1='{7}',CONTRACT2='{8}',APAUTH='{9}',EMAIL='{10}',UPD_ID='SYS',UPD_DATE=getdate()where COMP='{0}'and SETT='{1}' ";
                                    updatesql = string.Format(updatesql, COMP, SETT, COSY, CONA, IDNO, CUSY, BRDT, CONTRACT1, CONTRACT2, APAUTH, EMAIL);

                                    row++;
                                    isOK = execDB(Properties.Settings.Default.ConfigDB, updatesql, insertsql);
                                    if (isOK == false)
                                    {
                                        statuscode = "E";
                                        statusdesc = "DB轉檔指令失敗!";
                                        this.ErrLog(TableName + " SaveDB Error：DB轉檔指令失敗!");

                                    }
                                }
                                else
                                {
                                    row++;
                                    string updatesql = "delete STOCKCUS  where COMP='{0}'and SETT='{1}' ";
                                    updatesql = string.Format(updatesql, COMP, SETT);

                                    isOK = execDB(Properties.Settings.Default.ConfigDB, updatesql, updatesql);
                                    if (isOK == false)
                                    {
                                        statuscode = "E";
                                        statusdesc = "DB轉檔指令失敗!";
                                        this.ErrLog(TableName + " SaveDB Error：DB轉檔指令失敗!");

                                    }
                                }
                            }
                            idxPage++;
                        }
                    }
                    catch (Exception ex)
                    {
                        statuscode = "E";
                        statusdesc = "文字處理失敗!";
                        this.ErrLog(TableName + "文字處理失敗" + ex.ToString());
                    }
                }

            }

            if (row <= 0 && statuscode == "")
            {
                statuscode = "E";
                statusdesc = TableName + " ：該檔案無資料!";
                this.ErrLog(TableName + " ：該檔案無資料!");

            }
            else if (row > 0 && statuscode == "")
            {
                statuscode = "O";
                statusdesc = "轉檔成功!";
                this.Log(TableName + " Success：轉檔成功!");

            } 
        }

    }
}
