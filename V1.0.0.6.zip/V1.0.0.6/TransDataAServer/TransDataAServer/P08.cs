using System;
                                        using System.Collections.Generic;
                                        using System.Linq;
                                        using System.Text;
                                        using System.Runtime.InteropServices;
                                        namespace TransDataAServer
                                        {
                                            public class P08
                                            {
                                                public static string getSql(FileInfo.P08 raw)
                                                {
                                                    try
                                                    {
                                                        string cp = Function.getString(raw.P08_CP_CODE).Trim();
                                                        string tablename = "";
                                                        if (cp == "")
                                                            tablename = "P08F";
                                                        else
                                                            tablename = "P08O"; 
                                                        string sql = string.Format(@"INSERT INTO   {18}(COMMODITY_ID,SETTLEMENT_MONTH,STRIKE_PRICE,CP_CODE,BEGIN_DATE,END_DATE,RAISE_PRICE,FALL_PRICE,PREMIUM,RAISE_PRICE2,FALL_PRICE2,RAISE_PRICE3,FALL_PRICE3,PROD_KIND,ACCEPT_QUOTE_FLAG,DECIMAL_LOCATOR,PSEQ,FLOW_GROUP,UPD_DATE)VALUES
('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}','{12}','{13}','{14}','{15}','{16}','{17}',convert(char(8),getdate(),112))"
, Function.getString(raw.P08_COMMODITY_ID    ).Trim()
,Function.getString(raw.P08_SETTLEMENT_MONTH).Trim()
, Function.getPrice(5, 4, Function.getString(raw.P08_STRIKE_PRICE)).ToString("#0.###")
, cp
,Function.getString(raw.P08_BEGIN_DATE      ).Trim()
,Function.getString(raw.P08_END_DATE        ).Trim()
, Function.getPrice((9-int.Parse(Function.getString(raw.P08_DECIMAL_LOCATOR))), int.Parse(Function.getString(raw.P08_DECIMAL_LOCATOR)) , Function.getString(raw.P08_RAISE_PRICE     ))
, Function.getPrice((9-int.Parse(Function.getString(raw.P08_DECIMAL_LOCATOR))), int.Parse(Function.getString(raw.P08_DECIMAL_LOCATOR)) , Function.getString(raw.P08_FALL_PRICE      ))
, Function.getPrice((9-int.Parse(Function.getString(raw.P08_DECIMAL_LOCATOR))), int.Parse(Function.getString(raw.P08_DECIMAL_LOCATOR)) , Function.getString(raw.P08_PREMIUM         ))
, Function.getPrice((9-int.Parse(Function.getString(raw.P08_DECIMAL_LOCATOR))), int.Parse(Function.getString(raw.P08_DECIMAL_LOCATOR)) , Function.getString(raw.P08_RAISE_PRICE2    ))
, Function.getPrice((9-int.Parse(Function.getString(raw.P08_DECIMAL_LOCATOR))), int.Parse(Function.getString(raw.P08_DECIMAL_LOCATOR)) , Function.getString(raw.P08_FALL_PRICE2     ))
, Function.getPrice((9-int.Parse(Function.getString(raw.P08_DECIMAL_LOCATOR))), int.Parse(Function.getString(raw.P08_DECIMAL_LOCATOR)) , Function.getString(raw.P08_RAISE_PRICE3    ))
, Function.getPrice((9-int.Parse(Function.getString(raw.P08_DECIMAL_LOCATOR))), int.Parse(Function.getString(raw.P08_DECIMAL_LOCATOR)) , Function.getString(raw.P08_FALL_PRICE3     ))
,Function.getString(raw.P08_PROD_KIND       ).Trim()
,Function.getString(raw.P08_ACCEPT_QUOTE_FLAG).Trim()
,Function.getString(raw.P08_DECIMAL_LOCATOR ).Trim()
,Function.getString(raw.P08_PSEQ            ).Trim()
, Function.getString(raw.P08_FLOW_GROUP).Trim(), tablename
  );
                                    return sql;
                                }
                                catch (Exception ex)
                                {
                                    throw ex;
                                }
                            }
                            public static FileInfo.P08 getP08(Byte[] byLine )
                                {
                                    try
                                    {
                                        FileInfo.P08 P08F = new FileInfo.P08();

                                        int len = Marshal.SizeOf(P08F);
                                        IntPtr ptr = Marshal.AllocHGlobal(len);
                                        Marshal.Copy(byLine, 0, ptr, len);
                                        P08F = (FileInfo.P08)Marshal.PtrToStructure(ptr, typeof(FileInfo.P08));
                                        Marshal.FreeHGlobal(ptr); 
                                        return P08F;
                                    }
                                    catch (Exception ex)
                                    {
                                        throw ex;
                                    }
                                }

                            }
                        }

                        