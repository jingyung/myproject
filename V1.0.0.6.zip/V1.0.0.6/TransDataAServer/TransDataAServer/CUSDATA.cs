using System;
                                        using System.Collections.Generic;
                                        using System.Linq;
                                        using System.Text;
                                        using System.Runtime.InteropServices;
                                        namespace TransDataAServer
                                        {
                                            public class CUSDATA
                                            {
                                                public static string getSql(FileInfo.CUSDATA raw)
                                                {
                                                    try
                                                    {
                                                        string sql = string.Format(@" INSERT INTO   CUSTDATA(OCCTP,FIRM,ACTNO,BROKER,TACTNO,IDNO,AENO,SNDCHK,APPLYDATE,LEMAIL,MTYPE,ACTNAME,BIRTHDT,STCRRY,BANKNO,BANKACNO,BANKNO1,BANKACNO1,BANKNO2,BANKACNO2,BANKNO3,BANKACNO3,ODATE,FDATE,DTFLAG,SORT,SEX,EDUCATION,CONAME,JOB,LZIPCODE,LADDRESS,LTELNO,LCELLPHONE,LFAXNO,CZIPCODE,CADDRESS,CTELNO,ECUST,MKTFLG,PASSWORD,VIPFLG,NSKFLG,ITTFLG,ITJFLG,APIFLG,BANKNOUS,BANKACNOUS,BANKNOUS1,BANKACNOUS1,BANKNOUS2,BANKACNOUS2,BANKNOUS3,BANKACNOUS3,BANKNOCN,BANKACNOCN,BANKNOCN1,BANKACNOCN1,BANKNOCN2,BANKACNOCN2,BANKNOCN3,BANKACNOCN3,ITSFLG,ITPFLG,FUSIGNCODE,APAUTH)VALUES
('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}','{12}','{13}','{14}','{15}','{16}','{17}','{18}','{19}','{20}','{21}','{22}','{23}','{24}','{25}','{26}','{27}','{28}','{29}','{30}','{31}','{32}','{33}','{34}','{35}','{36}','{37}','{38}','{39}','{40}','{41}','{42}','{43}','{44}','{45}','{46}','{47}','{48}','{49}','{50}','{51}','{52}','{53}','{54}','{55}','{56}','{57}','{58}','{59}','{60}','{61}','{62}','{63}','{64}','{65}')"
, Function.getString(raw.OCCTP).Trim()
,Function.getString(raw.FIRM).Trim()
,Function.getString(raw.ACTNO).Trim()
,Function.getString(raw.BROKER).Trim()
,Function.getString(raw.TACTNO).Trim()
,Function.getString(raw.IDNO).Trim()
,Function.getString(raw.AENO).Trim()
,Function.getString(raw.SNDCHK).Trim()
,Function.getString(raw.APPLYDATE).Trim()
,Function.getString(raw.LEMAIL).Trim()
,Function.getString(raw.MTYPE).Trim()
,Function.getString(raw.ACTNAME).Trim()
,Function.getString(raw.BIRTHDT).Trim()
,Function.getString(raw.STCRRY).Trim()
,Function.getString(raw.BANKNO).Trim()
,Function.getString(raw.BANKACNO).Trim()
,Function.getString(raw.BANKNO1).Trim()
,Function.getString(raw.BANKACNO1).Trim()
,Function.getString(raw.BANKNO2).Trim()
,Function.getString(raw.BANKACNO2).Trim()
,Function.getString(raw.BANKNO3).Trim()
,Function.getString(raw.BANKACNO3).Trim()
,Function.getString(raw.ODATE).Trim()
,Function.getString(raw.FDATE).Trim()
,Function.getString(raw.DTFLAG).Trim()
,Function.getString(raw.SORT).Trim()
,Function.getString(raw.SEX).Trim()
,Function.getString(raw.EDUCATION).Trim()
,Function.getString(raw.CONAME).Trim()
,Function.getString(raw.JOB).Trim()
,Function.getString(raw.LZIPCODE).Trim()
,Function.getString(raw.LADDRESS).Trim()
,Function.getString(raw.LTELNO).Trim()
,Function.getString(raw.LCELLPHONE).Trim()
,Function.getString(raw.LFAXNO).Trim()
,Function.getString(raw.CZIPCODE).Trim()
,Function.getString(raw.CADDRESS).Trim()
,Function.getString(raw.CTELNO).Trim()
,Function.getString(raw.ECUST).Trim()
,Function.getString(raw.MKTFLG).Trim()
             , Function.getString(raw.PASSWORD).Trim()
           , Function.getString(raw.HTSFLG).Trim()
           , Function.getString(raw.NSKFLG).Trim()
           , Function.getString(raw.ITTFLG).Trim()
           , Function.getString(raw.ITJFLG).Trim()
           , Function.getString(raw.APIFLG).Trim()
           , Function.getString(raw.BANKNOUS).Trim()
           , Function.getString(raw.BANKACNOUS).Trim()
           , Function.getString(raw.BANKNOUS1).Trim()
           , Function.getString(raw.BANKACNOUS1).Trim()
           , Function.getString(raw.BANKNOUS2).Trim()
           , Function.getString(raw.BANKACNOUS2).Trim()
           , Function.getString(raw.BANKNOUS3).Trim()
           , Function.getString(raw.BANKACNOUS3).Trim()
           , Function.getString(raw.BANKNOCN).Trim()
           , Function.getString(raw.BANKACNOCN).Trim()
           , Function.getString(raw.BANKNOCN1).Trim()
           , Function.getString(raw.BANKACNOCN1).Trim()
           , Function.getString(raw.BANKNOCN2).Trim()
           , Function.getString(raw.BANKACNOCN2).Trim()
           , Function.getString(raw.BANKNOCN3).Trim()
           , Function.getString(raw.BANKACNOCN3).Trim()
           , Function.getString(raw.ITSFLG).Trim()
           , Function.getString(raw.ITPFLG).Trim()
            , Function.getString(raw.FUSIGNCODE).Trim()
             , Function.getString(raw.APAUTH).Trim());
                                    return sql;
                                }
                                catch (Exception ex)
                                {
                                    throw ex;
                                }
                            }
                            public static FileInfo.CUSDATA getCUSDATA(Byte[] byLine )
                                {
                                    try
                                    {
                                        FileInfo.CUSDATA CUSDATA = new FileInfo.CUSDATA();

                                        int len = Marshal.SizeOf(CUSDATA);
                                        IntPtr ptr = Marshal.AllocHGlobal(len);
                                        Marshal.Copy(byLine, 0, ptr, len);
                                        CUSDATA = (FileInfo.CUSDATA)Marshal.PtrToStructure(ptr, typeof(FileInfo.CUSDATA));
                                        Marshal.FreeHGlobal(ptr); 
                                        return CUSDATA;
                                    }
                                    catch (Exception ex)
                                    {
                                        throw ex;
                                    }
                                }

                            }
                        }

                        