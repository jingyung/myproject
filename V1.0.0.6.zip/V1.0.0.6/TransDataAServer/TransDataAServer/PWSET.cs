using System;
                                        using System.Collections.Generic;
                                        using System.Linq;
                                        using System.Text;
                                        using System.Runtime.InteropServices;
                                        namespace TransDataAServer
                                        {
                                            public class PWSET
                                            {
                                                public static string getSql(FileInfo.PWSET raw)
                                                {
                                                    try
                                                    {
                                                        string sql = string.Format(@" INSERT INTO   PW_SET(IDNO,TYPE,PASSWORD,PW_FLAG,PW_DATE,ERRORCOUNT,CRT_ID,CRT_DATE)VALUES
                                                                                ('{0}','{1}','{2}','{3}', CONVERT(char(8),getdate(),112),0,'SYS',getdate())"
                                                                                , Function.getString(raw.IDNO).Trim()
                                                                                , Function.getString(raw.TYPE).Trim()=="0"?"1":"2"
                                                                                , Function.getString(raw.PASSWORD).Trim()
                                                                                , Function.getString(raw.PWFLAG).Trim() == "10"?"N":"Y"
  );
                                    return sql;
                                }
                                catch (Exception ex)
                                {
                                    throw ex;
                                }
                            }
                                                public static FileInfo.PWSET getPWSET(Byte[] byLine)
                                {
                                    try
                                    {
                                        FileInfo.PWSET PWSET = new FileInfo.PWSET();

                                        int len = Marshal.SizeOf(PWSET);
                                        IntPtr ptr = Marshal.AllocHGlobal(len);
                                        Marshal.Copy(byLine, 0, ptr, len);
                                        PWSET = (FileInfo.PWSET)Marshal.PtrToStructure(ptr, typeof(FileInfo.PWSET));
                                        Marshal.FreeHGlobal(ptr);
                                        return PWSET;
                                    }
                                    catch (Exception ex)
                                    {
                                        throw ex;
                                    }
                                }

                            }
                        }

                        