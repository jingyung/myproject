﻿namespace TransDataAServer
{
    partial class MainForm
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改這個方法的內容。
        ///
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.chkOpenFile = new System.Windows.Forms.CheckBox();
            this.dgvMarketInfoSet = new System.Windows.Forms.DataGridView();
            this.chkSelColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.lblFolder = new System.Windows.Forms.Label();
            this.TransferTimer = new System.Windows.Forms.Timer(this.components);
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.btnTime2 = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnChange = new System.Windows.Forms.Button();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMarketInfoSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // chkOpenFile
            // 
            this.chkOpenFile.AutoSize = true;
            this.chkOpenFile.Font = new System.Drawing.Font("新細明體", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.chkOpenFile.Location = new System.Drawing.Point(23, 46);
            this.chkOpenFile.Name = "chkOpenFile";
            this.chkOpenFile.Size = new System.Drawing.Size(170, 19);
            this.chkOpenFile.TabIndex = 9;
            this.chkOpenFile.Text = "選取文字檔路徑轉檔";
            this.chkOpenFile.UseVisualStyleBackColor = true;
            this.chkOpenFile.CheckedChanged += new System.EventHandler(this.chkOpenFile_CheckedChanged);
            // 
            // dgvMarketInfoSet
            // 
            this.dgvMarketInfoSet.AllowUserToAddRows = false;
            this.dgvMarketInfoSet.AllowUserToDeleteRows = false;
            this.dgvMarketInfoSet.AllowUserToResizeRows = false;
            this.dgvMarketInfoSet.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            this.dgvMarketInfoSet.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMarketInfoSet.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.chkSelColumn});
            this.dgvMarketInfoSet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvMarketInfoSet.Location = new System.Drawing.Point(0, 0);
            this.dgvMarketInfoSet.Name = "dgvMarketInfoSet";
            this.dgvMarketInfoSet.RowHeadersVisible = false;
            this.dgvMarketInfoSet.RowTemplate.Height = 24;
            this.dgvMarketInfoSet.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.dgvMarketInfoSet.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvMarketInfoSet.Size = new System.Drawing.Size(666, 267);
            this.dgvMarketInfoSet.TabIndex = 1;
            // 
            // chkSelColumn
            // 
            this.chkSelColumn.HeaderText = "選取";
            this.chkSelColumn.Name = "chkSelColumn";
            this.chkSelColumn.Width = 40;
            // 
            // lblFolder
            // 
            this.lblFolder.AutoSize = true;
            this.lblFolder.Cursor = System.Windows.Forms.Cursors.Cross;
            this.lblFolder.Font = new System.Drawing.Font("新細明體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblFolder.Location = new System.Drawing.Point(214, 46);
            this.lblFolder.Name = "lblFolder";
            this.lblFolder.Size = new System.Drawing.Size(0, 15);
            this.lblFolder.TabIndex = 10;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.dgvMarketInfoSet);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.button1);
            this.splitContainer1.Panel2.Controls.Add(this.comboBox1);
            this.splitContainer1.Panel2.Controls.Add(this.btnTime2);
            this.splitContainer1.Panel2.Controls.Add(this.lblFolder);
            this.splitContainer1.Panel2.Controls.Add(this.chkOpenFile);
            this.splitContainer1.Panel2.Controls.Add(this.btnExit);
            this.splitContainer1.Panel2.Controls.Add(this.btnChange);
            this.splitContainer1.Size = new System.Drawing.Size(666, 425);
            this.splitContainer1.SplitterDistance = 267;
            this.splitContainer1.TabIndex = 3;
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(23, 81);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(119, 20);
            this.comboBox1.TabIndex = 12;
            // 
            // btnTime2
            // 
            this.btnTime2.BackColor = System.Drawing.Color.LightSkyBlue;
            this.btnTime2.Location = new System.Drawing.Point(148, 75);
            this.btnTime2.Name = "btnTime2";
            this.btnTime2.Size = new System.Drawing.Size(45, 30);
            this.btnTime2.TabIndex = 11;
            this.btnTime2.Text = "切換";
            this.btnTime2.UseVisualStyleBackColor = false;
            this.btnTime2.Click += new System.EventHandler(this.btnTime2_Click);
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("新細明體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnExit.Location = new System.Drawing.Point(311, 73);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(80, 35);
            this.btnExit.TabIndex = 1;
            this.btnExit.Text = "離 開";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnChange
            // 
            this.btnChange.Font = new System.Drawing.Font("新細明體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnChange.Location = new System.Drawing.Point(217, 73);
            this.btnChange.Name = "btnChange";
            this.btnChange.Size = new System.Drawing.Size(80, 35);
            this.btnChange.TabIndex = 0;
            this.btnChange.Text = "轉 換";
            this.btnChange.UseVisualStyleBackColor = true;
            this.btnChange.Click += new System.EventHandler(this.btnChange_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("新細明體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button1.Location = new System.Drawing.Point(23, 116);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(119, 26);
            this.button1.TabIndex = 13;
            this.button1.Text = "證券客戶資料重轉";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(666, 425);
            this.Controls.Add(this.splitContainer1);
            this.Name = "MainForm";
            this.Text = "每日轉檔";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_FormClosed);
            this.Load += new System.EventHandler(this.MainForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvMarketInfoSet)).EndInit();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.CheckBox chkOpenFile;
        protected internal System.Windows.Forms.DataGridView dgvMarketInfoSet;
        private System.Windows.Forms.DataGridViewCheckBoxColumn chkSelColumn;
        private System.Windows.Forms.Label lblFolder;
        private System.Windows.Forms.Timer TransferTimer;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnChange;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.Button btnTime2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button button1;
    }
}

