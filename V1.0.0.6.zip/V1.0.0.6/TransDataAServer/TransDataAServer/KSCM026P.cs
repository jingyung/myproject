using System;
                                        using System.Collections.Generic;
                                        using System.Linq;
                                        using System.Text;
                                        using System.Runtime.InteropServices;
                                        namespace TransDataAServer
                                        {
                                            public class KSCM026P
                                            {
                                                public static string getSql(FileInfo.KSCM026P raw)
                                                {
                                                    try
                                                    {
                                                        string sql = string.Format(@" INSERT INTO   TICKDATA( KIND_ID,RANGE,TICK,UPD_DATE)VALUES
('{0}','{1}','{2}',convert(char(8),getdate(),112))" 
,Function.getString(raw.CM026020).Trim() 
,Function.getPrice(7,6,Function.getString(raw.CM026050).Trim())
, Function.getPrice(7, 6, Function.getString(raw.CM026060).Trim())
  );
                                    return sql;
                                }
                                catch (Exception ex)
                                {
                                    throw ex;
                                }
                            }
                            public static FileInfo.KSCM026P getKSCM026P(Byte[] byLine )
                                {
                                    try
                                    {
                                        FileInfo.KSCM026P KSCM026P = new FileInfo.KSCM026P();

                                        int len = Marshal.SizeOf(KSCM026P);
                                        IntPtr ptr = Marshal.AllocHGlobal(len);
                                        Marshal.Copy(byLine, 0, ptr, len);
                                        KSCM026P = (FileInfo.KSCM026P)Marshal.PtrToStructure(ptr, typeof(FileInfo.KSCM026P));
                                        Marshal.FreeHGlobal(ptr); 
                                        return KSCM026P;
                                    }
                                    catch (Exception ex)
                                    {
                                        throw ex;
                                    }
                                }

                            }
                        }

                        