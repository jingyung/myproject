using System;
                                        using System.Collections.Generic;
                                        using System.Linq;
                                        using System.Text;
                                        using System.Runtime.InteropServices;
                                        namespace TransDataAServer
                                        {
                                            public class AEDATA
                                            {
                                                public static string getSql(FileInfo.AEDATA raw)
                                                {
                                                    try
                                                    {
                                                        string sql = string.Format(@"
declare @count int;
select @count=count(*) from AEDATA where BRANCH_NO='{3}'AND SALES='{1}';
if(@count>0)
begin
UPDATE AEDATA SET SALES_NO='{0}',SALS_NAME='{2}',CANCEL_FLAG='{4}',CANCEL_DATE='{5}' ,ENABLED_FLAG='Y',UPD_ID='SYSTEM',UPD_DATE=convert(char(8),getdate(),112)
where BRANCH_NO='{3}'AND SALES='{1}';
end
else
begin
INSERT INTO   AEDATA(SALES_NO,SALES,SALS_NAME,BRANCH_NO,CANCEL_FLAG,CANCEL_DATE,PASSWORD,PW_FLAG,CRT_ID,CRT_DATE,ENABLED_FLAG)VALUES
('{0}','{1}','{2}','{3}','{4}','{5}',dbo.ENCSTRING('{1}'),'Y','SYSTEM', getdate() ,'Y')
end"
, Function.getString(raw.SALES_NO).Trim()
,Function.getString(raw.SALES).Trim()
,Function.getString(raw.SALS_NAME).Trim()
,Function.getString(raw.BRANCH_NO).Trim()
,Function.getString(raw.CANCEL_FLAG).Trim()
,Function.getString(raw.CANCEL_DATE).Trim()
  );
                                    return sql;
                                }
                                catch (Exception ex)
                                {
                                    throw ex;
                                }
                            }
                            public static FileInfo.AEDATA getAEDATA(Byte[] byLine)
                                {
                                    try
                                    {
                                        FileInfo.AEDATA AEDATA = new FileInfo.AEDATA();

                                        int len = Marshal.SizeOf(AEDATA);
                                        IntPtr ptr = Marshal.AllocHGlobal(len);
                                        Marshal.Copy(byLine, 0, ptr, len);
                                        AEDATA = (FileInfo.AEDATA)Marshal.PtrToStructure(ptr, typeof(FileInfo.AEDATA));
                                        Marshal.FreeHGlobal(ptr); 
                                        return AEDATA;
                                    }
                                    catch (Exception ex)
                                    {
                                        throw ex;
                                    }
                                }

                            }
                        }

                        