using System;
                                        using System.Collections.Generic;
                                        using System.Linq;
                                        using System.Text;
                                        using System.Runtime.InteropServices;
                                        namespace TransDataAServer
                                        {
                                            public class ACPARTY
                                            {
                                                public static string getSql(FileInfo.ACPARTY raw)
                                                {
                                                    try
                                                    {
                                                        string sql = string.Format(@" INSERT INTO   ACPARTY(SETT,COMP,SUBSETT,SUBCOMP,UPD_DATE)VALUES
                                                                                    ('{0}', (select top 1 case when BROKER='F039000' then '15000' else BROKER end from CUSTDATA where ACTNO='{0}')
                                                                                        ,'{1}',(select top 1 case when BROKER='F039000' then '15000' else BROKER end from CUSTDATA where ACTNO='{1}') ,convert(char(8),getdate(),112))"
                                                                                      , Function.getString(raw.PARTY_NEMCUID).Trim().PadLeft(7,'0') 
                                                                                      , Function.getString(raw.PARTY_NPACUID).Trim().PadLeft(7, '0')
                                                                                      );
                                    return sql;
                                }
                                catch (Exception ex)
                                {
                                    throw ex;
                                }
                            }
                                                public static FileInfo.ACPARTY getCACPARTY(Byte[] byLine)
                                {
                                    try
                                    {
                                        FileInfo.ACPARTY ACPARTY = new FileInfo.ACPARTY();

                                        int len = Marshal.SizeOf(ACPARTY);
                                        IntPtr ptr = Marshal.AllocHGlobal(len);
                                        Marshal.Copy(byLine, 0, ptr, len);
                                        ACPARTY = (FileInfo.ACPARTY)Marshal.PtrToStructure(ptr, typeof(FileInfo.ACPARTY));
                                        Marshal.FreeHGlobal(ptr);
                                        return ACPARTY;
                                    }
                                    catch (Exception ex)
                                    {
                                        throw ex;
                                    }
                                }

                            }
                        }

                        