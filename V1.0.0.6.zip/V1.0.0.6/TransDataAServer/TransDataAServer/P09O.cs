using System;
                                        using System.Collections.Generic;
                                        using System.Linq;
                                        using System.Text;
                                        using System.Runtime.InteropServices;
                                        namespace TransDataAServer
                                        {
                                            public class P09O
                                            {
                                                public static string getSql(FileInfo.P09O raw)
                                                {
                                                    try
                                                    {
                                                        string sql = string.Format(@" INSERT INTO   P09O(KIND_ID ,NAME,STOCK_ID,SUBTYPE ,CONTRACT_SIZE ,STATUS_CODE,CURRENCY ,STRIKE_DECIMAIL,PRICE_DECIMAIL ,ACCEPT_QUOTE_FLAG ,BEGIN_DATE ,BLOCK_TRADE_FLAG ,EXPIRY_TYPE,UNDERLYING_TYPE,UPD_DATE)VALUES
('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}','{12}','{13}',convert(char(8),getdate(),112))"
, Function.getString(raw.P09_KIND_ID ).Trim()
,Function.getString(raw.P09_NAME).Trim()
,Function.getString(raw.P09_STOCK_ID).Trim()
,Function.getString(raw.P09_SUBTYPE ).Trim()
, Function.getPrice(7, 4, Function.getString(raw.P09_CONTRACT_SIZE ))
,Function.getString(raw.P09_STATUS_CODE).Trim()
,Function.getString(raw.P09_CURRENCY ).Trim()
,Function.getString(raw.P09_STRIKE_DECIMAIL).Trim()
,Function.getString(raw.P09_PRICE_DECIMAIL ).Trim()
,Function.getString(raw.P09_ACCEPT_QUOTE_FLAG ).Trim()
,Function.getString(raw.P09_BEGIN_DATE ).Trim()
,Function.getString(raw.P09_BLOCK_TRADE_FLAG ).Trim()
,Function.getString(raw.P09_EXPIRY_TYPE).Trim()
, Function.getString(raw.FP09_UNDERLYING_TYPE).Trim()
  );
                                    return sql;
                                }
                                catch (Exception ex)
                                {
                                    throw ex;
                                }
                            }
                            public static FileInfo.P09O getP09O(Byte[] byLine )
                                {
                                    try
                                    {
                                        FileInfo.P09O P09O = new FileInfo.P09O();

                                        int len = Marshal.SizeOf(P09O);
                                        IntPtr ptr = Marshal.AllocHGlobal(len);
                                        Marshal.Copy(byLine, 0, ptr, len);
                                        P09O = (FileInfo.P09O)Marshal.PtrToStructure(ptr, typeof(FileInfo.P09O));
                                        Marshal.FreeHGlobal(ptr); 
                                        return P09O;
                                    }
                                    catch (Exception ex)
                                    {
                                        throw ex;
                                    }
                                }

                            }
                        }

                        