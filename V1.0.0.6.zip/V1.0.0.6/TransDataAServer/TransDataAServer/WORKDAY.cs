using System;
                                        using System.Collections.Generic;
                                        using System.Linq;
                                        using System.Text;
                                        using System.Runtime.InteropServices;
                                        namespace TransDataAServer
                                        {
                                            public class WORKDAY
                                            {
                                                public static string getSql(FileInfo.WORKDAY raw)
                                                {
                                                    try
                                                    {
                                                        if (Function.getString(raw.DOMESTICFLAG).Trim() == "Y")
                                                        {
                                                            string sql = string.Format(@" INSERT INTO   WORKDAY(DATE,DOMESTICFLAG,FOREIGNFLAG,WEEK,UPD_DATE)VALUES
('{0}','{1}','{2}','{3}',convert(char(8),getdate(),112))"
    , Function.getString(raw.DATE).Trim()
    , Function.getString(raw.DOMESTICFLAG).Trim()
    , Function.getString(raw.FOREIGNFLAG).Trim()
    , Function.getString(raw.WEEK).Trim()
      );
                                                            return sql;
                                                        }
                                                        else
                                                            return "";
                                }
                                catch (Exception ex)
                                {
                                    throw ex;
                                }
                            }
                            public static FileInfo.WORKDAY getWORKDAY(Byte[] byLine )
                                {
                                    try
                                    {
                                        FileInfo.WORKDAY WORKDAY = new FileInfo.WORKDAY();

                                        int len = Marshal.SizeOf(WORKDAY);
                                        IntPtr ptr = Marshal.AllocHGlobal(len);
                                        Marshal.Copy(byLine, 0, ptr, len);
                                        WORKDAY = (FileInfo.WORKDAY)Marshal.PtrToStructure(ptr, typeof(FileInfo.WORKDAY));
                                        Marshal.FreeHGlobal(ptr); 
                                        return WORKDAY;
                                    }
                                    catch (Exception ex)
                                    {
                                        throw ex;
                                    }
                                }

                            }
                        }

                        