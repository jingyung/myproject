﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TransDataAServer
{
    public class Function
    {

        /// <summary>
        /// 從ProductID、ProductKind 取得複式類別 (ProductKind=1單式期貨、2單式選擇、3複式選擇、4複式期貨)
        /// </summary>
        /// <param name="ProductKind"></param>
        /// <param name="ProductId"></param>
        /// <returns></returns>
        public static string getMultipleKind(string ProductKind, string ProductId)
        {
            string ReturnValue = "";
            int length = ProductId.Trim().Length;
            switch (ProductKind)
            {
                case "3": //複式選擇權

                    if (ProductId.Contains("/"))
                    {
                        switch (length)
                        {

                            case 16:
                                ReturnValue = "1";//價格價差
                                break;
                            case 13:
                                ReturnValue = "2";//時間價差
                                break;
                        }
                    }
                    else if (ProductId.Contains(":"))
                    {
                        switch (length)
                        {

                            case 13:
                                ReturnValue = "3";//跨
                                break;
                            case 18:
                                ReturnValue = "4";//勒
                                break;
                        }
                    }
                    else if (ProductId.Contains("-"))
                    {
                        ReturnValue = "5";
                    }
                    else
                    {
                        ReturnValue = "";
                    }

                    break;
                case "4"://複式選擇權貨
                    ReturnValue = "0";
                    break;

            }
            return ReturnValue;

        }

        /// <summary>
        /// 取得價格
        /// </summary>
        /// <param name="h">整數長度</param>
        /// <param name="t">小數長度</param>
        /// <param name="price"></param>
        /// <returns></returns>
        public static decimal getPrice(int h, int t, string OrderPrice)
        {
            if (OrderPrice == "")
                OrderPrice = OrderPrice.PadLeft(h + t, '0');
            if (t == 0)
                return decimal.Parse(OrderPrice.Substring(0, h));
            else
                return decimal.Parse(OrderPrice.Substring(0, h) + "." + OrderPrice.Substring(h, t).ToString());
        }
        /// <summary>
        /// 取得價格
        /// </summary>
        /// <param name="h">整數長度</param>
        /// <param name="t">小數長度</param>
        /// <param name="price"></param>
        /// <returns></returns>
        public static decimal getSignPrice(int h, int t, string OrderPrice)
        {
            int sign = 1;
            if (OrderPrice == "")
                OrderPrice = OrderPrice.PadLeft(h + t+1, '0');
            if (OrderPrice.Substring(0,1) == "-")
                sign = -1;

            if (t == 0)
                return sign*decimal.Parse(OrderPrice.Substring(1, h));
            else
                return sign*decimal.Parse(OrderPrice.Substring(1, h) + "." + OrderPrice.Substring(1+h, t).ToString());
        }
        /// <summary>
        /// 取得價格
        /// </summary>
        /// <param name="h">整數長度</param>
        /// <param name="t">小數長度</param>
        /// <param name="price"></param>
        /// <returns></returns>
        public static decimal getPrice(int h, int t, string sign, string OrderPrice)
        {

            try
            {
                if (sign == "-")
                    return -1 * decimal.Parse(OrderPrice.Substring(0, h) + "." + OrderPrice.Substring(h, t).ToString());
                else
                    return decimal.Parse(OrderPrice.Substring(0, h) + "." + OrderPrice.Substring(h, t).ToString());
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        /// <summary>
        /// set price
        /// </summary>
        /// <param name="h">整數長度</param>
        /// <param name="t">小數長度</param>
        /// <param name="OrderPrice"></param>
        /// <returns></returns>
        public static string setPrice(int h, int t, decimal OrderPrice)
        {
            if (OrderPrice < 0)
            {
                OrderPrice = OrderPrice * (-1);
            }


            string[] price = OrderPrice.ToString().Split('.');
            if (price.Length > 1)
            {
                return price[0].PadLeft(h, '0') + price[1].PadRight(t, '0');
            }
            else
            {
                return price[0].PadLeft(h, '0') + "0".PadRight(t, '0');
            }

        }


        /// <summary>
        /// 轉換字串
        /// </summary>
        /// <param name="data">資料</param>
        /// <returns></returns>
        public static string getString(Byte[] data)
        {
            return Encoding.Default.GetString(data).TrimEnd();
        }
    }
}
