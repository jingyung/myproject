using System;
                                        using System.Collections.Generic;
                                        using System.Linq;
                                        using System.Text;
                                        using System.Runtime.InteropServices;
                                        namespace TransDataAServer
                                        {
                                            public class CASHLOG
                                            {
                                                public static string getSql(FileInfo.CASHLOG raw)
                                                {
                                                    try
                                                    {
                                                        string sql = string.Format(@" INSERT INTO   CASHLOG(TRDDT,FIRM,IBNO,ACTNO,CUSGROUP,TRADEID,CDTYPE,CURRENCY,ORIGNAMT,NTAMT,NETWORKID,BANK,BANKACTNO,TOBANK,TOBANKACTNO,TOBANKNAME,SLIPNO,SOURCECODE,FLOPPYFLAG,UPD_DATE)VALUES
('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}','{12}','{13}','{14}','{15}','{16}','{17}','{18}',convert(char(8),getdate(),112))"
, Function.getString(raw.TRDDT).Trim()
,Function.getString(raw.FIRM).Trim()
,Function.getString(raw.IBNO).Trim()
,Function.getString(raw.ACTNO).Trim()
,Function.getString(raw.CUSGROUP).Trim()
,Function.getString(raw.TRADEID).Trim()
,Function.getString(raw.CDTYPE).Trim()
,Function.getString(raw.CURRENCY).Trim()
, Function.getSignPrice(11,2,Function.getString(raw.ORIGNAMT))
,Function.getSignPrice(11,2,Function.getString(raw.NTAMT))
,Function.getString(raw.NETWORKID).Trim()
,Function.getString(raw.BANK).Trim()
,Function.getString(raw.BANKACTNO).Trim()
,Function.getString(raw.TOBANK).Trim()
,Function.getString(raw.TOBANKACTNO).Trim()
,Function.getString(raw.TOBANKNAME).Trim()
,Function.getString(raw.SLIPNO).Trim()
,Function.getString(raw.SOURCECODE).Trim()
, Function.getString(raw.FLOPPYFLAG).Trim()
  );
                                    return sql;
                                }
                                catch (Exception ex)
                                {
                                    throw ex;
                                }
                            }
                            public static FileInfo.CASHLOG getCASHLOG(Byte[] byLine )
                                {
                                    try
                                    {
                                        FileInfo.CASHLOG CASHLOG = new FileInfo.CASHLOG();

                                        int len = Marshal.SizeOf(CASHLOG);
                                        IntPtr ptr = Marshal.AllocHGlobal(len);
                                        Marshal.Copy(byLine, 0, ptr, len);
                                        CASHLOG = (FileInfo.CASHLOG)Marshal.PtrToStructure(ptr, typeof(FileInfo.CASHLOG));
                                        Marshal.FreeHGlobal(ptr); 
                                        return CASHLOG;
                                    }
                                    catch (Exception ex)
                                    {
                                        throw ex;
                                    }
                                }

                            }
                        }

                        